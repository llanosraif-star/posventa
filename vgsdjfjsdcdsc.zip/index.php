<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
if (isset($_SESSION['user_rol']) && strtolower($_SESSION['user_rol']) === 'cocinero') {
    header("Location: kds.php");
    exit;
}
?>
<!doctype html>
<html lang="es">
  <!--begin::Head-->
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Mi Restaurante | Dashboard</title>

    <!--begin::Accessibility Meta Tags-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="theme-color" content="#1a2538">
    <meta name="color-scheme" content="light dark" />
    <meta name="theme-color" content="#007bff" media="(prefers-color-scheme: light)" />
    <meta name="theme-color" content="#1a1a1a" media="(prefers-color-scheme: dark)" />
    <!--end::Accessibility Meta Tags-->

    <!--begin::PWA Tags-->
    <link rel="manifest" href="./manifest.json" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    <meta name="apple-mobile-web-app-title" content="Mi Restaurante" />
    <link rel="apple-touch-icon" href="./assets/img/AdminLTELogo.png" />
    <!--end::PWA Tags-->

    <!--begin::Primary Meta Tags-->
    <meta name="title" content="AdminLTE v4 | Dashboard" />
    <meta name="author" content="ColorlibHQ" />
    <meta
      name="description"
      content="AdminLTE is a Free Bootstrap 5 Admin Dashboard, 30 example pages using Vanilla JS. Fully accessible with WCAG 2.1 AA compliance."
    />
    <meta
      name="keywords"
      content="bootstrap 5, bootstrap, bootstrap 5 admin dashboard, bootstrap 5 dashboard, bootstrap 5 charts, bootstrap 5 calendar, bootstrap 5 datepicker, bootstrap 5 tables, bootstrap 5 datatable, vanilla js datatable, colorlibhq, colorlibhq dashboard, colorlibhq admin dashboard, accessible admin panel, WCAG compliant"
    />
    <!--end::Primary Meta Tags-->

    <!--begin::Accessibility Features-->
    <!-- Skip links will be dynamically added by accessibility.js -->
    <meta name="supported-color-schemes" content="light dark" />
    <link rel="preload" href="./css/adminlte.css" as="style" />
    <!--end::Accessibility Features-->

    <!--begin::Fonts-->
    <link href="./assets/vendor/css/dm-sans.css" rel="stylesheet">
    <!--end::Fonts-->

    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <link rel="stylesheet" href="./assets/vendor/css/overlayscrollbars.min.css" />
    <!--end::Third Party Plugin(OverlayScrollbars)-->

    <!--begin::Third Party Plugin(Bootstrap Icons)-->
    <link rel="stylesheet" href="./assets/vendor/css/bootstrap-icons.min.css" />
    <!--end::Third Party Plugin(Bootstrap Icons)-->

    <!--begin::Required Plugin(AdminLTE)-->
    <link rel="stylesheet" href="./css/adminlte.css" />
    <!--end::Required Plugin(AdminLTE)-->

    <!-- Tabulator (AdminLTE Data Tables) -->
    <link rel="stylesheet" href="./assets/vendor/css/tabulator_bootstrap5.min.css" />

    <!-- SweetAlert2 -->
    <link rel="stylesheet" href="./assets/vendor/css/sweetalert2.min.css" />

    <!-- Custom Font Override -->
    <style>
      body {
        font-family: 'DM Sans', sans-serif !important;
      }
    </style>
  </head>
  <!--end::Head-->
  <!--begin::Body-->
  <body class="layout-fixed sidebar-expand-lg bg-body-tertiary fixed-header">
    <!--begin::App Wrapper-->
    <div class="app-wrapper">
      <!--begin::Header-->
      <nav class="app-header navbar navbar-expand bg-body">
        <!--begin::Container-->
        <div class="container-fluid">
          <!--begin::Start Navbar Links-->
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" data-lte-toggle="sidebar" href="#" role="button">
                <i class="bi bi-list"></i>
              </a>
            </li>
          </ul>
          <!--end::Start Navbar Links-->

          <!--begin::Center Navbar Links-->
          <ul class="navbar-nav mx-auto">
            <li class="nav-item">
              <a class="nav-link ajax-link d-flex align-items-center fw-bold" href="#kds/visor" style="color: #f472b6;">
                <i class="bi bi-display" style="font-size: 1.4rem; margin-right: 8px;"></i>
                KDS
              </a>
            </li>
          </ul>
          <!--end::Center Navbar Links-->

          <!--begin::End Navbar Links-->
          <ul class="navbar-nav ms-auto">
            <!--begin::Navbar Search-->
            <li class="nav-item">
              <a class="nav-link" data-widget="navbar-search" href="#" role="button">
                <i class="bi bi-search"></i>
              </a>
            </li>
            <!--end::Navbar Search-->

            

            <!--begin::Fullscreen Toggle-->
            <li class="nav-item">
              <a class="nav-link" href="#" data-lte-toggle="fullscreen">
                <i data-lte-icon="maximize" class="bi bi-arrows-fullscreen"></i>
                <i data-lte-icon="minimize" class="bi bi-fullscreen-exit d-none"></i>
              </a>
            </li>
            <!--end::Fullscreen Toggle-->

            <!--begin::Color Mode Toggle (#6010)-->
            <li class="nav-item dropdown">
              <a
                class="nav-link"
                href="#"
                id="bd-theme"
                aria-label="Toggle color scheme"
                data-bs-toggle="dropdown"
                aria-expanded="false"
              >
                <i class="bi bi-sun-fill" data-lte-theme-icon="light"></i>
                <i class="bi bi-moon-fill d-none" data-lte-theme-icon="dark"></i>
                <i class="bi bi-circle-half d-none" data-lte-theme-icon="auto"></i>
              </a>
              <ul
                class="dropdown-menu dropdown-menu-end"
                aria-labelledby="bd-theme"
                style="--bs-dropdown-min-width: 8rem"
              >
                <li>
                  <button
                    type="button"
                    class="dropdown-item d-flex align-items-center"
                    data-bs-theme-value="light"
                    aria-pressed="false"
                  >
                    <i class="bi bi-sun-fill me-2"></i>
                    Light
                    <i class="bi bi-check-lg ms-auto d-none"></i>
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    class="dropdown-item d-flex align-items-center"
                    data-bs-theme-value="dark"
                    aria-pressed="false"
                  >
                    <i class="bi bi-moon-fill me-2"></i>
                    Dark
                    <i class="bi bi-check-lg ms-auto d-none"></i>
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    class="dropdown-item d-flex align-items-center active"
                    data-bs-theme-value="auto"
                    aria-pressed="true"
                  >
                    <i class="bi bi-circle-half me-2"></i>
                    Auto
                    <i class="bi bi-check-lg ms-auto d-none"></i>
                  </button>
                </li>
              </ul>
            </li>
            <!--end::Color Mode Toggle-->

            <!--begin::User Menu Dropdown-->
            <li class="nav-item dropdown user-menu">
              <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                <img
                  src="./assets/img/avatar5.png"
                  class="user-image rounded-circle shadow"
                  alt="User Image"
                />
                <span class="d-none d-md-inline"><?= htmlspecialchars($_SESSION['user_nombre'] ?? 'Usuario') ?> <?= htmlspecialchars($_SESSION['user_apellido'] ?? '') ?></span>
              </a>
              <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-end">
                <!--begin::User Image-->
                <li class="user-header text-bg-primary">
                  <img
                    src="./assets/img/avatar5.png"
                    class="rounded-circle shadow"
                    alt="User Image"
                  />
                  <p>
                    <?= htmlspecialchars($_SESSION['user_nombre'] ?? 'Usuario') ?> <?= htmlspecialchars($_SESSION['user_apellido'] ?? '') ?>
                    <small><?= htmlspecialchars($_SESSION['user_rol'] ?? 'Administrador') ?></small>
                  </p>
                </li>
                <!--end::User Image-->
                <!--begin::Menu Footer-->
                <li class="user-footer">
                  <a href="#" class="btn btn-outline-secondary">Perfil</a>
                  <a href="logout.php" class="btn btn-outline-danger float-end">Cerrar sesión</a>
                </li>
                <!--end::Menu Footer-->
              </ul>
            </li>
            <!--end::User Menu Dropdown-->
          </ul>
          <!--end::End Navbar Links-->
        </div>
        <!--end::Container-->
      </nav>
      <!--end::Header-->
      <!--begin::Sidebar-->
      <aside class="app-sidebar shadow" data-bs-theme="dark" style="background-color: rgb(15, 39, 68) !important;">
        <!--begin::Sidebar Brand-->
        <div class="sidebar-brand">
          <!--begin::Brand Link-->
          <a href="./index.php" class="brand-link">
            <!--begin::Brand Image-->
            <div class="brand-image opacity-75 shadow d-flex align-items-center justify-content-center" style="width: 33px; height: 33px; background-color: #f8f9fa; border-radius: 50%;">
                <i data-lucide="building-2" style="width: 20px; height: 20px; color: #343a40;"></i>
            </div>
            <!--end::Brand Image-->
            <!--begin::Brand Text-->
            <span class="brand-text fw-light">Mi Restaurante</span>
            <!--end::Brand Text-->
          </a>
          <!--end::Brand Link-->
        </div>
        <!--end::Sidebar Brand-->
        <!--begin::Sidebar Wrapper-->
        <div class="sidebar-wrapper">
          <nav class="mt-2">

            <!--begin::Sidebar Menu-->
            <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="navigation" data-accordion="false" id="navigation">
              <li class="nav-item">
                <a href="#dashboard" class="nav-link ajax-link active">
                  <i class="nav-icon bi bi-speedometer"></i>
                  <p>Dashboard</p>
                </a>
              </li>
              
              <li class="nav-header">RESTAURANTE</li>
              <li class="nav-item">
                <a href="#pos" class="nav-link ajax-link">
                  <i class="nav-icon bi bi-display"></i>
                  <p>Punto de Venta (POS)</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="#caja" class="nav-link ajax-link">
                  <i class="nav-icon bi bi-cash-stack"></i>
                  <p>Caja</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="#ventas/ventas" class="nav-link ajax-link">
                  <i class="nav-icon bi bi-clock-history"></i>
                  <p>Ventas / Historial</p>
                </a>
              </li>
              
              <!-- Emitir (Treeview) -->
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="nav-icon bi bi-file-earmark-plus"></i>
                  <p>
                    Emitir
                    <i class="nav-arrow bi bi-chevron-right"></i>
                  </p>
                </a>
                <ul class="nav nav-treeview">
                  <li class="nav-item">
                    <a href="#facturacion/emitir/factura" class="nav-link ajax-link">
                      <i class="nav-icon bi bi-circle"></i>
                      <p>Factura</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#facturacion/emitir/boleta" class="nav-link ajax-link">
                      <i class="nav-icon bi bi-circle"></i>
                      <p>Boleta</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#facturacion/emitir/nota_credito" class="nav-link ajax-link">
                      <i class="nav-icon bi bi-circle"></i>
                      <p>Nota de Crédito</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#facturacion/emitir/nota_debito" class="nav-link ajax-link">
                      <i class="nav-icon bi bi-circle"></i>
                      <p>Nota de Débito</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#facturacion/emitir/guia" class="nav-link ajax-link">
                      <i class="nav-icon bi bi-circle"></i>
                      <p>Guía de Remisión</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#facturacion/emitir/resumen" class="nav-link ajax-link">
                      <i class="nav-icon bi bi-circle"></i>
                      <p>Resumen Diario</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#facturacion/emitir/anulaciones" class="nav-link ajax-link">
                      <i class="nav-icon bi bi-circle"></i>
                      <p>Anulaciones</p>
                    </a>
                  </li>
                </ul>
              </li>
              <li class="nav-item">
                <a href="#clientes" class="nav-link ajax-link">
                  <i class="nav-icon bi bi-people"></i>
                  <p>Clientes</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="#kds/visor" class="nav-link ajax-link">
                  <i class="nav-icon bi bi-display" style="color: #f472b6;"></i>
                  <p>Visor KDS</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="#carta" class="nav-link ajax-link">
                  <i class="nav-icon bi bi-book"></i>
                  <p>Carta y Menú</p>
                </a>
              </li>

                            <li class="nav-header">ADMINISTRACIÓN</li>
              
              <!-- Inventario -->
              <li class="nav-item">
                <a href="#inventario" class="nav-link ajax-link">
                  <i class="nav-icon bi bi-box-seam"></i>
                  <p>Inventario</p>
                </a>
              </li>
              <!-- Facturación (Treeview) -->
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="nav-icon bi bi-receipt"></i>
                  <p>
                    Facturación
                    <i class="nav-arrow bi bi-chevron-right"></i>
                  </p>
                </a>
                <ul class="nav nav-treeview">
                  <li class="nav-item">
                    <a href="#facturacion/dashboard" class="nav-link ajax-link">
                      <i class="nav-icon bi bi-circle"></i>
                      <p>Dashboard</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#facturacion/lista" class="nav-link ajax-link">
                      <i class="nav-icon bi bi-circle"></i>
                      <p>Doc. Emitidos</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#facturacion/config" class="nav-link ajax-link">
                      <i class="nav-icon bi bi-circle"></i>
                      <p>Configuración API</p>
                    </a>
                  </li>
                </ul>
              </li>

              <!-- Configuración (Treeview) -->
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="nav-icon bi bi-gear"></i>
                  <p>
                    Configuración
                    <i class="nav-arrow bi bi-chevron-right"></i>
                  </p>
                </a>
                <ul class="nav nav-treeview">
                  <li class="nav-item">
                    <a href="#configuracion/empresa" class="nav-link ajax-link">
                      <i class="nav-icon bi bi-circle"></i>
                      <p>Empresa</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#configuracion/usuarios" class="nav-link ajax-link">
                      <i class="nav-icon bi bi-circle"></i>
                      <p>Personal</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#configuracion/kds" class="nav-link ajax-link">
                      <i class="nav-icon bi bi-circle"></i>
                      <p>Pantallas KDS</p>
                    </a>
                  </li>

                  <li class="nav-item">
                    <a href="#mesas" class="nav-link ajax-link">
                      <i class="nav-icon bi bi-circle"></i>
                      <p>Mesas</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#configuracion/impresoras" class="nav-link ajax-link">
                      <i class="nav-icon bi bi-circle"></i>
                      <p>Impresoras</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#mesas/areas_produccion" class="nav-link ajax-link">
                      <i class="nav-icon bi bi-circle"></i>
                      <p>Áreas de Prod.</p>
                    </a>
                  </li>
                </ul>
              </li>
            </ul>
            <!--end::Sidebar Menu-->
          </nav>
        </div>
        <!--end::Sidebar Wrapper-->
      </aside>
      <!--end::Sidebar-->
      <!--begin::App Main-->
      <main class="app-main">
        <!-- El header estático fue removido para que cada módulo (SPA) tenga su propio título -->
        <!--begin::App Content-->
        <div class="app-content">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <div class="col-12" id="main-content">
                <!-- El contenido SPA se inyectará aquí -->
              </div>
            </div>
            <!-- /.row (main row) -->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content-->
      </main>
      <!--end::App Main-->

    </div>
    <!--end::App Wrapper-->
    <!--begin::Script-->
    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <script src="./assets/vendor/js/overlayscrollbars.browser.es6.min.js"></script>
    <!--end::Third Party Plugin(OverlayScrollbars)--><!--begin::Required Plugin(popperjs for Bootstrap 5)-->
    <script src="./assets/vendor/js/popper.min.js"></script>
    <!--end::Required Plugin(popperjs for Bootstrap 5)--><!--begin::Required Plugin(Bootstrap 5)-->
    <script src="./assets/vendor/js/bootstrap.min.js"></script>
    <!--end::Required Plugin(Bootstrap 5)--><!--begin::Required Plugin(AdminLTE)-->
    <script src="./js/adminlte.js"></script>
    <!--end::Required Plugin(AdminLTE)--><!--begin::OverlayScrollbars Configure-->
    <script>
      const SELECTOR_SIDEBAR_WRAPPER = '.sidebar-wrapper';
      const Default = {
        scrollbarTheme: 'os-theme-light',
        scrollbarAutoHide: 'leave',
        scrollbarClickScroll: true,
      };
      document.addEventListener('DOMContentLoaded', function () {
        const sidebarWrapper = document.querySelector(SELECTOR_SIDEBAR_WRAPPER);

        // Disable OverlayScrollbars on mobile devices to prevent touch interference
        const isMobile = window.innerWidth <= 992;

        if (
          sidebarWrapper &&
          OverlayScrollbarsGlobal?.OverlayScrollbars !== undefined &&
          !isMobile
        ) {
          OverlayScrollbarsGlobal.OverlayScrollbars(sidebarWrapper, {
            scrollbars: {
              theme: Default.scrollbarTheme,
              autoHide: Default.scrollbarAutoHide,
              clickScroll: Default.scrollbarClickScroll,
            },
          });
        }
      });
    </script>
    <!--end::OverlayScrollbars Configure--><!--begin::Color Mode Toggle (#6010)-->
    <script>
      (() => {
        'use strict';

        const STORAGE_KEY = 'lte-theme';

        const getStoredTheme = () => localStorage.getItem(STORAGE_KEY);
        const setStoredTheme = (theme) => localStorage.setItem(STORAGE_KEY, theme);

        const prefersDark = () => globalThis.matchMedia('(prefers-color-scheme: dark)').matches;

        const getPreferredTheme = () => {
          const stored = getStoredTheme();
          if (stored) return stored;
          return prefersDark() ? 'dark' : 'light';
        };

        const setTheme = (theme) => {
          const resolved = theme === 'auto' ? (prefersDark() ? 'dark' : 'light') : theme;
          document.documentElement.setAttribute('data-bs-theme', resolved);
        };

        setTheme(getPreferredTheme());

        const showActiveTheme = (theme) => {
          // Highlight the active dropdown option
          document.querySelectorAll('[data-bs-theme-value]').forEach((el) => {
            el.classList.remove('active');
            el.setAttribute('aria-pressed', 'false');
            const check = el.querySelector('.bi-check-lg');
            if (check) check.classList.add('d-none');
          });
          const active = document.querySelector(`[data-bs-theme-value="${theme}"]`);
          if (active) {
            active.classList.add('active');
            active.setAttribute('aria-pressed', 'true');
            const check = active.querySelector('.bi-check-lg');
            if (check) check.classList.remove('d-none');
          }
          // Sync the topbar trigger icon
          document.querySelectorAll('[data-lte-theme-icon]').forEach((icon) => {
            icon.classList.toggle('d-none', icon.dataset.lteThemeIcon !== theme);
          });
        };

        globalThis.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
          const stored = getStoredTheme();
          if (!stored || stored === 'auto') setTheme(getPreferredTheme());
        });

        document.addEventListener('DOMContentLoaded', () => {
          showActiveTheme(getPreferredTheme());
          document.querySelectorAll('[data-bs-theme-value]').forEach((toggle) => {
            toggle.addEventListener('click', () => {
              const theme = toggle.getAttribute('data-bs-theme-value');
              setStoredTheme(theme);
              setTheme(theme);
              showActiveTheme(theme);
            });
          });
        });
      })();
    </script>
    <!--end::Color Mode Toggle-->

    <!-- jQuery (Requerido para DataTables) -->
    <script src="./assets/vendor/js/jquery-3.7.1.min.js"></script>

    <!-- DataTables -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

    <!-- Tabulator (AdminLTE Data Tables) -->
    <script src="./assets/vendor/js/tabulator.min.js"></script>

    <!-- SweetAlert2 -->
    <script src="./assets/vendor/js/sweetalert2.all.min.js"></script>

    <script>
      // Test SweetAlert2
      document.addEventListener('DOMContentLoaded', () => {
        const testBtn = document.getElementById('test-sweetalert');
        if (testBtn) {
          testBtn.addEventListener('click', () => {
            Swal.fire({
              title: '¡Plantilla Lista!',
              text: 'SweetAlert2 y DataTables están integrados. Arquitectura base preparada.',
              icon: 'success'
            });
          });
        }
      });
    </script>
    
    <!-- Lógica de navegación tipo SPA (Sin recarga) -->
    <script src="./assets/js/app.js"></script>

    <!-- Librerías requeridas por los módulos heredados -->
    <script src="./assets/vendor/js/lucide.min.js"></script>
    <script src="./assets/vendor/js/chart.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <script>
      // Inicializar Lucide Icons después de que el SPA inyecte el HTML
      $(document).ajaxComplete(function() {
          if (typeof lucide !== 'undefined') {
              lucide.createIcons();
          }
      });
    </script>

    <!-- Módulos JS de RestaurantePOS migrados -->
    <script src="assets/js/main.js?v=<?= time() ?>"></script>
    <script src="features/pos/pos.js?v=<?= time() ?>"></script>
    <script src="features/caja/caja.js?v=<?= time() ?>"></script>
    <script src="features/clientes/clientes.js?v=<?= time() ?>"></script>
    <!-- Módulo Inventario -->
    <script src="features/inventario/inventario.js?v=<?= time() ?>"></script>

    <script src="features/carta/carta.js?v=<?= time() ?>"></script>
    <script src="features/carta/modal_categorias.js?v=<?= time() ?>"></script>
    <script src="features/carta/modal_modificadores.js?v=<?= time() ?>"></script>
    <script src="features/carta/modal_productos.js?v=<?= time() ?>"></script>
    <script src="features/carta/modal_subcategorias.js?v=<?= time() ?>"></script>
    <script src="features/configuracion/empresa.js?v=<?= time() ?>"></script>
    <script src="features/mesas/mesas.js?v=<?= time() ?>"></script>
    <script src="features/configuracion/usuarios.js?v=<?= time() ?>"></script>
    <script src="features/mesas/areas_produccion.js?v=<?= time() ?>"></script>
    <script src="features/configuracion/kds.js?v=<?= time() ?>"></script>
    <script src="features/kds/visor.js?v=<?= time() ?>"></script>
    
    <!-- Módulos de Facturación API -->
    <script src="features/facturacion/js/store.js?v=<?= time() ?>"></script>
    <script src="features/facturacion/js/utils.js?v=<?= time() ?>"></script>
    <script src="features/facturacion/js/api.js?v=<?= time() ?>"></script>
    <script src="features/facturacion/js/responseModal.js?v=<?= time() ?>"></script>
    <script src="features/facturacion/js/main.js?v=<?= time() ?>"></script>
    
    <!-- PWA Service Worker Registration -->
    <script>
      if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
          navigator.serviceWorker.register('./sw.js')
            .then(registration => console.log('ServiceWorker registration successful'))
            .catch(err => console.log('ServiceWorker registration failed: ', err));
        });
      }
    </script>
    <!--end::Script-->
  </body>
  <!--end::Body-->
</html>
