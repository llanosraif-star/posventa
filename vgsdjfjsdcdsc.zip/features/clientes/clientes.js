/**
 * clientes.js - Módulo de Clientes
 * CRUD: crear, editar, listar clientes (Conectado a la base de datos)
 */

let clientesPaginaActual = 1;
let clientesFiltrados = [];

async function cargarClientes() {
    try {
        let res = await fetch('features/clientes/controller_clientes.php');
        let data = await res.json();
        
        if (data.status === 'ok') {
            window.datosApp = window.datosApp || {};
            window.datosApp.clientes = data.data || [];
            clientesFiltrados = data.data || [];
            clientesPaginaActual = 1;
            renderTablaClientesPaginada();
        } else {
            console.error('Error del servidor:', data.message);
            if(typeof Swal !== 'undefined') Swal.fire('Error', data.message, 'error');
        }
    } catch(e) { 
        console.error('Error cargando clientes:', e); 
        if(typeof Swal !== 'undefined') Swal.fire('Error', 'Error cargando clientes: ' + e.message, 'error');
    }
}

function buscarCliente() {
    let q = document.getElementById('inputBuscarCliente').value.toLowerCase();
    if (!q) {
        clientesFiltrados = window.datosApp.clientes || [];
    } else {
        clientesFiltrados = (window.datosApp.clientes || []).filter(c => 
            (c.nombre && c.nombre.toLowerCase().includes(q)) || 
            (c.documento && c.documento.toLowerCase().includes(q)) ||
            (c.direccion && c.direccion.toLowerCase().includes(q))
        );
    }
    clientesPaginaActual = 1;
    renderTablaClientesPaginada();
}

function cambiarPaginaClientes(accion) {
    let select = document.getElementById('clientesPerPage');
    let perPage = select ? parseInt(select.value) : 10;
    let totalPaginas = Math.ceil(clientesFiltrados.length / perPage);
    
    if (accion === 'prev') {
        if (clientesPaginaActual > 1) clientesPaginaActual--;
    } else if (accion === 'next') {
        if (clientesPaginaActual < totalPaginas) clientesPaginaActual++;
    } else if (typeof accion === 'number') {
        clientesPaginaActual = accion;
    }
    renderTablaClientesPaginada();
}

function renderTablaClientesPaginada() {
    let tbody = document.getElementById('tbodyClientes');
    let info = document.getElementById('clientesInfoPaginacion');
    let pagesContainer = document.getElementById('clientesPaginasContainer');
    let select = document.getElementById('clientesPerPage');
    
    if (!tbody) return;
    
    let perPage = select ? parseInt(select.value) : 10;
    let total = clientesFiltrados.length;
    let totalPaginas = Math.ceil(total / perPage);
    if (totalPaginas === 0) totalPaginas = 1;
    
    if (clientesPaginaActual > totalPaginas) clientesPaginaActual = totalPaginas;
    
    let inicio = (clientesPaginaActual - 1) * perPage;
    let fin = Math.min(inicio + perPage, total);
    
    if (total === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted py-4">Sin clientes encontrados</td></tr>';
        if (info) info.innerText = 'Mostrando 0 a 0 de 0 entradas';
        if (pagesContainer) pagesContainer.innerHTML = '';
        return;
    }
    
    let mostrar = clientesFiltrados.slice(inicio, fin);
    let html = '';
    
    mostrar.forEach((c, index) => {
        let nro = inicio + index + 1;
        let tipoDoc = (c.tipo_documento || 'RUC').toUpperCase();
        let badgeStyle = 'background-color: #f1f5f9; color: #475569;'; // default gray
        if (tipoDoc === 'DNI') {
            badgeStyle = 'background-color: #ffedd5; color: #9a3412;'; // pale orange
        } else if (tipoDoc === 'RUC') {
            badgeStyle = 'background-color: #eef2ff; color: #4338ca;'; // pale indigo/blue
        }
        
        html += `<tr>
            <td class="pl-4 font-weight-bold">${nro}</td>
            <td>
                <span class="badge px-2 py-1" style="${badgeStyle} border-radius:6px; font-weight:600; letter-spacing:0.3px;">${tipoDoc}</span> 
                <span class="font-weight-bold ml-1">${c.documento || '-'}</span>
            </td>
            <td>
                <div class="font-weight-bold">${c.nombre}</div>
                ${c.nombre_comercial ? `<div class="text-muted small">${c.nombre_comercial}</div>` : ''}
            </td>
            <td>${c.direccion || '-'}</td>
            <td>${c.telefono || '-'}</td>
            <td class="text-center">
                <div class="d-flex justify-content-center" style="gap: 6px;">
                    <button class="btn border text-secondary shadow-sm" style="width: 28px; height: 28px; padding: 0; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; background: var(--bs-body-bg);" onclick="alertaEditarCliente(${c.id})" title="Editar">
                        <i data-lucide="pencil" style="width:14px;height:14px; stroke-width:2;"></i>
                    </button>
                    <button class="btn border text-secondary shadow-sm" style="width: 28px; height: 28px; padding: 0; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; background: var(--bs-body-bg);" onclick="alertaEliminarCliente(${c.id})" title="Eliminar">
                        <i data-lucide="trash-2" style="width:14px;height:14px; stroke-width:2;"></i>
                    </button>
                </div>
            </td>
        </tr>`;
    });
    
    tbody.innerHTML = html;
    if (info) info.innerText = `Mostrando ${inicio + 1} a ${fin} de ${total} entradas`;
    
    if (pagesContainer) {
        pagesContainer.className = 'd-flex align-items-center m-0 p-0 float-end';
        pagesContainer.style.listStyle = 'none';
        pagesContainer.style.gap = '6px';

        let btns = '';
        
        let prevDisabled = (clientesPaginaActual === 1) ? 'opacity:0.5; pointer-events:none;' : '';
        btns += `<li><button class="btn btn-sm bg-body-tertiary text-body border" style="border-radius:6px; font-weight:500; padding: 4px 10px; border-color: var(--bs-border-color) !important; ${prevDisabled}" onclick="cambiarPaginaClientes('prev')">Anterior</button></li>`;
        
        let startPage = Math.max(1, clientesPaginaActual - 2);
        let endPage = Math.min(totalPaginas, clientesPaginaActual + 2);
        
        for (let i = startPage; i <= endPage; i++) {
            let btnClass = (i === clientesPaginaActual) 
                ? 'bg-primary-subtle text-primary border-primary-subtle' 
                : 'bg-body-tertiary text-body border';
            btns += `<li><button class="btn btn-sm ${btnClass}" style="border-radius:6px; min-width:32px; font-weight:700; padding: 4px 10px; border-color: var(--bs-border-color); transition: all 0.2s;" onclick="cambiarPaginaClientes(${i})">${i}</button></li>`;
        }
        
        let nextDisabled = (clientesPaginaActual === totalPaginas) ? 'opacity:0.5; pointer-events:none;' : '';
        btns += `<li><button class="btn btn-sm bg-body-tertiary text-body border" style="border-radius:6px; font-weight:500; padding: 4px 10px; border-color: var(--bs-border-color) !important; ${nextDisabled}" onclick="cambiarPaginaClientes('next')">Siguiente</button></li>`;
        
        pagesContainer.innerHTML = btns;
    }
    
    if (typeof lucide !== 'undefined') lucide.createIcons();
}


// ==========================================
// API - Consulta RUC / DNI a través del Backend
// ==========================================
async function buscarDocumentoExterno(tipo, numero) {
    try {
        const res = await fetch(`features/clientes/controller_clientes.php?action=buscar_documento&tipo=${tipo}&numero=${numero}`);
        const json = await res.json();
        
        if (!res.ok || json.status !== 'ok') {
            throw new Error(json.message || 'No se encontró el documento.');
        }
        
        return json.data;
    } catch (err) {
        throw new Error(err.message || 'No se encontró el documento o la API falló.');
    }
}

async function ejecutarBusquedaDocumento() {
    const tipo = document.getElementById('swal-cliente-tipo-doc').value;
    const numInput = document.getElementById('swal-cliente-doc');
    const num = numInput.value.trim();
    
    // Función auxiliar para mostrar mensaje sin usar SweetAlert (para no cerrar el modal)
    const showMsg = (msg, isError = true) => {
        let msgSpan = document.getElementById('search-msg-span');
        if (!msgSpan) {
            msgSpan = document.createElement('div');
            msgSpan.id = 'search-msg-span';
            msgSpan.style.fontSize = '0.75rem';
            msgSpan.style.marginTop = '0.25rem';
            msgSpan.style.fontWeight = 'bold';
            const container = document.getElementById('swal-cliente-doc').parentNode.parentNode;
            container.appendChild(msgSpan);
        }
        msgSpan.style.color = isError ? '#e74a3b' : '#1cc88a';
        msgSpan.innerText = msg;
        setTimeout(() => { if(document.getElementById('search-msg-span')) document.getElementById('search-msg-span').innerText = ''; }, 4000);
    };

    if (!num) return showMsg('Ingrese un número de documento');
    if (tipo === 'DNI' && num.length !== 8) return showMsg('El DNI debe tener 8 dígitos');
    if (tipo === 'RUC' && num.length !== 11) return showMsg('El RUC debe tener 11 dígitos');

    // Cambiar icono a cargando y deshabilitar botón
    const btn = document.getElementById('btn-buscar-doc');
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<i data-lucide="loader-2" class="lucide-spin" style="width:16px;height:16px;color:#374151;"></i>';
        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    try {
        const d = await buscarDocumentoExterno(tipo, num);
        
        // Rellenar campos
        if (tipo === 'RUC') {
            document.getElementById('swal-cliente-nombre').value = d.nombre_o_razon_social || d.razon_social || '';
            document.getElementById('swal-cliente-dir').value = d.direccion_completa || d.direccion || '';
            document.getElementById('swal-cliente-dep').value = d.departamento || '';
            document.getElementById('swal-cliente-prov').value = d.provincia || '';
            document.getElementById('swal-cliente-dist').value = d.distrito || '';
            document.getElementById('swal-cliente-ubigeo').value = d.ubigeo_sunat || d.ubigeo || '';
        } else {
            // DNI
            let nombreDni = d.nombre_completo || '';
            if (!nombreDni && d.nombres) {
                nombreDni = `${d.nombres} ${d.apellido_paterno} ${d.apellido_materno}`.trim();
            }
            document.getElementById('swal-cliente-nombre').value = nombreDni;
            document.getElementById('swal-cliente-dir').value = d.direccion_completa || d.direccion || '';
            document.getElementById('swal-cliente-dep').value = d.departamento || '';
            document.getElementById('swal-cliente-prov').value = d.provincia || '';
            document.getElementById('swal-cliente-dist').value = d.distrito || '';
            document.getElementById('swal-cliente-ubigeo').value = d.ubigeo_reniec || d.ubigeo_sunat || d.ubigeo || '';
        }
        showMsg('Datos encontrados y rellenados', false);
    } catch (e) {
        showMsg(e.message);
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = '<i data-lucide="search" style="width:16px;height:16px;color:#374151;"></i>';
            if (typeof lucide !== 'undefined') lucide.createIcons();
        }
    }
}

function generarFormularioCliente(item = null) {
    let t = item || {};
    return `
        <div style="text-align: left; font-family: 'Inter', sans-serif;" class="p-1 overflow-hidden">
            <div class="row g-3">
                <!-- Fila 1: Documento -->
                <div class="col-md-7">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.75rem;">Documento <span class="text-danger">*</span></label>
                    <div class="input-group input-group-sm">
                        <select id="swal-cliente-tipo-doc" class="form-select border-secondary-subtle" style="flex: 0 0 130px; box-shadow: none;" onchange="limpiarCamposCliente()">
                            <option value="RUC" ${(t.tipo_documento === 'RUC') ? 'selected' : ''}>RUC</option>
                            <option value="DNI" ${(t.tipo_documento === 'DNI') ? 'selected' : ''}>DNI</option>
                            <option value="CE" ${(t.tipo_documento === 'CE') ? 'selected' : ''}>Carnet Ext.</option>
                            <option value="PASAPORTE" ${(t.tipo_documento === 'PASAPORTE') ? 'selected' : ''}>Pasaporte</option>
                        </select>
                        <input id="swal-cliente-doc" class="form-control border-secondary-subtle" value="${t.documento || ''}" placeholder="Número" style="box-shadow: none;">
                        <button id="btn-buscar-doc" class="btn btn-secondary border-secondary" type="button" onclick="ejecutarBusquedaDocumento()" title="Buscar Datos">
                            <i data-lucide="search" style="width:14px;height:14px;"></i>
                        </button>
                    </div>
                </div>

                <!-- Fila 2: Nombres -->
                <div class="col-12">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.75rem;">Razón Social / Nombres <span class="text-danger">*</span></label>
                    <input id="swal-cliente-nombre" class="form-control form-control-sm border-secondary-subtle" value="${t.nombre || ''}" placeholder="Nombre completo o empresa">
                </div>

                <!-- Fila 2: Contacto -->
                <div class="col-md-5">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.75rem;">Teléfono</label>
                    <div class="input-group input-group-sm">
                        <span class="input-group-text bg-light border-secondary-subtle"><i data-lucide="phone" style="width:13px;height:13px;"></i></span>
                        <input id="swal-cliente-tel" class="form-control border-secondary-subtle border-start-0" value="${t.telefono || ''}" placeholder="Celular o fijo">
                    </div>
                </div>
                <div class="col-md-7">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.75rem;">Email</label>
                    <div class="input-group input-group-sm">
                        <span class="input-group-text bg-light border-secondary-subtle"><i data-lucide="mail" style="width:13px;height:13px;"></i></span>
                        <input id="swal-cliente-email" class="form-control border-secondary-subtle border-start-0" value="${t.email || ''}" placeholder="correo@ejemplo.com">
                    </div>
                </div>

                <!-- Fila 3: Dirección -->
                <div class="col-md-12">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.75rem;">Dirección Exacta</label>
                    <div class="input-group input-group-sm">
                        <span class="input-group-text bg-light border-secondary-subtle"><i data-lucide="map-pin" style="width:13px;height:13px;"></i></span>
                        <input id="swal-cliente-dir" class="form-control border-secondary-subtle border-start-0" value="${t.direccion || ''}" placeholder="Av. Principal 123">
                    </div>
                </div>
                
                <!-- Fila 4: Ubicación geográfica -->
                <div class="col-md-3 col-6">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.7rem;">Departamento</label>
                    <input id="swal-cliente-dep" class="form-control form-control-sm text-muted border-secondary-subtle" value="${t.departamento || ''}" style="font-size: 0.8rem;">
                </div>
                <div class="col-md-3 col-6">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.7rem;">Provincia</label>
                    <input id="swal-cliente-prov" class="form-control form-control-sm text-muted border-secondary-subtle" value="${t.provincia || ''}" style="font-size: 0.8rem;">
                </div>
                <div class="col-md-3 col-6">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.7rem;">Distrito</label>
                    <input id="swal-cliente-dist" class="form-control form-control-sm text-muted border-secondary-subtle" value="${t.distrito || ''}" style="font-size: 0.8rem;">
                </div>
                <div class="col-md-3 col-6">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.7rem;">Ubigeo</label>
                    <input id="swal-cliente-ubigeo" class="form-control form-control-sm text-muted border-secondary-subtle" value="${t.ubigeo || ''}" style="font-size: 0.8rem;">
                </div>
            </div>
        </div>
    `;
}

function limpiarCamposCliente() {
    const ids = [
        'swal-cliente-doc', 'swal-cliente-nombre', 'swal-cliente-tel', 
        'swal-cliente-email', 'swal-cliente-dir', 'swal-cliente-dep', 
        'swal-cliente-prov', 'swal-cliente-dist', 'swal-cliente-ubigeo'
    ];
    ids.forEach(id => {
        let el = document.getElementById(id);
        if (el) el.value = '';
    });
}

function modalNuevoCliente() {
    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Crear Nuevo Cliente</h5><p style="margin: 0; font-size: 0.85rem; color: #6b7280; font-weight: normal;">Completa el formulario para registrar un nuevo cliente</p></div>',
        html: generarFormularioCliente(),
        width: 650,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-secondary px-4',
            actions: 'w-100 justify-content-center mt-3 pt-3 border-top gap-3',
            popup: 'rounded-lg p-4',
            title: 'w-100 m-0'
        },
        didOpen: () => {
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            confirmBtn.style.borderRadius = '8px';
            confirmBtn.style.fontWeight = '500';
            cancelBtn.style.borderRadius = '8px';
            if (typeof lucide !== 'undefined') lucide.createIcons();
        },
        preConfirm: () => {
            return {
                tipo_documento: document.getElementById('swal-cliente-tipo-doc').value,
                documento: document.getElementById('swal-cliente-doc').value,
                nombre: document.getElementById('swal-cliente-nombre').value,
                nombre_comercial: '', // Removido de la UI
                telefono: document.getElementById('swal-cliente-tel').value,
                email: document.getElementById('swal-cliente-email').value,
                direccion: document.getElementById('swal-cliente-dir').value,
                departamento: document.getElementById('swal-cliente-dep').value,
                provincia: document.getElementById('swal-cliente-prov').value,
                distrito: document.getElementById('swal-cliente-dist').value,
                ubigeo: document.getElementById('swal-cliente-ubigeo').value
            };
        }
    }).then(async (r) => {
        if (r.isConfirmed) {
            if(!r.value.nombre || !r.value.documento) {
                Swal.fire('Error', 'El nombre y documento son requeridos', 'error');
                return;
            }
            
            try {
                let res = await fetch('features/clientes/controller_clientes.php?action=crear', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(r.value)
                });
                let data = await res.json();
                if (data.status === 'ok') {
                    cargarClientes();
                    Swal.fire({
                        toast: true,
                        position: 'top-end',
                        icon: 'success',
                        title: 'Cliente registrado correctamente',
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true
                    });
                } else {
                    Swal.fire('Error', data.message, 'error');
                }
            } catch(e) { 
                Swal.fire('Error', 'Error al conectar con el servidor', 'error'); 
            }
        }
    });
}

function alertaEditarCliente(id) {
    let item = window.datosApp.clientes.find(x => x.id == id);
    if (!item) {
        Swal.fire('Error', 'Cliente no encontrado', 'error');
        return;
    }

    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Editar Cliente</h5><p style="margin: 0; font-size: 0.85rem; color: #6b7280; font-weight: normal;">Modifica la información del cliente</p></div>',
        html: generarFormularioCliente(item),
        width: 650,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-secondary px-4',
            actions: 'w-100 justify-content-center mt-3 pt-3 border-top gap-3',
            popup: 'rounded-lg p-4',
            title: 'w-100 m-0'
        },
        didOpen: () => {
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            confirmBtn.style.borderRadius = '8px';
            confirmBtn.style.fontWeight = '500';
            cancelBtn.style.borderRadius = '8px';
            if (typeof lucide !== 'undefined') lucide.createIcons();
        },
        preConfirm: () => {
            return {
                id: id,
                tipo_documento: document.getElementById('swal-cliente-tipo-doc').value,
                documento: document.getElementById('swal-cliente-doc').value,
                nombre: document.getElementById('swal-cliente-nombre').value,
                nombre_comercial: '', // Removido de la UI
                telefono: document.getElementById('swal-cliente-tel').value,
                email: document.getElementById('swal-cliente-email').value,
                direccion: document.getElementById('swal-cliente-dir').value,
                departamento: document.getElementById('swal-cliente-dep').value,
                provincia: document.getElementById('swal-cliente-prov').value,
                distrito: document.getElementById('swal-cliente-dist').value,
                ubigeo: document.getElementById('swal-cliente-ubigeo').value
            };
        }
    }).then(async (r) => {
        if (r.isConfirmed) {
            if(!r.value.nombre || !r.value.documento) {
                Swal.fire('Error', 'El nombre y documento son requeridos', 'error');
                return;
            }
            
            try {
                let res = await fetch('features/clientes/controller_clientes.php?action=editar', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(r.value)
                });
                let data = await res.json();
                if (data.status === 'ok') {
                    cargarClientes();
                    Swal.fire({
                        toast: true,
                        position: 'top-end',
                        icon: 'success',
                        title: 'Cliente actualizado correctamente',
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true
                    });
                } else {
                    Swal.fire('Error', data.message, 'error');
                }
            } catch(e) { 
                Swal.fire('Error', 'Error al conectar con el servidor', 'error'); 
            }
        }
    });
}

function alertaEliminarCliente(id) {
    Swal.fire({
        title: '¿Eliminar cliente?',
        text: 'Esta acción no se puede revertir',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#e74a3b',
        cancelButtonColor: '#858796',
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar'
    }).then(async (r) => {
        if (r.isConfirmed) {
            try {
                let res = await fetch('features/clientes/controller_clientes.php?action=eliminar', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: id })
                });
                let data = await res.json();
                if (data.status === 'ok') {
                    cargarClientes();
                    Swal.fire({
                        toast: true,
                        position: 'top-end',
                        icon: 'success',
                        title: 'Cliente eliminado correctamente',
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true
                    });
                } else {
                    Swal.fire('Error', data.message, 'error');
                }
            } catch(e) { 
                Swal.fire('Error', 'Error al conectar con el servidor', 'error'); 
            }
        }
    });
}

// Paginación manual eliminada. Todo es gestionado por DataTables ahora.

