<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/model_clientes.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    switch ($method) {
        case 'GET':
            if ($action === 'buscar_documento') {
                $numero = $_GET['numero'] ?? '';
                $tipo = $_GET['tipo'] ?? 'RUC';
                
                if (empty($numero)) {
                    echo json_encode(['status' => 'error', 'message' => 'Número de documento requerido']);
                    exit;
                }
                
                // 1. Buscar en BD local
                $clienteLocal = ModelClientes::getByDocumento($numero);
                
                if ($clienteLocal) {
                    echo json_encode(['status' => 'ok', 'origen' => 'BD Local', 'data' => [
                        'nombre_o_razon_social' => $clienteLocal['nombre'],
                        'razon_social' => $clienteLocal['nombre'],
                        'nombre_completo' => $clienteLocal['nombre'],
                        'direccion_completa' => $clienteLocal['direccion'],
                        'departamento' => $clienteLocal['departamento'],
                        'provincia' => $clienteLocal['provincia'],
                        'distrito' => $clienteLocal['distrito'],
                        'ubigeo_sunat' => $clienteLocal['ubigeo'],
                        'ubigeo_reniec' => $clienteLocal['ubigeo']
                    ]]);
                    exit;
                }
                
                // 2. Si no existe, buscar en API externa
                $token = '461a4e35bb683c7b21e8da62a012108f81422441ed843b5b6a510f9b9fa8';
                $esRuc = ($tipo === 'RUC');
                $url = 'https://api.json.pe/api/' . ($esRuc ? 'ruc' : 'dni');
                $body = $esRuc ? ['ruc' => $numero] : ['dni' => $numero];
                
                $ch = curl_init($url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
                curl_setopt($ch, CURLOPT_HTTPHEADER, [
                    'Authorization: Bearer ' . $token,
                    'Content-Type: application/json'
                ]);
                $res = curl_exec($ch);
                $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                
                if ($httpcode == 200 && $res) {
                    $json = json_decode($res, true);
                    if ($json && isset($json['success']) && $json['success']) {
                        echo json_encode(['status' => 'ok', 'origen' => 'API Externa', 'data' => $json['data']]);
                        exit;
                    }
                }
                
                echo json_encode(['status' => 'error', 'message' => 'Documento no encontrado o API falló.']);
                exit;
            }

            // Listar todos
            $clientes = ModelClientes::getAll();
            echo json_encode(['status' => 'ok', 'data' => $clientes]);
            break;

        case 'POST':
            $data = json_decode(file_get_contents('php://input'), true);
            
            if ($action === 'crear') {
                $id = ModelClientes::create($data);
                echo json_encode(['status' => 'ok', 'message' => 'Cliente creado exitosamente', 'id' => $id]);
            } elseif ($action === 'editar') {
                ModelClientes::update($data);
                echo json_encode(['status' => 'ok', 'message' => 'Cliente actualizado exitosamente']);
            } elseif ($action === 'eliminar') {
                ModelClientes::delete($data['id']);
                echo json_encode(['status' => 'ok', 'message' => 'Cliente eliminado']);
            }
            break;

        default:
            http_response_code(405);
            echo json_encode(['status' => 'error', 'message' => 'Método no permitido']);
    }
} catch (PDOException $e) {
    if ($e->getCode() == 23000) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'El número de documento ya está registrado.']);
    } else {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}

