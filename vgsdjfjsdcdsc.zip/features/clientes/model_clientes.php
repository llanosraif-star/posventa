<?php
require_once __DIR__ . '/../../config/database.php';

class ModelClientes {
    private static function getDB() {
        return Database::getInstance()->getConnection();
    }

    public static function createTableIfNotExists() {
        $db = self::getDB();
        try {
            $sqlInit = "CREATE TABLE IF NOT EXISTS clientes (
                id INT AUTO_INCREMENT PRIMARY KEY,
                tipo_documento VARCHAR(20) NOT NULL DEFAULT 'RUC',
                documento VARCHAR(50) NOT NULL,
                nombre VARCHAR(255) NOT NULL,
                nombre_comercial VARCHAR(255) NULL,
                telefono VARCHAR(50) NULL,
                email VARCHAR(255) NULL,
                direccion TEXT NULL,
                departamento VARCHAR(100) NULL,
                provincia VARCHAR(100) NULL,
                distrito VARCHAR(100) NULL,
                ubigeo VARCHAR(20) NULL,
                estado TINYINT(1) DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY idx_documento (documento)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
            $db->exec($sqlInit);
        } catch (PDOException $e) {
            error_log("Error creando tabla clientes: " . $e->getMessage());
        }
    }

    public static function getByDocumento($numero) {
        $db = self::getDB();
        $stmt = $db->prepare("SELECT * FROM clientes WHERE documento = ? LIMIT 1");
        $stmt->execute([$numero]);
        return $stmt->fetch();
    }

    public static function getAll() {
        $db = self::getDB();
        $stmt = $db->query("SELECT * FROM clientes ORDER BY id DESC");
        return $stmt->fetchAll();
    }

    public static function create($data) {
        $db = self::getDB();
        $stmt = $db->prepare("
            INSERT INTO clientes (
                tipo_documento, documento, nombre, nombre_comercial, 
                telefono, email, direccion, departamento, provincia, distrito, ubigeo, estado
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
        ");
        $stmt->execute([
            $data['tipo_documento'] ?? 'RUC',
            $data['documento'] ?? '',
            $data['nombre'] ?? '',
            $data['nombre_comercial'] ?? '',
            $data['telefono'] ?? '',
            $data['email'] ?? '',
            $data['direccion'] ?? '',
            $data['departamento'] ?? '',
            $data['provincia'] ?? '',
            $data['distrito'] ?? '',
            $data['ubigeo'] ?? ''
        ]);
        return $db->lastInsertId();
    }

    public static function update($data) {
        $db = self::getDB();
        $stmt = $db->prepare("
            UPDATE clientes SET 
                tipo_documento=?, documento=?, nombre=?, nombre_comercial=?, 
                telefono=?, email=?, direccion=?, departamento=?, provincia=?, distrito=?, ubigeo=?
            WHERE id=?
        ");
        return $stmt->execute([
            $data['tipo_documento'] ?? 'RUC',
            $data['documento'] ?? '',
            $data['nombre'] ?? '',
            $data['nombre_comercial'] ?? '',
            $data['telefono'] ?? '',
            $data['email'] ?? '',
            $data['direccion'] ?? '',
            $data['departamento'] ?? '',
            $data['provincia'] ?? '',
            $data['distrito'] ?? '',
            $data['ubigeo'] ?? '',
            $data['id']
        ]);
    }

    public static function delete($id) {
        $db = self::getDB();
        $stmt = $db->prepare("DELETE FROM clientes WHERE id=?");
        return $stmt->execute([$id]);
    }
}

// Init table automatically when model is loaded
ModelClientes::createTableIfNotExists();
