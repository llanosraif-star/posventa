// Estado global del inventario
window.datosInventario = [];
window.paginaActualInventario = 1;
window.filtroCategoriaInventario = 'all';

// Cargar la lista de artículos
async function cargarInventario() {
    try {
        const res = await fetch('features/inventario/controller_inventario.php?action=listar');
        const data = await res.json();
        if (data.status === 'ok') {
            window.datosInventario = data.data;
            renderInventarioTable();
        } else {
            console.error('Error al cargar inventario:', data.message);
        }
    } catch (e) {
        console.error('Error de red:', e);
    }
}

// Renderizar la tabla con paginación y búsqueda
function renderInventarioTable() {
    const tbody = document.getElementById('tbodyInventario');
    const inputBusqueda = document.getElementById('inputBuscarArticulo').value.toLowerCase();
    const itemsPerPage = parseInt(document.getElementById('articulosPerPage').value);
    
    // Filtrar
    let filtrados = window.datosInventario.filter(item => {
        const matchesSearch = (item.nombre && item.nombre.toLowerCase().includes(inputBusqueda)) || 
                              (item.codigo_interno && item.codigo_interno.toLowerCase().includes(inputBusqueda));
        
        const matchesCategoria = window.filtroCategoriaInventario === 'all' || item.categoria === window.filtroCategoriaInventario;
        
        return matchesSearch && matchesCategoria;
    });

    // Paginación
    const totalItems = filtrados.length;
    const totalPages = Math.ceil(totalItems / itemsPerPage) || 1;
    
    if (window.paginaActualInventario > totalPages) {
        window.paginaActualInventario = totalPages;
    }
    
    const startIndex = (window.paginaActualInventario - 1) * itemsPerPage;
    const paginados = filtrados.slice(startIndex, startIndex + itemsPerPage);

    // Render HTML
    if (paginados.length === 0) {
        tbody.innerHTML = `<tr><td colspan="8" class="text-center py-4 text-muted">No se encontraron artículos</td></tr>`;
    } else {
        tbody.innerHTML = paginados.map((item, index) => {
            const num = startIndex + index + 1;
            const statusBadge = parseInt(item.estado) === 1 
                ? '<span class="badge bg-success bg-opacity-10 text-success border border-success-subtle">Activo</span>' 
                : '<span class="badge bg-secondary bg-opacity-10 text-secondary border border-secondary-subtle">Inactivo</span>';
            
            const stockActual = parseFloat(item.stock_actual);
            const stockMinimo = parseFloat(item.stock_minimo);
            
            let stockColor = 'text-dark';
            if (stockActual <= 0) stockColor = 'text-danger fw-bold';
            else if (stockActual <= stockMinimo) stockColor = 'text-warning fw-bold';

            let catBadge = '';
            if (item.categoria === 'Insumos') { 
                catBadge = '<span class="badge px-2 py-1" style="background-color: #e0f2fe; color: #0369a1; border: 1px solid #bae6fd; border-radius: 6px;">Insumos</span>'; 
            } else if (item.categoria === 'Empaques') { 
                catBadge = '<span class="badge px-2 py-1" style="background-color: #f3e8ff; color: #6b21a8; border: 1px solid #e9d5ff; border-radius: 6px;">Empaques</span>'; 
            } else if (item.categoria === 'Productos') { 
                catBadge = '<span class="badge px-2 py-1" style="background-color: #ffedd5; color: #9a3412; border: 1px solid #fed7aa; border-radius: 6px;">Productos</span>'; 
            } else {
                catBadge = `<span class="badge px-2 py-1 bg-light text-dark border rounded-3">${item.categoria || '-'}</span>`;
            }

            return `
                <tr class="align-middle">
                    <td class="pl-4 text-muted">${num}</td>
                    <td><span class="font-monospace px-2 py-1">${item.codigo_interno || '-'}</span></td>
                    <td class="fw-medium text-dark">${item.nombre}</td>
                    <td>${catBadge}</td>
                    <td class="text-end ${stockColor}" style="font-size:0.95rem;">${stockActual.toFixed(2)}</td>
                    <td class="text-center text-muted">${item.unidad_medida || 'NIU'}</td>
                    <td class="text-center">${statusBadge}</td>
                    <td class="text-center">
                        <div class="d-flex justify-content-center" style="gap: 6px;">
                            <button class="btn border text-secondary shadow-sm" style="width: 28px; height: 28px; padding: 0; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; background: var(--bs-body-bg);" onclick="modalEditarArticulo(${item.id})" title="Editar">
                                <i data-lucide="pencil" style="width:14px;height:14px; stroke-width:2;"></i>
                            </button>
                            <button class="btn border text-secondary shadow-sm" style="width: 28px; height: 28px; padding: 0; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; background: var(--bs-body-bg);" onclick="eliminarArticulo(${item.id})" title="Eliminar">
                                <i data-lucide="trash-2" style="width:14px;height:14px; stroke-width:2;"></i>
                            </button>
                            <button class="btn border text-success shadow-sm" style="width: 28px; height: 28px; padding: 0; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; background: var(--bs-body-bg);" onclick="modalAjusteStock(${item.id})" title="Ajuste de Stock">
                                <i data-lucide="package-plus" style="width:14px;height:14px; stroke-width:2;"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
        }).join('');
    }

    // Actualizar info de paginación
    const endCount = Math.min(startIndex + itemsPerPage, totalItems);
    document.getElementById('inventarioInfoPaginacion').innerText = 
        `Mostrando ${totalItems === 0 ? 0 : startIndex + 1} a ${endCount} de ${totalItems} entradas`;
    
    // Render paginador
    renderPaginadorInventario(totalPages);
    
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

function buscarArticulo() {
    window.paginaActualInventario = 1;
    renderInventarioTable();
}

function filtrarCategoriaInventario(cat) {
    window.filtroCategoriaInventario = cat;
    window.paginaActualInventario = 1;
    renderInventarioTable();
}

function cambiarPaginaInventario(page) {
    window.paginaActualInventario = page;
    renderInventarioTable();
}

function renderPaginadorInventario(totalPages) {
    const container = document.getElementById('inventarioPaginasContainer');
    let html = '';
    
    // Botón Anterior
    html += `<li class="page-item ${window.paginaActualInventario === 1 ? 'disabled' : ''}">
                <a class="page-link" href="#" onclick="event.preventDefault(); cambiarPaginaInventario(${window.paginaActualInventario - 1})">Anterior</a>
             </li>`;
             
    // Números de página
    for (let i = 1; i <= totalPages; i++) {
        if (totalPages > 7) {
            if (i !== 1 && i !== totalPages && Math.abs(i - window.paginaActualInventario) > 2) {
                if (i === 2 || i === totalPages - 1) {
                    html += `<li class="page-item disabled"><a class="page-link" href="#">...</a></li>`;
                }
                continue;
            }
        }
        
        html += `<li class="page-item ${i === window.paginaActualInventario ? 'active' : ''}">
                    <a class="page-link" href="#" onclick="event.preventDefault(); cambiarPaginaInventario(${i})">${i}</a>
                 </li>`;
    }
    
    // Botón Siguiente
    html += `<li class="page-item ${window.paginaActualInventario === totalPages ? 'disabled' : ''}">
                <a class="page-link" href="#" onclick="event.preventDefault(); cambiarPaginaInventario(${window.paginaActualInventario + 1})">Siguiente</a>
             </li>`;
             
    container.innerHTML = html;
}

// --- MODALES Y CRUD ---

function modalNuevoArticulo() {
    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Nuevo Artículo</h5><p style="margin: 0; font-size: 0.85rem; color: #6b7280; font-weight: normal;">Registra un insumo, empaque o producto</p></div>',
        html: `
            <div style="text-align: left; font-family: 'Inter', sans-serif;" class="p-1 overflow-hidden">
                <form id="formNuevoArticulo" class="row g-3">
                    <div class="col-md-8">
                        <label class="form-label mb-1 fw-bold text-muted" style="font-size:0.85rem;">Nombre del artículo <span class="text-danger">*</span></label>
                        <input type="text" class="form-control form-control-sm border-secondary-subtle" id="inv-nombre" placeholder="Ej. Harina, Caja..." required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label mb-1 fw-bold text-muted" style="font-size:0.85rem;">Código Interno</label>
                        <input type="text" class="form-control form-control-sm border-secondary-subtle" id="inv-codigo" placeholder="Ej. INS-001">
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label mb-1 fw-bold text-muted" style="font-size:0.85rem;">Categoría <span class="text-danger">*</span></label>
                        <select class="form-select form-select-sm border-secondary-subtle" id="inv-categoria">
                            <option value="Insumos">Insumos (Harina, Tomate)</option>
                            <option value="Empaques">Empaques (Cajas, Vasos)</option>
                            <option value="Productos">Productos (Gaseosas, Aguas)</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label mb-1 fw-bold text-muted" style="font-size:0.85rem;">Unidad de medida</label>
                        <select class="form-select form-select-sm border-secondary-subtle" id="inv-unidad">
                            <option value="NIU">NIU (Unidades)</option>
                            <option value="KGM">KGM (Kilogramos)</option>
                            <option value="LTR">LTR (Litros)</option>
                            <option value="BX">BX (Cajas)</option>
                        </select>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label mb-1 fw-bold text-muted" style="font-size:0.85rem;">Stock Mínimo (Alerta)</label>
                        <input type="number" step="0.01" class="form-control form-control-sm border-secondary-subtle" id="inv-stock-minimo" value="0.00">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label mb-1 fw-bold text-muted" style="font-size:0.85rem;">Costo Referencial (S/)</label>
                        <input type="number" step="0.01" class="form-control form-control-sm border-secondary-subtle" id="inv-costo" value="0.00">
                    </div>

                    <div class="col-12 mt-2">
                        <div class="alert alert-info border-info-subtle p-2 mb-0 d-flex align-items-start" style="font-size: 0.8rem; border-radius: 8px;">
                            <i data-lucide="info" style="width:16px;height:16px;margin-right:8px;flex-shrink:0;" class="text-info"></i>
                            <div><strong>Conexión con Carta:</strong> Para descontar stock de gaseosas, cervezas u otros productos al vender, usa este <strong>Código Interno</strong> cuando crees el producto en la Carta.</div>
                        </div>
                    </div>
                </form>
            </div>
        `,
        width: 600,
        showCancelButton: true,
        confirmButtonText: 'Guardar Artículo',
        cancelButtonText: 'Cancelar',
        customClass: {
            popup: 'rounded-4 shadow-sm',
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-light border px-4 text-dark',
            actions: 'w-100 justify-content-end mt-4 pt-3 border-top'
        },
        buttonsStyling: false,
        didOpen: () => {
            if (typeof lucide !== 'undefined') lucide.createIcons();
        },
        preConfirm: async () => {
            const nombre = document.getElementById('inv-nombre').value.trim();
            if (!nombre) {
                Swal.showValidationMessage('El nombre es obligatorio');
                return false;
            }
            
            const formData = new FormData();
            formData.append('nombre', nombre);
            formData.append('codigo_interno', document.getElementById('inv-codigo').value.trim());
            formData.append('categoria', document.getElementById('inv-categoria').value);
            formData.append('unidad_medida', document.getElementById('inv-unidad').value);
            formData.append('stock_minimo', document.getElementById('inv-stock-minimo').value || 0);
            formData.append('costo', document.getElementById('inv-costo').value || 0);

            try {
                const res = await fetch('features/inventario/controller_inventario.php?action=crear', {
                    method: 'POST',
                    body: formData
                });
                const data = await res.json();
                if (data.status !== 'ok') throw new Error(data.message);
                return data;
            } catch (error) {
                Swal.showValidationMessage(`Error: ${error}`);
                return false;
            }
        }
    }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire({
                toast: true, position: 'top-end', icon: 'success', 
                title: 'Artículo registrado exitosamente', showConfirmButton: false, timer: 2000
            });
            cargarInventario();
        }
    });
}

function modalEditarArticulo(id) {
    const item = window.datosInventario.find(i => parseInt(i.id) === parseInt(id));
    if (!item) return;

    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Editar Artículo</h5><p style="margin: 0; font-size: 0.85rem; color: #6b7280; font-weight: normal;">Modificar datos básicos del inventario</p></div>',
        html: `
            <div style="text-align: left; font-family: 'Inter', sans-serif;" class="p-1">
                <form id="formEditarArticulo" class="row g-3">
                    <input type="hidden" id="edit-inv-id" value="${item.id}">
                    <div class="col-md-8">
                        <label class="form-label mb-1 fw-bold text-muted" style="font-size:0.85rem;">Nombre del artículo <span class="text-danger">*</span></label>
                        <input type="text" class="form-control form-control-sm border-secondary-subtle" id="edit-inv-nombre" value="${item.nombre}" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label mb-1 fw-bold text-muted" style="font-size:0.85rem;">Código Interno</label>
                        <input type="text" class="form-control form-control-sm border-secondary-subtle" id="edit-inv-codigo" value="${item.codigo_interno || ''}">
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label mb-1 fw-bold text-muted" style="font-size:0.85rem;">Categoría <span class="text-danger">*</span></label>
                        <select class="form-select form-select-sm border-secondary-subtle" id="edit-inv-categoria">
                            <option value="Insumos" ${item.categoria == 'Insumos' ? 'selected' : ''}>Insumos</option>
                            <option value="Empaques" ${item.categoria == 'Empaques' ? 'selected' : ''}>Empaques</option>
                            <option value="Productos" ${item.categoria == 'Productos' ? 'selected' : ''}>Productos</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label mb-1 fw-bold text-muted" style="font-size:0.85rem;">Unidad de medida</label>
                        <select class="form-select form-select-sm border-secondary-subtle" id="edit-inv-unidad">
                            <option value="NIU" ${item.unidad_medida == 'NIU' ? 'selected' : ''}>NIU (Unidades)</option>
                            <option value="KGM" ${item.unidad_medida == 'KGM' ? 'selected' : ''}>KGM (Kilogramos)</option>
                            <option value="LTR" ${item.unidad_medida == 'LTR' ? 'selected' : ''}>LTR (Litros)</option>
                            <option value="BX" ${item.unidad_medida == 'BX' ? 'selected' : ''}>BX (Cajas)</option>
                        </select>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label mb-1 fw-bold text-muted" style="font-size:0.85rem;">Stock Mínimo (Alerta)</label>
                        <input type="number" step="0.01" class="form-control form-control-sm border-secondary-subtle" id="edit-inv-stock-minimo" value="${item.stock_minimo}">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label mb-1 fw-bold text-muted" style="font-size:0.85rem;">Costo Referencial (S/)</label>
                        <input type="number" step="0.01" class="form-control form-control-sm border-secondary-subtle" id="edit-inv-costo" value="${item.costo}">
                    </div>
                    
                    <div class="col-12 mt-3 pt-3 border-top">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="edit-inv-estado" ${parseInt(item.estado) === 1 ? 'checked' : ''}>
                            <label class="form-check-label fw-bold" for="edit-inv-estado" style="font-size:0.85rem;">Artículo Activo</label>
                        </div>
                    </div>
                </form>
            </div>
        `,
        width: 600,
        showCancelButton: true,
        confirmButtonText: 'Guardar Cambios',
        cancelButtonText: 'Cancelar',
        customClass: {
            popup: 'rounded-4 shadow-sm',
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-light border px-4 text-dark',
            actions: 'w-100 justify-content-end mt-4 pt-3 border-top'
        },
        buttonsStyling: false,
        preConfirm: async () => {
            const nombre = document.getElementById('edit-inv-nombre').value.trim();
            if (!nombre) {
                Swal.showValidationMessage('El nombre es obligatorio');
                return false;
            }
            
            const formData = new FormData();
            formData.append('id', id);
            formData.append('nombre', nombre);
            formData.append('codigo_interno', document.getElementById('edit-inv-codigo').value.trim());
            formData.append('categoria', document.getElementById('edit-inv-categoria').value);
            formData.append('unidad_medida', document.getElementById('edit-inv-unidad').value);
            formData.append('stock_minimo', document.getElementById('edit-inv-stock-minimo').value || 0);
            formData.append('costo', document.getElementById('edit-inv-costo').value || 0);
            formData.append('estado', document.getElementById('edit-inv-estado').checked ? 1 : 0);

            try {
                const res = await fetch('features/inventario/controller_inventario.php?action=editar', {
                    method: 'POST',
                    body: formData
                });
                const data = await res.json();
                if (data.status !== 'ok') throw new Error(data.message);
                return data;
            } catch (error) {
                Swal.showValidationMessage(`Error: ${error}`);
                return false;
            }
        }
    }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire({
                toast: true, position: 'top-end', icon: 'success', 
                title: 'Artículo actualizado', showConfirmButton: false, timer: 2000
            });
            cargarInventario();
        }
    });
}

function eliminarArticulo(id) {
    Swal.fire({
        title: '¿Estás seguro?',
        text: "Se eliminará (o desactivará) el artículo del inventario",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Sí, eliminar',
        cancelButtonText: 'Cancelar'
    }).then(async (result) => {
        if (result.isConfirmed) {
            const formData = new FormData();
            formData.append('id', id);
            try {
                const res = await fetch('features/inventario/controller_inventario.php?action=eliminar', {
                    method: 'POST',
                    body: formData
                });
                const data = await res.json();
                if (data.status === 'ok') {
                    Swal.fire({toast:true, position:'top-end', icon:'success', title:'Eliminado', showConfirmButton:false, timer:1500});
                    cargarInventario();
                } else {
                    Swal.fire('Error', data.message, 'error');
                }
            } catch(e) {
                console.error(e);
            }
        }
    });
}

function modalAjusteStock(id) {
    const item = window.datosInventario.find(i => parseInt(i.id) === parseInt(id));
    if (!item) return;

    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Ajuste de Stock</h5><p style="margin: 0; font-size: 0.85rem; color: #6b7280; font-weight: normal;">Registra un ingreso o salida manual</p></div>',
        html: `
            <div style="text-align: left; font-family: 'Inter', sans-serif;" class="p-1">
                <div class="p-3 mb-3 rounded" style="background: #f8fafc; border: 1px solid #cbd5e1;">
                    <div class="fw-bold text-dark">${item.nombre} <span class="text-muted ms-1" style="font-size:0.8rem;">(${item.codigo_interno || '-'})</span></div>
                    <div class="d-flex justify-content-between mt-1" style="font-size:0.85rem;">
                        <span class="text-muted">Stock Actual:</span>
                        <span class="fw-bold ${item.stock_actual <= item.stock_minimo ? 'text-danger' : 'text-primary'}">${parseFloat(item.stock_actual).toFixed(2)} ${item.unidad_medida}</span>
                    </div>
                </div>

                <form id="formAjusteStock" class="row g-3">
                    <input type="hidden" id="ajuste-id" value="${item.id}">
                    <div class="col-12">
                        <label class="form-label mb-1 fw-bold text-muted" style="font-size:0.85rem;">Tipo de Movimiento</label>
                        <div class="d-flex gap-2">
                            <input type="radio" class="btn-check" name="ajuste-tipo" id="tipo-ingreso" value="ingreso" checked>
                            <label class="btn btn-outline-success w-50" for="tipo-ingreso" style="border-radius:6px; font-weight:500;">
                                <i data-lucide="arrow-down-to-line" style="width:16px;height:16px;margin-right:4px;vertical-align:text-bottom;"></i> Ingreso (+)
                            </label>

                            <input type="radio" class="btn-check" name="ajuste-tipo" id="tipo-salida" value="salida">
                            <label class="btn btn-outline-danger w-50" for="tipo-salida" style="border-radius:6px; font-weight:500;">
                                <i data-lucide="arrow-up-from-line" style="width:16px;height:16px;margin-right:4px;vertical-align:text-bottom;"></i> Salida (-)
                            </label>
                        </div>
                    </div>
                    
                    <div class="col-md-6 mt-4">
                        <label class="form-label mb-1 fw-bold text-muted" style="font-size:0.85rem;">Cantidad</label>
                        <input type="number" step="0.01" class="form-control border-secondary-subtle" id="ajuste-cantidad" placeholder="0.00" required>
                    </div>
                    <div class="col-md-6 mt-4">
                        <label class="form-label mb-1 fw-bold text-muted" style="font-size:0.85rem;">Motivo / Observación</label>
                        <input type="text" class="form-control border-secondary-subtle" id="ajuste-motivo" placeholder="Ej. Compra, Merma..." required>
                    </div>
                </form>
            </div>
        `,
        width: 500,
        showCancelButton: true,
        confirmButtonText: 'Registrar Movimiento',
        cancelButtonText: 'Cancelar',
        customClass: {
            popup: 'rounded-4 shadow-sm',
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-light border px-4 text-dark',
            actions: 'w-100 justify-content-end mt-4 pt-3 border-top'
        },
        buttonsStyling: false,
        didOpen: () => {
            if (typeof lucide !== 'undefined') lucide.createIcons();
        },
        preConfirm: async () => {
            const cantidad = parseFloat(document.getElementById('ajuste-cantidad').value);
            const motivo = document.getElementById('ajuste-motivo').value.trim();
            const tipo = document.querySelector('input[name="ajuste-tipo"]:checked').value;
            
            if (!cantidad || cantidad <= 0) {
                Swal.showValidationMessage('La cantidad debe ser mayor a 0');
                return false;
            }
            if (!motivo) {
                Swal.showValidationMessage('Debes ingresar un motivo');
                return false;
            }
            
            const formData = new FormData();
            formData.append('id_articulo', id);
            formData.append('tipo', tipo);
            formData.append('cantidad', cantidad);
            formData.append('motivo', motivo);

            try {
                const res = await fetch('features/inventario/controller_inventario.php?action=ajustar_stock', {
                    method: 'POST',
                    body: formData
                });
                const data = await res.json();
                if (data.status !== 'ok') throw new Error(data.message);
                return data;
            } catch (error) {
                Swal.showValidationMessage(`Error: ${error}`);
                return false;
            }
        }
    }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire({
                toast: true, position: 'top-end', icon: 'success', 
                title: 'Stock actualizado', showConfirmButton: false, timer: 2000
            });
            cargarInventario();
        }
    });
}
