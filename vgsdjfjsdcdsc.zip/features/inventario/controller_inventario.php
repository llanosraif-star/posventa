<?php
session_start();
require_once '../../config/database.php';
$pdo = Database::getInstance()->getConnection();

$action = $_GET['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if ($action === 'listar') {
        try {
            $stmt = $pdo->prepare("SELECT * FROM inventario_pos ORDER BY nombre ASC");
            $stmt->execute();
            $data = $stmt->fetchAll();
            echo json_encode(["status" => "ok", "data" => $data]);
        } catch (PDOException $e) {
            echo json_encode(["status" => "error", "message" => $e->getMessage()]);
        }
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = $_POST;
    
    if ($action === 'crear') {
        try {
            $stmt = $pdo->prepare("INSERT INTO inventario_pos (nombre, codigo_interno, categoria, unidad_medida, stock_minimo, costo) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $input['nombre'],
                $input['codigo_interno'] ?? '',
                $input['categoria'] ?? 'Insumos',
                $input['unidad_medida'] ?? 'NIU',
                is_numeric($input['stock_minimo']) ? (float)$input['stock_minimo'] : 0,
                is_numeric($input['costo']) ? (float)$input['costo'] : 0
            ]);
            echo json_encode(["status" => "ok", "message" => "Artículo creado"]);
        } catch (PDOException $e) {
            echo json_encode(["status" => "error", "message" => $e->getMessage()]);
        }
    } elseif ($action === 'editar') {
        try {
            $stmt = $pdo->prepare("UPDATE inventario_pos SET nombre=?, codigo_interno=?, categoria=?, unidad_medida=?, stock_minimo=?, costo=?, estado=? WHERE id=?");
            $stmt->execute([
                $input['nombre'],
                $input['codigo_interno'] ?? '',
                $input['categoria'] ?? 'Insumos',
                $input['unidad_medida'] ?? 'NIU',
                is_numeric($input['stock_minimo']) ? (float)$input['stock_minimo'] : 0,
                is_numeric($input['costo']) ? (float)$input['costo'] : 0,
                $input['estado'] ?? 1,
                $input['id']
            ]);
            echo json_encode(["status" => "ok", "message" => "Artículo actualizado"]);
        } catch (PDOException $e) {
            echo json_encode(["status" => "error", "message" => $e->getMessage()]);
        }
    } elseif ($action === 'eliminar') {
        try {
            $stmt = $pdo->prepare("UPDATE inventario_pos SET estado=0 WHERE id=?");
            $stmt->execute([$input['id']]);
            echo json_encode(["status" => "ok", "message" => "Artículo desactivado"]);
        } catch (PDOException $e) {
            echo json_encode(["status" => "error", "message" => $e->getMessage()]);
        }
    } elseif ($action === 'ajustar_stock') {
        try {
            $pdo->beginTransaction();
            
            $id_articulo = $input['id_articulo'];
            $tipo = $input['tipo']; // 'ingreso' o 'salida'
            $cantidad = (float)$input['cantidad'];
            $motivo = $input['motivo'];
            $usuario_id = $_SESSION['user_id'] ?? null;
            
            // Insertar movimiento
            $stmt = $pdo->prepare("INSERT INTO inventario_pos_movimientos (id_articulo, tipo_movimiento, cantidad, motivo, usuario_id) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$id_articulo, $tipo, $cantidad, $motivo, $usuario_id]);
            
            // Actualizar stock
            if ($tipo === 'ingreso') {
                $update = $pdo->prepare("UPDATE inventario_pos SET stock_actual = stock_actual + ? WHERE id = ?");
            } else {
                $update = $pdo->prepare("UPDATE inventario_pos SET stock_actual = stock_actual - ? WHERE id = ?");
            }
            $update->execute([$cantidad, $id_articulo]);
            
            $pdo->commit();
            echo json_encode(["status" => "ok", "message" => "Stock actualizado"]);
        } catch (PDOException $e) {
            $pdo->rollBack();
            echo json_encode(["status" => "error", "message" => $e->getMessage()]);
        }
    }
}
