<div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="mb-0 text-gray-800" style="font-size: 24px; font-weight: 600;"><i data-lucide="layout-dashboard" style="width:24px;height:24px;margin-right:8px;color:inherit;stroke-width:2.7;"></i>Dashboard</h1>
                <a href="javascript:void(0)" onclick="generarReporte()" class="d-none d-sm-inline-block btn btn-sm btn-primary bg-theme-primary border-theme-primary shadow-sm">
                    <i data-lucide="download" class="lucide-btn"></i> Generar Reporte
                </a>
            </div>
            <div class="row">
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-theme-primary shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-theme-primary text-uppercase mb-1">Ganancias (Mensual)</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">$40,000</div>
                                </div>
                                <div class="col-auto"><i data-lucide="calendar" class="lucide-card"></i></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-theme-primary shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-theme-primary text-uppercase mb-1">Ganancias (Anual)</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">$215,000</div>
                                </div>
                                <div class="col-auto"><i data-lucide="dollar-sign" class="lucide-card"></i></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-theme-primary shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-theme-primary text-uppercase mb-1">Tareas</div>
                                    <div class="row no-gutters align-items-center">
                                        <div class="col-auto">
                                            <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">50%</div>
                                        </div>
                                        <div class="col">
                                            <div class="progress progress-sm mr-2">
                                                <div class="progress-bar bg-theme-primary" role="progressbar" style="width: 50%"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-auto"><i data-lucide="clipboard-list" class="lucide-card"></i></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-theme-primary shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-theme-primary text-uppercase mb-1">Solicitudes Pendientes</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">18</div>
                                </div>
                                <div class="col-auto"><i data-lucide="message-square" class="lucide-card"></i></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-8 col-lg-7">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                            <h6 class="m-0 font-weight-bold text-theme-primary">Resumen de Ganancias</h6>
                        </div>
                        <div class="card-body">
                            <div class="text-center py-5">
                                <i data-lucide="trending-up" class="lucide-placeholder"></i>
                                <p class="text-gray-500 mt-3">Área de gráficos - Conectar con datos MySQL</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-5">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                            <h6 class="m-0 font-weight-bold text-theme-primary">Fuentes de Ingreso</h6>
                        </div>
                        <div class="card-body">
                            <div class="text-center py-5">
                                <i data-lucide="pie-chart" class="lucide-placeholder"></i>
                                <p class="text-gray-500 mt-3">Gráfico de torta - Conectar con datos MySQL</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>