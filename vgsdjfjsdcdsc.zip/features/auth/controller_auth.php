<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/model_auth.php';

$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'login':
            $data = json_decode(file_get_contents('php://input'), true);
            $email = trim($data['email'] ?? '');
            $password = $data['password'] ?? '';

            if (empty($email) || empty($password)) {
                echo json_encode(['status' => 'error', 'message' => 'Complete todos los campos']);
                break;
            }

            $user = ModelAuth::getUserByEmail($email);

            if (!$user || !password_verify($password, $user['password'])) {
                echo json_encode(['status' => 'error', 'message' => 'Credenciales incorrectas']);
                break;
            }

            // Actualizar último acceso
            ModelAuth::updateLastAccess($user['id']);

            // Guardar sesión
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_nombre'] = $user['nombre'];
            $_SESSION['user_apellido'] = $user['apellido'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_rol'] = $user['rol'];

            echo json_encode([
                'status' => 'ok',
                'message' => 'Inicio de sesión exitoso',
                'user' => [
                    'id' => $user['id'],
                    'nombre' => $user['nombre'],
                    'apellido' => $user['apellido'],
                    'email' => $user['email'],
                    'rol' => $user['rol']
                ]
            ]);
            break;

        case 'logout':
            session_destroy();
            echo json_encode(['status' => 'ok', 'message' => 'Sesión cerrada']);
            break;

        case 'session':
            if (isset($_SESSION['user_id'])) {
                echo json_encode([
                    'status' => 'ok',
                    'user' => [
                        'id' => $_SESSION['user_id'],
                        'nombre' => $_SESSION['user_nombre'],
                        'apellido' => $_SESSION['user_apellido'],
                        'email' => $_SESSION['user_email'],
                        'rol' => $_SESSION['user_rol']
                    ]
                ]);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'No hay sesión activa']);
            }
            break;

        default:
            echo json_encode(['status' => 'error', 'message' => 'Acción no válida']);
    }
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}

