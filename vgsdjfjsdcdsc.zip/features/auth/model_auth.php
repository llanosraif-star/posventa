<?php
require_once __DIR__ . '/../../config/database.php';

class ModelAuth {
    public static function getUserByEmail($email) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("SELECT u.*, r.nombre as rol FROM usuarios u LEFT JOIN roles r ON u.id_rol = r.id WHERE u.email = ? AND u.estado = 1 LIMIT 1");
        $stmt->execute([$email]);
        return $stmt->fetch();
    }

    public static function updateLastAccess($userId) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("UPDATE usuarios SET ultimo_acceso = NOW() WHERE id = ?");
        return $stmt->execute([$userId]);
    }
}
