/**
 * pos.js - Módulo de Punto de Venta (POS)
 * Carrito, ordenes de mesa, delivery, cobro
 */

// ==========================================
// MÓDULO POS (PUNTO DE VENTA)
// ==========================================

window.posCart = [];
window.posCategoriaActiva = null;
window.posGrupoActivo = null;
window.posTipoOrden = 'mesa';
window.posMesaSeleccionada = null;
window.posMesas = [];
window.posZonas = [];
window.posEstadoMesas = {};
window.posTimerInterval = null;
window.posZonaActiva = 'todos';

async function cargarPOS() {
    window.posCart = [];
    window.posCategoriaActiva = null;
    window.posGrupoActivo = null;
    window.posTipoOrden = 'mesa';
    window.posMesaSeleccionada = null;
    if (window.posTimerInterval) clearInterval(window.posTimerInterval);

    try {
        const [resCarta, resMI] = await Promise.all([
            fetch('features/carta/controller_carta.php?t=' + Date.now()),
            fetch('features/mesas/controller_mesas.php')
        ]);
        const carta = await resCarta.json();
        if (carta.status === 'ok') {
            window.datosApp.categorias = carta.data.categorias;
            window.datosApp.subcategorias = carta.data.subcategorias;
            window.datosApp.productos = carta.data.productos;
            window.datosApp.modificadores = carta.data.modificadores;
        }
        const mi = await resMI.json();
        if (mi.status === 'ok') {
            window.posZonas = mi.data.zonas || [];
            window.posMesas = mi.data.mesas || [];
        }
    } catch(e) { console.error('Error cargando POS:', e); }

    // Sincronizar estados reales de mesas desde el backend
    window.posMesas.forEach(m => {
        window.posEstadoMesas[m.id] = { estado: m.estado_mesa || 'libre', inicio: m.estado_mesa === 'ocupada' ? Date.now() : null };
    });

    seleccionarTipoOrdenPOS('mesa');
    lucide.createIcons();
}

function seleccionarTipoOrdenPOS(tipo) {
    window.posTipoOrden = tipo;
    
    // Si estábamos en la pestaña Carrito (móvil), salimos de ella
    document.body.classList.remove('mostrar-carrito-movil');
    
    // Si cambiamos de tipo (ej a delivery) y teníamos mesa, la limpiamos
    if (tipo !== 'mesa') {
        window.posMesaSeleccionada = null;
    }
    
    // Si entramos a mostrador, limpiar carrito para orden nueva
    if (tipo === 'mostrador') {
        window.posCart = [];
        window.posOrdenDeliveryActiva = null;
        window.posOrdenActivaId = null;
    } 

    ['mesa','mostrador','resumen'].forEach(t => {
        const tab = document.getElementById('pos-tab-' + t);
        if (tab) {
            if (t === tipo) { tab.className = 'px-4 py-2 font-weight-bold text-theme-primary'; tab.style.borderBottom = '3px solid'; }
            else { tab.className = 'px-4 py-2 text-muted'; tab.style.borderBottom = '3px solid transparent'; }
        }
        
        // Actualizar estado activo en Bottom Nav (móvil/tablet)
        const bottomTab = document.getElementById('pos-bottom-tab-' + t);
        if (bottomTab) {
            if (t === tipo) bottomTab.classList.add('active');
            else bottomTab.classList.remove('active');
        }
    });

    const mapaMesas = document.getElementById('pos-vista-mapa-mesas');
    const resumenDash = document.getElementById('pos-vista-resumen');
    const pedidoHeader = document.getElementById('pos-vista-pedido-header');
    const gruposCont = document.getElementById('pos-grupos-container');
    const prodWrapper = document.getElementById('pos-subcategorias-wrapper');
    const infoMesa = document.getElementById('pos-mesa-activa-info');
    const infoDelivery = document.getElementById('pos-delivery-info');
    const cartOverlay = document.getElementById('pos-cart-overlay');
    const btnDelivery = document.getElementById('pos-btn-group-delivery');

    if (tipo === 'mesa' && !window.posMesaSeleccionada) {
        mapaMesas.classList.remove('d-none');
        if (resumenDash) resumenDash.classList.add('d-none');
        pedidoHeader.classList.add('d-none');
        gruposCont.classList.add('d-none');
        gruposCont.classList.remove('d-flex');
        prodWrapper.classList.add('d-none');
        if (btnDelivery) btnDelivery.classList.add('d-none');
        
        if (cartOverlay) {
            cartOverlay.classList.remove('d-none');
            cartOverlay.classList.add('d-flex');
            cartOverlay.innerHTML = '<i data-lucide="mouse-pointer-click" style="width:48px;height:48px;color:#cbd5e1;margin-bottom:15px;"></i><span style="font-size:0.95rem;">Ninguna mesa seleccionada</span><span class="px-4" style="font-size:0.8rem;color:#94a3b8;margin-top:5px;">Selecciona una mesa del mapa a la izquierda para poder visualizar y agregar subcategorias al pedido.</span>';
        }
        
        renderPOSZonasFiltros();
        renderPOSMapaMesas();
        sincronizarMesasPOS(); // Fetch fresh states immediately when tab is opened
    } else if (tipo === 'resumen') {
        mapaMesas.classList.add('d-none');
        if (resumenDash) resumenDash.classList.remove('d-none');
        pedidoHeader.classList.add('d-none');
        gruposCont.classList.add('d-none');
        gruposCont.classList.remove('d-flex');
        prodWrapper.classList.add('d-none');
        if (btnDelivery) btnDelivery.classList.add('d-none');
        
        if (cartOverlay) {
            cartOverlay.classList.remove('d-none');
            cartOverlay.classList.add('d-flex');
            cartOverlay.innerHTML = '<i data-lucide="file-text" style="width:48px;height:48px;color:#cbd5e1;margin-bottom:15px;"></i><span style="font-size:0.95rem;">Seleccione una orden</span><span class="px-4" style="font-size:0.8rem;color:#94a3b8;margin-top:5px;">Visualiza los detalles haciendo clic en una orden pendiente.</span>';
        }
        renderPOSResumen();
    } else {
        mapaMesas.classList.add('d-none');
        if (resumenDash) resumenDash.classList.add('d-none');
        pedidoHeader.classList.remove('d-none');
        prodWrapper.classList.remove('d-none');
        if (btnDelivery) {
            if (tipo === 'mostrador') btnDelivery.classList.remove('d-none');
            else btnDelivery.classList.add('d-none');
        }
        
        if (cartOverlay) {
            cartOverlay.classList.add('d-none');
            cartOverlay.classList.remove('d-flex');
        }
        
        if (tipo === 'mostrador') {
            infoMesa.classList.add('d-none');
            infoMesa.classList.remove('d-flex');
            infoDelivery.classList.remove('d-none');
            infoDelivery.classList.add('d-flex');
            posToggleDeliveryTipo();
        } else if (tipo === 'mesa') {
            infoMesa.classList.remove('d-none');
            infoMesa.classList.add('d-flex');
            infoDelivery.classList.add('d-none');
            infoDelivery.classList.remove('d-flex');
        }
        
        if (tipo === 'mesa' && window.posMesaSeleccionada) {
            document.getElementById('pos-mesa-activa-nombre').innerText = window.posMesaSeleccionada.numero;
        }

        renderPOSCategorias();
        renderPOSCart();
    }
    
    actualizarBadgeOrden();
    lucide.createIcons();
}

function posVolverAMesas() {
    window.posMesaSeleccionada = null;
    seleccionarTipoOrdenPOS('mesa');
}

// ==========================================
// DELIVERY DASHBOARD LOGIC
// ==========================================
window.posCreandoOrdenDelivery = false;
window.posFiltroDelivery = 'todos'; // todos, delivery, recoger, llevar

function posNuevaOrdenDelivery() {
    window.posCreandoOrdenDelivery = true;
    window.posCart = []; // Limpiar carrito
    document.getElementById('pos-delivery-cliente').value = '';
    document.getElementById('pos-delivery-telefono').value = '';
    document.getElementById('pos-delivery-direccion').value = '';
    seleccionarTipoOrdenPOS('delivery');
}

function posVolverADeliveryDashboard() {
    window.posCreandoOrdenDelivery = false;
    seleccionarTipoOrdenPOS('resumen');
}

function posSetFiltroDelivery(filtro) {
    window.posFiltroDelivery = filtro;
    renderPOSResumen();
}

async function guardarPedidoDeliveryPOS() {
    if (window.posCart.length === 0) {
        return Swal.fire({
            icon: 'warning',
            title: 'Orden vacía',
            text: 'Agrega subcategorias a la orden primero.',
            confirmButtonColor: '#e11d48'
        });
    }

    let subTipo = document.getElementById('pos-delivery-tipo') ? document.getElementById('pos-delivery-tipo').value : 'delivery';
    let cliente = document.getElementById('pos-delivery-cliente') ? document.getElementById('pos-delivery-cliente').value : '';
    let telefono = document.getElementById('pos-delivery-telefono') ? document.getElementById('pos-delivery-telefono').value : '';
    let direccion = document.getElementById('pos-delivery-direccion') ? document.getElementById('pos-delivery-direccion').value : '';
    let pickupTime = document.getElementById('pos-pickup-time') ? document.getElementById('pos-pickup-time').value : '';
    // Validaciones de integridad por tipo de orden (frontend)
    if (subTipo === 'delivery') {
        if (!cliente) return mostrarAlerta('warning', 'El nombre del cliente es obligatorio para delivery.');
        if (!direccion) return mostrarAlerta('warning', 'La dirección es obligatoria para delivery.');
        if (!telefono) return mostrarAlerta('warning', 'El teléfono es obligatorio para delivery.');
    }
    if ((subTipo === 'recoger' || subTipo === 'llevar') && !cliente) {
        return mostrarAlerta('warning', 'El nombre del cliente es obligatorio para recojo/para llevar.');
    }

    let subtotal = window.posCart.reduce((s, x) => s + x.cantidad * x.precio, 0);

    try {
        let res = await fetch('features/caja/controller_caja.php?action=guardar_orden', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                tipo_pedido: subTipo,
                cliente_nombre: cliente,
                cliente_telefono: telefono,
                cliente_direccion: direccion,
                pickup_time: pickupTime,
                subtotal: subtotal,
                descuento: 0,
                total: subtotal,
                items: window.posCart.map(i => ({ id_subcategoria: i.id || 1, producto_id: i.producto_id || 0, cantidad: i.cantidad, precio: i.precio, nombre: i.nombre, notas: i.notas }))
            })
        });
        
        let data = await res.json();
        if (data.status === 'ok') {
            mostrarAlerta('success', 'Orden Guardada: ' + data.numero_pedido);
            window.posCart = [];
            // Aquí podríamos recargar los datos reales del backend si los conectamos en renderPOSResumen
            posVolverADeliveryDashboard();
        } else {
            mostrarAlerta('error', data.message || 'Error al completar orden');
        }
    } catch (e) {
        mostrarAlerta('error', 'Error de red');
    }
}

// ==========================================
// CARRITO MÓVIL (PESTAÑA)
// ==========================================
function posAbrirCarritoMovil() {
    if (window.innerWidth >= 992) return;
    document.body.classList.add('mostrar-carrito-movil');
    
    // Quitar active a los otros tabs del bottom nav
    ['mesa','mostrador','resumen'].forEach(t => {
        const bottomTab = document.getElementById('pos-bottom-tab-' + t);
        if (bottomTab) bottomTab.classList.remove('active');
    });
    
    // Poner active al carrito
    const cartTab = document.getElementById('pos-bottom-tab-carrito');
    if (cartTab) cartTab.classList.add('active');
}

function posCerrarCarritoMovil() {
    // Si quisieran cerrar explícitamente (ej: botón X), volvemos a mesa por defecto
    seleccionarTipoOrdenPOS('mesa');
}

window.posFiltroResumen = 'todos';

function posSetFiltroResumen(f) {
    window.posFiltroResumen = f;
    renderPOSResumen();
}

async function renderPOSResumen(silent = false) {
    const container = document.getElementById('pos-resumen-orders-list');
    if (!container) return;

    // Actualizar botones de filtro
    const filtros = ['todos', 'mesa', 'delivery', 'recoger', 'llevar'];
    filtros.forEach(f => {
        let btn = document.getElementById('pos-btn-filtro-' + f);
        if (btn) {
            if (f === window.posFiltroResumen) {
                btn.className = 'btn btn-sm px-4 font-weight-bold shadow-sm text-white';
                btn.style.backgroundColor = '#f97316';
                btn.style.borderColor = '#ea580c';
            } else {
                btn.className = 'btn btn-sm btn-white text-secondary border px-4 shadow-sm';
                btn.style.backgroundColor = '#ffffff';
                btn.style.borderColor = '#e2e8f0';
            }
        }
    });

    if (!silent) container.innerHTML = '<div class="text-center p-4 text-muted">Cargando órdenes...</div>';

    try {
        let res = await fetch('features/caja/controller_caja.php?action=ordenes_activas&filtro=' + window.posFiltroResumen + '&t=' + Date.now());
        let data = await res.json();
        if (data.status !== 'ok' || !data.data || data.data.length === 0) {
            container.innerHTML = '<div class="text-center p-4 text-muted border rounded" style="background:#fff; border-radius:12px;"><i data-lucide="inbox" style="width:48px;height:48px;color:#cbd5e1;margin-bottom:10px;"></i><br>No hay órdenes activas</div>';
            lucide.createIcons();
            return;
        }

        let html = '';
        data.data.forEach(o => {
            // Colores del badge vienen de la tabla tipo_orden via API
            let tipoNombre = o.tipo_pedido || '-';
            let tipoLabel  = o.tipo_codigo === 'salon' ? 'Mesa ' + (o.nombre_mesa || '') : tipoNombre;
            let tipoBg     = o.badge_bg     || '#f3f4f6';
            let tipoColor  = o.badge_color  || '#4b5563';
            let tipoBorder = o.badge_border || '#d1d5db';
            let typeBadgeStyle = `background-color:${tipoBg}!important; color:${tipoColor}!important; border: 1px solid ${tipoBorder};`;
            
            let tipoIcon = 'shopping-cart';
            if (o.tipo_codigo === 'salon') tipoIcon = 'layout-grid';
            else if (o.tipo_codigo === 'llevar') tipoIcon = 'shopping-bag';
            else if (o.tipo_codigo === 'recoger') tipoIcon = 'clock';
            else if (o.tipo_codigo === 'delivery') tipoIcon = 'bike';
            
            let st = { lbl: '', bg: '', color: '' };
            let pagoBg = '', pagoColor = '', pagoBorder = '', pagoDot = '', pagoLbl = '';
            
            // Lógica para badge de PAGO
            if (o.estado_pago === 'pagado') {
                pagoBg = '#f0fdf4'; pagoColor = '#166534'; pagoBorder = '#bbf7d0'; pagoDot = '#166534'; pagoLbl = 'Pagado';
            } else {
                pagoBg = '#ffedd5'; pagoColor = '#9a3412'; pagoBorder = '#fed7aa'; pagoDot = '#9a3412'; pagoLbl = 'Pend. pago';
            }

            // Lógica para badge de ESTADO PEDIDO
            let estBg = '', estColor = '', estBorder = '', estDot = '', estLbl = '';
            
            if (o.tipo_codigo === 'salon') {
                // Para mesa, si no está pagado, está "Mesa ocupada"
                if (o.estado_pago === 'pagado') {
                    estBg = '#f3f4f6'; estColor = '#4b5563'; estBorder = '#e5e7eb'; estDot = '#6b7280'; estLbl = 'Completado';
                } else {
                    estBg = '#fce7f3'; estColor = '#9d174d'; estBorder = '#fbcfe8'; estDot = '#9d174d'; estLbl = 'Mesa ocupada';
                }
            } else {
                if (o.estado_pedido === 'pendiente') {
                    estBg = '#f3f4f6'; estColor = '#4b5563'; estBorder = '#e5e7eb'; estDot = '#6b7280'; estLbl = 'Pendiente';
                } else if (o.estado_pedido === 'listo') {
                    estBg = '#f0fdf4'; estColor = '#166534'; estBorder = '#bbf7d0'; estDot = '#166534'; estLbl = 'Listo';
                } else if (o.estado_pedido === 'en_camino') {
                    estBg = '#eff6ff'; estColor = '#1e3a8a'; estBorder = '#bfdbfe'; estDot = '#1d4ed8'; estLbl = 'En camino';
                } else if (o.estado_pedido === 'completado') {
                    estBg = '#f3f4f6'; estColor = '#4b5563'; estBorder = '#e5e7eb'; estDot = '#6b7280'; estLbl = 'Completado';
                } else if (o.estado_pedido === 'anulado') {
                    estBg = '#fef2f2'; estColor = '#991b1b'; estBorder = '#fecaca'; estDot = '#b91c1c'; estLbl = 'Anulado';
                }
            }
            
            // Lógica de botones rápidos
            let botonesHtml = '';
            
            if (o.estado_pedido !== 'anulado' && o.estado_pedido !== 'completado') {
                if (o.tipo_codigo === 'salon') {
                    if (o.estado_pago === 'pendiente') {
                        botonesHtml += `<button class="btn btn-sm btn-outline-secondary" style="border-radius:8px; font-weight:500;" onclick="posDirectPrecuenta(${o.table_id}, event)">Precuenta</button>`;
                        botonesHtml += `<button class="btn btn-sm btn-outline-success" style="border-radius:8px; font-weight:500;" onclick="posDirectCobrar(${o.id}, event, true)">Cobrar y liberar</button>`;
                    }
                } else {
                    // Para llevar, recoger, delivery
                    if (o.estado_pago === 'pendiente') {
                        botonesHtml += `<button class="btn btn-sm btn-outline-secondary" style="border-radius:8px; font-weight:500;" onclick="posDirectCobrar(${o.id}, event, false)">Cobrar</button>`;
                    }
                    
                    if (o.estado_pedido === 'pendiente') {
                        botonesHtml += `<button class="btn btn-sm btn-outline-secondary" style="border-radius:8px; font-weight:500;" onclick="posDirectEstado(${o.id}, 'listo', event)">Marcar listo</button>`;
                    }
                    
                    if (o.tipo_codigo === 'delivery') {
                        if (o.estado_pedido === 'listo') {
                            botonesHtml += `<button class="btn btn-sm btn-outline-secondary" style="border-radius:8px; font-weight:500;" onclick="posDirectEstado(${o.id}, 'en_camino', event)">En camino</button>`;
                        }
                    } else if (['llevar', 'recoger'].includes(o.tipo_codigo)) {
                        if (o.estado_pedido === 'listo') {
                            botonesHtml += `<button class="btn btn-sm btn-outline-success" style="border-radius:8px; font-weight:500;" onclick="posDirectEstado(${o.id}, 'completado', event)">Entregar / completar</button>`;
                        }
                    }
                    
                    if (o.estado_pedido !== 'completado') {
                        if (o.tipo_codigo === 'delivery') {
                            botonesHtml += `<button class="btn btn-sm btn-outline-success" style="border-radius:8px; font-weight:500;" onclick="posDirectEstado(${o.id}, 'completado', event)">Completar</button>`;
                        } else if (o.estado_pedido !== 'listo') {
                            botonesHtml += `<button class="btn btn-sm btn-outline-success" style="border-radius:8px; font-weight:500;" onclick="posDirectEstado(${o.id}, 'completado', event)">Completar</button>`;
                        }
                    }
                }
            }

            let total = parseFloat(o.total || 0);

            let isActive = (window.posOrdenActivaId && window.posOrdenActivaId == o.id);

            html += `
            <div id="pos-resumen-card-${o.id}" class="card shadow-sm border pos-resumen-card ${isActive ? 'active-card' : ''}" style="border-radius:12px; margin-bottom: 12px; cursor:pointer; transition:all 0.2s; border-color:${o.estado_pedido === 'en_camino' ? '#38bdf8' : '#e2e8f0'};" onclick="posSeleccionarOrdenDelivery(${o.id})">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <div class="d-flex align-items-center" style="gap:8px;">
                            <span class="font-weight-bold text-dark" style="font-size: 1.05rem;">#${o.numero_pedido}</span>
                            <span class="badge px-2 py-1 d-flex align-items-center" style="border-radius:6px; ${typeBadgeStyle} gap:4px;">
                                <i data-lucide="${tipoIcon}" style="width:14px;height:14px;"></i> ${tipoLabel}
                            </span>
                        </div>
                        <span class="font-weight-bold text-theme-primary" style="font-size:1.15rem;">S/ ${total.toFixed(2)}</span>
                    </div>
                    
                    <div class="d-flex justify-content-between align-items-end">
                        <div>
                            <div class="text-muted mb-1" style="font-size:0.85rem;">
                                <i data-lucide="user" style="width:14px;height:14px;margin-right:4px;"></i> ${o.cliente_nombre || 'Sin nombre'} ${o.cliente_telefono ? '· ' + o.cliente_telefono : ''}
                            </div>
                            ${o.cliente_direccion ? `<div class="text-muted mb-1" style="font-size:0.85rem;"><i data-lucide="map-pin" style="width:14px;height:14px;margin-right:4px;"></i> ${o.cliente_direccion}</div>` : ''}
                            <div class="text-muted" style="font-size:0.85rem;">
                                ${o.total_items || 0} subcategoria${o.total_items == 1 ? '' : 's'} · ${o.hora || '--:--'}
                            </div>
                        </div>
                        
                        <div class="d-flex align-items-center" style="gap: 8px;">
                            <span class="badge px-2 py-1 d-flex align-items-center font-weight-normal" style="border-radius:20px; background-color:${pagoBg}; color:${pagoColor}; border:1px solid ${pagoBorder}; gap:4px;">
                                <span style="width:6px;height:6px;border-radius:50%;background-color:${pagoDot};"></span> ${pagoLbl}
                            </span>
                            
                            <span class="badge px-2 py-1 d-flex align-items-center font-weight-normal" style="border-radius:20px; background-color:${estBg}; color:${estColor}; border:1px solid ${estBorder}; gap:4px;">
                                <span style="width:6px;height:6px;border-radius:50%;background-color:${estDot};"></span> ${estLbl}
                            </span>
                        </div>
                    </div>
                    
                    ${botonesHtml !== '' ? `
                    <hr class="my-3" style="border-color:#f1f5f9;">
                    <div class="d-flex justify-content-end" style="gap: 8px;">
                        ${botonesHtml}
                    </div>` : ''}
                </div>
            </div>`;
        });
        
        container.innerHTML = html;
        lucide.createIcons();
    } catch(e) {
        container.innerHTML = '<div class="text-center p-4 text-danger">Error al cargar órdenes</div>';
    }
}

// ==========================================
// SELECCIONAR ORDEN DELIVERY → VER DETALLE EN CARRITO
// ==========================================

async function posSeleccionarOrdenDelivery(id) {
    // Fuente única de verdad para la tarjeta activa
    window.posOrdenActivaId = id;

    // Resaltado visual inmediato
    document.querySelectorAll('.pos-resumen-card').forEach(el => el.classList.remove('active-card'));
    let selectedCard = document.getElementById('pos-resumen-card-' + id);
    if (selectedCard) selectedCard.classList.add('active-card');

    try {
        let res = await fetch('features/caja/controller_caja.php?action=detalle_orden&id=' + id + '&t=' + Date.now());
        let data = await res.json();
        if (data.status !== 'ok') return mostrarAlerta('error', data.message || 'Error');

        let pedido = data.pedido;
        let items = data.items;

        // Limpiar el estado de selección anterior para evitar múltiples tarjetas activas
        window.posMesaSeleccionada = null;
        window.posPedidosMesaActivos = [];
        window.posOrdenDeliveryActiva = pedido; // Asignar inmediatamente

        if (pedido.tipo_codigo === 'salon') {
            let m = window.posMesas.find(x => x.id == pedido.table_id);
            if (m) {
                window.posMesaSeleccionada = m;
                // Cargar los pedidos de la mesa al carrito (sin cambiar a la vista de mesas)
                posCargarPedidosMesa(m.id);
                
                const cartOverlay = document.getElementById('pos-cart-overlay');
                if (cartOverlay) {
                    cartOverlay.classList.add('d-none');
                    cartOverlay.classList.remove('d-flex');
                }
            }
            return;
        }

        // Para Mostrador, Llevar, Recoger, Delivery: cargarlo en el panel POS normal
        window.posCart = [];
        items.forEach(item => {
            window.posCart.push({
                id: item.id_subcategoria,
                nombre: item.subcategoria_nombre || 'Subcategoria #' + item.id_subcategoria,
                precio: parseFloat(item.precio),
                cantidad: parseInt(item.cantidad),
                fromDB: true
            });
        });

        // Restaurar datos del formulario PRIMERO
        let inputCliente = document.getElementById('pos-delivery-cliente');
        if (inputCliente) inputCliente.value = pedido.cliente_nombre || '';
        
        let inputTelefono = document.getElementById('pos-delivery-telefono');
        if (inputTelefono) inputTelefono.value = pedido.cliente_telefono || '';
        
        let inputDireccion = document.getElementById('pos-delivery-direccion');
        if (inputDireccion) inputDireccion.value = pedido.cliente_direccion || '';
        
        let inputPickup = document.getElementById('pos-pickup-time');
        if (inputPickup) inputPickup.value = pedido.pickup_time || '';

        // LUEGO configurar el tipo para que dispare los cambios de UI de un solo golpe
        let selectTipo = document.getElementById('pos-delivery-tipo');
        if (selectTipo) {
            selectTipo.value = pedido.tipo_codigo; // Usar el código
            posToggleDeliveryTipo(); // Esto dispara también actualizarBadgeOrden() de forma óptima
        } else {
            actualizarBadgeOrden();
        }
        
        renderPOSCart();
        
        const cartOverlay = document.getElementById('pos-cart-overlay');
        if (cartOverlay) {
            cartOverlay.classList.add('d-none');
            cartOverlay.classList.remove('d-flex');
        }
        
        // Open mobile cart if needed
        if (window.innerWidth < 992 && typeof posAbrirCarritoMovil === 'function') {
            posAbrirCarritoMovil();
        }
    } catch(e) {
        console.error(e);
        mostrarAlerta('error', 'Error al cargar orden');
    }
}

async function posActualizarEstadoOrden(id, estado) {
    try {
        let res = await fetch('features/caja/controller_caja.php?action=actualizar_estado', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ id, estado })
        });
        let data = await res.json();
        
        if (data.status === 'ok') {
            let msg = 'Estado actualizado';
            if (estado === 'listo') msg = 'Pedido marcado como Listo';
            else if (estado === 'en_camino') msg = 'Pedido en camino';
            else if (estado === 'completado') msg = 'Pedido completado con éxito';
            
            mostrarAlerta('success', msg);
            // Refresh
            await posSeleccionarOrdenDelivery(id);
            renderPOSResumen();
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Acción rechazada',
                text: data.message || 'Error al actualizar estado',
                confirmButtonColor: '#e11d48',
                confirmButtonText: 'Aceptar'
            });
        }
    } catch(e) { 
        console.error(e);
        mostrarAlerta('error', 'Error al procesar estado'); 
    }
}

window.posDirectCobrar = async function(id, event, completarAuto = false) {
    if(event) event.stopPropagation();
    
    let hasUnsentItems = window.posCart && window.posCart.some(item => !item.fromDB);
    if (hasUnsentItems) {
        return Swal.fire({
            icon: 'warning',
            title: 'Pedido no enviado',
            text: 'Tienes subcategorias sin enviar a cocina. Haz clic en "Enviar Pedido" antes de cobrar.',
            confirmButtonColor: '#e11d48'
        });
    }

    await posSeleccionarOrdenDelivery(id);
    if (!window.posOrdenDeliveryActiva) return;
    
    let cart = [];
    document.querySelectorAll('.pos-cart-item').forEach(el => {
        let n = el.querySelector('.item-title').innerText;
        let c = parseInt(el.querySelector('.item-qty').innerText);
        let p = parseFloat(el.querySelector('.item-price').innerText.replace('S/ ', ''));
        cart.push({nombre: n, cantidad: c, precio: p, subtotal: c*p});
    });
    if(cart.length === 0) cart = window.posCart || [];

    let total = cart.reduce((acc, item) => acc + (item.precio * item.cantidad), 0);
    if (total === 0 && window.posOrdenDeliveryActiva.total) {
        total = parseFloat(window.posOrdenDeliveryActiva.total);
    }
    
    let lbl = 'Orden #' + window.posOrdenDeliveryActiva.numero_pedido;

    posAbrirModalCobro({
        items: cart,
        tipoPedidoDB: window.posOrdenDeliveryActiva.tipo_codigo,
        cliente: window.posOrdenDeliveryActiva.cliente_nombre || '',
        idMesa: window.posOrdenDeliveryActiva.table_id || null,
        orderId: id,
        isExistente: true,
        completarAuto: completarAuto,
        total: total,
        lbl: lbl
    });
};

window.posDirectEstado = async function(id, estado, event) {
    if(event) event.stopPropagation();
    await posActualizarEstadoOrden(id, estado);
};

window.posDirectPrecuenta = async function(idMesa, event) {
    if(event) event.stopPropagation();
    try {
        await fetch('features/caja/controller_caja.php?action=precuenta', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ id_mesa: idMesa })
        });
        mostrarAlerta('success', 'Precuenta solicitada');
        if (window.posEstadoMesas && window.posEstadoMesas[idMesa]) {
            window.posEstadoMesas[idMesa].estado = 'precuenta';
            if (typeof renderPOSMapaMesas === 'function') renderPOSMapaMesas();
        }
        renderPOSResumen();
    } catch(e) { mostrarAlerta('error', 'Error'); }
};

async function posCancelarOrden(id) {
    let r = await Swal.fire({
        title: '¿Cancelar esta orden?',
        text: 'La orden será marcada como cancelada.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#e11d48',
        cancelButtonColor: '#94a3b8',
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar'
    });
    if (!r.isConfirmed) return;
    
    try {
        await fetch('features/caja/controller_caja.php?action=cancelar_orden', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ id })
        });
        mostrarAlerta('success', 'Orden cancelada');
        window.posOrdenDeliveryActiva = null;
        window.posOrdenActivaId = null;
        // Reset cart overlay
        const cartOverlay = document.getElementById('pos-cart-overlay');
        if (cartOverlay) {
            cartOverlay.classList.remove('d-none');
            cartOverlay.classList.add('d-flex');
            cartOverlay.innerHTML = '<i data-lucide="file-text" style="width:48px;height:48px;color:#cbd5e1;margin-bottom:15px;"></i><span style="font-size:0.95rem;">Seleccione o cree una orden</span><span class="px-4" style="font-size:0.8rem;color:#94a3b8;margin-top:5px;">Visualiza los detalles haciendo clic en una orden pendiente, o haz clic en "Nueva orden".</span>';
        }
        const cartItems = document.getElementById('pos-cart-items');
        if (cartItems) cartItems.innerHTML = '';
        renderPOSResumen();
        lucide.createIcons();
    } catch(e) { mostrarAlerta('error', 'Error de conexión'); }
}

// ==========================================
// ASIGNAR REPARTIDOR (DELIVERY FLOW STEP 4)
// ==========================================
async function posAsignarRepartidor(orderId) {
    const { value: formData } = await Swal.fire({
        title: '🛵 Despachar Delivery',
        html: `
            <div class="text-left mt-2">
                <label class="font-weight-bold text-muted" style="font-size:0.85rem;">Nombre del Repartidor</label>
                <input id="swal-repartidor-nombre" class="form-control mb-3" placeholder="Ej. Carlos Mendoza" style="border-radius:8px;">
                <label class="font-weight-bold text-muted" style="font-size:0.85rem;">Costo de Envío (S/)</label>
                <input id="swal-shipping-cost" type="number" class="form-control mb-3" value="5.00" min="0" step="0.50" style="border-radius:8px;">
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        confirmButtonColor: '#0ea5e9',
        preConfirm: () => {
            let nombre = document.getElementById('swal-repartidor-nombre').value;
            if (!nombre) { Swal.showValidationMessage('Ingresa el nombre del repartidor'); return false; }
            return {
                nombre: nombre,
                shipping_cost: parseFloat(document.getElementById('swal-shipping-cost').value || 0)
            };
        }
    });

    if (!formData) return;

    try {
        await fetch('features/caja/controller_caja.php?action=asignar_repartidor', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                order_id: orderId,
                delivery_boy_id: 1, // Placeholder — in production this would be an actual ID
                shipping_cost: formData.shipping_cost
            })
        });
        mostrarAlerta('success', `Pedido despachado con ${formData.nombre}`);
        posSeleccionarOrdenDelivery(orderId);
        renderPOSResumen();
    } catch(e) { mostrarAlerta('error', 'Error de conexión'); }
}

// ==========================================
// COBRAR ORDEN EXISTENTE (DELIVERY/PICKUP)
// ==========================================
async function posCobrarOrdenExistente(orderId, total) {
    // RBAC: Solo cajero o admin pueden cobrar
    let rolActual = window.USER_ROL || 'admin';
    if (rolActual === 'mesero') {
        return mostrarAlerta('error', 'Acceso denegado. Solo un Cajero o Admin puede procesar pagos.');
    }
    
    let items = window.posOrdenDeliveryActivaItems || [];
    let numero = window.posOrdenDeliveryActiva ? window.posOrdenDeliveryActiva.numero_pedido : orderId;
    let tipo = window.posOrdenDeliveryActiva ? window.posOrdenDeliveryActiva.tipo_pedido : 'delivery';
    
    posAbrirModalCobro({
        isExistente: true,
        orderId: orderId,
        tipoPedidoDB: tipo,
        lbl: 'Pedido #' + numero,
        total: total,
        items: items
    });
}

function seleccionarMesaPOS(idMesa) {
    let mesa = window.posMesas.find(m => m.id == idMesa);
    if (!mesa) return;

    let st = window.posEstadoMesas[idMesa];
    if (st && st.estado === 'libre') {
        Swal.fire({
            title: `Apertura: Mesa ${mesa.numero}`,
            html: `
                <div class="text-left mt-3">
                    <label class="font-weight-bold text-muted" style="font-size: 0.85rem;">Número de personas</label>
                    <input id="swal-pos-personas" type="number" class="form-control mb-3" placeholder="Ej. 2" min="1" value="2" style="border-radius: 8px;">
                    
                    <label class="font-weight-bold text-muted" style="font-size: 0.85rem;">Seleccionar Mozo</label>
                    <select id="swal-pos-mozo" class="form-control" style="border-radius: 8px;">
                        <option value="1">Mozo 1 (Juan)</option>
                        <option value="2">Mozo 2 (María)</option>
                        <option value="3">Mozo 3 (Carlos)</option>
                    </select>
                </div>
            `,
            showCancelButton: true,
            confirmButtonText: 'Aceptar',
            cancelButtonText: 'Cancelar',
            confirmButtonColor: '#188df1',
            preConfirm: () => {
                let p = document.getElementById('swal-pos-personas').value;
                if (!p || p < 1) {
                    Swal.showValidationMessage('Ingrese un número de personas válido');
                }
                return {
                    personas: p,
                    mozo: document.getElementById('swal-pos-mozo').value
                }
            }
        }).then((result) => {
            if (result.isConfirmed) {
                st.estado = 'ocupada';
                st.inicio = Date.now();
                st.personas = result.value.personas;
                st.mozo = result.value.mozo;
                
                window.posMesaSeleccionada = mesa;
                window.posCart = [];
                window.posPedidosMesaActivos = [];
                posIniciarTimerMapa();
                seleccionarTipoOrdenPOS('mesa');
            }
        });
    } else {
        // Mesa ya ocupada o por cobrar — cargar pedidos existentes
        window.posMesaSeleccionada = mesa;
        seleccionarTipoOrdenPOS('mesa');
        posCargarPedidosMesa(mesa.id);
    }
}

// ==========================================
// CARGAR PEDIDOS EXISTENTES DE UNA MESA
// ==========================================
async function posCargarPedidosMesa(idMesa) {
    try {
        let res = await fetch('features/caja/controller_caja.php?action=pedidos_mesa&id_mesa=' + idMesa);
        let data = await res.json();
        if (data.status !== 'ok' || !data.data || data.data.length === 0) {
            // No hay pedidos — carrito vacío, listo para agregar
            window.posCart = [];
            window.posPedidosMesaActivos = [];
            renderPOSCart();
            actualizarBadgeOrden(); // Refresh badge
            return;
        }

        window.posPedidosMesaActivos = data.data;

        // Combinar todos los items de todos los pedidos en el carrito
        window.posCart = [];
        data.data.forEach(ped => {
            if (ped.items) {
                ped.items.forEach(item => {
                    let nombre = item.subcategoria_nombre || 'Subcategoria #' + item.id_subcategoria;
                    let existing = window.posCart.findIndex(x => x.nombre === nombre && x.fromDB);
                    if (existing >= 0) {
                        window.posCart[existing].cantidad += parseInt(item.cantidad);
                    } else {
                        window.posCart.push({
                            id: parseInt(item.id_subcategoria),
                            nombre: nombre,
                            precio: parseFloat(item.precio_unitario),
                            cantidad: parseInt(item.cantidad),
                            fromDB: true
                        });
                    }
                });
            }
        });
        renderPOSCart();
        actualizarBadgeOrden(); // Refresh badge with the loaded order number
    } catch(e) {
        console.error('Error al cargar pedidos de mesa:', e);
    }
}

function renderPOSZonasFiltros() {
    const container = document.getElementById('pos-zonas-filtros');
    if (!container) return;
    
    let actStyle = 'background-color:#f97316; color:white; border: 1px solid #ea580c;';
    let html = `<span class="badge ${window.posZonaActiva === 'todos' ? 'shadow-sm' : 'bg-white text-secondary border'} px-3 py-2" style="border-radius: 20px; cursor: pointer; font-size: 0.85rem; ${window.posZonaActiva === 'todos' ? actStyle : ''}" onclick="filtrarPOSMesasPorZona('todos')">Todas las zonas</span>`;
    
    window.posZonas.forEach(z => {
        let isAct = window.posZonaActiva == z.id;
        html += `<span class="badge ${isAct ? 'shadow-sm' : 'bg-white text-secondary border'} px-3 py-2" style="border-radius: 20px; cursor: pointer; font-size: 0.85rem; ${isAct ? actStyle : ''}" onclick="filtrarPOSMesasPorZona(${z.id})">${z.nombre}</span>`;
    });
    
    container.innerHTML = html;
}

function filtrarPOSMesasPorZona(zonaId) {
    window.posZonaActiva = zonaId;
    renderPOSZonasFiltros();
    renderPOSMapaMesas();
}

function renderPOSMapaMesas() {
    const container = document.getElementById('pos-zonas-mesas-grid');
    if (!container) return;
    if (!window.posZonas || window.posZonas.length === 0) {
        container.innerHTML = '<div class="text-center text-muted p-5">No hay zonas configuradas</div>';
        return;
    }

    let html = '';
    window.posZonas.forEach(z => {
        if (window.posZonaActiva !== 'todos' && window.posZonaActiva != z.id) return;

        let mesasZona = window.posMesas.filter(m => m.id_zona == z.id);
        if (mesasZona.length === 0) return;
        
        html += `<div class="mb-3">
            <h6 class="font-weight-bold mb-2 d-flex align-items-center" style="color: ${z.color || '#334155'}; font-size: 0.95rem;">
                <span style="display:inline-block;width:10px;height:10px;background:${z.color || '#334155'};border-radius:3px;margin-right:6px;"></span>
                ${z.nombre} <span class="text-muted ml-2" style="font-size:0.8rem;font-weight:normal;">(${mesasZona.length})</span>
            </h6>
            <div class="row mx-n1">`;
            
        mesasZona.forEach(m => {
            let st = window.posEstadoMesas[m.id] || { estado: 'libre', inicio: null };
            let bg = st.estado === 'libre' ? '#f0fdf4' : st.estado === 'ocupada' ? '#fef2f2' : '#faf5ff';
            let border = st.estado === 'libre' ? '#bbf7d0' : st.estado === 'ocupada' ? '#fecaca' : '#e9d5ff';
            let topBorder = st.estado === 'libre' ? '#22c55e' : st.estado === 'ocupada' ? '#ef4444' : '#a855f7';
            
            let badgeClass = st.estado === 'libre' ? 'bg-success text-white' : st.estado === 'ocupada' ? 'bg-danger text-white' : 'text-white';
            let badgeStyle = st.estado !== 'libre' && st.estado !== 'ocupada' ? 'background-color: #a855f7;' : '';
            let estadoHtml = '';
            
            if (st.estado === 'libre') {
                estadoHtml = `<span class="badge ${badgeClass} px-2 py-1" style="border-radius:6px; font-weight:600;">Libre</span>`;
            } else if (st.estado === 'ocupada') {
                estadoHtml = `<div class="font-weight-bold mb-1" style="color:#dc2626; font-size:0.8rem;" id="pos-map-timer-${m.id}">--:--</div>
                              <span class="badge ${badgeClass} px-2 py-1" style="border-radius:6px; font-weight:600;">Ocupada</span>`;
            } else {
                estadoHtml = `<span class="badge ${badgeClass} px-2 py-1" style="border-radius:6px; font-weight:600; ${badgeStyle}">Por cobrar</span>`;
            }
            
            html += `<div class="col-auto px-1 mb-2" style="width: 115px;">
                <div class="card h-100 pos-mesa-card shadow-sm border" style="border-radius:10px; border-top: 4px solid ${topBorder} !important; cursor:pointer; background-color:${bg}; border-color:${border} !important; transition:all 0.2s;" onclick="seleccionarMesaPOS(${m.id})">
                    <div class="card-body p-2 text-center d-flex flex-column align-items-center justify-content-center">
                        <div class="font-weight-bold text-dark" style="font-size:1rem; margin-bottom:2px;">${m.numero}</div>
                        <div class="text-muted mb-2" style="font-size:0.7rem;">${m.capacidad} pers.</div>
                        <div class="mt-auto w-100" style="line-height:1.1;">
                            ${estadoHtml}
                        </div>
                    </div>
                </div>
            </div>`;
        });
        html += `</div></div>`;
    });
    
    container.innerHTML = html;
    posIniciarTimerMapa();
}

function posFormatTimer(ms) {
    if (!ms) return '';
    let secs = Math.floor(ms / 1000);
    let h = Math.floor(secs / 3600), m = Math.floor((secs % 3600) / 60), s = secs % 60;
    return h > 0 ? h + 'h ' + String(m).padStart(2,'0') + 'm' : m + ':' + String(s).padStart(2,'0');
}

async function sincronizarMesasPOS() {
    try {
        let res = await fetch('features/mesas/controller_mesas.php?tipo=mesas&t=' + Date.now());
        let data = await res.json();
        if (data.status === 'ok') {
            let changed = false;
            data.data.forEach(m => {
                let oldState = window.posEstadoMesas[m.id]?.estado;
                let newState = m.estado_mesa || 'libre';
                if (oldState !== newState) {
                    changed = true;
                    window.posEstadoMesas[m.id] = { estado: newState, inicio: newState === 'ocupada' ? (window.posEstadoMesas[m.id]?.inicio || Date.now()) : null };
                }
            });
            if (changed) renderPOSMapaMesas();
        }
    } catch(e) {}
}

function posIniciarTimerMapa() {
    if (window.posTimerInterval) clearInterval(window.posTimerInterval);
    
    let lastSyncResumen = 0;
    let lastSyncMesa = 0;

    const update = () => {
        let now = Date.now();
        window.posMesas.forEach(m => {
            let st = window.posEstadoMesas[m.id];
            if (st && st.estado === 'ocupada' && st.inicio) {
                let diff = now - st.inicio;
                let el = document.getElementById('pos-map-timer-' + m.id);
                if (el) el.innerText = posFormatTimer(diff);
                if (window.posMesaSeleccionada && window.posMesaSeleccionada.id == m.id) {
                    let activeEl = document.getElementById('pos-mesa-activa-timer');
                    if (activeEl) activeEl.innerText = posFormatTimer(diff);
                }
            }
        });

        // Auto-sync Resumen tab every 1 segundo
        if (window.posTipoOrden === 'resumen' && (now - lastSyncResumen >= 1000)) {
            lastSyncResumen = now;
            renderPOSResumen(true);
        }

        // Auto-sync Mesas tab every 1 segundo
        if (window.posTipoOrden === 'mesa' && (now - lastSyncMesa >= 1000)) {
            lastSyncMesa = now;
            sincronizarMesasPOS();
        }
    };
    update();
    window.posTimerInterval = setInterval(update, 1000);
}

function renderPOSCategorias() {
    const container = document.getElementById('pos-categorias-container');
    if (!container || !window.datosApp.categorias || window.datosApp.categorias.length === 0) { if(container) container.innerHTML = '<div class="text-center text-muted p-2 w-100">No hay categorías</div>'; return; }
    if (!window.posCategoriaActiva) window.posCategoriaActiva = window.datosApp.categorias[0].id;
    container.innerHTML = window.datosApp.categorias.map(c => {
        let a = window.posCategoriaActiva == c.id;
        let imgHtml = c.imagen 
            ? `<div style="width:24px;height:24px;border-radius:6px;overflow:hidden;flex-shrink:0;margin-right:8px;"><img src="${c.imagen}" style="width:100%;height:100%;object-fit:cover;"></div>` 
            : '';
        return `<div class="px-2 py-2 shadow-sm d-flex align-items-center ${a ? 'bg-primary text-white font-weight-bold border border-primary' : 'bg-white text-dark border'}" style="border-radius:8px;cursor:pointer;flex-shrink:0;${a ? '' : 'border-color:#94a3b8!important;'}" onclick="seleccionarCategoriaPOS(${c.id})">
            ${imgHtml}
            <span>${c.nombre}</span>
        </div>`;
    }).join('');
    seleccionarCategoriaPOS(window.posCategoriaActiva);
}

function seleccionarCategoriaPOS(id) {
    window.posCategoriaActiva = id; window.posGrupoActivo = 'todos';
    let c = document.getElementById('pos-categorias-container');
    if (c) Array.from(c.children).forEach(ch => { let s = (ch.getAttribute('onclick')||'').includes(`seleccionarCategoriaPOS(${id})`); ch.className = s ? 'px-2 py-2 shadow-sm d-flex align-items-center bg-primary text-white font-weight-bold border border-primary' : 'px-2 py-2 shadow-sm d-flex align-items-center bg-white text-dark border'; ch.style.borderColor = s ? '' : '#94a3b8'; if(!s) ch.style.setProperty('border-color', '#94a3b8', 'important'); });
    renderPOSGrupos(); renderPOSSubcategorias();
}

function renderPOSGrupos() {
    let c = document.getElementById('pos-grupos-container'); if (!c) return;
    let g = window.datosApp.subcategorias.filter(p => p.id_categoria == window.posCategoriaActiva);
    if (g.length <= 1) { c.classList.add('d-none'); c.classList.remove('d-flex'); return; }
    c.classList.remove('d-none'); c.classList.add('d-flex');
    c.innerHTML = `<div class="px-3 py-1 shadow-sm ${window.posGrupoActivo==='todos'?'bg-secondary text-white':'bg-white text-dark border'}" style="border-radius:20px;font-size:0.85rem;cursor:pointer;" onclick="seleccionarGrupoPOS('todos')">Todos</div>` + g.map(gr => `<div class="px-3 py-1 shadow-sm ${window.posGrupoActivo==gr.id?'bg-secondary text-white':'bg-white text-dark border'}" style="border-radius:20px;font-size:0.85rem;cursor:pointer;" onclick="seleccionarGrupoPOS(${gr.id})">${gr.nombre}</div>`).join('');
}
function seleccionarGrupoPOS(id) { window.posGrupoActivo = id; renderPOSGrupos(); renderPOSSubcategorias(); }

function renderPOSSubcategorias() {
    let c = document.getElementById('pos-subcategorias-container'); if (!c) return;
    let grupos = window.datosApp.subcategorias.filter(p => p.id_categoria == window.posCategoriaActiva), items = [];
    if (window.posGrupoActivo === 'todos') { grupos.forEach(g => { items = items.concat(window.datosApp.productos.filter(pr => pr.id_subcategoria == g.id).map(pr => ({...pr, grupoNombre: g.nombre}))); }); }
    else { let g = grupos.find(gx => gx.id == window.posGrupoActivo); if (g) items = window.datosApp.productos.filter(pr => pr.id_subcategoria == g.id).map(pr => ({...pr, grupoNombre: g.nombre})); }
    let catActiva = window.datosApp.categorias.find(x => x.id == window.posCategoriaActiva);
    let htmlMitadYMitad = '';
    if (catActiva && catActiva.tiene_tamanos == 1 && window.posGrupoActivo === 'todos') {
        htmlMitadYMitad = `<div class="col-xl-2 col-lg-3 col-md-4 col-sm-4 col-6 mb-2 px-1">
            <div class="card h-100 shadow-sm border pos-item-card" style="border-radius:12px;cursor:pointer; border-color: #f59e0b !important; background-color: #fef3c7;" onclick="posAbrirModalMitadYMitad(${catActiva.id})">
                <div class="card-body p-2 d-flex flex-column align-items-center justify-content-center text-center">
                    <i data-lucide="split-square-horizontal" style="width:32px;height:32px;color:#d97706;margin-bottom:8px;"></i>
                    <h6 class="font-weight-bold text-dark mb-0" style="font-size:0.9rem; line-height: 1.1; color: #b45309 !important;">Mitad y Mitad</h6>
                    <div class="mt-auto pt-1 text-center"><span class="font-weight-bold" style="font-size:0.75rem; color:#b45309;">Combinar Sabores</span></div>
                </div>
            </div>
        </div>`;
    }

    if (items.length === 0 && htmlMitadYMitad === '') { c.innerHTML = '<div class="col-12 text-center text-muted p-5"><i data-lucide="inbox" style="width:48px;height:48px;color:#cbd5e1;margin-bottom:15px;"></i><br>No hay subcategorias</div>'; lucide.createIcons(); return; }
    
    c.innerHTML = htmlMitadYMitad + items.map(pr => {
        let n = pr.nombre === 'Única' || pr.nombre === 'Masa Tradicional' ? pr.grupoNombre : pr.nombre;
        let d = pr.descripcion ? `<div class="text-xs text-muted mt-1" style="display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden; line-height: 1.2;">${pr.descripcion}</div>` : '';
        let imgHtml = pr.imagen 
            ? `<div style="width:100%; height:90px; border-radius:12px 12px 0 0; overflow:hidden; border-bottom: 1px solid #e2e8f0; flex-shrink: 0;"><img src="${pr.imagen}" style="width:100%;height:100%;object-fit:cover;"></div>`
            : '';
            
        let hasSizes = pr.nombre_t1 && pr.nombre_t1.trim();
        if (hasSizes) { 
            let tamsHtml = [];
            for (let i = 1; i <= 4; i++) {
                if (pr['nombre_t' + i] && pr['nombre_t' + i].trim()) {
                    let tName = pr['nombre_t' + i];
                    let tPrice = parseFloat(pr['precio_' + i]) || 0;
                    tamsHtml.push(`<button class="btn btn-sm btn-outline-primary mb-1 w-100 d-flex justify-content-between align-items-center" style="border-radius:6px;font-size:0.75rem; padding: 0.2rem 0.5rem;" onclick='agregarAlCarrito(${pr.id_subcategoria}, ${JSON.stringify(n+" ("+tName+")")},${tPrice}, ${pr.id})'><span>${tName}</span><span class="font-weight-bold">S/${tPrice.toFixed(2)}</span></button>`);
                }
            }
            let b = tamsHtml.join('');
            return `<div class="col-xl-2 col-lg-3 col-md-4 col-sm-4 col-6 mb-2 px-1">
                <div class="card h-100 shadow-sm border" style="border-radius:12px; border-color: #94a3b8 !important;">
                    ${imgHtml}
                    <div class="card-body p-2 d-flex flex-column">
                        <h6 class="font-weight-bold text-dark mb-0" style="font-size:0.85rem; line-height: 1.1;">${n}</h6>
                        <div class="mt-auto pt-2">${b}</div>
                    </div>
                </div>
            </div>`; 
        }
        
        let p = pr.precio || 0;
        return `<div class="col-xl-2 col-lg-3 col-md-4 col-sm-4 col-6 mb-2 px-1">
            <div class="card h-100 shadow-sm border pos-item-card" style="border-radius:12px;cursor:pointer; border-color: #94a3b8 !important;" onclick='agregarAlCarrito(${pr.id_subcategoria}, ${JSON.stringify(n)},${p}, ${pr.id})'>
                ${imgHtml}
                <div class="card-body p-2 d-flex flex-column">
                    <h6 class="font-weight-bold text-dark mb-0" style="font-size:0.85rem; line-height: 1.1;">${n}</h6>
                    <div class="mt-auto pt-1 text-right"><span class="font-weight-bold text-theme-primary" style="font-size:1rem;">S/${parseFloat(p).toFixed(2)}</span></div>
                </div>
            </div>
        </div>`;
    }).join('');
    lucide.createIcons();
}

function agregarAlCarrito(id, nombre, precio, producto_id = null) { 
    let prod = window.datosApp.subcategorias.find(p => p.id == id);
    if (!prod) return;
    
    let tieneModificadores = false;
    if (window.datosApp.modificadores) {
        tieneModificadores = window.datosApp.modificadores.some(m => {
            let aplicaStr = m.aplica_a ? m.aplica_a.trim() : '';
            if (aplicaStr === '') return true;
            let aplica = aplicaStr.split(',');
            return aplica.includes('todos') || aplica.includes(prod.id_categoria.toString());
        });
    }

    if (tieneModificadores) {
        abrirModalConfigurarPOS(id, nombre, precio, prod.id_categoria, false, null, producto_id);
        return;
    }

    agregarItemAlCarritoLogico(id, nombre, precio, '', null, null, producto_id);
}

function agregarItemAlCarritoLogico(id, nombre, precio, notas, precio_base = null, indexToUpdate = null, producto_id = null) {
    let p_base = precio_base !== null ? parseFloat(precio_base) : parseFloat(precio);
    if (indexToUpdate !== null) {
        window.posCart[indexToUpdate].precio = parseFloat(precio);
        window.posCart[indexToUpdate].notas = notas;
    } else {
        let i = window.posCart.findIndex(x => x.nombre === nombre && x.notas === notas && !x.fromDB); 
        if (i >= 0) {
            window.posCart[i].cantidad++; 
        } else {
            window.posCart.push({ id, nombre, precio: parseFloat(precio), cantidad: 1, fromDB: false, notas: notas, precio_original: p_base, producto_id: producto_id }); 
        }
    }
    renderPOSCart(); 
}

function cambiarCantidadPOS(i, d) { if (!window.posCart[i] || window.posCart[i].fromDB) return; window.posCart[i].cantidad += d; if (window.posCart[i].cantidad <= 0) window.posCart.splice(i, 1); renderPOSCart(); }
function eliminarDelCarritoPOS(i) { if (!window.posCart[i] || window.posCart[i].fromDB) return; window.posCart.splice(i, 1); renderPOSCart(); }

function abrirModalConfigurarPOS(id_subcategoria, nombre, precio, id_categoria, fromCart = false, indexInCart = null, producto_id = null) {
    let notasPrevias = '';
    let precio_base = parseFloat(precio);
    
    if (fromCart && indexInCart !== null) {
        let item = window.posCart[indexInCart];
        notasPrevias = item.notas || '';
        precio_base = item.precio_original || parseFloat(item.precio);
    }
    
    // Extraer comentario puro y modificadores seleccionados previos (simple string parsing o empezar vacío)
    // Para simplificar, en la edición cargamos todo el texto en "notas" y permitimos re-editar.
    // Lo ideal es que el cajero simplemente re-escriba o veamos la nota completa.
    let textoComentario = notasPrevias.includes('Nota:') ? notasPrevias.split('Nota:')[1].trim() : notasPrevias;
    if (textoComentario.includes('|')) textoComentario = textoComentario.split('|')[0].trim();

    let modificadoresHtml = '';
    let modsAplicables = [];
    if (window.datosApp.modificadores) {
        modsAplicables = window.datosApp.modificadores.filter(m => {
            let aplicaStr = m.aplica_a ? m.aplica_a.trim() : '';
            if (aplicaStr === '') return true;
            let aplica = aplicaStr.split(',');
            return aplica.includes('todos') || aplica.includes(id_categoria.toString());
        });
    }

    if (modsAplicables.length > 0) {
        modificadoresHtml += `<div class="mt-3 mb-2 font-weight-bold text-muted" style="font-size:0.8rem; letter-spacing:0.5px;">EXTRAS DISPONIBLES</div>`;
        modsAplicables.forEach(m => {
            let extraPrice = parseFloat(m.precio_extra);
            let priceText = extraPrice > 0 ? `+ S/ ${extraPrice.toFixed(2)}` : 'Gratis';
            let reqTexto = m.requiere_texto == 1 ? `<input type="text" id="mod_text_${m.id}" class="form-control form-control-sm mt-1 d-none" placeholder="Especificar..." style="font-size:0.8rem; border-radius:6px;">` : '';
            
            // Check if it was checked before (naive string match)
            let isChecked = notasPrevias.includes(m.nombre) ? 'checked' : '';
            
            modificadoresHtml += `
            <div class="card shadow-sm mb-2" style="border-radius:10px; border:1px solid #e2e8f0;">
                <div class="card-body p-2 d-flex flex-column">
                    <label class="d-flex align-items-center mb-0" style="cursor:pointer; width:100%;">
                        <input type="checkbox" class="modificador-checkbox mr-2" data-id="${m.id}" data-name="${m.nombre}" data-price="${extraPrice}" data-reqtext="${m.requiere_texto}" ${isChecked} onchange="if(this.checked && ${m.requiere_texto}) { document.getElementById('mod_text_${m.id}').classList.remove('d-none'); } else if(${m.requiere_texto}) { document.getElementById('mod_text_${m.id}').classList.add('d-none'); }">
                        <div class="flex-grow-1">
                            <div style="font-size:0.85rem; font-weight:600; color:#1e293b;">${m.nombre}</div>
                            <div style="font-size:0.75rem; color:#16a34a; font-weight:500;">${priceText}</div>
                        </div>
                    </label>
                    ${reqTexto}
                </div>
            </div>`;
        });
    }

    Swal.fire({
        title: 'Configurar ' + nombre,
        html: `
            <div class="text-left">
                ${modificadoresHtml}
                <div class="mt-3 mb-2 font-weight-bold text-muted" style="font-size:0.8rem; letter-spacing:0.5px;">COMENTARIO / NOTA</div>
                <textarea id="swal-pos-nota" class="form-control" rows="2" placeholder="Ej: Sin cebolla, alergia al maní..." style="border-radius:8px; font-size:0.9rem;">${textoComentario}</textarea>
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        reverseButtons: true,
        customClass: { confirmButton: 'btn btn-primary px-4 font-weight-bold', cancelButton: 'btn px-4 font-weight-bold', actions: 'd-flex' },
        buttonsStyling: false,
        didOpen: () => {
            const cancelBtn = Swal.getCancelButton();
            cancelBtn.style.backgroundColor = '#717c8a'; 
            cancelBtn.style.color = '#ffffff';
            cancelBtn.style.border = 'none';
            cancelBtn.style.marginLeft = '8px';
            const confirmBtn = Swal.getConfirmButton();
            confirmBtn.style.backgroundColor = '#188df1'; 
            confirmBtn.style.color = '#ffffff';
            confirmBtn.style.border = 'none';
            Swal.getActions().insertBefore(confirmBtn, cancelBtn);
            
            // Trigger change for already checked items to show text inputs
            document.querySelectorAll('.modificador-checkbox:checked').forEach(cb => {
                if (cb.dataset.reqtext == "1") {
                    document.getElementById('mod_text_' + cb.dataset.id).classList.remove('d-none');
                }
            });
        },
        preConfirm: () => {
            let nota = document.getElementById('swal-pos-nota').value.trim();
            let precioFinal = precio_base;
            let extrasAplicados = [];
            
            document.querySelectorAll('.modificador-checkbox:checked').forEach(cb => {
                let mName = cb.dataset.name;
                let mPrice = parseFloat(cb.dataset.price);
                precioFinal += mPrice;
                
                let mText = '';
                if (cb.dataset.reqtext == "1") {
                    mText = document.getElementById('mod_text_' + cb.dataset.id).value.trim();
                    if (mText) mName += ` (${mText})`;
                }
                extrasAplicados.push(mPrice > 0 ? `+ ${mName} (S/${mPrice.toFixed(2)})` : `+ ${mName}`);
            });
            
            let finalNotaStr = '';
            if (extrasAplicados.length > 0) finalNotaStr += extrasAplicados.join(' | ');
            if (nota) finalNotaStr += (finalNotaStr ? ' | Nota: ' : 'Nota: ') + nota;
            
            return { precioFinal, finalNotaStr };
        }
    }).then((r) => {
        if (r.isConfirmed) {
            agregarItemAlCarritoLogico(id_subcategoria, nombre, r.value.precioFinal, r.value.finalNotaStr, precio_base, fromCart ? indexInCart : null, window.itemConfigPOS ? window.itemConfigPOS.producto_id : null);
        }
    });
}

function renderPOSCart() {
    let c = document.getElementById('pos-cart-items'), bc = document.getElementById('pos-cart-count'), ts = document.getElementById('pos-subtotal'), tt = document.getElementById('pos-total');
    let fbc = document.getElementById('pos-fab-cart-count');
    let bnc = document.getElementById('pos-bottom-nav-cart-count');
    if (!c) return;
    let ti = 0, sub = 0; window.posCart.forEach(x => { ti += x.cantidad; sub += x.cantidad * x.precio; });
    if (bc) bc.innerText = ti; if (ts) ts.innerText = 'S/ ' + sub.toFixed(2); if (tt) tt.innerText = 'S/ ' + sub.toFixed(2);
    if (fbc) fbc.innerText = ti;
    bnc = document.getElementById('pos-bottom-nav-cart-count');
    if (bnc) bnc.innerText = ti;
    if (window.posCart.length === 0) { c.innerHTML = '<div class="text-center text-muted py-5 d-flex flex-column align-items-center justify-content-center h-100"><i data-lucide="shopping-bag" style="width:48px;height:48px;color:#cbd5e1;margin-bottom:15px;"></i><span style="font-size:0.95rem;">La orden está vacía</span><span style="font-size:0.8rem;color:#94a3b8;margin-top:5px;">Agrega subcategorias desde el menú</span></div>'; lucide.createIcons(); renderPOSFooterActions(); return; }
    
    let existingItems = window.posCart.filter(x => x.fromDB);
    let newItems = window.posCart.filter(x => !x.fromDB);
    let html = '';
    
    // Items existentes (de la BD) — no editables
    if (existingItems.length > 0) {
        html += '<div class="px-3 py-1 text-muted font-weight-bold d-flex align-items-center" style="font-size:0.7rem; background:#f1f5f9; letter-spacing:0.5px;"><i data-lucide="check-circle" style="width:12px;height:12px;margin-right:5px;"></i>PEDIDOS ANTERIORES</div>';
        
        html += `<div class="d-flex px-3 py-2 border-bottom text-muted font-weight-bold align-items-center" style="font-size:0.8rem; background:#ffffff;">
            <div style="min-width:40px;">Cant</div>
            <div class="flex-grow-1 pr-2">Descripción</div>
            <div style="min-width:60px; text-align:right;">Importe</div>
        </div>`;
        
        existingItems.forEach(item => {
            let tot = item.cantidad * item.precio;
            let notasHtml = item.notas ? `<div class="text-danger mt-1 font-weight-bold" style="font-size:0.75rem; line-height:1.1;">${item.notas}</div>` : '';
            html += `<div class="d-flex px-3 py-2 border-bottom align-items-start" style="background:#ffffff;">
                <div class="text-dark pr-2" style="font-size:0.85rem; min-width:40px;">${item.cantidad}</div>
                <div class="flex-grow-1 pr-2">
                    <div class="text-dark" style="font-size:0.85rem; line-height:1.2;">${item.nombre}</div>
                    ${notasHtml}
                </div>
                <div class="font-weight-bold text-dark" style="min-width:60px; text-align:right; font-size:0.85rem;">${tot.toFixed(2)}</div>
            </div>`;
        });
    }
    
    // Items nuevos — editables
    if (newItems.length > 0) {
        html += '<div class="px-3 py-1 text-success font-weight-bold d-flex align-items-center" style="font-size:0.7rem; background:#f0fdf4; letter-spacing:0.5px;"><i data-lucide="plus-circle" style="width:12px;height:12px;margin-right:5px;"></i>NUEVOS (se enviará a preparación)</div>';
        newItems.forEach(item => {
            let i = window.posCart.indexOf(item);
            let tot = item.cantidad * item.precio;
            let idCat = window.datosApp.subcategorias.find(p => p.id == item.id)?.id_categoria || 0;
            let nombreJs = JSON.stringify(item.nombre).replace(/"/g, '&quot;');
            let notasHtml = item.notas ? `<div class="text-danger mt-1 font-weight-bold" style="font-size:0.7rem; line-height:1.1;">${item.notas}</div>` : '';
            html += `<div class="d-flex p-2 border-bottom align-items-center">
                <div class="d-flex align-items-center pr-2">
                    <button class="btn btn-sm btn-light border p-0 d-flex justify-content-center align-items-center" style="width:22px;height:22px;border-radius:4px;" onclick="cambiarCantidadPOS(${i},-1)"><i data-lucide="minus" style="width:12px;height:12px;"></i></button>
                    <span class="mx-1 font-weight-bold" style="min-width:16px;text-align:center;font-size:0.8rem;">${item.cantidad}</span>
                    <button class="btn btn-sm btn-light border p-0 d-flex justify-content-center align-items-center" style="width:22px;height:22px;border-radius:4px;" onclick="cambiarCantidadPOS(${i},1)"><i data-lucide="plus" style="width:12px;height:12px;"></i></button>
                </div>
                <div class="flex-grow-1 pr-2">
                    <div class="font-weight-bold text-dark" style="font-size:0.75rem; line-height:1.2;">${item.nombre}</div>
                    ${notasHtml}
                    <div class="text-theme-primary font-weight-bold mt-1" style="font-size:0.75rem;">S/${item.precio.toFixed(2)}</div>
                </div>
                <div class="ml-2 font-weight-bold text-dark" style="min-width:45px; text-align:right; font-size:0.8rem;">S/${tot.toFixed(2)}</div>
                <div class="ml-2 d-flex flex-column" style="gap:4px;">
                    <button class="btn btn-sm btn-light border p-0 d-flex justify-content-center align-items-center" style="width:24px;height:24px;border-radius:4px;color:#64748b;" onclick="abrirModalConfigurarPOS(${item.id}, ${nombreJs}, ${item.precio_original || item.precio}, ${idCat}, true, ${i})" title="Opciones / Notas"><i data-lucide="settings-2" style="width:14px;height:14px;"></i></button>
                    <button class="btn btn-sm btn-light border text-danger p-0 d-flex justify-content-center align-items-center" style="width:24px;height:24px;border-radius:4px;" onclick="eliminarDelCarritoPOS(${i})" title="Eliminar"><i data-lucide="trash-2" style="width:14px;height:14px;"></i></button>
                </div>
            </div>`;
        });
    }
    
    // Fallback: if no separation needed (delivery/mostrador with no fromDB items)
    if (existingItems.length === 0 && newItems.length === 0) {
        window.posCart.forEach((item, i) => {
            let tot = item.cantidad * item.precio;
            let idCat = window.datosApp.subcategorias.find(p => p.id == item.id)?.id_categoria || 0;
            let nombreJs = JSON.stringify(item.nombre).replace(/"/g, '&quot;');
            let notasHtml = item.notas ? `<div class="text-danger mt-1 font-weight-bold" style="font-size:0.7rem; line-height:1.1;">${item.notas}</div>` : '';
            html += `<div class="d-flex p-2 border-bottom align-items-center">
                <div class="d-flex align-items-center pr-2">
                    <button class="btn btn-sm btn-light border p-0 d-flex justify-content-center align-items-center" style="width:22px;height:22px;border-radius:4px;" onclick="cambiarCantidadPOS(${i},-1)"><i data-lucide="minus" style="width:12px;height:12px;"></i></button>
                    <span class="mx-1 font-weight-bold" style="min-width:16px;text-align:center;font-size:0.8rem;">${item.cantidad}</span>
                    <button class="btn btn-sm btn-light border p-0 d-flex justify-content-center align-items-center" style="width:22px;height:22px;border-radius:4px;" onclick="cambiarCantidadPOS(${i},1)"><i data-lucide="plus" style="width:12px;height:12px;"></i></button>
                </div>
                <div class="flex-grow-1 pr-2">
                    <div class="font-weight-bold text-dark" style="font-size:0.75rem; line-height:1.2;">${item.nombre}</div>
                    ${notasHtml}
                    <div class="text-theme-primary font-weight-bold mt-1" style="font-size:0.75rem;">S/${item.precio.toFixed(2)}</div>
                </div>
                <div class="ml-2 font-weight-bold text-dark" style="min-width:45px; text-align:right; font-size:0.8rem;">S/${tot.toFixed(2)}</div>
                <div class="ml-2 d-flex flex-column" style="gap:4px;">
                    <button class="btn btn-sm btn-light border p-0 d-flex justify-content-center align-items-center" style="width:24px;height:24px;border-radius:4px;color:#64748b;" onclick="abrirModalConfigurarPOS(${item.id}, ${nombreJs}, ${item.precio_original || item.precio}, ${idCat}, true, ${i})" title="Opciones / Notas"><i data-lucide="settings-2" style="width:14px;height:14px;"></i></button>
                    <button class="btn btn-sm btn-light border text-danger p-0 d-flex justify-content-center align-items-center" style="width:24px;height:24px;border-radius:4px;" onclick="eliminarDelCarritoPOS(${i})" title="Eliminar"><i data-lucide="trash-2" style="width:14px;height:14px;"></i></button>
                </div>
            </div>`;
        });
    }
    
    c.innerHTML = html;
    lucide.createIcons();
    c.scrollTop = c.scrollHeight;
    renderPOSFooterActions();
}

// ==========================================
// BOTONES DINÁMICOS SEGÚN ROL Y TIPO DE ORDEN
// ==========================================
function renderPOSFooterActions() {
    const container = document.getElementById('pos-footer-actions');
    if (!container) return;
    
    let rol = window.USER_ROL || 'admin';
    let tipo = window.posTipoOrden || 'mesa';
    let esMesero = (rol === 'mesero');
    let html = '';

    if (tipo === 'mesa') {
        // === MESA ===
        html += `<div class="row mx-n1">
            <div class="col-4 px-1">
                <button class="btn btn-white w-100 py-2 border shadow-sm text-danger font-weight-bold d-flex justify-content-center align-items-center" onclick="limpiarPOS()" style="border-radius: 8px; font-size:0.85rem;">
                    <i data-lucide="trash-2" style="width:16px;height:16px;margin-right:4px;"></i> Cancelar
                </button>
            </div>
            <div class="col-8 px-1">
                <button class="btn w-100 py-2 font-weight-bold text-white shadow d-flex justify-content-center align-items-center" onclick="enviarPedidoMesaPOS()" style="border-radius: 8px; font-size:0.95rem; background-color:#22c55e; border-color:#22c55e;">
                    <i data-lucide="send" style="width:18px;height:18px;margin-right:6px;"></i> Enviar Pedido
                </button>
            </div>
        </div>`;
        // Segunda fila: Precuenta siempre, Cobrar solo si NO es mesero
        html += `<div class="row mx-n1 mt-2">
            <div class="${esMesero ? 'col-12' : 'col-6'} px-1">
                <button class="btn btn-white w-100 py-2 border shadow-sm text-dark font-weight-bold d-flex justify-content-center align-items-center" onclick="imprimirPrecuentaPOS()" style="border-radius: 8px; font-size:0.85rem;">
                    <i data-lucide="receipt" style="width:16px;height:16px;margin-right:4px;"></i> Precuenta
                </button>
            </div>`;
        if (!esMesero) {
            html += `<div class="col-6 px-1">
                <button class="btn w-100 py-2 font-weight-bold text-white shadow d-flex justify-content-center align-items-center" onclick="enviarPedidoPOS()" style="border-radius: 8px; font-size:0.85rem; background-color:#f97316; border-color:#ea580c;">
                    <i data-lucide="banknote" style="width:16px;height:16px;margin-right:4px;"></i> Cobrar
                </button>
            </div>`;
        }
        html += '</div>';
    } else if (tipo === 'mostrador') {
        // === MOSTRADOR ===
        html += `<div class="row mx-n1">
            <div class="col-4 px-1">
                <button class="btn btn-white w-100 py-2 border shadow-sm text-danger font-weight-bold d-flex justify-content-center align-items-center" onclick="limpiarPOS()" style="border-radius: 8px; font-size:0.85rem;">
                    <i data-lucide="trash-2" style="width:16px;height:16px;margin-right:4px;"></i> Cancelar
                </button>
            </div>
            <div class="col-8 px-1">
                <button class="btn w-100 py-2 font-weight-bold text-white shadow d-flex justify-content-center align-items-center" onclick="enviarPedidoMostradorPOS()" style="border-radius: 8px; font-size:0.95rem; background-color:#22c55e; border-color:#22c55e;">
                    <i data-lucide="send" style="width:18px;height:18px;margin-right:6px;"></i> Enviar Pedido
                </button>
            </div>
        </div>`;
        html += `<div class="row mx-n1 mt-2">
            <div class="col-6 px-1">
                <button class="btn btn-white w-100 py-2 border shadow-sm text-dark font-weight-bold d-flex justify-content-center align-items-center" onclick="imprimirPrecuentaPOS()" style="border-radius: 8px; font-size:0.85rem;">
                    <i data-lucide="receipt" style="width:16px;height:16px;margin-right:4px;"></i> Precuenta
                </button>
            </div>
            <div class="col-6 px-1">
                <button class="btn w-100 py-2 font-weight-bold text-white shadow d-flex justify-content-center align-items-center" onclick="enviarPedidoPOS()" style="border-radius: 8px; font-size:0.85rem; background-color:#f97316; border-color:#ea580c;">
                    <i data-lucide="banknote" style="width:16px;height:16px;margin-right:4px;"></i> Cobrar
                </button>
            </div>
        </div>`;
    } else if (tipo === 'resumen') {
        // === DASHBOARD (ORDEN EXISTENTE) ===
        let isMesa = window.posMesaSeleccionada != null;
        let idActiva = window.posOrdenDeliveryActiva ? window.posOrdenDeliveryActiva.id : (isMesa && window.posPedidosMesaActivos.length > 0 ? window.posPedidosMesaActivos[0].id : null);
        let estadoPago = window.posOrdenDeliveryActiva ? window.posOrdenDeliveryActiva.estado_pago : (isMesa && window.posPedidosMesaActivos.length > 0 ? window.posPedidosMesaActivos[0].estado_pago : 'pendiente');
        
        if (idActiva) {
            let mostrarCobrar = !esMesero && estadoPago !== 'pagado';
            
            html += `<div class="row mx-n1">
                <div class="${!mostrarCobrar ? 'col-12' : 'col-6'} px-1">
                    <button class="btn btn-white w-100 py-2 border shadow-sm text-dark font-weight-bold d-flex justify-content-center align-items-center" onclick="imprimirPrecuentaPOS()" style="border-radius: 8px; font-size:0.85rem;">
                        <i data-lucide="receipt" style="width:16px;height:16px;margin-right:4px;"></i> Precuenta
                    </button>
                </div>`;
            if (mostrarCobrar) {
                let compAuto = isMesa ? 'true' : 'false';
                html += `<div class="col-6 px-1">
                    <button class="btn w-100 py-2 font-weight-bold text-white shadow d-flex justify-content-center align-items-center" onclick="posDirectCobrar(${idActiva}, event, ${compAuto})" style="border-radius: 8px; font-size:0.85rem; background-color:#f97316; border-color:#ea580c;">
                        <i data-lucide="banknote" style="width:16px;height:16px;margin-right:4px;"></i> Cobrar
                    </button>
                </div>`;
            }
            html += `</div>`;
        }
    }
    // delivery buttons are handled by pos-btn-group-delivery separately
    
    container.innerHTML = html;
    lucide.createIcons();
}

// ==========================================
// ENVIAR PEDIDO MESA (guardar como pendiente)
// Solo envía los items NUEVOS (no los que ya están en BD)
// ==========================================
async function enviarPedidoMesaPOS() {
    if (window.posCart.length === 0) {
        return Swal.fire({
            icon: 'warning',
            title: 'Orden vacía',
            text: 'Agrega subcategorias primero.',
            confirmButtonColor: '#e11d48'
        });
    }
    if (!window.posMesaSeleccionada) return mostrarAlerta('warning', 'Selecciona una mesa');

    // Filtrar solo items nuevos (sin fromDB)
    let nuevosItems = window.posCart.filter(x => !x.fromDB);
    if (nuevosItems.length === 0) {
        return Swal.fire({
            icon: 'info',
            title: 'Sin subcategorias nuevos',
            text: 'No hay subcategorias nuevos para enviar a cocina. Agrega subcategorias del menú.',
            confirmButtonColor: '#3b82f6'
        });
    }

    let mesa = window.posMesaSeleccionada;
    let subtotal = nuevosItems.reduce((s, x) => s + x.cantidad * x.precio, 0);

    try {
        let res = await fetch('features/caja/controller_caja.php?action=guardar_orden', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                tipo_pedido: 'salon',
                id_mesa: mesa.id,
                cliente_nombre: 'Mesa ' + mesa.numero,
                subtotal: subtotal,
                descuento: 0,
                total: subtotal,
                items: nuevosItems.map(i => ({ id_subcategoria: i.id || 1, producto_id: i.producto_id || 0, cantidad: i.cantidad, precio: i.precio, nombre: i.nombre, notas: i.notas }))
            })
        });
        let data = await res.json();
        if (data.status === 'ok') {
            Swal.fire({
                icon: 'success',
                title: 'Enviado a Pantallas KDS',
                html: `<b>${data.numero_pedido}</b><br>Mesa ${mesa.numero} · ${nuevosItems.length} subcategoria(s) nuevo(s)<br><b>S/ ${subtotal.toFixed(2)}</b>`,
                confirmButtonColor: '#22c55e',
                confirmButtonText: 'Aceptar',
                timer: 3000
            });
            
            // Marcar mesa como ocupada
            let st = window.posEstadoMesas[mesa.id];
            if (st) st.estado = 'ocupada';
            
            // Recargar todos los pedidos de la mesa (incluyendo el nuevo)
            posCargarPedidosMesa(mesa.id);
        } else {
            mostrarAlerta('error', data.message || 'Error al enviar pedido');
        }
    } catch(e) {
        mostrarAlerta('error', 'Error de conexión');
    }
}

// ==========================================
// ENVIAR PEDIDO MOSTRADOR (guardar como pendiente)
// ==========================================
async function enviarPedidoMostradorPOS() {
    if (window.posCart.length === 0) {
        return Swal.fire({
            icon: 'warning',
            title: 'Orden vacía',
            text: 'Agrega subcategorias primero.',
            confirmButtonColor: '#e11d48'
        });
    }

    // Filtrar solo items nuevos (sin fromDB)
    let nuevosItems = window.posCart.filter(x => !x.fromDB);
    if (nuevosItems.length === 0) {
        return Swal.fire({
            icon: 'info',
            title: 'Sin subcategorias nuevos',
            text: 'No hay subcategorias nuevos para enviar a cocina.',
            confirmButtonColor: '#3b82f6'
        });
    }

    let subtotal = nuevosItems.reduce((s, x) => s + x.cantidad * x.precio, 0);
    
    // Leer valores reales de los inputs
    let inputCliente = document.getElementById('pos-delivery-cliente');
    let clienteNombre = inputCliente && inputCliente.value.trim() !== '' ? inputCliente.value.trim() : (window.posClienteSeleccionado ? window.posClienteSeleccionado.nombre : 'Cliente Mostrador');
    
    let inputTelefono = document.getElementById('pos-delivery-telefono');
    let clienteTelefono = inputTelefono ? inputTelefono.value.trim() : '';

    let inputDireccion = document.getElementById('pos-delivery-direccion');
    let clienteDireccion = inputDireccion ? inputDireccion.value.trim() : '';

    let inputPickup = document.getElementById('pos-pickup-time');
    let pickupTime = inputPickup ? inputPickup.value : '';

    let selectTipo = document.getElementById('pos-delivery-tipo');
    let tipoPedidoDB = selectTipo ? selectTipo.value : 'llevar'; // puede ser llevar, recoger, delivery
    
    // Formatear tipo para imprimir
    let tipoImpreso = tipoPedidoDB === 'llevar' ? 'para llevar' : tipoPedidoDB === 'recoger' ? 'recoger' : 'delivery';

    try {
        let payload = {
            order_id: window.posOrdenDeliveryActiva ? window.posOrdenDeliveryActiva.id : 0,
            tipo_pedido: tipoPedidoDB,
            cliente_nombre: clienteNombre,
            cliente_telefono: clienteTelefono,
            cliente_direccion: clienteDireccion,
            pickup_time: pickupTime,
            subtotal: subtotal,
            descuento: 0,
            total: subtotal,
            items: nuevosItems.map(i => ({ id_subcategoria: i.id || 1, producto_id: i.producto_id || 0, cantidad: i.cantidad, precio: i.precio, nombre: i.nombre, notas: i.notas }))
        };

        let res = await fetch('features/caja/controller_caja.php?action=guardar_orden', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });
        let data = await res.json();
        if (data.status === 'ok') {
            Swal.fire({
                icon: 'success',
                title: 'Enviado a Pantallas KDS',
                html: `<b>${data.numero_pedido}</b><br>${clienteNombre} · ${nuevosItems.length} subcategoria(s) nuevo(s)<br><b>S/ ${subtotal.toFixed(2)}</b>`,
                confirmButtonColor: '#22c55e',
                confirmButtonText: 'Aceptar',
                timer: 3000
            });
            
            // Limpiamos el POS silenciosamente ya que en mostrador se generó la orden
            window.posCart = []; 
            window.posOrdenDeliveryActiva = null;
            window.posOrdenActivaId = null;
            renderPOSCart();
            actualizarBadgeOrden();
            ['pos-delivery-cliente', 'pos-delivery-telefono', 'pos-delivery-direccion'].forEach(id => {
                let e = document.getElementById(id);
                if (e) e.value = '';
            });
        } else {
            mostrarAlerta('error', data.message || 'Error al enviar pedido');
        }
    } catch(e) {
        mostrarAlerta('error', 'Error de red');
    }
}

// ==========================================
// CAMBIAR MESA
// ==========================================
function posAbrirModalCambiarMesa() {
    if (!window.posMesaSeleccionada) {
        return mostrarAlerta('warning', 'No hay una mesa seleccionada para cambiar.');
    }

    let mesasLibres = window.posMesas.filter(m => m.estado_mesa === 'libre');
    if (mesasLibres.length === 0) {
        return mostrarAlerta('info', 'No hay mesas libres disponibles para el cambio.');
    }

    let optionsHtml = mesasLibres.map(m => `<option value="${m.id}">Mesa ${m.numero}</option>`).join('');

    Swal.fire({
        title: '🔄 Cambiar de Mesa',
        html: `
            <div class="mb-3 text-left">
                <label class="form-label font-weight-bold text-muted">Mesa Origen:</label>
                <div class="form-control bg-light">Mesa ${window.posMesaSeleccionada.numero}</div>
            </div>
            <div class="text-left">
                <label class="form-label font-weight-bold text-theme-primary">Seleccionar Mesa Destino:</label>
                <select id="pos-select-cambiar-mesa" class="form-control" style="border-radius:8px;">
                    <option value="" disabled selected>-- Seleccione una mesa libre --</option>
                    ${optionsHtml}
                </select>
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        confirmButtonColor: '#3b82f6',
        preConfirm: () => {
            const select = document.getElementById('pos-select-cambiar-mesa');
            if (!select.value) {
                Swal.showValidationMessage('Por favor seleccione una mesa de destino');
                return false;
            }
            return select.value;
        }
    }).then(async (result) => {
        if (result.isConfirmed) {
            let idMesaDestino = result.value;
            let idMesaOrigen = window.posMesaSeleccionada.id;

            let data;
            try {
                let res = await fetch('features/caja/controller_caja.php?action=cambiar_mesa', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        id_mesa_origen: idMesaOrigen,
                        id_mesa_destino: idMesaDestino
                    })
                });
                data = await res.json();
            } catch (error) {
                console.error('Error de red cambiar mesa:', error);
                mostrarAlerta('error', 'Error de red al intentar cambiar la mesa');
                return;
            }

            if (data.status === 'ok') {
                // Actualizar estados locales
                if (window.posEstadoMesas[idMesaOrigen]) {
                    window.posEstadoMesas[idMesaOrigen].estado = 'libre';
                    window.posEstadoMesas[idMesaOrigen].inicio = null;
                }
                if (window.posEstadoMesas[idMesaDestino]) {
                    window.posEstadoMesas[idMesaDestino].estado = 'ocupada';
                    window.posEstadoMesas[idMesaDestino].inicio = Date.now();
                } else {
                    window.posEstadoMesas[idMesaDestino] = { estado: 'ocupada', inicio: Date.now() };
                }

                Swal.fire({
                    icon: 'success',
                    title: 'Mesa Cambiada',
                    text: 'El pedido ha sido transferido correctamente.',
                    timer: 2000,
                    showConfirmButton: false
                });
                
                try {
                    await posCargarMesas();
                    // Ir directamente a la mesa destino sin modal de apertura
                    let mesaDestObj = window.posMesas.find(m => m.id == idMesaDestino);
                    if (mesaDestObj) {
                        window.posMesaSeleccionada = mesaDestObj;
                        seleccionarTipoOrdenPOS('mesa');
                        posCargarPedidosMesa(idMesaDestino);
                    } else {
                        posVolverAMesas();
                    }
                } catch(e) {
                    console.error('Error al actualizar UI después de cambiar mesa:', e);
                    posVolverAMesas();
                }
            } else {
                mostrarAlerta('error', data.message || 'Error al cambiar de mesa');
            }
        }
    });
}

// ==========================================
// IMPRIMIR PRECUENTA
// ==========================================
function imprimirPrecuentaPOS() {
    if (window.posCart.length === 0) return mostrarAlerta('warning', 'La orden está vacía');

    let lbl = '';
    if (window.posTipoOrden === 'mesa' && window.posMesaSeleccionada) {
        lbl = 'Mesa ' + window.posMesaSeleccionada.numero;
    } else {
        lbl = 'Orden';
    }
    let subtotal = window.posCart.reduce((s, x) => s + x.cantidad * x.precio, 0);
    
    let itemsHtml = window.posCart.map(i => 
        `<tr><td style="text-align:center;">${i.cantidad}</td><td style="text-align:left;">${i.nombre}</td><td style="text-align:right;">${parseFloat(i.precio).toFixed(2)}</td><td style="text-align:right;">${(i.cantidad * i.precio).toFixed(2)}</td></tr>`
    ).join('');

    Swal.fire({
        title: '🧾 Precuenta',
        html: `
            <div style="text-align:left; font-size:0.9rem;">
                <div class="d-flex justify-content-between mb-2 p-2 rounded" style="background:#f8fafc;">
                    <span class="font-weight-bold">${lbl}</span>
                    <span class="text-muted">${new Date().toLocaleTimeString('es-PE', {hour:'2-digit',minute:'2-digit'})}</span>
                </div>
                <table class="w-100 mb-3" style="font-size:0.85rem;">
                    <thead><tr style="border-bottom:1px dashed #ccc;"><th style="text-align:center; width:40px;">Cant.</th><th style="text-align:left;">Subcategoria</th><th style="text-align:right; width:60px;">P. Unit</th><th style="text-align:right; width:60px;">Total</th></tr></thead>
                    <tbody>${itemsHtml}</tbody>
                </table>
                <hr style="border-style:dashed;">
                <div class="d-flex justify-content-between font-weight-bold" style="font-size:1.1rem;">
                    <span>TOTAL</span><span class="text-theme-primary">S/ ${subtotal.toFixed(2)}</span>
                </div>
                <div class="text-center text-muted mt-3" style="font-size:0.75rem;">*** PRECUENTA - NO ES COMPROBANTE DE PAGO ***</div>
            </div>
        `,
        confirmButtonText: 'Aceptar',
        showCancelButton: true,
        cancelButtonText: 'Cancelar',
        confirmButtonColor: '#334155',
        width: 380
    }).then(r => {
        if (r.isConfirmed) {
            mostrarAlerta('success', 'Precuenta enviada a impresora');
            
            // Generar ticket PDF de Precuenta
            posImprimirTicket('PRECUENTA', '----------', lbl, window.posCart, subtotal, '', '*** NO ES COMPROBANTE DE PAGO ***');
            
            // Cambiar estado visual de la mesa a 'cuenta' y orden a 'precuenta' para alertar al cajero
            if (window.posTipoOrden === 'mesa' && window.posMesaSeleccionada) {
                let idMesa = window.posMesaSeleccionada.id;
                fetch('features/caja/controller_caja.php?action=precuenta', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ id_mesa: idMesa })
                }).then(() => {
                    let st = window.posEstadoMesas[idMesa];
                    if (st) st.estado = 'cuenta';
                    // Re-render the map if we are on the mesas view
                    if (document.getElementById('pos-mesas-map')) posIniciarTimerMapa();
                });
            }
        }
    });
}

function limpiarPOS() {
    if (window.posCart.length === 0) return;
    Swal.fire({ title: '¿Cancelar orden?', text: 'Se eliminarán todos los subcategorias.', icon: 'warning', showCancelButton: true, confirmButtonColor: '#e11d48', cancelButtonColor: '#94a3b8', confirmButtonText: 'Aceptar', cancelButtonText: 'Cancelar'
    }).then(r => { if (r.isConfirmed) { window.posCart = []; renderPOSCart(); } });
}

async function enviarPedidoPOS() {
    // RBAC: Solo cajero o admin pueden procesar cobros
    let rolActual = window.USER_ROL || 'admin';
    if (rolActual === 'mesero') {
        return mostrarAlerta('error', 'Acceso denegado. Solo un Cajero o Admin puede procesar pagos. Use "Precuenta" para solicitar el cobro al cajero.');
    }
    if (window.posCart.length === 0) {
        return Swal.fire({
            icon: 'warning',
            title: 'Orden vacía',
            text: 'Agrega subcategorias primero.',
            confirmButtonColor: '#e11d48'
        });
    }
    if (window.posTipoOrden === 'mesa' && !window.posMesaSeleccionada) return mostrarAlerta('warning', 'Selecciona una mesa');

    let hasUnsentItems = window.posCart.some(item => !item.fromDB);
    if (hasUnsentItems) {
        return Swal.fire({
            icon: 'warning',
            title: 'Pedido no enviado',
            text: 'Tienes subcategorias sin enviar a cocina. Haz clic en "Enviar Pedido" antes de cobrar.',
            confirmButtonColor: '#e11d48'
        });
    }

    let lbl = '';
    let tipoPedidoDB = 'salon';
    if (window.posTipoOrden === 'mesa') {
        tipoPedidoDB = 'salon';
        lbl = 'Mesa ' + window.posMesaSeleccionada.numero;
    } else if (window.posTipoOrden === 'delivery') {
        let subTipo = document.getElementById('pos-delivery-tipo') ? document.getElementById('pos-delivery-tipo').value : 'delivery';
        lbl = subTipo === 'llevar' ? 'Para llevar' : subTipo === 'recoger' ? 'Por recoger' : 'Delivery';
        tipoPedidoDB = subTipo;
    } else {
        lbl = 'Mostrador'; tipoPedidoDB = 'llevar';
    }

    let total = window.posCart.reduce((s, x) => s + x.cantidad * x.precio, 0);

    posAbrirModalCobro({
        isExistente: false,
        tipoPedidoDB: tipoPedidoDB,
        idMesa: window.posMesaSeleccionada ? window.posMesaSeleccionada.id : null,
        lbl: lbl,
        total: total,
        items: window.posCart
    });
}



function posToggleDeliveryTipo() {
    let selectTipo = document.getElementById('pos-delivery-tipo');
    let dir = document.getElementById('pos-delivery-direccion');
    let time = document.getElementById('pos-pickup-time');
    
    if (!selectTipo) return;
    let tipo = selectTipo.value;
    
    if (dir) {
        if (tipo === 'llevar' || tipo === 'recoger') {
            dir.classList.add('d-none');
        } else {
            dir.classList.remove('d-none');
        }
    }
    
    if (time) {
        if (tipo === 'recoger') {
            time.classList.remove('d-none');
        } else {
            time.classList.add('d-none');
        }
    }
    
    actualizarBadgeOrden();
}

function actualizarBadgeOrden() {
    let nb = document.getElementById('pos-orden-numero-badge');
    let b = document.getElementById('pos-orden-tipo-badge');
    let bText = document.getElementById('pos-orden-tipo-text');
    let bIcon = document.getElementById('pos-orden-tipo-icon');
    
    let eb = document.getElementById('pos-orden-extra-badge');
    let ebText = document.getElementById('pos-orden-extra-text');
    let ebIcon = document.getElementById('pos-orden-extra-icon');
    
    if (!b) return;
    
    let orderNum = '';
    let tBg = '#f1f5f9', tTextCol = '#475569', tIcon = 'shopping-cart', tText = 'Mostrador';
    let eIcon = 'user', eText = '', showE = false;
    
    let getCustomerName = () => {
        if (window.posOrdenDeliveryActiva && window.posOrdenDeliveryActiva.cliente_nombre) {
            return window.posOrdenDeliveryActiva.cliente_nombre;
        }
        let input = document.getElementById('pos-delivery-cliente');
        return input ? input.value : '';
    };

    if (window.posTipoOrden === 'mesa') {
        tBg = '#f0f9ff'; tTextCol = '#0284c7'; tIcon = 'layout-grid'; tText = 'Mesa';
        if (window.posPedidosMesaActivos && window.posPedidosMesaActivos.length > 0) orderNum = window.posPedidosMesaActivos[0].numero_pedido;
        else if (window.posOrdenDeliveryActiva && window.posOrdenDeliveryActiva.numero_pedido) orderNum = window.posOrdenDeliveryActiva.numero_pedido;
        
        if (window.posMesaSeleccionada) {
            eIcon = 'map-pin';
            eText = window.posMesaSeleccionada.numero;
            showE = true;
        }
    } else if (window.posTipoOrden === 'mostrador') {
        let subTipo = document.getElementById('pos-delivery-tipo') ? document.getElementById('pos-delivery-tipo').value : 'mostrador';
        if (subTipo === 'llevar') { tBg = '#faf5ff'; tTextCol = '#9333ea'; tIcon = 'shopping-bag'; tText = 'Para llevar'; }
        else if (subTipo === 'recoger') { tBg = '#f0fdf4'; tTextCol = '#16a34a'; tIcon = 'clock'; tText = 'Por recoger'; }
        else if (subTipo === 'delivery') { tBg = '#fff7ed'; tTextCol = '#ea580c'; tIcon = 'bike'; tText = 'Delivery'; }
        else { tBg = '#f1f5f9'; tTextCol = '#475569'; }
        
        if (window.posOrdenDeliveryActiva && window.posOrdenDeliveryActiva.numero_pedido) orderNum = window.posOrdenDeliveryActiva.numero_pedido;
        
        eText = getCustomerName();
        if (eText) showE = true;
    } else if (window.posTipoOrden === 'resumen') {
        if (window.posOrdenDeliveryActiva && window.posOrdenDeliveryActiva.numero_pedido) {
            orderNum = window.posOrdenDeliveryActiva.numero_pedido;
            let tc = window.posOrdenDeliveryActiva.tipo_codigo;
            if (tc === 'salon') {
                tBg = '#f0f9ff'; tTextCol = '#0284c7'; tIcon = 'layout-grid'; tText = 'Mesa';
                if (window.posMesaSeleccionada) {
                    eIcon = 'map-pin'; eText = window.posMesaSeleccionada.numero; showE = true;
                }
            }
            else if (tc === 'llevar') { tBg = '#faf5ff'; tTextCol = '#9333ea'; tIcon = 'shopping-bag'; tText = 'Para llevar'; }
            else if (tc === 'recoger') { tBg = '#f0fdf4'; tTextCol = '#16a34a'; tIcon = 'clock'; tText = 'Por recoger'; }
            else if (tc === 'delivery') { tBg = '#fff7ed'; tTextCol = '#ea580c'; tIcon = 'bike'; tText = 'Delivery'; }
            
            if (tc !== 'salon') {
                eText = window.posOrdenDeliveryActiva.cliente_nombre || '';
                if (eText) showE = true;
            }
        } else if (window.posMesaSeleccionada && window.posPedidosMesaActivos && window.posPedidosMesaActivos.length > 0) {
            orderNum = window.posPedidosMesaActivos[0].numero_pedido;
            tBg = '#f0f9ff'; tTextCol = '#0284c7'; tIcon = 'layout-grid'; tText = 'Mesa';
            eIcon = 'map-pin'; eText = window.posMesaSeleccionada.numero; showE = true;
        } else {
            tText = 'Órdenes Activas'; tBg = '#f1f5f9'; tTextCol = '#475569'; tIcon = 'shopping-cart';
        }
    }
    
    // Apply Order Num
    if (nb) {
        if (orderNum) { nb.innerText = orderNum; nb.classList.remove('d-none'); }
        else { nb.innerText = ''; nb.classList.add('d-none'); }
    }
    
    // Apply Type
    b.className = `badge px-3 py-1 font-weight-bold shadow-sm d-flex align-items-center`;
    b.style.backgroundColor = tBg;
    b.style.color = tTextCol;
    b.innerHTML = `<i data-lucide="${tIcon}" style="width:14px;height:14px;margin-right:6px;"></i> <span>${tText}</span>`;
    
    // Apply Extra
    if (eb) {
        if (showE) {
            eb.classList.remove('d-none');
            eb.classList.add('d-flex');
            eb.innerHTML = `<i data-lucide="${eIcon}" style="width:14px;height:14px;margin-right:6px;"></i> <span>${eText}</span>`;
        } else {
            eb.classList.add('d-none');
            eb.classList.remove('d-flex');
        }
    }
    
    if (window.lucide) window.lucide.createIcons();
}

// ==========================================
// MODAL COBRO FULL PAGE
// ==========================================
function posAbrirModalCobro(config) {
    let wrapper = document.getElementById('pos-fullscreen-cobro');
    if (!wrapper) {
        wrapper = document.createElement('div');
        wrapper.id = 'pos-fullscreen-cobro';
        wrapper.style.cssText = 'position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(15, 23, 42, 0.6); backdrop-filter:blur(4px); z-index:9999; display:flex; align-items:center; justify-content:center; padding: 20px; font-family: "DM Sans", sans-serif;';
        document.body.appendChild(wrapper);
    }
    
    window.posCobroConfig = config;
    window.posCobroState = {
        comprobante: 'boleta', 
        documento: '',
        nombre: '',
        direccion: '',
        metodo: 'efectivo', 
        montoRecibido: config.total,
        vuelto: 0,
        consumo: false 
    };

    posRenderModalCobroUI();
}

function posRenderModalCobroUI() {
    let wrapper = document.getElementById('pos-fullscreen-cobro');
    if (!wrapper) return;
    let config = window.posCobroConfig;
    let state = window.posCobroState;
    let finalTotal = Math.max(0, config.total - (state.descuento || 0));

    let isOk = true;
    if (state.comprobante !== 'nota_venta' && !state.consumo) {
        if (!state.documento || !state.nombre) isOk = false;
        if (state.comprobante === 'factura' && state.documento.length !== 11) isOk = false;
    }
    if ((state.metodo === 'efectivo' || state.metodo === 'dolar') && state.montoRecibido < finalTotal) isOk = false;

    wrapper.innerHTML = `
    <div style="display:flex; width:100%; max-width: 1000px; height:85vh; max-height:750px; background:#fff; border-radius:16px; overflow:hidden; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25); position:relative;">
        <!-- Botón cerrar superior -->
        <button onclick="posCerrarModalCobro()" style="position:absolute; top:15px; right:15px; background:#fff; border:1px solid #e2e8f0; border-radius:50%; width:36px; height:36px; display:flex; align-items:center; justify-content:center; cursor:pointer; color:#64748b; z-index:10; box-shadow:0 2px 4px rgba(0,0,0,0.05);">
            <i data-lucide="x" style="width:20px;height:20px;"></i>
        </button>
        
        <!-- COLUMNA IZQUIERDA -->
        <div style="width: 45%; background:#fff; border-right:1px solid #e2e8f0; display:flex; flex-direction:column; height:100%;">
            <div style="background:#1e293b; color:#fff; padding:12px 15px; font-weight:bold; font-size:1rem; display:flex; align-items:center;">
                <i data-lucide="shopping-bag" style="width:18px;height:18px;margin-right:8px;"></i> DETALLE PEDIDO - ${config.lbl}
            </div>
            <div style="flex:1; overflow-y:auto; padding:15px;">
                <table style="width:100%; border-collapse: collapse;">
                    <thead>
                        <tr style="border-bottom:2px solid #e2e8f0; color:#64748b; font-size:0.8rem;">
                            <th style="padding:8px 4px; text-align:center; width:50px;">Cant.</th>
                            <th style="padding:8px 4px; text-align:left;">Subcategoria</th>
                            <th style="padding:8px 4px; text-align:right; width:75px;">P. Unit</th>
                            <th style="padding:8px 4px; text-align:right; width:85px;">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${config.items.map(i => {
                            let nombre = i.nombre || i.subcategoria_nombre || 'Subcategoria';
                            let sub = parseFloat(i.subtotal || (i.cantidad * i.precio)).toFixed(2);
                            let pu = parseFloat(i.precio).toFixed(2);
                            return `<tr style="border-bottom:1px solid #f1f5f9;">
                                <td style="padding:10px 4px; text-align:center; font-weight:bold; color:#334155; font-size:0.9rem;">${i.cantidad}</td>
                                <td style="padding:10px 4px;">
                                    <div style="font-weight:600; color:#1e293b; font-size:0.85rem;">${nombre}</div>
                                </td>
                                <td style="padding:10px 4px; text-align:right; color:#64748b; font-size:0.85rem;">S/ ${pu}</td>
                                <td style="padding:10px 4px; text-align:right; font-weight:bold; color:#0f172a; font-size:0.9rem;">S/ ${sub}</td>
                            </tr>`;
                        }).join('')}
                    </tbody>
                </table>
            </div>
            <div style="background:#f8fafc; padding:15px; border-top:1px solid #e2e8f0;">
                <div style="display:flex; justify-content:space-between; margin-bottom:6px; color:#64748b; font-size:0.85rem;">
                    <span>Sub Total</span><span>S/ ${config.total.toFixed(2)}</span>
                </div>
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px; color:#64748b; font-size:0.85rem;">
                    <span>Descuento (S/)</span>
                    <input type="number" min="0" step="0.5" value="${state.descuento || 0}" style="width:70px; padding:2px 5px; border:1px solid #cbd5e1; border-radius:4px; text-align:right; font-size:0.85rem; outline:none;" onchange="posModalCobroSetDescuento(this.value)">
                </div>
                <div style="display:flex; justify-content:space-between; margin-bottom:6px; color:#64748b; font-size:0.85rem;">
                    <span>Propina</span><span>S/ 0.00</span>
                </div>
                <div style="display:flex; justify-content:space-between; margin-top:10px; padding-top:10px; border-top:2px dashed #cbd5e1; font-weight:bold; font-size:1.2rem; color:#0f172a;">
                    <span>TOTAL</span><span style="color:#22c55e;">S/ ${finalTotal.toFixed(2)}</span>
                </div>
                ${state.metodo === 'efectivo' ? `<div style="display:flex; justify-content:space-between; margin-top:10px; padding:10px; background:#dcfce7; border-radius:6px; font-weight:bold; font-size:1rem; color:#166534;">
                    <span>Vuelto</span><span id="pos-modal-vuelto-val">S/ ${state.vuelto.toFixed(2)}</span>
                </div>` : ''}
                <div id="pos-modal-pago-alert" style="margin-top:10px; text-align:center; color:#ef4444; font-weight:bold; font-size:0.85rem; padding:8px; background:#fef2f2; border-radius:6px; border:1px solid #fecaca; display:${(!state.metodo || (state.metodo === 'efectivo' && state.montoRecibido < finalTotal)) ? 'block' : 'none'};">
                    <i data-lucide="alert-circle" style="width:14px;height:14px;margin-bottom:-3px;"></i> ¡Agrega Forma de Pago válida!
                </div>
            </div>
        </div>
        
        <!-- COLUMNA DERECHA -->
        <div style="width: 55%; padding:20px 25px; display:flex; flex-direction:column; background:#f1f5f9; overflow-y:auto;">
            <!-- Tipo Comprobante Tabs -->
            <div style="margin-bottom:15px;">
                <div style="font-size:0.75rem; font-weight:bold; color:#64748b; margin-bottom:6px; text-transform:uppercase;">Tipo de Documento</div>
                <div style="display:flex; background:#e2e8f0; border-radius:8px; padding:4px;">
                    <div onclick="posModalCobroSeleccionarComprobante('boleta')" style="flex:1; text-align:center; padding:8px; cursor:pointer; font-weight:bold; font-size:0.85rem; border-radius:6px; ${state.comprobante==='boleta'?'background:#fff; color:#0f172a; box-shadow:0 1px 3px rgba(0,0,0,0.1);':'color:#64748b;'}">🧾 Boleta</div>
                    <div onclick="posModalCobroSeleccionarComprobante('factura')" style="flex:1; text-align:center; padding:8px; cursor:pointer; font-weight:bold; font-size:0.85rem; border-radius:6px; ${state.comprobante==='factura'?'background:#fff; color:#0f172a; box-shadow:0 1px 3px rgba(0,0,0,0.1);':'color:#64748b;'}">📄 Factura</div>
                    <div onclick="posModalCobroSeleccionarComprobante('nota_venta')" style="flex:1; text-align:center; padding:8px; cursor:pointer; font-weight:bold; font-size:0.85rem; border-radius:6px; ${state.comprobante==='nota_venta'?'background:#fff; color:#0f172a; box-shadow:0 1px 3px rgba(0,0,0,0.1);':'color:#64748b;'}">📝 Nota Venta</div>
                </div>
            </div>

            <!-- Buscar Cliente -->
            ${state.comprobante !== 'nota_venta' ? `
            <div style="background:#fff; padding:15px; border-radius:10px; box-shadow:0 1px 3px rgba(0,0,0,0.05); margin-bottom:15px;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                    <div style="font-size:0.75rem; font-weight:bold; color:#64748b; text-transform:uppercase;">Datos del Cliente</div>
                    ${state.comprobante === 'boleta' ? `<label style="display:flex; align-items:center; cursor:pointer; font-size:0.8rem; font-weight:600; color:#334155; margin:0;">
                        <input type="checkbox" ${state.consumo ? 'checked' : ''} onchange="posModalCobroToggleConsumo(this.checked)" style="margin-right:6px; width:14px; height:14px; accent-color:#188df1;"> Venta por consumo
                    </label>` : ''}
                </div>
                
                ${!state.consumo ? `<div style="display:flex; gap:8px; margin-bottom:10px;">
                    <input type="text" id="pos-modal-doc-input" placeholder="${state.comprobante === 'factura' ? 'RUC (11 dígitos)' : 'DNI (8 dígitos)'}" value="${state.documento}" style="flex:1; padding:10px 12px; border:1px solid #cbd5e1; border-radius:6px; font-size:0.95rem; outline:none;" oninput="window.posCobroState.documento=this.value;" onkeydown="if(event.key==='Enter') posModalCobroBuscarCliente()">
                    <button onclick="posModalCobroBuscarCliente()" style="background:#188df1; color:#fff; border:none; border-radius:6px; padding:0 15px; font-weight:bold; cursor:pointer; display:flex; align-items:center; gap:6px; font-size:0.9rem;">
                        <i data-lucide="search" style="width:16px;height:16px;"></i> Buscar
                    </button>
                </div>` : ''}
                
                ${state.nombre && !state.consumo ? `<div style="background:#f0fdf4; border:1px solid #bbf7d0; color:#166534; padding:10px 12px; border-radius:6px; font-size:0.9rem;">
                    <div style="display:flex; align-items:center; gap:8px; font-weight:600;">
                        <i data-lucide="user-check" style="width:18px;height:18px; flex-shrink:0;"></i> ${state.nombre}
                    </div>
                    ${state.direccion ? `<div style="margin-top:6px; padding-top:6px; border-top:1px solid #bbf7d0; font-size:0.8rem; color:#15803d; display:flex; align-items:flex-start; gap:6px;">
                        <i data-lucide="map-pin" style="width:14px;height:14px; flex-shrink:0; margin-top:1px;"></i> ${state.direccion}
                    </div>` : ''}
                </div>` : ''}
            </div>` : ''}

            <!-- Formas de Pago -->
            <div style="background:#fff; padding:15px; border-radius:10px; box-shadow:0 1px 3px rgba(0,0,0,0.05); flex:1;">
                <div style="font-size:0.75rem; font-weight:bold; color:#64748b; margin-bottom:10px; text-transform:uppercase;">Formas de Pago</div>
                <div style="display:grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap:10px; margin-bottom:15px;">
                    <button onclick="posModalCobroSeleccionarMetodo('efectivo')" style="padding:10px; border-radius:8px; font-weight:bold; font-size:0.85rem; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:6px; cursor:pointer; transition:all 0.2s; ${state.metodo==='efectivo' ? 'background:#ecfdf5; border:2px solid #10b981; color:#047857;' : 'background:#f8fafc; border:2px solid transparent; color:#64748b;'}">
                        <i data-lucide="banknote" style="width:24px;height:24px; ${state.metodo==='efectivo'?'color:#10b981':''}"></i> Efectivo
                    </button>
                    <button onclick="posModalCobroSeleccionarMetodo('tarjeta')" style="padding:10px; border-radius:8px; font-weight:bold; font-size:0.85rem; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:6px; cursor:pointer; transition:all 0.2s; ${state.metodo==='tarjeta' ? 'background:#eff6ff; border:2px solid #3b82f6; color:#1d4ed8;' : 'background:#f8fafc; border:2px solid transparent; color:#64748b;'}">
                        <i data-lucide="credit-card" style="width:24px;height:24px; ${state.metodo==='tarjeta'?'color:#3b82f6':''}"></i> Tarjeta
                    </button>
                    <button onclick="posModalCobroSeleccionarMetodo('yape')" style="padding:10px; border-radius:8px; font-weight:bold; font-size:0.85rem; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:6px; cursor:pointer; transition:all 0.2s; ${state.metodo==='yape' ? 'background:#faf5ff; border:2px solid #a855f7; color:#7e22ce;' : 'background:#f8fafc; border:2px solid transparent; color:#64748b;'}">
                        <i data-lucide="smartphone" style="width:24px;height:24px; ${state.metodo==='yape'?'color:#a855f7':''}"></i> Yape
                    </button>
                    <button onclick="posModalCobroSeleccionarMetodo('dolar')" style="padding:10px; border-radius:8px; font-weight:bold; font-size:0.85rem; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:6px; cursor:pointer; transition:all 0.2s; ${state.metodo==='dolar' ? 'background:#fffbeb; border:2px solid #f59e0b; color:#b45309;' : 'background:#f8fafc; border:2px solid transparent; color:#64748b;'}">
                        <i data-lucide="dollar-sign" style="width:24px;height:24px; ${state.metodo==='dolar'?'color:#f59e0b':''}"></i> Dólar
                    </button>
                </div>

                ${(state.metodo === 'efectivo' || state.metodo === 'dolar') ? `<div style="background:#f8fafc; padding:15px; border-radius:8px; border:1px solid #e2e8f0;">
                    <div style="font-size:0.8rem; font-weight:bold; color:#475569; margin-bottom:8px;">Monto Recibido</div>
                    <input type="number" step="0.01" min="${finalTotal}" value="${state.montoRecibido}" style="width:100%; padding:10px; border:2px solid #cbd5e1; border-radius:6px; font-size:1.2rem; font-weight:bold; color:#0f172a; text-align:right; margin-bottom:10px; outline:none;" oninput="posModalCobroCalcVuelto(this.value, true)">
                    <div style="display:flex; gap:8px;">
                        <button onclick="posModalCobroSetMontoRápido(20)" style="flex:1; padding:8px; background:#fff; border:1px solid #cbd5e1; border-radius:6px; font-weight:bold; font-size:0.9rem; color:#334155; cursor:pointer;">S/ 20</button>
                        <button onclick="posModalCobroSetMontoRápido(50)" style="flex:1; padding:8px; background:#fff; border:1px solid #cbd5e1; border-radius:6px; font-weight:bold; font-size:0.9rem; color:#334155; cursor:pointer;">S/ 50</button>
                        <button onclick="posModalCobroSetMontoRápido(100)" style="flex:1; padding:8px; background:#fff; border:1px solid #cbd5e1; border-radius:6px; font-weight:bold; font-size:0.9rem; color:#334155; cursor:pointer;">S/ 100</button>
                        <button onclick="posModalCobroSetMontoRápido(${finalTotal})" style="flex:1; padding:8px; background:#10b981; border:none; border-radius:6px; font-weight:bold; font-size:0.9rem; color:#fff; cursor:pointer;">Exacto</button>
                    </div>
                </div>` : ''}
            </div>

            <!-- FOOTER ACTION BUTTONS -->
            <div style="display:flex; gap:10px; margin-top:15px;">
                <button onclick="posCerrarModalCobro()" style="flex:1; padding:12px; background:#fff; border:1px solid #cbd5e1; border-radius:8px; font-weight:bold; font-size:0.95rem; color:#475569; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:6px;">
                    <i data-lucide="arrow-left" style="width:18px;height:18px;"></i> VOLVER
                </button>
                <button onclick="posModalCobroImprimirPrecuenta()" style="flex:1; padding:12px; background:#f8fafc; border:1px solid #cbd5e1; border-radius:8px; font-weight:bold; font-size:0.95rem; color:#334155; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:6px;">
                    <i data-lucide="printer" style="width:18px;height:18px;"></i> IMPRIMIR
                </button>
                <button id="pos-modal-btn-aceptar" onclick="posProcesarModalCobro()" style="flex:2; padding:12px; background:#22c55e; border:none; border-radius:8px; font-weight:bold; font-size:1.05rem; color:#fff; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:8px; box-shadow:0 4px 6px rgba(34,197,94,0.3); transition:all 0.2s; ${isOk?'':'opacity:0.5;cursor:not-allowed;'}" ${isOk?'':'disabled'}>
                    ACEPTAR <i data-lucide="check-circle" style="width:20px;height:20px;"></i>
                </button>
            </div>
        </div>
    </div>
    `;
    lucide.createIcons();
}

function posModalCobroCalcVuelto(val, fromInput = false) {
    let num = parseFloat(val) || 0;
    let finalTotal = Math.max(0, window.posCobroConfig.total - (window.posCobroState.descuento || 0));
    window.posCobroState.montoRecibido = num;
    window.posCobroState.vuelto = Math.max(0, num - finalTotal);
    
    if (fromInput) {
        let vueltoSpan = document.getElementById('pos-modal-vuelto-val');
        if (vueltoSpan) vueltoSpan.innerText = 'S/ ' + window.posCobroState.vuelto.toFixed(2);
        
        let state = window.posCobroState;
        let isOk = true;
        if (state.comprobante !== 'nota_venta' && !state.consumo) {
            if (!state.documento || !state.nombre) isOk = false;
            if (state.comprobante === 'factura' && state.documento.length !== 11) isOk = false;
        }
        if ((state.metodo === 'efectivo' || state.metodo === 'dolar') && state.montoRecibido < finalTotal) isOk = false;
        
        let btnAceptar = document.getElementById('pos-modal-btn-aceptar');
        if (btnAceptar) {
            btnAceptar.disabled = !isOk;
            btnAceptar.style.opacity = isOk ? '1' : '0.5';
            btnAceptar.style.cursor = isOk ? 'pointer' : 'not-allowed';
        }
        
        let alertDiv = document.getElementById('pos-modal-pago-alert');
        if (alertDiv) {
            alertDiv.style.display = (!state.metodo || (state.metodo === 'efectivo' && state.montoRecibido < finalTotal)) ? 'block' : 'none';
        }
    } else {
        posRenderModalCobroUI();
    }
}

function posModalCobroSetDescuento(val) {
    window.posCobroState.descuento = parseFloat(val) || 0;
    let finalTotal = Math.max(0, window.posCobroConfig.total - window.posCobroState.descuento);
    if (window.posCobroState.montoRecibido === window.posCobroConfig.total) {
        window.posCobroState.montoRecibido = finalTotal;
    }
    posRenderModalCobroUI();
}

function posModalCobroImprimirPrecuenta() {
    let lbl = window.posCobroConfig.lbl || 'Mostrador';
    let finalTotal = window.posCobroConfig.total - (window.posCobroState.descuento || 0);
    posImprimirTicket('PRECUENTA', lbl, 'Cliente', window.posCobroConfig.items, finalTotal, window.posCobroConfig.tipoPedidoDB || window.posTipoOrden, '--- REVISIÓN DE CUENTA ---');
}

function posModalCobroSetMontoRápido(val) { posModalCobroCalcVuelto(val); }

function posModalCobroSeleccionarMetodo(metodo) {
    window.posCobroState.metodo = metodo;
    let finalTotal = Math.max(0, window.posCobroConfig.total - (window.posCobroState.descuento || 0));
    window.posCobroState.montoRecibido = finalTotal;
    window.posCobroState.vuelto = 0;
    posRenderModalCobroUI();
}

function posModalCobroSeleccionarComprobante(comp) {
    window.posCobroState.comprobante = comp;
    if (comp === 'factura') window.posCobroState.consumo = false;
    posRenderModalCobroUI();
}

function posModalCobroToggleConsumo(isChecked) {
    window.posCobroState.consumo = isChecked;
    if (isChecked) { window.posCobroState.documento = ''; window.posCobroState.nombre = ''; window.posCobroState.direccion = ''; }
    posRenderModalCobroUI();
}

async function posModalCobroBuscarCliente() {
    let state = window.posCobroState;
    let docInput = document.getElementById('pos-modal-doc-input');
    if (!docInput) return;
    let doc = docInput.value.trim();
    state.documento = doc;
    
    if (!doc) return mostrarAlerta('warning', 'Ingrese un documento');
    if (state.comprobante === 'factura' && doc.length !== 11) return mostrarAlerta('warning', 'RUC debe tener 11 dígitos');
    if (state.comprobante === 'boleta' && doc.length !== 8) return mostrarAlerta('warning', 'DNI debe tener 8 dígitos');
    
    let tipoStr = state.comprobante === 'factura' ? '6' : '1';
    
    try {
        Swal.fire({title: 'Buscando...', allowOutsideClick: false, didOpen: () => { Swal.showLoading() }});
        
        let tipoParaApi = state.comprobante === 'factura' ? 'RUC' : 'DNI';
        let res = await fetch(`features/clientes/controller_clientes.php?action=buscar_documento&tipo=${tipoParaApi}&numero=${doc}`);
        let data = await res.json();
        
        Swal.close();
        
        if (data.status === 'ok' && data.data) {
            let nombre = data.data.razon_social || data.data.nombre_o_razon_social || data.data.nombre_completo || data.data.nombre || '';
            let direccion = data.data.direccion_completa || data.data.direccion || '';
            if (nombre) { 
                state.nombre = nombre;
                state.direccion = direccion;
                mostrarAlerta('success', 'Cliente encontrado (' + (data.origen || 'API') + ')'); 
            } else { 
                mostrarAlerta('warning', 'No se encontró nombre en la respuesta'); 
                state.nombre = ''; 
                state.direccion = '';
            }
        } else {
            mostrarAlerta('error', data.message || data.error || 'No se encontró el documento');
            state.nombre = '';
            state.direccion = '';
        }
    } catch(e) { Swal.close(); mostrarAlerta('error', 'Error al consultar BD/SUNAT'); state.direccion = ''; }
    posRenderModalCobroUI();
}

function posCerrarModalCobro() {
    let w = document.getElementById('pos-fullscreen-cobro');
    if (w) w.remove();
}

async function posProcesarModalCobro() {
    let state = window.posCobroState;
    let config = window.posCobroConfig;
    let total = config.total;
    let finalTotal = Math.max(0, total - (state.descuento || 0));
    
    if (state.comprobante !== 'nota_venta' && !state.consumo) {
        if (!state.documento || !state.nombre) return mostrarAlerta('warning', 'Complete los datos del cliente');
        if (state.comprobante === 'factura' && state.documento.length !== 11) return mostrarAlerta('warning', 'Factura requiere RUC de 11 dígitos');
    }
    if ((state.metodo === 'efectivo' || state.metodo === 'dolar') && state.montoRecibido < finalTotal) return mostrarAlerta('warning', 'Monto recibido insuficiente');
    
    let dbMetodo = state.metodo;
    if (dbMetodo === 'yape') dbMetodo = 'transferencia';
    if (dbMetodo === 'dolar') dbMetodo = 'efectivo'; 

    let payload = {
        tipo_comprobante: state.comprobante,
        comprobante: state.comprobante,
        cliente_documento: state.documento,
        cliente_nombre: state.consumo ? 'Venta por consumo' : (state.nombre || document.getElementById('pos-delivery-cliente')?.value || null),
        metodo_pago: dbMetodo,
        monto_recibido: state.montoRecibido,
        vuelto: state.vuelto,
        descuento: state.descuento || 0,
        completar_pedido: config.completarAuto || false
    };

    if (config.isExistente) {
        payload.order_id = config.orderId;
        payload.action = 'cobrar_orden_existente'; 
        try {
            const res = await fetch('features/caja/controller_caja.php?action=cobrar_orden_existente', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload) });
            const data = await res.json();
            if (data.status === 'error') return mostrarAlerta('error', data.message);
            
            // Llamar a facturación SUNAT
            let isComprobante = state.comprobante === 'boleta' || state.comprobante === 'factura';
            let sunatEmitido = false;
            if (isComprobante && typeof window.facEmitirComprobante === 'function') {
                sunatEmitido = await window.facEmitirComprobante(config.orderId, config.items, state.comprobante, finalTotal, state.documento, state.nombre, state.direccion);
            }

            // Solo mostrar éxito genérico si NO se intentó emitir (nota_venta) o si SUNAT ya mostró su propio modal
            if (!isComprobante) {
                Swal.fire({ title: '¡Cobro Exitoso!', html: `Total: <b>S/ ${finalTotal.toFixed(2)}</b><br>Método: <b>${state.metodo.toUpperCase()}</b>${state.vuelto > 0 ? '<br>Vuelto: <b>S/ '+state.vuelto.toFixed(2)+'</b>' : ''}`, icon: 'success', confirmButtonColor: '#188df1' });
            } else if (sunatEmitido) {
                // SUNAT emitió OK — el ResponseModal ya se mostró, no hacer nada más
            } else {
                // SUNAT falló — facEmitirComprobante ya mostró el error, esperamos a que el usuario lo lea
                await Swal.fire({ 
                    title: '⚠️ Cobro registrado SIN comprobante SUNAT', 
                    html: `El cobro de <b>S/ ${finalTotal.toFixed(2)}</b> se guardó localmente.<br>Pero <b>NO se emitió ${state.comprobante.toUpperCase()}</b> electrónica.<br><br>Revisa la consola del navegador (F12) para ver el detalle del error.<br><small>Puedes emitir el comprobante manualmente desde Emitir → ${state.comprobante === 'factura' ? 'Factura' : 'Boleta'}</small>`, 
                    icon: 'warning', 
                    confirmButtonColor: '#f59e0b',
                    confirmButtonText: 'Entendido'
                });
            }
            
            // Ticket manual: Siempre se imprime el comprobante de pago interno
            let numPedidoTxt = config.isExistente ? config.lbl : (config.orderId || '0000');
            posImprimirTicket('TICKET DE VENTA', numPedidoTxt, payload.cliente_nombre, config.items, finalTotal, config.tipoPedidoDB || window.posTipoOrden, '*** GRACIAS POR SU COMPRA ***');

            window.posOrdenDeliveryActiva = null;
            window.posOrdenActivaId = null;
            posCerrarModalCobro();
            
            if (config.tipoPedidoDB === 'salon' && config.idMesa) { 
                let st = window.posEstadoMesas[config.idMesa]; 
                if (st) { st.estado = 'libre'; st.inicio = null; } 
            }
            if (window.posTipoOrden === 'mesa') posVolverAMesas();
            
            renderPOSResumen();
            const cartItems = document.getElementById('pos-cart-items'); if (cartItems) cartItems.innerHTML = '';
            const cartOverlay = document.getElementById('pos-cart-overlay'); if (cartOverlay) { cartOverlay.classList.remove('d-none'); cartOverlay.classList.add('d-flex'); }
        } catch(e) { console.error('Error POS cobro existente:', e); mostrarAlerta('error', 'Error de conexión'); }
    } else {
        payload.tipo_pedido = config.tipoPedidoDB;
        payload.id_mesa = config.idMesa;
        payload.cliente_telefono = document.getElementById('pos-delivery-telefono')?.value || null;
        payload.cliente_direccion = document.getElementById('pos-delivery-direccion')?.value || null;
        payload.pickup_time = document.getElementById('pos-pickup-time')?.value || null;
        payload.subtotal = total; payload.total = finalTotal; payload.descuento = state.descuento || 0;
        payload.items = config.items.map(x => ({ id_subcategoria: x.id || 1, producto_id: x.producto_id || 0, cantidad: x.cantidad, precio: x.precio, nombre: x.nombre, subcategoria_nombre: x.nombre }));
        try {
            const res = await fetch('features/caja/controller_caja.php?action=cobrar', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
            const data = await res.json();
            if (data.status === 'error') return mostrarAlerta('error', data.message);
            
            // Llamar a facturación SUNAT
            let isComprobante = state.comprobante === 'boleta' || state.comprobante === 'factura';
            let sunatEmitido = false;
            if (isComprobante && typeof window.facEmitirComprobante === 'function') {
                sunatEmitido = await window.facEmitirComprobante(data.order_id || 0, payload.items, state.comprobante, finalTotal, state.documento, state.nombre, state.direccion);
            }

            // Solo mostrar éxito genérico si fue nota_venta (sin SUNAT)
            if (!isComprobante) {
                Swal.fire({ title: '¡Cobro Exitoso!', html: `<b>${config.lbl}</b><br><b>${data.numero_pedido}</b><br>Total: <b>S/ ${finalTotal.toFixed(2)}</b>${state.vuelto > 0 ? '<br>Vuelto: <b>S/ '+state.vuelto.toFixed(2)+'</b>' : ''}<br><span class="badge bg-primary text-white mt-2">${state.comprobante.toUpperCase()}</span>`, icon: 'success', confirmButtonColor: '#188df1' });
            } else if (sunatEmitido) {
                // SUNAT emitió OK — el ResponseModal ya se mostró
            } else {
                // SUNAT falló — mostrar advertencia clara
                await Swal.fire({ 
                    title: '⚠️ Cobro registrado SIN comprobante SUNAT', 
                    html: `Pedido <b>${data.numero_pedido}</b> cobrado por <b>S/ ${finalTotal.toFixed(2)}</b>.<br>Pero <b>NO se emitió ${state.comprobante.toUpperCase()}</b> electrónica.<br><br>Revisa la consola (F12) para ver el error.<br><small>Puedes emitir manualmente desde Emitir → ${state.comprobante === 'factura' ? 'Factura' : 'Boleta'}</small>`, 
                    icon: 'warning', 
                    confirmButtonColor: '#f59e0b',
                    confirmButtonText: 'Entendido'
                });
            }
            
            // Ticket manual: Siempre se imprime el comprobante de pago interno
            posImprimirTicket('TICKET DE VENTA', data.numero_pedido, payload.cliente_nombre, payload.items, finalTotal, payload.tipo_pedido, '*** GRACIAS POR SU COMPRA ***');

            if (config.tipoPedidoDB === 'salon' && config.idMesa) { let st = window.posEstadoMesas[config.idMesa]; if (st) { st.estado = 'libre'; st.inicio = null; } }
            window.posCart = []; renderPOSCart(); posCerrarModalCobro();
            if (window.posTipoOrden === 'mesa') posVolverAMesas();
            else if (window.posTipoOrden === 'delivery') { ['pos-delivery-cliente','pos-delivery-telefono','pos-delivery-direccion'].forEach(id => { let e = document.getElementById(id); if(e) e.value = ''; }); }
        } catch(e) { console.error('Error POS cobro nuevo:', e); mostrarAlerta('error', 'Error de conexión al cobrar'); }
    }
}

document.head.insertAdjacentHTML('beforeend', `
<style>
.pos-item-card:hover { transform: translateY(-2px); box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -1px rgba(0,0,0,0.06) !important; border-color: #188df1 !important; }
.pos-mesa-card:hover { transform: translateY(-3px) scale(1.03); box-shadow: 0 8px 16px rgba(0,0,0,0.12) !important; }
.swal2-container { z-index: 99999 !important; }
</style>
`);

// ==========================================
// IMPRIMIR TICKET COMANDA / NOTA (PDF)
// ==========================================
function numeroALetras(num) {
    const unidades = ['','UNO','DOS','TRES','CUATRO','CINCO','SEIS','SIETE','OCHO','NUEVE'];
    const decenas = ['','DIEZ','VEINTE','TREINTA','CUARENTA','CINCUENTA','SESENTA','SETENTA','OCHENTA','NOVENTA'];
    const especiales = {11:'ONCE',12:'DOCE',13:'TRECE',14:'CATORCE',15:'QUINCE',16:'DIECISEIS',17:'DIECISIETE',18:'DIECIOCHO',19:'DIECINUEVE'};
    const centenas = ['','CIENTO','DOSCIENTOS','TRESCIENTOS','CUATROCIENTOS','QUINIENTOS','SEISCIENTOS','SETECIENTOS','OCHOCIENTOS','NOVECIENTOS'];
    
    let entero = Math.floor(num);
    let decimales = Math.round((num - entero) * 100);
    
    function convertir(n) {
        if (n === 0) return 'CERO';
        if (n === 100) return 'CIEN';
        let str = '';
        if (n >= 100) { str += centenas[Math.floor(n/100)] + ' '; n %= 100; }
        if (n >= 11 && n <= 19) { str += especiales[n]; return str; }
        if (n >= 10) { 
            let d = Math.floor(n/10); 
            let u = n % 10;
            if (d === 2 && u > 0) { str += 'VEINTI' + unidades[u]; return str; }
            str += decenas[d]; 
            if (u > 0) str += ' Y ' + unidades[u];
            return str;
        }
        if (n > 0) { str += unidades[n]; }
        return str.trim();
    }
    
    let strEntero = '';
    if (entero >= 1000) {
        let miles = Math.floor(entero/1000);
        if (miles === 1) strEntero += 'MIL ';
        else strEntero += convertir(miles) + ' MIL ';
        entero %= 1000;
    }
    if (entero > 0 || strEntero === '') {
        strEntero += convertir(entero);
    }
    
    let strDec = decimales.toString().padStart(2, '0') + '/100 SOLES';
    return `SON: ${strEntero.trim()} CON ${strDec}`;
}

function padR(str, len) { return (str.toString() || '').substring(0, len).padEnd(len, ' '); }
function padL(str, len) { return (str.toString() || '').substring(0, len).padStart(len, ' '); }

function posImprimirTicket(titulo, numero, cliente, items, total, tipo, extra) {
    let dateStr = new Date().toLocaleString('es-PE', {day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit', hour12:true});
    let cajero = window.posUserNombre || '';

    let itemsHtml = items.map(i => `
        <tr>
            <td style="text-align: left; vertical-align: top; padding: 2px 0;">${i.cantidad}</td>
            <td style="text-align: left; vertical-align: top; padding: 2px 4px;">${i.nombre}</td>
            <td style="text-align: right; vertical-align: top; padding: 2px 0;">${parseFloat(i.precio).toFixed(2)}</td>
            <td style="text-align: right; vertical-align: top; padding: 2px 0;">${(i.cantidad * parseFloat(i.precio)).toFixed(2)}</td>
        </tr>
    `).join('');

    let htmlContent = `
        <div style="width: 100%; padding: 4mm; font-family: 'Courier New', Courier, monospace; font-size: 12px; color: #000; box-sizing: border-box; background: #fff; margin: 0 auto; line-height: 1.2;">
            <div style="text-align: center; margin-bottom: 5px;">
                Pizeria sac.<br>
                JR. JUAN VALER SANDOVAL Nº 682<br>
                RUC:20615656888
            </div>
            
            <div style="border-bottom: 1px dashed #000; margin-bottom: 2px;"></div>
            <div style="border-bottom: 3px double #000; margin-bottom: 5px;"></div>
            
            <div style="text-align: center; font-weight: bold; margin-bottom: 5px; font-size: 14px;">
                NOTA DE VENTA<br>
                Nº ${numero}
            </div>
            
            <div style="border-bottom: 3px double #000; margin-bottom: 5px;"></div>
            
            <table style="width: 100%; font-size: 12px; font-family: 'Courier New', Courier, monospace; margin-bottom: 5px; border-collapse: collapse;">
                <tr><td style="width: 75px; vertical-align: top;">FECHA</td><td style="vertical-align: top;">: ${dateStr}</td></tr>
                <tr><td style="vertical-align: top;">SEÑOR(ES)</td><td style="vertical-align: top;">: ${cliente || '--'}</td></tr>
                <tr><td style="vertical-align: top;">TIPO</td><td style="vertical-align: top;">: ${tipo || 'MESA'}</td></tr>
                <tr><td style="vertical-align: top;">CAJERO</td><td style="vertical-align: top;">: ${cajero || '--'}</td></tr>
            </table>
            
            <div style="border-bottom: 1px dashed #000; margin-bottom: 5px;"></div>
            
            <table style="width: 100%; font-size: 12px; font-family: 'Courier New', Courier, monospace; border-collapse: collapse;">
                <tr>
                    <th style="text-align: left; width: 15%; padding-bottom: 3px;">CANT</th>
                    <th style="text-align: left; width: 45%; padding-bottom: 3px;">DESCRIPCIÓN</th>
                    <th style="text-align: right; width: 20%; padding-bottom: 3px;">PU</th>
                    <th style="text-align: right; width: 20%; padding-bottom: 3px;">TOTAL</th>
                </tr>
                <tr><td colspan="4"><div style="border-bottom: 1px dashed #000; margin-bottom: 3px;"></div></td></tr>
                ${itemsHtml}
                <tr><td colspan="4"><div style="border-bottom: 1px dashed #000; margin-top: 3px; margin-bottom: 3px;"></div></td></tr>
            </table>
            
            <table style="width: 100%; font-size: 12px; font-family: 'Courier New', Courier, monospace; margin-bottom: 5px; border-collapse: collapse;">
                <tr>
                    <td style="text-align: right;">DESCUENTO</td>
                    <td style="text-align: right; width: 30%;">0.00</td>
                </tr>
                <tr><td colspan="2"><div style="border-bottom: 3px double #000; margin: 3px 0;"></div></td></tr>
                <tr>
                    <td style="text-align: left; font-size: 13px;"><strong>IMPORTE TOTAL</strong></td>
                    <td style="text-align: right; font-size: 13px;"><strong>S/. ${parseFloat(total).toFixed(2)}</strong></td>
                </tr>
                <tr><td colspan="2"><div style="border-bottom: 3px double #000; margin: 3px 0;"></div></td></tr>
            </table>
            
            <div style="margin-bottom: 5px;">
                SON: ${numeroALetras(total)}
            </div>
            
            <div style="border-bottom: 1px dashed #000; margin-bottom: 5px;"></div>
            
            <div style="text-align: center; margin-top: 5px; font-weight: bold;">
                *** GRACIAS POR SU COMPRA ***<br>
                ${extra ? extra : ''}
            </div>
        </div>
    `;

    Swal.fire({title: 'Generando PDF...', allowOutsideClick: false, didOpen: () => { Swal.showLoading(); }});

    if (typeof html2pdf === 'undefined') {
        Swal.close();
        mostrarAlerta('error', 'La librería PDF no se cargó. Recarga la página.');
        return;
    }

    let tempElement = document.createElement('div');
    tempElement.innerHTML = htmlContent;

    let opt = {
        margin: 0,
        filename: numero + '.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'mm', format: [80, 250], orientation: 'portrait' }
    };

    html2pdf().set(opt).from(tempElement).output('blob').then(function(pdfBlob) {
        let pdfUrl = URL.createObjectURL(pdfBlob);
        Swal.fire({
            title: `<div style="font-size: 1.15rem; color: #1f2937; margin-bottom: -10px;">${titulo} - ${numero}</div>`,
            html: `
                <div style="height: 50vh; background: #525659; border-radius: 6px; padding: 4px; box-sizing: border-box; margin-bottom: 15px; margin-top: 15px;">
                     <iframe id="ticket-pdf-iframe" src="${pdfUrl}" style="width: 100%; height: 100%; border: none; border-radius: 4px; background: white;"></iframe>
                </div>
                <div style="display: flex; gap: 8px; justify-content: flex-start; align-items: center; border-top: 1px solid #e5e7eb; padding-top: 15px;">
                    <button id="btn-print-pdf" class="btn text-white" style="background-color: #f97316; border-color: #f97316; padding: 6px 14px; font-weight: 500; border-radius: 6px; font-size: 14px; display: flex; align-items: center; gap: 5px;">
                        <i data-lucide="printer" style="width:16px;height:16px;"></i> Imprimir
                    </button>
                    <button id="btn-download-pdf" class="btn btn-light border" style="padding: 6px 14px; font-weight: 500; border-radius: 6px; font-size: 14px; color: #4b5563; display: flex; align-items: center; gap: 5px;">
                        <i data-lucide="download" style="width:16px;height:16px;"></i> Descargar
                    </button>
                    <button id="btn-close-pdf" class="btn btn-light border" style="padding: 6px 14px; font-weight: 500; border-radius: 6px; font-size: 14px; color: #4b5563; margin-left: auto;">
                        Cerrar
                    </button>
                </div>
            `,
            width: 480,
            showConfirmButton: false,
            showCloseButton: false,
            padding: '1.25em',
            didOpen: () => { 
                if (typeof lucide !== 'undefined') lucide.createIcons(); 
                document.getElementById('btn-print-pdf').addEventListener('click', () => {
                    let iframe = document.getElementById('ticket-pdf-iframe');
                    if (iframe) { iframe.contentWindow.print(); }
                });
                document.getElementById('btn-download-pdf').addEventListener('click', () => {
                    let a = document.createElement('a');
                    a.href = pdfUrl;
                    a.download = numero + '.pdf';
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                });
                document.getElementById('btn-close-pdf').addEventListener('click', () => {
                    Swal.close();
                });
            }
        });
    }).catch(function(err) {
        console.error(err);
        Swal.fire('Error', 'No se pudo generar el PDF', 'error');
    });
}

// ==========================================
// MITAD Y MITAD (HALF AND HALF)
// ==========================================
function posAbrirModalMitadYMitad(idCategoria) {
    let prodsCategoria = window.datosApp.subcategorias.filter(p => p.id_categoria == idCategoria);
    let idsProds = prodsCategoria.map(p => p.id);
    
    let pres = window.datosApp.productos.filter(pr => idsProds.includes(pr.id_subcategoria) && pr.estado == 1);
    
    // Buscar la presentación combinada
    let presCombinada = pres.find(pr => (pr.nombre && pr.nombre.toLowerCase().includes('combinada')) || (pr.subcategoria_nombre && pr.subcategoria_nombre.toLowerCase().includes('combinada')));
    
    if (!presCombinada) {
        return mostrarAlerta('warning', 'Crea primero un subcategoria o presentación llamada "Combinada" con sus precios.');
    }

    // Excluir combinada de los sabores elegibles
    let presSabores = pres.filter(pr => pr.id !== presCombinada.id);
    
    if (presSabores.length < 2) return mostrarAlerta('warning', 'Necesitas al menos 2 productos (sabores) configuradas para combinar.');
    
    let prodOptions = '<option value="" disabled selected>-- Seleccionar Sabor --</option>';
    presSabores.forEach(p => {
        let pName = p.nombre === 'Única' || p.nombre === 'Masa Tradicional' ? p.subcategoria_nombre : p.nombre;
        prodOptions += `<option value="${p.id}">${pName}</option>`;
    });

    // Generar la lista de tamaños basada EXCLUSIVAMENTE en presCombinada
    let sizesHtml = '';
    let first = true;
    for (let i = 1; i <= 4; i++) {
        if (presCombinada['nombre_t'+i] && presCombinada['nombre_t'+i].trim()) {
            let tName = presCombinada['nombre_t'+i].trim();
            let tPrice = parseFloat(presCombinada['precio_'+i]);
            sizesHtml += `
                <label class="d-flex align-items-center border p-2 mb-0 bg-white shadow-sm" style="border-radius:8px; cursor:pointer;">
                    <input type="radio" name="swal-tamano" value="${tName}" data-precio="${tPrice}" ${first ? 'checked' : ''} class="mr-2">
                    <span class="flex-grow-1" style="font-size:0.85rem;">${tName}</span>
                    <span class="font-weight-bold text-theme-primary">S/${tPrice.toFixed(2)}</span>
                </label>
            `;
            first = false;
        }
    }

    if (sizesHtml === '') {
        return mostrarAlerta('error', 'La presentación "Combinada" no tiene tamaños ni precios configurados.');
    }

    Swal.fire({
        title: '🍕 Crear Mitad y Mitad',
        html: `
            <div class="text-left mb-3">
                <label class="font-weight-bold text-secondary" style="font-size:0.85rem;">Mitad 1</label>
                <select id="swal-mitad-1" class="form-control mb-2" style="border-radius:8px;" onchange="posActualizarTamanosMitadYMitad()">
                    ${prodOptions}
                </select>
                <label class="font-weight-bold text-secondary" style="font-size:0.85rem;">Mitad 2</label>
                <select id="swal-mitad-2" class="form-control mb-2" style="border-radius:8px;" onchange="posActualizarTamanosMitadYMitad()">
                    ${prodOptions}
                </select>
            </div>
            <div id="swal-tamanos-container" class="text-left d-none">
                <label class="font-weight-bold text-theme-primary mb-2" style="font-size:0.85rem;">Seleccionar Tamaño</label>
                <div id="swal-tamanos-lista" class="d-flex flex-column mt-1" style="gap:6px;">
                    ${sizesHtml}
                </div>
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        confirmButtonColor: '#d97706',
        preConfirm: () => {
            let m1 = document.getElementById('swal-mitad-1').value;
            let m2 = document.getElementById('swal-mitad-2').value;
            if (!m1 || !m2) { Swal.showValidationMessage('Selecciona ambos sabores'); return false; }
            if (m1 === m2) { Swal.showValidationMessage('Selecciona sabores diferentes'); return false; }
            
            let checkedRadio = document.querySelector('input[name="swal-tamano"]:checked');
            if (!checkedRadio) { Swal.showValidationMessage('Selecciona un tamaño válido'); return false; }
            
            return {
                id1: m1,
                id2: m2,
                tamano: checkedRadio.value,
                precio: parseFloat(checkedRadio.dataset.precio)
            };
        }
    }).then(r => {
        if (r.isConfirmed) {
            let p1 = presSabores.find(x => x.id == r.value.id1);
            let p2 = presSabores.find(x => x.id == r.value.id2);
            let n1 = p1.nombre === 'Única' || p1.nombre === 'Masa Tradicional' ? p1.subcategoria_nombre : p1.nombre;
            let n2 = p2.nombre === 'Única' || p2.nombre === 'Masa Tradicional' ? p2.subcategoria_nombre : p2.nombre;
            
            let nombre = `${r.value.tamano} (1/2 ${n1} y 1/2 ${n2})`;
            
            // Agregamos al carrito usando el id de la combinada, para que cobre correctamente si hay lógica interna
            agregarItemAlCarritoLogico(presCombinada.id_subcategoria, nombre, r.value.precio, '');
        }
    });
}

window.posActualizarTamanosMitadYMitad = function() {
    let id1 = document.getElementById('swal-mitad-1').value;
    let id2 = document.getElementById('swal-mitad-2').value;
    let container = document.getElementById('swal-tamanos-container');
    
    if (id1 && id2) {
        container.classList.remove('d-none');
    } else {
        container.classList.add('d-none');
    }
}

// ==========================================
// ENVIAR COMANDAS POR IP (ESC/POS)
// ==========================================
async function posImprimirComandaIP(numero_pedido, cliente_nombre, items, tipo_pedido, mozo) {
    try {
        let res = await fetch('features/caja/controller_imprimir.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                action: 'comanda',
                numero_pedido: numero_pedido,
                cliente_nombre: cliente_nombre,
                items: items,
                tipo_pedido: tipo_pedido,
                mozo: mozo
            })
        });
        let data = await res.json();
        if (data.status !== 'ok') {
            console.error('Error enviando comandas IP:', data.errores || data.message);
        } else {
            console.log('Comandas enviadas a impresoras IP exitosamente');
        }
    } catch(e) {
        console.error('Error de red al enviar comandas IP', e);
    }
}

