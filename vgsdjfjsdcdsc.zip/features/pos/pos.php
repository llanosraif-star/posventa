<style>
                /* ===== MOBILE POS OPTIMIZATIONS ===== */
                @media (max-width: 991.98px) {
                    /* Hide sidebar completely on mobile POS */
                    body.pos-mobile-mode #accordionSidebar {
                        display: none !important;
                    }
                    body.pos-mobile-mode .sidebar-toggled #accordionSidebar {
                        display: none !important;
                    }
                    /* Hide topbar hamburger since sidebar is hidden */
                    body.pos-mobile-mode #sidebarToggleTop {
                        display: none !important;
                    }
                    /* Full width content */
                    body.pos-mobile-mode #content-wrapper {
                        margin-left: 0 !important;
                    }
                    body.pos-mobile-mode #content {
                        padding: 0 !important;
                    }
                    body.pos-mobile-mode .topbar {
                        padding-left: 0.5rem !important;
                    }

                    /* Cart Mobile Tab Behavior (replaces offcanvas) */
                    #pos-col-cart {
                        display: none !important;
                        padding-left: 5px !important;
                        padding-right: 5px !important;
                        padding-bottom: 70px !important;
                        width: 100% !important;
                        max-width: 100% !important;
                        flex: 0 0 100% !important;
                    }
                    body.mostrar-carrito-movil #pos-col-main {
                        display: none !important;
                    }
                    body.mostrar-carrito-movil #pos-col-cart {
                        display: flex !important;
                    }
                    #pos-cart-overlay-bg {
                        display: none !important;
                    }

                } /* End of first media query */

                @media (max-width: 991.98px) {
                    /* POS main area full height on mobile */
                    #pos-col-main {
                        padding-left: 5px !important;
                        padding-right: 5px !important;
                        padding-bottom: 70px !important;
                    }
                    /* Ocultar tabs superiores en móvil/tablet (reemplazados por bottom nav) */
                    #pos-tipo-orden-tabs {
                        display: none !important;
                    }
                    
                    /* Mostrar Bottom Nav en móvil/tablet */
                    .pos-bottom-nav {
                        display: flex !important;
                    }
                }

                /* Bottom Navigation Bar for Mobile POS */
                .pos-bottom-nav {
                    display: none; /* Oculto en desktop */
                    position: fixed;
                    bottom: 0;
                    left: 0;
                    width: 100%;
                    height: 60px;
                    background: #ffffff;
                    box-shadow: 0 -4px 15px rgba(0,0,0,0.08);
                    z-index: 1050;
                    justify-content: space-around;
                    align-items: center;
                    border-top: 1px solid #e2e8f0;
                }
                .pos-bottom-nav-item {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    flex: 1;
                    height: 100%;
                    color: #64748b;
                    text-decoration: none;
                    cursor: pointer;
                    transition: color 0.2s;
                    position: relative;
                }
                .pos-bottom-nav-item:hover, .pos-bottom-nav-item:active {
                    color: #0ea5e9;
                    text-decoration: none;
                }
                .pos-bottom-nav-item.active {
                    color: #0ea5e9;
                    font-weight: 600;
                }
                .pos-bottom-nav-item.active::after {
                    content: '';
                    position: absolute;
                    bottom: 0;
                    left: 50%;
                    transform: translateX(-50%);
                    width: 30px;
                    height: 4px;
                    background-color: #0ea5e9;
                    border-radius: 4px 4px 0 0;
                }
                .pos-bottom-nav-icon {
                    margin-bottom: 2px;
                }
                .pos-bottom-nav-text {
                    font-size: 0.75rem;
                }

                @keyframes fadeInOverlay {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }

                @keyframes fabPulse {
                    0% { box-shadow: 0 4px 15px rgba(14, 165, 233, 0.4); }
                    50% { box-shadow: 0 4px 25px rgba(14, 165, 233, 0.7), 0 0 0 8px rgba(14, 165, 233, 0.15); }
                    100% { box-shadow: 0 4px 15px rgba(14, 165, 233, 0.4); }
                }
            </style>
            
            <div id="pos-cart-overlay-bg" onclick="posCerrarCarritoMovil()"></div>

            <!-- Bottom Navigation Bar (reemplaza al FAB y Tabs en móvil) -->
            <div class="pos-bottom-nav">
                <div class="pos-bottom-nav-item active" id="pos-bottom-tab-mesa" onclick="seleccionarTipoOrdenPOS('mesa')">
                    <i data-lucide="layout-grid" class="pos-bottom-nav-icon" style="width: 22px; height: 22px;"></i>
                    <span class="pos-bottom-nav-text">Mesas</span>
                </div>
                <div class="pos-bottom-nav-item" id="pos-bottom-tab-mostrador" onclick="seleccionarTipoOrdenPOS('mostrador')">
                    <i data-lucide="store" class="pos-bottom-nav-icon" style="width: 22px; height: 22px;"></i>
                    <span class="pos-bottom-nav-text">Mostrador</span>
                </div>
                <div class="pos-bottom-nav-item" id="pos-bottom-tab-resumen" onclick="seleccionarTipoOrdenPOS('resumen')">
                    <i data-lucide="receipt" class="pos-bottom-nav-icon" style="width: 22px; height: 22px;"></i>
                    <span class="pos-bottom-nav-text">Resumen</span>
                </div>
                <div class="pos-bottom-nav-item" id="pos-bottom-tab-carrito" onclick="posAbrirCarritoMovil()">
                    <div class="position-relative">
                        <i data-lucide="shopping-cart" class="pos-bottom-nav-icon" style="width: 22px; height: 22px;"></i>
                        <span id="pos-bottom-nav-cart-count" class="position-absolute d-flex align-items-center justify-content-center" 
                            style="top: -6px; right: -10px; min-width: 18px; height: 18px; border-radius: 9px; padding: 0 4px; font-size: 0.65rem; font-weight: 700; background-color: #ef4444; color: white; border: 2px solid white; line-height: 1;">0</span>
                    </div>
                    <span class="pos-bottom-nav-text">Carrito</span>
                </div>
            </div>

            <div class="row mt-3" style="height: calc(100vh - 85px); min-height: 500px; max-height: calc(100vh - 85px);">
                <!-- Main Col -->
                <div id="pos-col-main" class="col-lg-8 d-flex flex-column h-100 pr-lg-2 mb-3 mb-lg-0" style="transition: all 0.2s ease;">
                    
                    <!-- Unified Main Panel -->
                    <div class="card shadow-sm border d-flex flex-column h-100" style="border-radius: 12px; border-color: #94a3b8 !important; overflow: hidden;">
                        
                        <!-- Tipo de Orden: Mesa / Delivery / Mostrador -->
                        <div class="d-flex border-bottom px-3 pt-3 pb-0 bg-white" id="pos-tipo-orden-tabs" style="gap: 0px; flex-shrink: 0;">
                            <div class="px-4 py-2 font-weight-bold text-theme-primary" style="border-bottom: 3px solid; border-radius: 0; cursor: pointer;" 
                                onclick="seleccionarTipoOrdenPOS('mesa')" id="pos-tab-mesa">
                                <i data-lucide="armchair" style="width:16px;height:16px;margin-right:4px;"></i> Mesa
                            </div>

                            <div class="px-4 py-2 text-muted" style="border-bottom: 3px solid transparent; border-radius: 0; cursor: pointer;" 
                                onclick="seleccionarTipoOrdenPOS('mostrador')" id="pos-tab-mostrador">
                                <i data-lucide="store" style="width:16px;height:16px;margin-right:4px;"></i> Mostrador
                            </div>
                            <div class="px-4 py-2 text-muted" style="border-bottom: 3px solid transparent; border-radius: 0; cursor: pointer;" 
                                onclick="seleccionarTipoOrdenPOS('resumen')" id="pos-tab-resumen">
                                <i data-lucide="inbox" style="width:16px;height:16px;margin-right:4px;"></i> Resumen
                            </div>
                        </div>
                        
                        <!-- MAPA DE MESAS (visible en tipo 'mesa' cuando no hay seleccion) -->
                        <div id="pos-vista-mapa-mesas" class="p-3 bg-light flex-grow-1" style="overflow-y: auto;">
                            
                            <!-- Filtros de Zona -->
                            <div id="pos-zonas-filtros" class="d-flex flex-wrap mb-3 border-bottom pb-3" style="gap: 8px;">
                            </div>

                            <div class="d-flex align-items-center justify-content-between mb-3">
                                <div class="d-flex align-items-center" style="gap:14px; font-size:0.78rem;">
                                    <span><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#22c55e;margin-right:3px;"></span>Libre</span>
                                    <span><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#ef4444;margin-right:3px;"></span>Ocupada</span>
                                    <span><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#a855f7;margin-right:3px;"></span>Por cobrar</span>
                                </div>
                            </div>
                            <div id="pos-zonas-mesas-grid"></div>
                        </div>

                        <!-- RESUMEN DASHBOARD (visible en tipo 'resumen') -->
                        <div id="pos-vista-resumen" class="p-3 bg-light d-none flex-grow-1" style="overflow-y: auto;">
                            <!-- Filtros Resumen -->
                            <div class="d-flex flex-wrap mb-3 border-bottom pb-3" style="gap: 8px;">
                                <button id="pos-btn-filtro-todos" onclick="posSetFiltroResumen('todos')" class="btn btn-sm px-4 font-weight-bold shadow-sm text-white bg-theme-primary border-theme-primary" style="border-radius:20px;">
                                    <i data-lucide="list" style="width:14px;height:14px;margin-right:4px;"></i> Todos
                                </button>
                                <button id="pos-btn-filtro-mesa" onclick="posSetFiltroResumen('mesa')" class="btn btn-sm btn-white text-secondary border px-4 shadow-sm" style="border-radius:20px;">
                                    <i data-lucide="armchair" style="width:14px;height:14px;margin-right:4px;"></i> Mesas
                                </button>
                                <button id="pos-btn-filtro-delivery" onclick="posSetFiltroResumen('delivery')" class="btn btn-sm btn-white text-secondary border px-4 shadow-sm" style="border-radius:20px;">
                                    <i data-lucide="truck" style="width:14px;height:14px;margin-right:4px;"></i> Delivery
                                </button>
                                <button id="pos-btn-filtro-recoger" onclick="posSetFiltroResumen('recoger')" class="btn btn-sm btn-white text-secondary border px-4 shadow-sm" style="border-radius:20px;">
                                    <i data-lucide="person-standing" style="width:14px;height:14px;margin-right:4px;"></i> Por recoger
                                </button>
                                <button id="pos-btn-filtro-llevar" onclick="posSetFiltroResumen('llevar')" class="btn btn-sm btn-white text-secondary border px-4 shadow-sm" style="border-radius:20px;">
                                    <i data-lucide="shopping-bag" style="width:14px;height:14px;margin-right:4px;"></i> Para llevar
                                </button>
                            </div>

                            <!-- Leyenda -->
                            <div class="d-flex align-items-center mb-4" style="gap:14px; font-size:0.8rem;">
                                <span><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#f59e0b;margin-right:4px;"></span>Pendiente</span>
                                <span><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#3b82f6;margin-right:4px;"></span>En proceso</span>
                                <span><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#10b981;margin-right:4px;"></span>Listo</span>
                            </div>

                            <!-- Lista de Órdenes -->
                            <div id="pos-resumen-orders-list" class="d-flex flex-column" style="gap:12px;">
                                <div class="text-center p-4 text-muted border rounded" style="background:#fff; border-radius:12px;">
                                    No hay órdenes activas
                                </div>
                            </div>
                        </div>
                        
                        <!-- HEADER PEDIDO (visible si hay seleccion o es delivery/mostrador) -->
                        <div id="pos-vista-pedido-header" class="d-none bg-white border-bottom" style="flex-shrink: 0;">
                            <!-- Info Mesa Seleccionada -->
                            <div class="px-3 py-2 d-flex align-items-center justify-content-between border-bottom bg-light d-none" id="pos-mesa-activa-info">
                                <div>
                                    <span class="text-muted font-weight-bold" style="font-size:0.8rem;">MESA:</span>
                                    <span id="pos-mesa-activa-nombre" class="font-weight-bold ml-2 text-theme-primary" style="font-size:1.1rem;">--</span>
                                </div>
                                <div class="d-flex align-items-center">
                                    <span id="pos-mesa-activa-timer" class="text-danger font-weight-bold" style="font-size:0.9rem;"></span>
                                    <button class="btn btn-sm btn-outline-primary ml-3" onclick="posAbrirModalCambiarMesa()" style="border-radius:6px;font-size:0.75rem;"><i data-lucide="arrow-right-left" style="width:14px;height:14px;margin-right:4px;"></i>Cambiar Mesa</button>
                                    <button class="btn btn-sm btn-outline-secondary ml-2" onclick="posVolverAMesas()" style="border-radius:6px;font-size:0.75rem;"><i data-lucide="arrow-left" style="width:14px;height:14px;margin-right:4px;"></i>Volver a Mesas</button>
                                </div>
                            </div>
                            
                            <!-- Info Delivery -->
                            <div class="px-3 py-2 border-bottom bg-light d-none align-items-center justify-content-between" id="pos-delivery-info">
                                <div class="d-flex align-items-center flex-wrap" style="gap: 8px;">
                                    <div class="input-group input-group-sm" style="max-width:160px; flex-wrap: nowrap; border-radius:6px;">
                                        <span class="input-group-text bg-white text-muted" style="border-radius:6px 0 0 6px;"><i data-lucide="shopping-bag" style="width:14px;height:14px;"></i></span>
                                        <select id="pos-delivery-tipo" class="form-select" style="border-radius:0 6px 6px 0; font-weight:bold; cursor:pointer;" onchange="posToggleDeliveryTipo()">
                                            <option value="llevar">Para llevar</option>
                                            <option value="delivery">Delivery</option>
                                            <option value="recoger">Por recoger</option>
                                        </select>
                                    </div>
                                    <input id="pos-delivery-cliente" class="form-control form-control-sm" placeholder="Nombre del cliente" style="max-width:200px; border-radius:6px;">
                                    <input id="pos-delivery-telefono" class="form-control form-control-sm" placeholder="Teléfono" style="max-width:140px; border-radius:6px;">
                                    <input id="pos-delivery-direccion" class="form-control form-control-sm" placeholder="Dirección de entrega" style="max-width:250px; border-radius:6px;">
                                    <input id="pos-pickup-time" type="time" class="form-control form-control-sm d-none" style="max-width:110px; border-radius:6px;" title="Hora de Recojo">
                                </div>

                            </div>
                            
                            <!-- Categorías -->
                            <div class="p-3 d-flex" style="overflow-x: auto; white-space: nowrap; gap: 8px;" id="pos-categorias-container">
                                <div class="text-center text-muted p-2 w-100">Cargando categorías...</div>
                            </div>
                        </div>
                        
                        <!-- Subcategorías -->
                        <div id="pos-grupos-container" class="d-none px-3 py-2 border-bottom bg-white" style="overflow-x: auto; white-space: nowrap; gap: 8px; flex-shrink: 0;">
                        </div>
                        
                        <!-- Grid de Subcategorias -->
                        <div id="pos-subcategorias-wrapper" class="flex-grow-1 d-none bg-light" style="overflow-y: auto;">
                            <div class="p-3">
                                <div class="row mx-n2" id="pos-subcategorias-container">
                                    <div class="col-12 text-center text-muted p-5 d-flex flex-column align-items-center">
                                        <i data-lucide="layout-grid" style="width:48px;height:48px;color:#cbd5e1;margin-bottom:15px;"></i>
                                        Selecciona una categoría para ver el menú
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Resumen de Pedido / Carrito (Derecha) -->
                <div id="pos-col-cart" class="col-lg-4 d-flex flex-column h-100 pl-lg-2">
                    <div class="card shadow border h-100 d-flex flex-column position-relative" style="border-radius: 12px; border-color: #94a3b8 !important; overflow: hidden;">
                        
                        <!-- Overlay "Selecciona una Mesa" -->
                        <div id="pos-cart-overlay" class="d-none flex-column align-items-center justify-content-center position-absolute w-100 h-100 bg-white text-center text-muted" style="z-index: 10;">
                            <i data-lucide="mouse-pointer-click" style="width:48px;height:48px;color:#cbd5e1;margin-bottom:15px;"></i>
                            <span style="font-size:0.95rem;">Ninguna mesa seleccionada</span>
                            <span style="font-size:0.8rem;color:#94a3b8;margin-top:5px;" class="px-4">Selecciona una mesa del mapa a la izquierda para poder visualizar y agregar subcategorias al pedido.</span>
                        </div>

                        <!-- Header del Carrito -->
                        <div class="card-header px-3 d-flex flex-column position-relative border-bottom" style="background-color: #64748b; border-radius: 12px 12px 0 0; z-index: 15; gap: 6px; padding-bottom: 10px !important; padding-top: 14px !important;">
                            <!-- Top Row -->
                            <div class="d-flex justify-content-between align-items-center w-100">
                                <h6 class="m-0 font-weight-bold d-flex align-items-center text-white" style="font-size: 1.05rem;">
                                    <i data-lucide="shopping-cart" style="width:20px;height:20px;margin-right:8px;color:#ffffff;"></i> Orden Actual
                                </h6>
                                <div class="d-flex align-items-center" style="gap: 8px;">
                                    <span class="badge bg-white text-dark px-4 font-weight-bold shadow-sm d-none align-items-center" style="border-radius:6px; font-size:0.9rem; letter-spacing: 0.5px; min-width: 70px; height: 24px; justify-content: center;" id="pos-orden-numero-badge"></span>
                                </div>
                            </div>
                            
                            <!-- Bottom Row -->
                            <div class="d-flex justify-content-between align-items-center w-100">
                                <div class="d-flex align-items-center" style="gap: 8px;">
                                    <span class="badge px-3 py-1 font-weight-bold shadow-sm d-flex align-items-center" style="border-radius:20px; font-size:0.8rem; color: white;" id="pos-orden-tipo-badge">
                                        <i id="pos-orden-tipo-icon" data-lucide="layout-grid" style="width:14px;height:14px;margin-right:6px;"></i>
                                        <span id="pos-orden-tipo-text">Mesa</span>
                                    </span>
                                    <span class="badge bg-white text-theme-primary px-2 py-1 font-weight-bold shadow-sm" style="border-radius:20px; font-size:0.75rem;" id="pos-cart-count">0</span>
                                </div>
                                
                                <span class="badge bg-white text-theme-primary px-3 py-1 font-weight-bold shadow-sm align-items-center d-none" style="border-radius:20px; font-size:0.8rem; border: 1px solid #e2e8f0;" id="pos-orden-extra-badge">
                                    <i id="pos-orden-extra-icon" data-lucide="map-pin" style="width:14px;height:14px;margin-right:6px;"></i>
                                    <span id="pos-orden-extra-text">--</span>
                                </span>
                            </div>
                        </div>
                        
                        <!-- Lista de Ítems en el Carrito -->
                        <div class="card-body p-0 flex-grow-1" style="overflow-y: auto; background-color: #ffffff;" id="pos-cart-items">
                            <div class="text-center text-muted py-5 d-flex flex-column align-items-center justify-content-center h-100">
                                <i data-lucide="shopping-bag" style="width:48px;height:48px;color:#cbd5e1;margin-bottom:15px;"></i>
                                <span style="font-size:0.95rem;">La orden está vacía</span>
                                <span style="font-size:0.8rem;color:#94a3b8;margin-top:5px;">Agrega subcategorias desde el menú</span>
                            </div>
                        </div>
                        
                        <!-- Resumen y Checkout (Footer) -->
                        <div class="card-footer bg-light pt-2 pb-2 px-3" style="border-radius: 0 0 10px 10px; border-top: 2px dashed #e2e8f0;">
                            <div class="d-flex justify-content-between mb-1" style="font-size: 0.85rem;">
                                <span class="text-muted">Subtotal</span>
                                <span class="font-weight-bold text-dark" id="pos-subtotal">S/ 0.00</span>
                            </div>
                            <div class="d-flex justify-content-between mb-2" style="font-size: 0.85rem;">
                                <span class="text-muted">Descuento</span>
                                <span class="font-weight-bold text-danger" id="pos-discount">- S/ 0.00</span>
                            </div>
                            <hr class="mt-0 mb-2" style="border-color: #cbd5e1;">
                            <div class="d-flex justify-content-between mb-3 align-items-end">
                                <span class="font-weight-bold text-dark text-uppercase" style="letter-spacing: 0.5px; font-size: 0.9rem;">Total</span>
                                <span class="font-weight-bold text-theme-primary" style="font-size: 1.4rem; line-height: 1;" id="pos-total">S/ 0.00</span>
                            </div>
                            
                            <!-- Botones dinámicos según rol y tipo -->
                            <div id="pos-footer-actions"></div>
                        </div>
                    </div>
                </div>
            </div>

<script>
// Auto-inicializar cuando el SPA inyecte el HTML
if (typeof cargarPOS === 'function') {
    cargarPOS();
}
</script>