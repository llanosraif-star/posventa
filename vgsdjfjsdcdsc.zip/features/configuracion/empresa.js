/**
 * empresa.js - Módulo de Configuración de Empresa
 * Carga y guarda los datos de la empresa
 */

async function cargarEmpresa() {
    try {
        const response = await fetch('features/configuracion/controller_empresa.php');
        const result = await response.json();
        
        if (result.status === 'ok' && result.data) {
            const data = result.data;
            document.getElementById('empNombre').value = data.nombre_comercial || '';
            document.getElementById('empRazon').value = data.razon_social || '';
            document.getElementById('empRuc').value = data.ruc || '';
            document.getElementById('empTel').value = data.telefono || '';
            document.getElementById('empEmail').value = data.email || '';
            document.getElementById('empDir').value = data.direccion || '';
            document.getElementById('empMoneda').value = data.moneda || 'USD';
            document.getElementById('empIgv').value = data.igv || '0';
            document.getElementById('empEstado').value = data.estado || '1';
            
            if (data.logo) {
                const logoPreview = document.getElementById('logoPreview');
                if (logoPreview) {
                    logoPreview.src = data.logo;
                    logoPreview.style.display = 'block';
                    const logoIcon = document.getElementById('logoIcon');
                    if (logoIcon) logoIcon.style.display = 'none';
                }
            }
            
            const cards = document.querySelectorAll('.card-body .h5');
            if (cards.length >= 4) {
                cards[0].textContent = data.razon_social || 'Sin Razón Social';
                cards[1].textContent = data.ruc || 'Sin RUC';
                cards[2].textContent = data.moneda || 'USD';
                cards[3].innerHTML = data.estado == 1 ? '<span class="badge badge-success">Activo</span>' : '<span class="badge badge-danger">Inactivo</span>';
            }
        }
    } catch (error) { console.error('Error:', error); }
}

async function guardarEmpresa() {
    const formData = new FormData();
    formData.append('nombre_comercial', document.getElementById('empNombre').value);
    formData.append('razon_social', document.getElementById('empRazon').value);
    formData.append('ruc', document.getElementById('empRuc').value);
    formData.append('telefono', document.getElementById('empTel').value);
    formData.append('email', document.getElementById('empEmail').value);
    formData.append('direccion', document.getElementById('empDir').value);
    formData.append('moneda', document.getElementById('empMoneda').value);
    formData.append('igv', document.getElementById('empIgv').value);
    formData.append('estado', document.getElementById('empEstado').value);
    
    const logoFile = document.getElementById('empLogo').files[0];
    if (logoFile) {
        formData.append('logo', logoFile);
    }
    
    try {
        const response = await fetch('features/configuracion/controller_empresa.php', { 
            method: 'POST', 
            body: formData 
        });
        const result = await response.json();
        if (result.status === 'ok') {
            Swal.fire({ icon: 'success', title: 'Empresa actualizada', confirmButtonColor: 'hwb(209 7% 2%)' });
            cargarEmpresa();
        } else { mostrarAlerta('error', result.message); }
    } catch (e) { mostrarAlerta('error', 'Error de conexión'); }
}

// Logo preview logic
document.addEventListener('DOMContentLoaded', () => {
    const empLogoInput = document.getElementById('empLogo');
    if (empLogoInput) {
        empLogoInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    let logoPreview = document.getElementById('logoPreview');
                    let logoIcon = document.getElementById('logoIcon');
                    if (logoPreview) {
                        logoPreview.src = e.target.result;
                        logoPreview.style.display = 'block';
                    }
                    if (logoIcon) {
                        logoIcon.style.display = 'none';
                    }
                }
                reader.readAsDataURL(this.files[0]);
            }
        });
    }
});

