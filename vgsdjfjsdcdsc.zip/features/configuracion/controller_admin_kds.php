<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../config/database.php';

// Verificar permisos
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'No autorizado']);
    exit;
}

$db = Database::getInstance()->getConnection();
$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'listar':
            $stmt = $db->query("SELECT k.*, a.nombre as area_nombre 
                                FROM kds_pantallas k 
                                LEFT JOIN areas_produccion a ON k.id_areaproduccion = a.id 
                                ORDER BY k.id DESC");
            $pantallas = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['status' => 'ok', 'data' => $pantallas]);
            break;

        case 'areas':
            $stmt = $db->query("SELECT id, nombre FROM areas_produccion WHERE estado = 1");
            $areas = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['status' => 'ok', 'data' => $areas]);
            break;

        case 'guardar':
            $data = json_decode(file_get_contents('php://input'), true);
            $id = intval($data['id'] ?? 0);
            $nombre = trim($data['nombre'] ?? '');
            $id_areaproduccion = intval($data['id_areaproduccion'] ?? 0);
            $estado = intval($data['estado'] ?? 1);

            if (empty($nombre) || empty($id_areaproduccion)) {
                echo json_encode(['status' => 'error', 'message' => 'El nombre y el área de producción son obligatorios.']);
                break;
            }

            if ($id > 0) {
                // Update
                $stmt = $db->prepare("UPDATE kds_pantallas SET nombre = ?, id_areaproduccion = ?, estado = ? WHERE id = ?");
                $stmt->execute([$nombre, $id_areaproduccion, $estado, $id]);
                echo json_encode(['status' => 'ok', 'message' => 'Pantalla KDS actualizada correctamente.']);
            } else {
                // Insert
                $stmt = $db->prepare("INSERT INTO kds_pantallas (nombre, id_areaproduccion, estado) VALUES (?, ?, ?)");
                $stmt->execute([$nombre, $id_areaproduccion, $estado]);
                echo json_encode(['status' => 'ok', 'message' => 'Pantalla KDS creada correctamente.']);
            }
            break;

        case 'eliminar':
            $data = json_decode(file_get_contents('php://input'), true);
            $id = intval($data['id'] ?? 0);
            if ($id > 0) {
                // Hard delete or soft delete
                $stmt = $db->prepare("DELETE FROM kds_pantallas WHERE id = ?");
                $stmt->execute([$id]);
                echo json_encode(['status' => 'ok', 'message' => 'Pantalla eliminada.']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'ID inválido.']);
            }
            break;

        default:
            echo json_encode(['status' => 'error', 'message' => 'Acción no válida']);
            break;
    }
} catch (Exception $e) {
    error_log("Error en controller_admin_kds: " . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => 'Error interno del servidor.']);
}
