/**
 * usuarios.js - Módulo de Administración de Personal
 * CRUD completo: crear, editar, listar usuarios
 */

// ==========================================
// TOGGLE CONTRASEÑA (SVG inline para SweetAlert)
// ==========================================
const svgEyeOpen = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#64748b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/></svg>';
const svgEyeClosed = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#64748b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49"/><path d="M14.084 14.158a3 3 0 0 1-4.242-4.242"/><path d="M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143"/><path d="m2 2 20 20"/></svg>';

window.togglePassVis = function(inputId, btn) {
    var input = document.getElementById(inputId);
    if (input.type === 'password') {
        input.type = 'text';
        btn.innerHTML = svgEyeClosed;
    } else {
        input.type = 'password';
        btn.innerHTML = svgEyeOpen;
    }
};

// ==========================================
// FORMULARIO USUARIO
// ==========================================
function generarFormularioUsuario(item = null) {
    let t = item || {};
    let estado = (t.estado !== undefined) ? t.estado : 1;
    let rol = t.id_rol || 3;
    
    return `
        <div style="text-align: left; font-family: 'Inter', sans-serif;" class="p-1 overflow-hidden">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Nombre <span class="text-danger">*</span></label>
                    <input id="swal-nombre" class="form-control form-control-sm border-secondary-subtle" placeholder="Ej. Juan" value="${t.nombre || ''}">
                </div>
                <div class="col-md-6">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Apellido <span class="text-danger">*</span></label>
                    <input id="swal-apellido" class="form-control form-control-sm border-secondary-subtle" placeholder="Ej. Pérez" value="${t.apellido || ''}">
                </div>
                <div class="col-12">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Email / Usuario <span class="text-danger">*</span></label>
                    <input id="swal-email" class="form-control form-control-sm border-secondary-subtle" placeholder="Ej. juan@correo.com" value="${t.email || ''}">
                </div>
                <div class="col-12">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Contraseña ${t.id ? '<span class="text-muted fw-normal" style="font-size: 0.75rem;">(Dejar en blanco para no cambiar)</span>' : '<span class="text-danger">*</span>'}</label>
                    <div class="input-group input-group-sm">
                        <input id="swal-pass" class="form-control border-secondary-subtle" type="password" placeholder="Contraseña">
                        <button class="btn btn-outline-secondary border-secondary-subtle px-2" type="button" onclick="togglePassVis('swal-pass', this)" style="background-color: #f8fafc; display:flex; align-items:center;">
                            ${svgEyeOpen}
                        </button>
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Rol</label>
                    <select id="swal-rol" class="form-select form-select-sm border-secondary-subtle">
                        <option value="1" ${rol == 1 ? 'selected' : ''}>Administrador</option>
                        <option value="2" ${rol == 2 ? 'selected' : ''}>Cajero</option>
                        <option value="3" ${rol == 3 ? 'selected' : ''}>Mesero</option>
                        <option value="4" ${rol == 4 ? 'selected' : ''}>Cocinero</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Estado</label>
                    <select id="swal-estado" class="form-select form-select-sm border-secondary-subtle">
                        <option value="1" ${estado == 1 ? 'selected' : ''}>ACTIVO</option>
                        <option value="0" ${estado == 0 ? 'selected' : ''}>INACTIVO</option>
                    </select>
                </div>
            </div>
        </div>
    `;
}

// ==========================================
// EDITAR PERSONAL
// ==========================================
function editarUsuario(id, item) {
    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Editar Personal</h5><p style="margin: 0; font-size: 0.88rem; color: #6b7280; font-weight: normal;">Modifica los datos del personal</p></div>',
        html: generarFormularioUsuario(item),
        width: 550,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-secondary px-4',
            actions: 'w-100 justify-content-center mt-3 pt-3 border-top gap-3',
            popup: 'rounded-lg p-4',
            title: 'w-100 m-0'
        },
        didOpen: () => {
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            confirmBtn.style.borderRadius = '8px';
            confirmBtn.style.fontWeight = '500';
            cancelBtn.style.borderRadius = '8px';
        },
        preConfirm: () => {
            return {
                id: id,
                nombre: document.getElementById('swal-nombre').value,
                apellido: document.getElementById('swal-apellido').value,
                email: document.getElementById('swal-email').value,
                password: document.getElementById('swal-pass').value,
                id_rol: document.getElementById('swal-rol').value,
                estado: document.getElementById('swal-estado').value
            }
        }
    }).then(async (r) => {
        if (r.isConfirmed) {
            if(!r.value.nombre || !r.value.email) { Swal.fire('Error', 'Nombre y Email son obligatorios', 'error'); return; }
            const res = await fetch('features/configuracion/controller_usuarios.php?action=editar', { method: 'POST', body: JSON.stringify(r.value) });
            const data = await res.json();
            if (data.status === 'ok') { 
                Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Usuario actualizado', showConfirmButton: false, timer: 3000 });
                cargarUsuarios(); 
            } else mostrarAlerta('error', data.message);
        }
    });
}

// ==========================================
// NUEVO PERSONAL
// ==========================================
function modalNuevoUsuario() {
    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Nuevo Personal</h5><p style="margin: 0; font-size: 0.88rem; color: #6b7280; font-weight: normal;">Registra un nuevo miembro del personal</p></div>',
        html: generarFormularioUsuario(),
        width: 550,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-secondary px-4',
            actions: 'w-100 justify-content-center mt-3 pt-3 border-top gap-3',
            popup: 'rounded-lg p-4',
            title: 'w-100 m-0'
        },
        didOpen: () => {
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            confirmBtn.style.borderRadius = '8px';
            confirmBtn.style.fontWeight = '500';
            cancelBtn.style.borderRadius = '8px';
        },
        preConfirm: () => {
            return {
                nombre: document.getElementById('swal-nombre').value,
                apellido: document.getElementById('swal-apellido').value,
                email: document.getElementById('swal-email').value,
                password: document.getElementById('swal-pass').value,
                id_rol: document.getElementById('swal-rol').value,
                estado: document.getElementById('swal-estado').value
            };
        }
    }).then(async (r) => {
        if (r.isConfirmed) {
            if(!r.value.nombre || !r.value.email || !r.value.password) { Swal.fire('Error', 'Nombre, Email y Contraseña son obligatorios para un nuevo usuario', 'error'); return; }
            const res = await fetch('features/configuracion/controller_usuarios.php?action=crear', { method: 'POST', body: JSON.stringify(r.value) });
            const data = await res.json();
            if (data.status === 'ok') { 
                Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Usuario creado', showConfirmButton: false, timer: 3000 });
                cargarUsuarios(); 
            } else mostrarAlerta('error', data.message);
        }
    });
}

// ==========================================
// CARGAR / LISTAR USUARIOS
// ==========================================
async function cargarUsuarios() {
    try {
        const response = await fetch('features/configuracion/controller_usuarios.php');
        const result = await response.json();
        const tbody = document.getElementById('tbodyUsuarios');
        
        if (result.status === 'ok') {
            window.datosApp.usuarios = result.data;
            if (result.data.length > 0) {
                let html = '';
                result.data.forEach((u, index) => {
                    let badgeClass = 'bg-secondary text-white';
                    let rolDisplay = u.rol.charAt(0).toUpperCase() + u.rol.slice(1);
                    if (u.rol === 'administrador' || u.rol === 'admin') { badgeClass = 'bg-danger text-white'; rolDisplay = 'Administrador'; }
                    if (u.rol === 'cajero') { badgeClass = 'bg-primary text-white'; rolDisplay = 'Cajero'; }
                    if (u.rol === 'mesero') { badgeClass = 'bg-info text-white'; rolDisplay = 'Mesero'; }
                    if (u.rol === 'cocina' || u.rol === 'cocinero') { badgeClass = 'bg-warning text-white'; rolDisplay = 'Cocinero'; }
                    
                    let estadoBadge = u.estado == 1 ? '<span class="badge bg-success text-white">Activo</span>' : '<span class="badge bg-secondary text-white">Inactivo</span>';
                    
                    html += `<tr>
                        <td class="pl-4">${index + 1}</td>
                        <td>${u.nombre} ${u.apellido}</td>
                        <td>${u.email}</td>
                        <td><span class="badge ${badgeClass}">${rolDisplay}</span></td>
                        <td>${estadoBadge}</td>
                        <td class="small text-gray-500">${u.ultimo_acceso || '-'}</td>
                        <td class="text-center">
                            <div class="d-flex justify-content-center" style="gap: 6px;">
                                <button class="btn btn-sm p-1 d-flex align-items-center justify-content-center" style="border-radius:6px; color:#475569; background:#f8fafc; border:1px solid #e2e8f0; width:26px; height:26px;" onclick="alertaEditar(${u.id}, 'usuarios')" title="Editar"><i data-lucide="pencil" style="width:12px;height:12px;"></i></button>
                                <button class="btn btn-sm p-1 d-flex align-items-center justify-content-center" style="border-radius:6px; color:#ef4444; background:#fef2f2; border:1px solid #fecaca; width:26px; height:26px;" onclick="alertaEliminar(${u.id}, 'usuarios')" title="Eliminar"><i data-lucide="trash-2" style="width:12px;height:12px;"></i></button>
                            </div>
                        </td>
                    </tr>`;
                });
                tbody.innerHTML = html;
                lucide.createIcons();
            } else {
                tbody.innerHTML = '<tr><td colspan="7" class="text-center">No hay usuarios registrados</td></tr>';
            }
        }
    } catch (error) { console.error('Error:', error); }
}

