<!--begin::App Content Header-->
<div class="app-content-header">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-sm-6">
                <h4 class="mb-0 d-flex align-items-center text-dark" style="font-weight: 600; font-size: 22px;">
                    <i data-lucide="monitor" style="width:22px;height:22px;margin-right:8px; color: #475569;"></i> Gestión de Pantallas KDS
                </h4>
            </div>
            <div class="col-sm-6">
                <div class="float-sm-end d-flex align-items-center gap-3">
                    <button class="btn btn-primary shadow-sm d-flex align-items-center" style="font-weight: 500; border-radius: 8px; padding: 0.45rem 1rem; transition: all 0.2s;" onclick="modalNuevoKDS()">
                        <i data-lucide="plus" style="width:18px;height:18px;margin-right:6px; stroke-width: 2.5;"></i> Nuevo KDS
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end::App Content Header-->

<style>
    .table-hover tbody tr:hover {
        background-color: #e2e8f0 !important;
        transition: background-color 0.2s ease;
    }
</style>

<div class="card mb-4" style="border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.03) !important;">
    <div class="card-header py-3 d-flex justify-content-between align-items-center" style="border-radius: 12px 12px 0 0;">
        <div class="d-flex flex-column">
            <h6 class="m-0 font-weight-bold d-flex align-items-center"><i data-lucide="monitor" style="width:16px;height:16px;margin-right:6px;"></i>Lista de Pantallas KDS</h6>
            <span style="font-size: 0.75rem; color: #64748b; margin-top: 2px;">Configura las pantallas que se utilizarán en la cocina y pizzeros.</span>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0" style="font-size:0.85rem;">
                <thead style="border-bottom: 1px solid var(--bs-border-color);">
                    <tr>
                        <th class="border-0 pl-4 bg-body-secondary">ID</th>
                        <th class="border-0 bg-body-secondary">Nombre de Pantalla</th>
                        <th class="border-0 bg-body-secondary">Área de Producción</th>
                        <th class="border-0 bg-body-secondary">Estado</th>
                        <th class="border-0 text-center bg-body-secondary" style="width: 150px;">Acciones</th>
                    </tr>
                </thead>
                <tbody id="tbodyKDS">
                    <tr><td colspan="5" class="text-center py-4 text-muted">Cargando pantallas...</td></tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
if(typeof cargarPantallasKDS === 'function') {
    cargarPantallasKDS();
}
</script>
