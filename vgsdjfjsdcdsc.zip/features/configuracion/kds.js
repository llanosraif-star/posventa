async function cargarPantallasKDS() {
    try {
        let res = await fetch('features/configuracion/controller_admin_kds.php?action=listar');
        let data = await res.json();
        
        let html = '';
        if (data.data && data.data.length > 0) {
            data.data.forEach(k => {
                let badgeEstado = k.estado == 1 ? '<span class="badge bg-success">Activo</span>' : '<span class="badge bg-secondary">Inactivo</span>';
                
                html += `
                <tr>
                    <td class="pl-4">#${k.id}</td>
                    <td class="font-weight-bold">${k.nombre}</td>
                    <td><span class="badge bg-info text-dark">${k.area_nombre || 'N/A'}</span></td>
                    <td>${badgeEstado}</td>
                    <td class="text-center">
                        <a href="kds.php?area=${k.id_areaproduccion}&name=${encodeURIComponent(k.nombre)}" target="_blank" class="btn btn-sm btn-light border shadow-sm" title="Abrir Pantalla KDS">
                            <i data-lucide="external-link" class="text-success" style="width:16px;height:16px;"></i>
                        </a>
                        <button class="btn btn-sm btn-light border shadow-sm" onclick='modalEditarKDS(${JSON.stringify(k)})'>
                            <i data-lucide="edit" class="text-primary" style="width:16px;height:16px;"></i>
                        </button>
                        <button class="btn btn-sm btn-light border shadow-sm text-danger" onclick="eliminarKDS(${k.id})">
                            <i data-lucide="trash-2" style="width:16px;height:16px;"></i>
                        </button>
                    </td>
                </tr>`;
            });
        } else {
            html = '<tr><td colspan="5" class="text-center py-4 text-muted">No hay pantallas KDS registradas</td></tr>';
        }
        
        document.getElementById('tbodyKDS').innerHTML = html;
        if(typeof lucide !== 'undefined') lucide.createIcons();
    } catch(e) {
        console.error(e);
        document.getElementById('tbodyKDS').innerHTML = '<tr><td colspan="5" class="text-center py-4 text-danger">Error al cargar pantallas KDS</td></tr>';
    }
}

async function obtenerAreasProduccion() {
    let options = '<option value="">Seleccione un área...</option>';
    try {
        let res = await fetch('features/configuracion/controller_admin_kds.php?action=areas');
        let data = await res.json();
        if(data.data) {
            data.data.forEach(a => {
                options += `<option value="${a.id}">${a.nombre}</option>`;
            });
        }
    } catch(e) { console.error(e); }
    return options;
}

function generarFormularioKDS(item = null, areasOptions = '') {
    let t = item || {};
    let estado = (t.estado !== undefined) ? t.estado : 1;
    
    // Si es edición, preseleccionar área
    if (t.id_areaproduccion) {
        areasOptions = areasOptions.replace(`value="${t.id_areaproduccion}"`, `value="${t.id_areaproduccion}" selected`);
    }

    return `
        <div style="text-align: left; font-family: 'Inter', sans-serif;" class="p-1 overflow-hidden">
            <input type="hidden" id="kdsId" value="${t.id || ''}">
            <div class="row g-3">
                <div class="col-12">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Nombre del KDS <span class="text-danger">*</span></label>
                    <input id="kdsNombre" class="form-control form-control-sm border-secondary-subtle" value="${t.nombre || ''}" placeholder="Ej. Tablet Pizzeros" required>
                </div>
                <div class="col-12">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Área de Producción <span class="text-danger">*</span></label>
                    <select id="kdsArea" class="form-select form-select-sm border-secondary-subtle" required>
                        ${areasOptions}
                    </select>
                </div>
                <div class="col-12">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Estado</label>
                    <select id="kdsEstado" class="form-select form-select-sm border-secondary-subtle">
                        <option value="1" ${estado == 1 ? 'selected' : ''}>ACTIVO</option>
                        <option value="0" ${estado == 0 ? 'selected' : ''}>INACTIVO</option>
                    </select>
                </div>
            </div>
        </div>
    `;
}

async function modalNuevoKDS() {
    let areasOptions = await obtenerAreasProduccion();
    
    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Nueva Pantalla KDS</h5><p style="margin: 0; font-size: 0.85rem; color: #6b7280; font-weight: normal;">Agrega una pantalla de cocina</p></div>',
        html: generarFormularioKDS(null, areasOptions),
        width: 550,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-secondary px-4',
            actions: 'w-100 justify-content-center mt-3 pt-3 border-top gap-3',
            popup: 'rounded-lg p-4',
            title: 'w-100 m-0'
        },
        didOpen: () => {
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            confirmBtn.style.borderRadius = '8px';
            confirmBtn.style.fontWeight = '500';
            cancelBtn.style.borderRadius = '8px';
        },
        preConfirm: () => {
            const nombre = document.getElementById('kdsNombre').value;
            const area = document.getElementById('kdsArea').value;
            if(!nombre || !area) {
                Swal.showValidationMessage('El nombre y el área son obligatorios');
                return false;
            }
            return {
                nombre: nombre,
                id_areaproduccion: area,
                estado: document.getElementById('kdsEstado').value
            };
        }
    }).then(async (result) => {
        if(result.isConfirmed) {
            guardarKDS(result.value);
        }
    });
}

async function modalEditarKDS(kds) {
    let areasOptions = await obtenerAreasProduccion();
    
    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Editar Pantalla KDS</h5><p style="margin: 0; font-size: 0.85rem; color: #6b7280; font-weight: normal;">Modifica los detalles de la pantalla</p></div>',
        html: generarFormularioKDS(kds, areasOptions),
        width: 550,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-secondary px-4',
            actions: 'w-100 justify-content-center mt-3 pt-3 border-top gap-3',
            popup: 'rounded-lg p-4',
            title: 'w-100 m-0'
        },
        didOpen: () => {
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            confirmBtn.style.borderRadius = '8px';
            confirmBtn.style.fontWeight = '500';
            cancelBtn.style.borderRadius = '8px';
        },
        preConfirm: () => {
            const nombre = document.getElementById('kdsNombre').value;
            const area = document.getElementById('kdsArea').value;
            if(!nombre || !area) {
                Swal.showValidationMessage('El nombre y el área son obligatorios');
                return false;
            }
            return {
                id: document.getElementById('kdsId').value,
                nombre: nombre,
                id_areaproduccion: area,
                estado: document.getElementById('kdsEstado').value
            };
        }
    }).then(async (result) => {
        if(result.isConfirmed) {
            guardarKDS(result.value);
        }
    });
}

async function guardarKDS(data) {
    try {
        let res = await fetch('features/configuracion/controller_admin_kds.php?action=guardar', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(data)
        });
        let result = await res.json();
        
        if (result.status === 'ok') {
            Swal.fire({ icon: 'success', title: '¡Éxito!', text: result.message, timer: 1500, showConfirmButton: false });
            cargarPantallasKDS();
        } else {
            Swal.fire('Error', result.message, 'error');
        }
    } catch(e) {
        Swal.fire('Error', 'Error de conexión', 'error');
    }
}

function eliminarKDS(id) {
    Swal.fire({
        title: '¿Eliminar KDS?',
        text: "No podrás revertir esto",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Sí, eliminar'
    }).then(async (result) => {
        if (result.isConfirmed) {
            try {
                let res = await fetch('features/configuracion/controller_admin_kds.php?action=eliminar', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({id: id})
                });
                let data = await res.json();
                if(data.status === 'ok') {
                    Swal.fire({ icon: 'success', title: 'Eliminado', text: data.message, timer: 1500, showConfirmButton: false });
                    cargarPantallasKDS();
                } else {
                    Swal.fire('Error', data.message, 'error');
                }
            } catch(e) {
                Swal.fire('Error', 'Error de conexión', 'error');
            }
        }
    });
}
