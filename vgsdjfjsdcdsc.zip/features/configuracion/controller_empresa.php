<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../config/database.php';

$db = Database::getInstance()->getConnection();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    // Ensure table exists
    $db->exec("CREATE TABLE IF NOT EXISTS empresa (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre_comercial VARCHAR(150) DEFAULT '',
        razon_social VARCHAR(150) DEFAULT '',
        ruc VARCHAR(20) DEFAULT '',
        direccion VARCHAR(255) DEFAULT '',
        telefono VARCHAR(50) DEFAULT '',
        email VARCHAR(100) DEFAULT '',
        moneda VARCHAR(10) DEFAULT 'USD',
        igv DECIMAL(5,2) DEFAULT 0.00,
        estado TINYINT DEFAULT 1,
        logo VARCHAR(255) DEFAULT ''
    )");

    // Ensure logo column exists if table was created previously without it
    try {
        $db->exec("ALTER TABLE empresa ADD COLUMN logo VARCHAR(255) DEFAULT ''");
    } catch (PDOException $e) {
        // Ignore error if column already exists
    }

    // Ensure a default row exists with id=1
    $stmt = $db->query("SELECT COUNT(*) FROM empresa WHERE id = 1");
    if ($stmt->fetchColumn() == 0) {
        $db->exec("INSERT INTO empresa (id, nombre_comercial, razon_social, ruc, direccion, telefono, email, moneda, igv, estado) 
                   VALUES (1, 'Mi Proyecto', 'Mi Empresa S.A.C.', '20123456789', 'Av. Principal 123', '999888777', 'admin@miproyecto.com', 'USD', 0, 1)");
    }

    switch ($method) {
        case 'GET':
            $stmt = $db->query("SELECT * FROM empresa WHERE id=1 LIMIT 1");
            $empresa = $stmt->fetch();
            echo json_encode(['status' => 'ok', 'data' => $empresa ?: []]);
            break;

        case 'POST':
            $isJson = isset($_SERVER['CONTENT_TYPE']) && strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false;
            $data = $isJson ? json_decode(file_get_contents('php://input'), true) : $_POST;
            
            $logoPath = null;
            
            if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
                $uploadDir = __DIR__ . '/../assets/img/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }
                
                $fileExtension = pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION);
                $fileName = 'logo_' . time() . '.' . $fileExtension;
                $targetFile = $uploadDir . $fileName;
                
                if (move_uploaded_file($_FILES['logo']['tmp_name'], $targetFile)) {
                    $logoPath = 'assets/img/' . $fileName;
                }
            }

            if ($logoPath) {
                $stmt = $db->prepare("UPDATE empresa SET nombre_comercial=?, razon_social=?, ruc=?, direccion=?, telefono=?, email=?, moneda=?, igv=?, estado=?, logo=? WHERE id=1");
                $stmt->execute([
                    $data['nombre_comercial'], $data['razon_social'], $data['ruc'],
                    $data['direccion'], $data['telefono'], $data['email'],
                    $data['moneda'], $data['igv'], $data['estado'], $logoPath
                ]);
            } else {
                $stmt = $db->prepare("UPDATE empresa SET nombre_comercial=?, razon_social=?, ruc=?, direccion=?, telefono=?, email=?, moneda=?, igv=?, estado=? WHERE id=1");
                $stmt->execute([
                    $data['nombre_comercial'], $data['razon_social'], $data['ruc'],
                    $data['direccion'], $data['telefono'], $data['email'],
                    $data['moneda'], $data['igv'], $data['estado']
                ]);
            }
            
            echo json_encode(['status' => 'ok', 'message' => 'Empresa actualizada', 'logo' => $logoPath]);
            break;

        default:
            http_response_code(405);
            echo json_encode(['status' => 'error', 'message' => 'Método no permitido']);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}

