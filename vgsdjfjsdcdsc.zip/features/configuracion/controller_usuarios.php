<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../config/database.php';

$db = Database::getInstance()->getConnection();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    switch ($method) {
        case 'GET':
            if ($action === 'roles') {
                $stmt = $db->query("SELECT id, nombre FROM roles ORDER BY id");
                echo json_encode(['status'=>'ok','data'=>$stmt->fetchAll()]);
            } else {
                $stmt = $db->query("SELECT u.id, u.nombre, u.apellido, u.email, u.id_rol, r.nombre as rol, u.estado, u.ultimo_acceso, u.created_at FROM usuarios u JOIN roles r ON u.id_rol = r.id ORDER BY u.id");
                echo json_encode(['status'=>'ok','data'=>$stmt->fetchAll()]);
            }
            break;

        case 'POST':
            $data = json_decode(file_get_contents('php://input'), true);
            if ($action === 'crear') {
                $hash = password_hash($data['password'], PASSWORD_DEFAULT);
                $stmt = $db->prepare("INSERT INTO usuarios (nombre, apellido, email, password, id_rol, estado) VALUES (?,?,?,?,?,?)");
                $stmt->execute([$data['nombre'], $data['apellido'], $data['email'], $hash, $data['id_rol'], $data['estado'] ?? 1]);
                echo json_encode(['status'=>'ok','message'=>'Usuario creado','id'=>$db->lastInsertId()]);
            } elseif ($action === 'editar') {
                $sql = "UPDATE usuarios SET nombre=?, apellido=?, email=?, id_rol=?, estado=? WHERE id=?";
                $params = [$data['nombre'], $data['apellido'], $data['email'], $data['id_rol'], $data['estado'], $data['id']];
                if (!empty($data['password'])) {
                    $sql = "UPDATE usuarios SET nombre=?, apellido=?, email=?, password=?, id_rol=?, estado=? WHERE id=?";
                    $params = [$data['nombre'], $data['apellido'], $data['email'], password_hash($data['password'], PASSWORD_DEFAULT), $data['id_rol'], $data['estado'], $data['id']];
                }
                $db->prepare($sql)->execute($params);
                echo json_encode(['status'=>'ok','message'=>'Usuario actualizado']);
            } elseif ($action === 'eliminar') {
                $db->prepare("DELETE FROM usuarios WHERE id=?")->execute([$data['id']]);
                echo json_encode(['status'=>'ok','message'=>'Usuario eliminado']);
            }
            break;

        default:
            http_response_code(405);
            echo json_encode(['status'=>'error','message'=>'Método no permitido']);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['status'=>'error','message'=>$e->getMessage()]);
}

