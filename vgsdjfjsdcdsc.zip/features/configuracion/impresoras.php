<!--begin::App Content Header-->
<div class="app-content-header">
    <!--begin::Container-->
    <div class="container-fluid">
        <!--begin::Row-->
        <div class="row align-items-center">
            <div class="col-sm-6">
                <h4 class="mb-0 d-flex align-items-center text-dark" style="font-weight: 600; font-size: 22px;">
                    <i data-lucide="printer" style="width:22px;height:22px;margin-right:8px; color: #475569;"></i> Impresoras
                </h4>
            </div>
            <div class="col-sm-6">
                <div class="float-sm-end d-flex align-items-center gap-3">
                    <button class="btn btn-primary shadow-sm d-flex align-items-center" style="font-weight: 500; border-radius: 8px; padding: 0.45rem 1rem; transition: all 0.2s;" onclick="modalNuevaImpresora()">
                        <i data-lucide="plus" style="width:18px;height:18px;margin-right:6px; stroke-width: 2.5;"></i> Nueva Impresora
                    </button>
                </div>
            </div>
        </div>
        <!--end::Row-->
    </div>
    <!--end::Container-->
</div>
<!--end::App Content Header-->

<style>
    /* Efecto hover más gris para la tabla */
    .table-hover tbody tr:hover {
        background-color: #e2e8f0 !important;
        transition: background-color 0.2s ease;
    }
</style>

<div class="row">
    <div class="col-lg-8">
        <div class="card mb-4" style="border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.03) !important;">
            <div class="card-header py-3 d-flex justify-content-between align-items-center" style="border-radius: 12px 12px 0 0;">
                <h6 class="m-0 font-weight-bold d-flex align-items-center"><i data-lucide="printer" style="width:16px;height:16px;margin-right:6px;"></i>Impresoras de Red</h6>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0" style="font-size:0.85rem;">
                        <thead style="border-bottom: 1px solid var(--bs-border-color);">
                            <tr>
                                <th class="border-0 pl-4 bg-body-secondary">#</th>
                                <th class="border-0 bg-body-secondary">Nombre</th>
                                <th class="border-0 bg-body-secondary">IP</th>
                                <th class="border-0 bg-body-secondary">Puerto</th>
                                <th class="border-0 bg-body-secondary">Papel</th>
                                <th class="border-0 bg-body-secondary">Estado</th>
                                <th class="border-0 text-center bg-body-secondary" style="width: 100px;">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="tbodyImpresoras">
                            <tr><td colspan="7" class="text-center py-5 text-muted">Cargando...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <div class="card mb-4" style="border-radius: 12px; overflow: hidden; border: 1px solid #bae6fd; box-shadow: 0 4px 15px rgba(3, 105, 161, 0.05) !important; background: #e0f2fe; color: #0369a1;">
            <div class="card-body p-4">
                <div class="d-flex align-items-center mb-3" style="gap: 10px;">
                    <i data-lucide="alert-circle" style="width:22px;height:22px;color:#0369a1;fill:#0369a1;color:white;"></i>
                    <h5 class="m-0 font-weight-bold" style="font-size: 1.1rem; color: #0369a1;">Información</h5>
                </div>
                <h6 class="font-weight-bold mb-2" style="font-size: 0.95rem; color: #0369a1;">Impresoras</h6>
                <p class="mb-4" style="font-size: 0.85rem; line-height: 1.5; color: #075985;">
                    Permite la impresión de tickets de comandas para informar a la área de producción sobre la preparación de los pedidos.
                </p>
                
                <div class="d-flex mb-3" style="gap: 10px;">
                    <i data-lucide="chevron-right" style="width:16px;height:16px;color:#0369a1;flex-shrink:0;margin-top:2px;"></i>
                    <p class="mb-0" style="font-size: 0.85rem; line-height: 1.5; color: #075985;">
                        Agregue una o varias impresoras, según la distribución de su restaurante.
                    </p>
                </div>
                
                <div class="d-flex" style="gap: 10px;">
                    <i data-lucide="chevron-right" style="width:16px;height:16px;color:#0369a1;flex-shrink:0;margin-top:2px;"></i>
                    <p class="mb-0" style="font-size: 0.85rem; line-height: 1.5; color: #075985;">
                        Asegúrese de que el nombre de la impresora sea igual al nombre de la impresora instalada en su ordenador.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
if(typeof cargarMesasImpresoras === 'function') {
    cargarMesasImpresoras();
}
</script>