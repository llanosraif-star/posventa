<!--begin::App Content Header-->
<div class="app-content-header">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-sm-6">
                <h4 class="mb-0 d-flex align-items-center text-dark" style="font-weight: 600; font-size: 22px;">
                    <i data-lucide="settings" style="width:22px;height:22px;margin-right:8px; color: #475569;"></i> Configuración de Empresa
                </h4>
            </div>
        </div>
    </div>
</div>
<!--end::App Content Header-->

<style>
    /* Efecto hover más gris para la tabla */
    .table-hover tbody tr:hover {
        background-color: #e2e8f0 !important;
        transition: background-color 0.2s ease;
    }
</style>

<div class="row">
    <div class="col-lg-8">
        <!-- DATOS PRINCIPALES -->
        <div class="card mb-4" style="border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.03) !important; border: none;">
            <div class="card-header py-3 d-flex align-items-center" style="border-radius: 12px 12px 0 0; background-color: #fff; border-bottom: 1px solid #f1f5f9;">
                <h6 class="m-0 font-weight-bold d-flex align-items-center text-dark" style="font-size: 1rem;"><i data-lucide="building-2" style="width:18px;height:18px;margin-right:8px;color:#3b82f6;"></i>Datos de la Empresa</h6>
            </div>
            <div class="card-body">
                <p class="text-muted small mb-3">Estos datos aparecerán en todos los comprobantes impresos del sistema.</p>
                <form id="formEmpresa">
                    <div class="row">
                        <div class="form-group col-md-6 mb-3">
                            <label class="font-weight-bold small text-muted">Nombre del Negocio</label>
                            <input type="text" class="form-control" id="empNombre" placeholder="Nombre comercial">
                        </div>
                        <div class="form-group col-md-6 mb-3">
                            <label class="font-weight-bold small text-muted">Razón Social</label>
                            <input type="text" class="form-control" id="empRazon" placeholder="Razón social">
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4 mb-3">
                            <label class="font-weight-bold small text-muted">RUC / NIT</label>
                            <input type="text" class="form-control" id="empRuc" placeholder="RUC">
                        </div>
                        <div class="form-group col-md-4 mb-3">
                            <label class="font-weight-bold small text-muted">Teléfono</label>
                            <input type="text" class="form-control" id="empTel" placeholder="Teléfono">
                        </div>
                        <div class="form-group col-md-4 mb-3">
                            <label class="font-weight-bold small text-muted">Email</label>
                            <input type="email" class="form-control" id="empEmail" placeholder="admin@empresa.com">
                        </div>
                    </div>
                    <div class="form-group mb-4">
                        <label class="font-weight-bold small text-muted">Dirección</label>
                        <input type="text" class="form-control" id="empDir" placeholder="Dirección completa">
                    </div>
                    
                    <h6 class="font-weight-bold text-gray-800 mb-3" style="font-size: 0.9rem;"><i data-lucide="sliders-horizontal" style="width:16px;height:16px;margin-right:6px;"></i> Ajustes de Sistema</h6>
                    <div class="row bg-light p-3 rounded mb-4" style="border: 1px solid #f1f5f9;">
                        <div class="form-group col-md-4 mb-3 mb-md-0">
                            <label class="font-weight-bold small text-muted">Moneda</label>
                            <select class="form-select" id="empMoneda">
                                <option value="USD">USD - Dólar</option>
                                <option value="PEN">PEN - Sol</option>
                                <option value="EUR">EUR - Euro</option>
                            </select>
                        </div>
                        <div class="form-group col-md-4 mb-3 mb-md-0">
                            <label class="font-weight-bold small text-muted">IGV / IVA (%)</label>
                            <input type="number" class="form-control" id="empIgv" min="0" max="100" step="0.01">
                        </div>
                        <div class="form-group col-md-4 mb-0">
                            <label class="font-weight-bold small text-muted">Estado</label>
                            <select class="form-select" id="empEstado">
                                <option value="1">Activo</option>
                                <option value="0">Inactivo</option>
                            </select>
                        </div>
                    </div>
                    <div class="text-right">
                        <button type="button" class="btn btn-primary bg-theme-primary shadow-sm" onclick="guardarEmpresa()" style="border-radius:8px;">
                            <i data-lucide="save" style="width:18px;height:18px;margin-right:6px;vertical-align:middle;"></i> Guardar Cambios
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- TIPOS DE DOCUMENTOS -->
        <div class="card mb-4" style="border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.03) !important; border: none;">
            <div class="card-header py-3 d-flex align-items-center" style="border-radius: 12px 12px 0 0; background-color: #fff; border-bottom: 1px solid #f1f5f9;">
                <h6 class="m-0 font-weight-bold d-flex align-items-center text-dark" style="font-size: 1rem;"><i data-lucide="file-text" style="width:18px;height:18px;margin-right:8px;color:#8b5cf6;"></i>Tipos de Documentos</h6>
            </div>
            <div class="card-body p-0">
                <div class="p-3 border-bottom border-light">
                    <p class="text-muted small m-0">Configura los comprobantes que emitirá tu negocio y sus correlativos actuales.</p>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover mb-0" style="font-size:0.85rem;">
                        <thead style="border-bottom: 1px solid var(--bs-border-color);">
                            <tr>
                                <th class="border-0 pl-4 bg-body-secondary">Documento</th>
                                <th class="border-0 bg-body-secondary">Serie</th>
                                <th class="border-0 bg-body-secondary">Correlativo</th>
                                <th class="border-0 bg-body-secondary">Estado</th>
                                <th class="border-0 text-center bg-body-secondary" style="width: 100px;">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="pl-4 font-weight-bold text-gray-800">Factura</td>
                                <td>F001</td>
                                <td>152</td>
                                <td><span class="badge badge-success" style="background-color: #10b981;">Activo</span></td>
                                <td class="text-center">
                                    <button class="btn btn-sm p-1 d-flex align-items-center justify-content-center ml-auto" style="border-radius:6px; color:#475569; background:#f8fafc; border:1px solid #e2e8f0; width:26px; height:26px;"><i data-lucide="pencil" style="width:12px;height:12px;"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td class="pl-4 font-weight-bold text-gray-800">Boleta</td>
                                <td>B001</td>
                                <td>3425</td>
                                <td><span class="badge badge-success" style="background-color: #10b981;">Activo</span></td>
                                <td class="text-center">
                                    <button class="btn btn-sm p-1 d-flex align-items-center justify-content-center ml-auto" style="border-radius:6px; color:#475569; background:#f8fafc; border:1px solid #e2e8f0; width:26px; height:26px;"><i data-lucide="pencil" style="width:12px;height:12px;"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td class="pl-4 font-weight-bold text-gray-800">Nota de Venta</td>
                                <td>T001</td>
                                <td>8912</td>
                                <td><span class="badge badge-success" style="background-color: #10b981;">Activo</span></td>
                                <td class="text-center">
                                    <button class="btn btn-sm p-1 d-flex align-items-center justify-content-center ml-auto" style="border-radius:6px; color:#475569; background:#f8fafc; border:1px solid #e2e8f0; width:26px; height:26px;"><i data-lucide="pencil" style="width:12px;height:12px;"></i></button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- FACTURACIÓN ELECTRÓNICA -->
        <div class="card mb-4" style="border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.03) !important; border: none;">
            <div class="card-header py-3 d-flex align-items-center" style="border-radius: 12px 12px 0 0; background-color: #fff; border-bottom: 1px solid #f1f5f9;">
                <h6 class="m-0 font-weight-bold d-flex align-items-center text-dark" style="font-size: 1rem;"><i data-lucide="zap" style="width:18px;height:18px;margin-right:8px;color:#10b981;"></i>Facturación Electrónica</h6>
            </div>
            <div class="card-body">
                <p class="text-muted small mb-3">Configura las credenciales para la conexión con el sistema de impuestos.</p>
                <form>
                    <div class="row">
                        <div class="form-group col-md-6 mb-3">
                            <label class="font-weight-bold small text-muted">Entorno</label>
                            <select class="form-select">
                                <option value="beta">Beta (Pruebas)</option>
                                <option value="prod" selected>Producción</option>
                            </select>
                        </div>
                        <div class="form-group col-md-6 mb-3">
                            <label class="font-weight-bold small text-muted">Certificado Digital</label>
                            <input type="file" class="form-control" accept=".pfx,.p12,.pem">
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4 mb-3">
                            <label class="font-weight-bold small text-muted">Usuario API</label>
                            <input type="text" class="form-control" placeholder="MODDATOS">
                        </div>
                        <div class="form-group col-md-4 mb-3">
                            <label class="font-weight-bold small text-muted">Clave API</label>
                            <input type="password" class="form-control" placeholder="********">
                        </div>
                        <div class="form-group col-md-4 mb-3">
                            <label class="font-weight-bold small text-muted">Clave Certificado</label>
                            <input type="password" class="form-control" placeholder="********">
                        </div>
                    </div>
                    <button type="button" class="btn btn-sm btn-outline-primary" style="border-radius: 8px;" onclick="mostrarAlerta('success', 'Credenciales guardadas correctamente')">
                        <i data-lucide="shield" style="width:14px;height:14px;margin-right:4px;"></i> Guardar Credenciales
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <!-- LOGO -->
        <div class="card mb-4" style="border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.03) !important; border: none;">
            <div class="card-header py-3 d-flex align-items-center" style="border-radius: 12px 12px 0 0; background-color: #fff; border-bottom: 1px solid #f1f5f9;">
                <h6 class="m-0 font-weight-bold d-flex align-items-center text-dark" style="font-size: 1rem;"><i data-lucide="image" style="width:18px;height:18px;margin-right:8px;color:#f59e0b;"></i>Logo de la Empresa</h6>
            </div>
            <div class="card-body text-center">
                <div class="mb-3 p-4 border rounded" style="background:#f8f9fc; border-radius: 10px !important;">
                    <div id="logoIcon">
                        <i data-lucide="image" style="width:80px;height:80px;color:#d1d3e2;"></i>
                        <p class="text-gray-500 mt-2 small mb-0">Arrastra o selecciona un logo</p>
                    </div>
                    <img id="logoPreview" src="" alt="Preview" style="display:none; max-width:100%; max-height:120px; object-fit:contain; margin: 0 auto;">
                </div>
                <input type="file" class="form-control mb-3" id="empLogo" accept="image/*">
                <small class="text-gray-500">Formatos: JPG, PNG. Máx: 2MB. Aparecerá en comprobantes.</small>
            </div>
        </div>
        
        <!-- INFO PANEL -->
        <div class="card mb-4" style="border-radius: 12px; overflow: hidden; border: 1px solid #bae6fd; box-shadow: 0 4px 15px rgba(3, 105, 161, 0.05) !important; background: #e0f2fe; color: #0369a1;">
            <div class="card-body p-4">
                <div class="d-flex align-items-center mb-3" style="gap: 10px;">
                    <i data-lucide="alert-circle" style="width:22px;height:22px;color:#0369a1;fill:#0369a1;color:white;"></i>
                    <h5 class="m-0 font-weight-bold" style="font-size: 1.1rem; color: #0369a1;">Información</h5>
                </div>
                <h6 class="font-weight-bold mb-2" style="font-size: 0.95rem; color: #0369a1;">Datos de empresa</h6>
                <p class="mb-4" style="font-size: 0.85rem; line-height: 1.5; color: #075985;">
                    Los datos de la empresa aparecen en la cabecera de todos los comprobantes impresos (boletas, facturas, tickets).
                </p>
                
                <div class="d-flex mb-3" style="gap: 10px;">
                    <i data-lucide="chevron-right" style="width:16px;height:16px;color:#0369a1;flex-shrink:0;margin-top:2px;"></i>
                    <p class="mb-0" style="font-size: 0.85rem; line-height: 1.5; color: #075985;">
                        Configura los tipos de documentos y sus correlativos para mantener un orden en tu facturación.
                    </p>
                </div>
                
                <div class="d-flex" style="gap: 10px;">
                    <i data-lucide="chevron-right" style="width:16px;height:16px;color:#0369a1;flex-shrink:0;margin-top:2px;"></i>
                    <p class="mb-0" style="font-size: 0.85rem; line-height: 1.5; color: #075985;">
                        Si usas facturación electrónica, ingresa tus credenciales de API y certificado digital.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>