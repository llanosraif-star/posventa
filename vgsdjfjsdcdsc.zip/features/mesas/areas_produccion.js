/**
 * areas_produccion.js - Módulo de Áreas de Producción
 * CRUD: crear, editar, listar áreas de producción
 */

// ==========================================
// ÁREAS DE PRODUCCIÓN CRUD
// ==========================================
async function cargarAreasProduccion() {
    try {
        if (!window.datosApp.impresoras || window.datosApp.impresoras.length === 0) {
            let impRes = await fetch('features/mesas/controller_mesas.php');
            let impData = await impRes.json();
            if (impData.status === 'ok') {
                window.datosApp.impresoras = impData.data.impresoras;
            }
        }
        let res = await fetch('features/mesas/controller_areas_produccion.php');
        let data = await res.json();
        if (data.status === 'ok') {
            window.datosApp.areas_produccion = data.data;
            let html = '';
            if (data.data.length === 0) {
                html = '<tr><td colspan="4" class="text-center py-4 text-muted">No hay áreas de producción registradas</td></tr>';
            } else {
                data.data.forEach(a => {
                    let badge = a.estado == 1 ? '<span class="badge bg-success text-white px-2 py-1" style="border-radius:6px; font-weight:600;">Activa</span>' : '<span class="badge bg-danger text-white px-2 py-1" style="border-radius:6px; font-weight:600;">Inactiva</span>';
                    html += `<tr>
                        <td class="pl-4 font-weight-bold">${a.nombre}</td>
                        <td>${a.impresora_nombre || '-'}</td>
                        <td>${badge}</td>
                        <td class="text-center">
                            <div class="d-flex justify-content-center" style="gap: 6px;">
                                <button class="btn border text-secondary shadow-sm" style="width: 28px; height: 28px; padding: 0; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; background: var(--bs-body-bg);" onclick="alertaEditarArea(${a.id})" title="Editar">
                                    <i data-lucide="pencil" style="width:14px;height:14px; stroke-width:2;"></i>
                                </button>
                                <button class="btn border text-secondary shadow-sm" style="width: 28px; height: 28px; padding: 0; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; background: var(--bs-body-bg);" onclick="alertaEliminarArea(${a.id})" title="Eliminar">
                                    <i data-lucide="trash-2" style="width:14px;height:14px; stroke-width:2;"></i>
                                </button>
                            </div>
                        </td>
                    </tr>`;
                });
            }
            document.getElementById('tbodyAreasProduccion').innerHTML = html;
            if (typeof lucide !== 'undefined') lucide.createIcons();
        }
    } catch(e) { console.error('Error cargando áreas:', e); }
}

function generarFormularioArea(item = null) {
    let t = item || {};
    let estado = (t.estado !== undefined) ? t.estado : 1;
    let opcionesImp = window.datosApp.impresoras ? '<option value="">-- NINGUNO --</option>' + window.datosApp.impresoras.map(i => `<option value="${i.id}" ${i.id==t.id_impresora?'selected':''}>${i.nombre}</option>`).join('') : '<option value="">-- NINGUNO --</option>';
    
    return `
        <div style="text-align: left; font-family: 'Inter', sans-serif;" class="p-1 overflow-hidden">
            <div class="row g-3">
                <div class="col-12">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Nombre del Área <span class="text-danger">*</span></label>
                    <input id="swal-area-nombre" class="form-control form-control-sm border-secondary-subtle" value="${t.nombre || ''}" placeholder="Ej. Cocina, Barra, Horno...">
                </div>
                <div class="col-12">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Impresora de Comandas</label>
                    <select id="swal-area-impresora" class="form-select form-select-sm border-secondary-subtle">
                        ${opcionesImp}
                    </select>
                </div>
                <div class="col-12">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Estado</label>
                    <select id="swal-area-estado" class="form-select form-select-sm border-secondary-subtle">
                        <option value="1" ${estado == 1 ? 'selected' : ''}>ACTIVO</option>
                        <option value="0" ${estado == 0 ? 'selected' : ''}>INACTIVO</option>
                    </select>
                </div>
            </div>
        </div>
    `;
}

function modalNuevaAreaProduccion() {
    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Nueva Área de Producción</h5><p style="margin: 0; font-size: 0.85rem; color: #6b7280; font-weight: normal;">Agrega un área para gestionar comandas</p></div>',
        html: generarFormularioArea(),
        width: 550,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-secondary px-4',
            actions: 'w-100 justify-content-center mt-3 pt-3 border-top gap-3',
            popup: 'rounded-lg p-4',
            title: 'w-100 m-0'
        },
        didOpen: () => {
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            confirmBtn.style.borderRadius = '8px';
            confirmBtn.style.fontWeight = '500';
            cancelBtn.style.borderRadius = '8px';
        },
        preConfirm: () => {
            return {
                nombre: document.getElementById('swal-area-nombre').value,
                id_impresora: document.getElementById('swal-area-impresora').value,
                estado: document.getElementById('swal-area-estado').value
            };
        }
    }).then(async (r) => {
        if (r.isConfirmed) {
            if(!r.value.nombre) {
                Swal.fire('Error', 'El nombre del área es requerido', 'error');
                return;
            }
            try {
                let res = await fetch('features/mesas/controller_areas_produccion.php?action=crear', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(r.value)
                });
                let data = await res.json();
                if (data.status === 'ok') {
                    cargarAreasProduccion();
                    Swal.fire({
                        toast: true,
                        position: 'top-end',
                        icon: 'success',
                        title: 'Área creada correctamente',
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true
                    });
                } else {
                    Swal.fire('Error', data.message, 'error');
                }
            } catch(e) { 
                Swal.fire('Error', 'Error al conectar con el servidor', 'error'); 
            }
        }
    });
}

function alertaEditarArea(id) {
    let item = window.datosApp.areas_produccion.find(x => x.id == id);
    if (!item) {
        Swal.fire('Error', 'Área no encontrada', 'error');
        return;
    }

    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Editar Área</h5><p style="margin: 0; font-size: 0.85rem; color: #6b7280; font-weight: normal;">Modifica la información del área de producción</p></div>',
        html: generarFormularioArea(item),
        width: 550,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-secondary px-4',
            actions: 'w-100 justify-content-center mt-3 pt-3 border-top gap-3',
            popup: 'rounded-lg p-4',
            title: 'w-100 m-0'
        },
        didOpen: () => {
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            confirmBtn.style.borderRadius = '8px';
            confirmBtn.style.fontWeight = '500';
            cancelBtn.style.borderRadius = '8px';
        },
        preConfirm: () => {
            return {
                id: id,
                nombre: document.getElementById('swal-area-nombre').value,
                id_impresora: document.getElementById('swal-area-impresora').value,
                estado: document.getElementById('swal-area-estado').value
            };
        }
    }).then(async (r) => {
        if (r.isConfirmed) {
            if(!r.value.nombre) {
                Swal.fire('Error', 'El nombre del área es requerido', 'error');
                return;
            }
            try {
                let res = await fetch('features/mesas/controller_areas_produccion.php?action=editar', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(r.value)
                });
                let data = await res.json();
                if (data.status === 'ok') {
                    cargarAreasProduccion();
                    Swal.fire({
                        toast: true,
                        position: 'top-end',
                        icon: 'success',
                        title: 'Área actualizada correctamente',
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true
                    });
                } else {
                    Swal.fire('Error', data.message, 'error');
                }
            } catch(e) { 
                Swal.fire('Error', 'Error al conectar con el servidor', 'error'); 
            }
        }
    });
}

function alertaEliminarArea(id) {
    Swal.fire({
        title: '¿Eliminar área?',
        text: 'Esta acción no se puede revertir',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#e74a3b',
        cancelButtonColor: '#858796',
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar'
    }).then(async (r) => {
        if (r.isConfirmed) {
            try {
                let res = await fetch('features/mesas/controller_areas_produccion.php?action=eliminar', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: id })
                });
                let data = await res.json();
                if (data.status === 'ok') {
                    cargarAreasProduccion();
                    Swal.fire({
                        toast: true,
                        position: 'top-end',
                        icon: 'success',
                        title: 'Área eliminada correctamente',
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true
                    });
                } else {
                    Swal.fire('Error', data.message, 'error');
                }
            } catch(e) { 
                Swal.fire('Error', 'Error al conectar con el servidor', 'error'); 
            }
        }
    });
}

