<!--begin::App Content Header-->
<div class="app-content-header">
    <!--begin::Container-->
    <div class="container-fluid">
        <!--begin::Row-->
        <div class="row align-items-center">
            <div class="col-sm-6">
                <h4 class="mb-0 d-flex align-items-center text-dark" style="font-weight: 600; font-size: 22px;">
                    <i data-lucide="armchair" style="width:22px;height:22px;margin-right:8px; color: #475569;"></i> Mesas
                </h4>
            </div>
        </div>
        <!--end::Row-->
    </div>
    <!--end::Container-->
</div>
<!--end::App Content Header-->

<style>
    /* Efecto hover más gris para la tabla */
    .table-hover tbody tr:hover {
        background-color: #e2e8f0 !important;
        transition: background-color 0.2s ease;
    }
    .color-picker-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
    }
    .color-dot {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        cursor: pointer;
        border: 2px solid transparent;
        transition: transform 0.1s ease, box-shadow 0.1s ease;
    }
    .color-dot:hover {
        transform: scale(1.15);
    }
    .color-dot.selected {
        border-color: #fff;
    }
</style>

<!-- ZONAS Y MESAS -->
<div class="row">
    <div class="col-lg-5">
        <div class="card mb-4" style="border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.03) !important;">
            <div class="card-header py-3 d-flex align-items-center" style="border-radius: 12px 12px 0 0; background-color: #fff; border-bottom: 1px solid #f1f5f9;">
                <h6 class="m-0 font-weight-bold d-flex align-items-center text-dark" style="font-size: 1rem;"><i data-lucide="map-pin" style="width:18px;height:18px;margin-right:8px;color:#3b82f6;"></i>Zonas</h6>
                <button class="btn btn-sm btn-primary ms-auto d-flex align-items-center shadow-sm" onclick="modalNuevaZona()" style="border-radius:8px; font-size:0.8rem; font-weight: 500; padding: 0.4rem 0.8rem;"><i data-lucide="plus" style="width:16px;height:16px;margin-right:4px;"></i> Nueva Zona</button>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0" style="font-size:0.85rem;">
                        <thead style="border-bottom: 1px solid var(--bs-border-color);">
                            <tr>
                                <th class="border-0 pl-3 bg-body-secondary">#</th>
                                <th class="border-0 bg-body-secondary">Zona</th>
                                <th class="border-0 bg-body-secondary">Color</th>
                                <th class="border-0 bg-body-secondary">Estado</th>
                                <th class="border-0 text-center bg-body-secondary" style="width: 100px;">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="tbodyZonas">
                            <tr><td colspan="5" class="text-center py-4 text-muted">Cargando...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-7">
        <div class="card mb-4" style="border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.03) !important;">
            <div class="card-header py-3 d-flex align-items-center" style="border-radius: 12px 12px 0 0; background-color: #fff; border-bottom: 1px solid #f1f5f9;">
                <h6 class="m-0 font-weight-bold d-flex align-items-center text-dark" style="font-size: 1rem;"><i data-lucide="armchair" style="width:18px;height:18px;margin-right:8px;color:#8b5cf6;"></i>Mesas</h6>
                <button class="btn btn-sm btn-primary ms-auto d-flex align-items-center shadow-sm" onclick="modalNuevaMesa()" style="border-radius:8px; font-size:0.8rem; font-weight: 500; padding: 0.4rem 0.8rem;"><i data-lucide="plus" style="width:16px;height:16px;margin-right:4px;"></i> Nueva Mesa</button>
            </div>
            <div class="card-body p-0">
                <div id="filtrosMesas" class="d-flex flex-wrap border-bottom" style="gap: 8px; padding: 1rem; background-color: #f8fafc;">
                    <button class="btn btn-sm btn-theme-primary px-3 rounded">Todos</button>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover mb-0" style="font-size:0.85rem;">
                        <thead style="border-bottom: 1px solid var(--bs-border-color);">
                            <tr>
                                <th class="border-0 pl-4 bg-body-secondary">#</th>
                                <th class="border-0 bg-body-secondary">Mesa</th>
                                <th class="border-0 bg-body-secondary">Zona</th>
                                <th class="border-0 bg-body-secondary">Capacidad</th>
                                <th class="border-0 bg-body-secondary">Estado</th>
                                <th class="border-0 text-center bg-body-secondary" style="width: 100px;">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="tbodyMesas">
                            <tr><td colspan="6" class="text-center py-4 text-muted">Cargando...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
if(typeof cargarMesasImpresoras === 'function') {
    cargarMesasImpresoras();
}
</script>