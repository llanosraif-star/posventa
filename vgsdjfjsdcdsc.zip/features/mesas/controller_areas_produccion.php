<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../config/database.php';

$db = Database::getInstance()->getConnection();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    // Ensure table exists
    $db->exec("CREATE TABLE IF NOT EXISTS areas_produccion (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(100) NOT NULL,
        id_impresora INT NULL,
        estado TINYINT DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    // Ensure impresoras table exists to prevent LEFT JOIN errors
    $db->exec("CREATE TABLE IF NOT EXISTS impresoras (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(100) NOT NULL,
        ip VARCHAR(50) NOT NULL,
        puerto VARCHAR(20) DEFAULT '9100',
        ancho_papel INT DEFAULT 80,
        estado TINYINT DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    try { $db->exec("ALTER TABLE areas_produccion DROP COLUMN descripcion"); } catch(PDOException $e) {}
    try { $db->exec("ALTER TABLE areas_produccion ADD COLUMN id_impresora INT NULL AFTER nombre"); } catch(PDOException $e) {}

    switch ($method) {
        case 'GET':
            $stmt = $db->query("SELECT a.id, a.nombre, a.id_impresora, a.estado, a.created_at, i.nombre as impresora_nombre FROM areas_produccion a LEFT JOIN impresoras i ON a.id_impresora = i.id ORDER BY a.id");
            echo json_encode(['status'=>'ok','data'=>$stmt->fetchAll(PDO::FETCH_ASSOC)]);
            break;

        case 'POST':
            $data = json_decode(file_get_contents('php://input'), true);
            if ($action === 'crear') {
                $stmt = $db->prepare("INSERT INTO areas_produccion (nombre, id_impresora, estado) VALUES (?,?,?)");
                $idImp = (!empty($data['id_impresora'])) ? $data['id_impresora'] : null;
                $stmt->execute([$data['nombre'], $idImp, $data['estado'] ?? 1]);
                echo json_encode(['status'=>'ok','message'=>'Área de producción creada','id'=>$db->lastInsertId()]);
            } elseif ($action === 'editar') {
                $stmt = $db->prepare("UPDATE areas_produccion SET nombre=?, id_impresora=?, estado=? WHERE id=?");
                $idImp = (!empty($data['id_impresora'])) ? $data['id_impresora'] : null;
                $stmt->execute([$data['nombre'], $idImp, $data['estado'], $data['id']]);
                echo json_encode(['status'=>'ok','message'=>'Área de producción actualizada']);
            } elseif ($action === 'eliminar') {
                $db->prepare("DELETE FROM areas_produccion WHERE id=?")->execute([$data['id']]);
                echo json_encode(['status'=>'ok','message'=>'Área de producción eliminada']);
            }
            break;

        default:
            http_response_code(405);
            echo json_encode(['status'=>'error','message'=>'Método no permitido']);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['status'=>'error','message'=>$e->getMessage()]);
}

