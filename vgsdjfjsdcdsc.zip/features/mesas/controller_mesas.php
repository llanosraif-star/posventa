<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../config/database.php';

$db = Database::getInstance()->getConnection();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$tipo = $_GET['tipo'] ?? '';

try {
    switch ($method) {
        case 'GET':
            if ($tipo === 'zonas') {
                $stmt = $db->query("SELECT * FROM zonas ORDER BY orden");
                echo json_encode(['status'=>'ok','data'=>$stmt->fetchAll()]);
            } elseif ($tipo === 'mesas') {
                $stmt = $db->query("SELECT m.*, z.nombre as zona_nombre, z.color as zona_color FROM mesas m LEFT JOIN zonas z ON m.id_zona = z.id ORDER BY m.id");
                echo json_encode(['status'=>'ok','data'=>$stmt->fetchAll()]);
            } elseif ($tipo === 'impresoras') {
                $stmt = $db->query("SELECT * FROM impresoras ORDER BY id");
                echo json_encode(['status'=>'ok','data'=>$stmt->fetchAll()]);
            } else {
                // Devolver todo junto
                $zonas = $db->query("SELECT * FROM zonas ORDER BY orden")->fetchAll();
                $mesas = $db->query("SELECT m.*, z.nombre as zona_nombre, z.color as zona_color FROM mesas m LEFT JOIN zonas z ON m.id_zona = z.id ORDER BY m.id")->fetchAll();
                $impresoras = $db->query("SELECT * FROM impresoras ORDER BY id")->fetchAll();
                echo json_encode(['status'=>'ok','data'=>['zonas'=>$zonas,'mesas'=>$mesas,'impresoras'=>$impresoras]]);
            }
            break;

        case 'POST':
            $data = json_decode(file_get_contents('php://input'), true);

            if ($tipo === 'zonas') {
                if ($action === 'crear') {
                    $db->prepare("INSERT INTO zonas (nombre, descripcion, color, orden, estado) VALUES (?,?,?,?,?)")
                       ->execute([$data['nombre'], $data['descripcion'] ?? '', $data['color'], $data['orden'] ?? 0, $data['estado'] ?? 1]);
                    echo json_encode(['status'=>'ok','message'=>'Zona creada','id'=>$db->lastInsertId()]);
                } elseif ($action === 'eliminar') {
                    $db->prepare("DELETE FROM zonas WHERE id=?")->execute([$data['id']]);
                    echo json_encode(['status'=>'ok','message'=>'Zona eliminada']);
                } elseif ($action === 'editar') {
                    $db->prepare("UPDATE zonas SET nombre=?, descripcion=?, color=?, estado=? WHERE id=?")
                       ->execute([$data['nombre'], $data['descripcion'] ?? '', $data['color'], $data['estado'], $data['id']]);
                    echo json_encode(['status'=>'ok','message'=>'Zona actualizada']);
                }
            } elseif ($tipo === 'mesas') {
                if ($action === 'crear') {
                    $db->prepare("INSERT INTO mesas (id_zona, numero, capacidad) VALUES (?,?,?)")
                       ->execute([$data['id_zona'], $data['numero'], $data['capacidad']]);
                    echo json_encode(['status'=>'ok','message'=>'Mesa creada','id'=>$db->lastInsertId()]);
                } elseif ($action === 'eliminar') {
                    $db->prepare("DELETE FROM mesas WHERE id=?")->execute([$data['id']]);
                    echo json_encode(['status'=>'ok','message'=>'Mesa eliminada']);
                } elseif ($action === 'editar') {
                    $db->prepare("UPDATE mesas SET id_zona=?, numero=?, capacidad=? WHERE id=?")
                       ->execute([$data['id_zona'], $data['numero'], $data['capacidad'], $data['id']]);
                    echo json_encode(['status'=>'ok','message'=>'Mesa actualizada']);
                }
            } elseif ($tipo === 'impresoras') {
                if ($action === 'crear') {
                    $db->prepare("INSERT INTO impresoras (nombre, ip, puerto, ancho_papel, estado) VALUES (?,?,?,?,?)")
                        ->execute([$data['nombre'], $data['ip'], $data['puerto'], $data['ancho_papel'] ?? 80, $data['estado'] ?? 1]);
                    echo json_encode(['status'=>'ok','message'=>'Impresora registrada','id'=>$db->lastInsertId()]);
                } elseif ($action === 'eliminar') {
                    $db->prepare("DELETE FROM impresoras WHERE id=?")->execute([$data['id']]);
                    echo json_encode(['status'=>'ok','message'=>'Impresora eliminada']);
                } elseif ($action === 'editar') {
                    $db->prepare("UPDATE impresoras SET nombre=?, ip=?, puerto=?, ancho_papel=?, estado=? WHERE id=?")
                        ->execute([$data['nombre'], $data['ip'], $data['puerto'], $data['ancho_papel'] ?? 80, $data['estado'] ?? 1, $data['id']]);
                    echo json_encode(['status'=>'ok','message'=>'Impresora actualizada']);
                }
            }
            break;

        default:
            http_response_code(405);
            echo json_encode(['status'=>'error','message'=>'Método no permitido']);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['status'=>'error','message'=>$e->getMessage()]);
}

