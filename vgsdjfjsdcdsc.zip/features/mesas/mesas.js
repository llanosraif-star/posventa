/**
 * mesas.js - Módulo de Mesas, Zonas e Impresoras
 * CRUD completo para zonas, mesas e impresoras
 */

// ==========================================

// ==========================================
// FORMULARIO ZONA
// ==========================================
function generarFormularioZona(item = null) {
    let t = item || {};
    let estado = (t.estado !== undefined) ? t.estado : 1;
    let colorOriginal = t.color || '#4e73df';
    
    const colores = ['#4e73df', '#6610f2', '#e83e8c', '#e74a3b', '#fd7e14', '#f6c23e', '#1cc88a', '#20c9a6', '#36b9cc', '#858796'];
    if (!colores.includes(colorOriginal)) colores.push(colorOriginal);
    let dotsHtml = colores.map(c => `<div class="color-dot ${c === colorOriginal ? 'selected' : ''}" style="background-color: ${c}; ${c === colorOriginal ? 'box-shadow: 0 0 0 2px '+c+';' : ''}" data-color="${c}"></div>`).join('');

    return `
        <div style="text-align: left; font-family: 'Inter', sans-serif;" class="p-1 overflow-hidden">
            <div class="row g-3">
                <div class="col-12">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Nombre de zona <span class="text-danger">*</span></label>
                    <input id="swal-nombre" class="form-control form-control-sm border-secondary-subtle" value="${t.nombre || ''}" placeholder="Ej. Terraza, Principal...">
                </div>
                <div class="col-12">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Color personalizado</label>
                    <div class="color-picker-grid mb-1">${dotsHtml}</div>
                    <div class="text-muted" style="font-size: 0.8rem; font-style: italic;">Elige un color para identificar la zona fácilmente.</div>
                    <input type="hidden" id="swal-color" value="${colorOriginal}">
                </div>
                <div class="col-12">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Estado</label>
                    <select id="swal-estado" class="form-select form-select-sm border-secondary-subtle">
                        <option value="1" ${estado == 1 ? 'selected' : ''}>ACTIVA</option>
                        <option value="0" ${estado == 0 ? 'selected' : ''}>INACTIVA</option>
                    </select>
                </div>
            </div>
        </div>
    `;
}

// ==========================================
// EDITAR ZONA
// ==========================================
function editarZona(id, item) {
    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Editar Zona</h5><p style="margin: 0; font-size: 0.85rem; color: #6b7280; font-weight: normal;">Modifica los detalles de la zona de mesas</p></div>',
        html: generarFormularioZona(item),
        width: 550,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-secondary px-4',
            actions: 'w-100 justify-content-center mt-3 pt-3 border-top gap-3',
            popup: 'rounded-lg p-4',
            title: 'w-100 m-0'
        },
        didOpen: () => {
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            confirmBtn.style.borderRadius = '8px';
            confirmBtn.style.fontWeight = '500';
            cancelBtn.style.borderRadius = '8px';

            const dots = document.querySelectorAll('.color-dot');
            const inputColor = document.getElementById('swal-color');
            dots.forEach(dot => {
                dot.addEventListener('click', () => {
                    dots.forEach(d => {
                        d.classList.remove('selected');
                        d.style.boxShadow = 'none';
                    });
                    dot.classList.add('selected');
                    dot.style.boxShadow = '0 0 0 2px ' + dot.getAttribute('data-color');
                    inputColor.value = dot.getAttribute('data-color');
                });
            });
        },
        preConfirm: () => { 
            return { 
                id: id, 
                nombre: document.getElementById('swal-nombre').value, 
                color: document.getElementById('swal-color').value, 
                estado: document.getElementById('swal-estado').value 
            }; 
        }
    }).then(async (r) => {
        if (r.isConfirmed) {
            if(!r.value.nombre) { Swal.fire('Error', 'El nombre es requerido', 'error'); return; }
            try {
                const res = await fetch('features/mesas/controller_mesas.php?tipo=zonas&action=editar', { method: 'POST', body: JSON.stringify(r.value) });
                if ((await res.json()).status === 'ok') { 
                    Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Zona actualizada', showConfirmButton: false, timer: 3000 });
                    cargarMesasImpresoras(); 
                } else { Swal.fire('Error', 'Error al actualizar', 'error'); }
            } catch(e) { Swal.fire('Error', 'Error de conexión', 'error'); }
        }
    });
}


// ==========================================
// FORMULARIO MESA
// ==========================================
function generarFormularioMesa(item = null) {
    let t = item || {};
    let opcionesZonas = window.datosApp.zonas.map(z => `<option value="${z.id}" ${z.id == t.id_zona ? 'selected' : ''}>${z.nombre}</option>`).join('');
    
    return `
        <div style="text-align: left; font-family: 'Inter', sans-serif;" class="p-1 overflow-hidden">
            <div class="row g-3">
                <div class="col-12">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Número de Mesa <span class="text-danger">*</span></label>
                    <input id="swal-num" class="form-control form-control-sm border-secondary-subtle" placeholder="Ej. 10, Barra 1..." value="${t.numero || ''}">
                </div>
                <div class="col-6">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Capacidad</label>
                    <input id="swal-cap" class="form-control form-control-sm border-secondary-subtle" type="number" placeholder="Ej. 4" value="${t.capacidad || 4}">
                </div>
                <div class="col-6">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Zona</label>
                    <select id="swal-zona" class="form-select form-select-sm border-secondary-subtle">
                        ${opcionesZonas}
                    </select>
                </div>
            </div>
        </div>
    `;
}

// ==========================================
// EDITAR MESA
// ==========================================
function editarMesa(id, item) {
    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Editar Mesa</h5><p style="margin: 0; font-size: 0.85rem; color: #6b7280; font-weight: normal;">Modifica los datos de la mesa</p></div>',
        html: generarFormularioMesa(item),
        width: 550,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-secondary px-4',
            actions: 'w-100 justify-content-center mt-3 pt-3 border-top gap-3',
            popup: 'rounded-lg p-4',
            title: 'w-100 m-0'
        },
        didOpen: () => {
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            confirmBtn.style.borderRadius = '8px';
            confirmBtn.style.fontWeight = '500';
            cancelBtn.style.borderRadius = '8px';
        },
        preConfirm: () => { 
            return { 
                id: id, 
                numero: document.getElementById('swal-num').value, 
                capacidad: document.getElementById('swal-cap').value, 
                id_zona: document.getElementById('swal-zona').value 
            }; 
        }
    }).then(async (r) => {
        if (r.isConfirmed) {
            if(!r.value.numero) { Swal.fire('Error', 'El número de mesa es requerido', 'error'); return; }
            try {
                const res = await fetch('features/mesas/controller_mesas.php?tipo=mesas&action=editar', { method: 'POST', body: JSON.stringify(r.value) });
                if ((await res.json()).status === 'ok') { 
                    Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Mesa actualizada', showConfirmButton: false, timer: 3000 });
                    cargarMesasImpresoras(); 
                } else { Swal.fire('Error', 'Error al actualizar', 'error'); }
            } catch(e) { Swal.fire('Error', 'Error de conexión', 'error'); }
        }
    });
}

// ==========================================
// FORMULARIO IMPRESORA
// ==========================================
function generarFormularioImpresora(item = null) {
    let t = item || {};
    let estado = (t.estado !== undefined) ? t.estado : 1;
    let ancho = t.ancho_papel || 80;
    
    return `
        <div style="text-align: left; font-family: 'Inter', sans-serif;" class="p-1 overflow-hidden">
            <div class="row g-3">
                <div class="col-12">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Nombre de la Impresora <span class="text-danger">*</span></label>
                    <input id="swal-imp-nombre" class="form-control form-control-sm border-secondary-subtle" value="${t.nombre || ''}" placeholder="Ej. Impresora Cocina">
                </div>
                <div class="col-md-6">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Dirección IP</label>
                    <input id="swal-imp-ip" class="form-control form-control-sm border-secondary-subtle" value="${t.ip || ''}" placeholder="Ej. 192.168.1.100">
                </div>
                <div class="col-md-6">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Puerto</label>
                    <input id="swal-imp-puerto" class="form-control form-control-sm border-secondary-subtle" value="${t.puerto || '9100'}" placeholder="Ej. 9100">
                </div>
                <div class="col-md-6">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Ancho de papel</label>
                    <select id="swal-imp-ancho" class="form-select form-select-sm border-secondary-subtle">
                        <option value="80" ${ancho == 80 ? 'selected' : ''}>80 mm (Estándar)</option>
                        <option value="58" ${ancho == 58 ? 'selected' : ''}>58 mm (Pequeño)</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Estado</label>
                    <select id="swal-imp-estado" class="form-select form-select-sm border-secondary-subtle">
                        <option value="1" ${estado == 1 ? 'selected' : ''}>ACTIVA</option>
                        <option value="0" ${estado == 0 ? 'selected' : ''}>INACTIVA</option>
                    </select>
                </div>
            </div>
        </div>
    `;
}

// ==========================================
// EDITAR IMPRESORA
// ==========================================
function editarImpresora(id, item) {
    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Editar Impresora</h5><p style="margin: 0; font-size: 0.88rem; color: #6b7280; font-weight: normal;">Modifica la configuración de la impresora</p></div>',
        html: generarFormularioImpresora(item),
        width: 550,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-secondary px-4',
            actions: 'w-100 justify-content-center mt-3 pt-3 border-top gap-3',
            popup: 'rounded-lg p-4',
            title: 'w-100 m-0'
        },
        didOpen: () => {
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            confirmBtn.style.borderRadius = '8px';
            confirmBtn.style.fontWeight = '500';
            cancelBtn.style.borderRadius = '8px';
        },
        preConfirm: () => {
            return { 
                id: id, 
                nombre: document.getElementById('swal-imp-nombre').value, 
                ip: document.getElementById('swal-imp-ip').value, 
                puerto: document.getElementById('swal-imp-puerto').value, 
                ancho_papel: document.getElementById('swal-imp-ancho').value, 
                estado: document.getElementById('swal-imp-estado').value 
            };
        }
    }).then(async (r) => {
        if (r.isConfirmed) {
            if(!r.value.nombre) {
                Swal.fire('Error', 'El nombre es requerido', 'error');
                return;
            }
            try {
                const res = await fetch('features/mesas/controller_mesas.php?tipo=impresoras&action=editar', { method: 'POST', body: JSON.stringify(r.value) });
                if ((await res.json()).status === 'ok') { 
                    Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Impresora actualizada', showConfirmButton: false, timer: 3000 });
                    cargarMesasImpresoras(); 
                } else {
                    Swal.fire('Error', 'Error al actualizar', 'error');
                }
            } catch (e) {
                Swal.fire('Error', 'Error de conexión', 'error');
            }
        }
    });
}


// ==========================================
// MODALES DE CREACIÓN
// ==========================================
function modalNuevaZona() {
    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Nueva Zona</h5><p style="margin: 0; font-size: 0.85rem; color: #6b7280; font-weight: normal;">Registra una nueva zona de mesas</p></div>',
        html: generarFormularioZona(),
        width: 550,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-secondary px-4',
            actions: 'w-100 justify-content-center mt-3 pt-3 border-top gap-3',
            popup: 'rounded-lg p-4',
            title: 'w-100 m-0'
        },
        didOpen: () => {
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            confirmBtn.style.borderRadius = '8px';
            confirmBtn.style.fontWeight = '500';
            cancelBtn.style.borderRadius = '8px';

            const dots = document.querySelectorAll('.color-dot');
            const inputColor = document.getElementById('swal-color');
            dots.forEach(dot => {
                dot.addEventListener('click', () => {
                    dots.forEach(d => {
                        d.classList.remove('selected');
                        d.style.boxShadow = 'none';
                    });
                    dot.classList.add('selected');
                    dot.style.boxShadow = '0 0 0 2px ' + dot.getAttribute('data-color');
                    inputColor.value = dot.getAttribute('data-color');
                });
            });
        },
        preConfirm: () => { 
            return { 
                nombre: document.getElementById('swal-nombre').value, 
                color: document.getElementById('swal-color').value, 
                estado: document.getElementById('swal-estado').value 
            }; 
        }
    }).then(async (r) => {
        if (r.isConfirmed) {
            if(!r.value.nombre) { Swal.fire('Error', 'El nombre es requerido', 'error'); return; }
            try {
                const res = await fetch('features/mesas/controller_mesas.php?tipo=zonas&action=crear', { method: 'POST', body: JSON.stringify(r.value) });
                if ((await res.json()).status === 'ok') { 
                    Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Zona creada', showConfirmButton: false, timer: 3000 });
                    cargarMesasImpresoras(); 
                } else { Swal.fire('Error', 'Error al crear', 'error'); }
            } catch(e) { Swal.fire('Error', 'Error de conexión', 'error'); }
        }
    });
}

function modalNuevaMesa() {
    if(window.datosApp.zonas.length === 0) {
        Swal.fire('Atención', 'Primero debes crear al menos una zona', 'warning');
        return;
    }
    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Nueva Mesa</h5><p style="margin: 0; font-size: 0.85rem; color: #6b7280; font-weight: normal;">Registra una mesa y asígnala a una zona</p></div>',
        html: generarFormularioMesa(),
        width: 550,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-secondary px-4',
            actions: 'w-100 justify-content-center mt-3 pt-3 border-top gap-3',
            popup: 'rounded-lg p-4',
            title: 'w-100 m-0'
        },
        didOpen: () => {
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            confirmBtn.style.borderRadius = '8px';
            confirmBtn.style.fontWeight = '500';
            cancelBtn.style.borderRadius = '8px';
        },
        preConfirm: () => { 
            return { 
                numero: document.getElementById('swal-num').value, 
                capacidad: document.getElementById('swal-cap').value, 
                id_zona: document.getElementById('swal-zona').value 
            }; 
        }
    }).then(async (r) => {
        if (r.isConfirmed) {
            if(!r.value.numero) { Swal.fire('Error', 'El número de mesa es requerido', 'error'); return; }
            try {
                const res = await fetch('features/mesas/controller_mesas.php?tipo=mesas&action=crear', { method: 'POST', body: JSON.stringify(r.value) });
                if ((await res.json()).status === 'ok') { 
                    Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Mesa creada', showConfirmButton: false, timer: 3000 });
                    cargarMesasImpresoras(); 
                } else { Swal.fire('Error', 'Error al crear', 'error'); }
            } catch(e) { Swal.fire('Error', 'Error de conexión', 'error'); }
        }
    });
}

// CARGAR / LISTAR MESAS E IMPRESORAS
// ==========================================
function modalNuevaImpresora() {
    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Nueva Impresora</h5><p style="margin: 0; font-size: 0.88rem; color: #6b7280; font-weight: normal;">Registra una nueva impresora</p></div>',
        html: generarFormularioImpresora(),
        width: 550,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-secondary px-4',
            actions: 'w-100 justify-content-center mt-3 pt-3 border-top gap-3',
            popup: 'rounded-lg p-4',
            title: 'w-100 m-0'
        },
        didOpen: () => {
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            confirmBtn.style.borderRadius = '8px';
            confirmBtn.style.fontWeight = '500';
            cancelBtn.style.borderRadius = '8px';
        },
        preConfirm: () => {
            return { 
                nombre: document.getElementById('swal-imp-nombre').value, 
                ip: document.getElementById('swal-imp-ip').value, 
                puerto: document.getElementById('swal-imp-puerto').value, 
                ancho_papel: document.getElementById('swal-imp-ancho').value, 
                estado: document.getElementById('swal-imp-estado').value 
            };
        }
    }).then(async (r) => {
        if (r.isConfirmed) {
            if(!r.value.nombre) {
                Swal.fire('Error', 'El nombre es requerido', 'error');
                return;
            }
            try {
                const res = await fetch('features/mesas/controller_mesas.php?tipo=impresoras&action=crear', { method: 'POST', body: JSON.stringify(r.value) });
                if ((await res.json()).status === 'ok') { 
                    Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Impresora creada', showConfirmButton: false, timer: 3000 });
                    cargarMesasImpresoras(); 
                } else {
                    Swal.fire('Error', 'Error al crear', 'error');
                }
            } catch (e) {
                Swal.fire('Error', 'Error de conexión', 'error');
            }
        }
    });
}


// ==========================================
// CARGAR / LISTAR MESAS E IMPRESORAS
// ==========================================
async function cargarMesasImpresoras() {
    try {
        const response = await fetch('features/mesas/controller_mesas.php');
        const result = await response.json();
        
        if (result.status === 'ok') {
            const data = result.data;
            window.datosApp.zonas = data.zonas;
            window.datosApp.mesas = data.mesas;
            window.datosApp.impresoras = data.impresoras;
            
            const tbodyZonas = document.getElementById('tbodyZonas');
            if (tbodyZonas) {
                if (data.zonas.length > 0) {
                    tbodyZonas.innerHTML = data.zonas.map((z, i) => `<tr>
                        <td class="pl-3">${i + 1}</td>
                        <td>${z.nombre}</td>
                        <td><span class="badge p-2" style="background:${z.color};color:#fff;">${z.color}</span></td>
                        <td><span class="badge bg-${z.estado==1?'success':'secondary'} text-white">${z.estado==1?'Activa':'Inactiva'}</span></td>
                        <td class="text-center">
                            <div class="d-flex justify-content-center" style="gap: 6px;">
                                <button class="btn btn-sm p-1 d-flex align-items-center justify-content-center" style="border-radius:6px; color:#475569; background:#f8fafc; border:1px solid #e2e8f0; width:26px; height:26px;" onclick="alertaEditar(${z.id}, 'zonas')" title="Editar"><i data-lucide="pencil" style="width:12px;height:12px;"></i></button>
                                <button class="btn btn-sm p-1 d-flex align-items-center justify-content-center" style="border-radius:6px; color:#ef4444; background:#fef2f2; border:1px solid #fecaca; width:26px; height:26px;" onclick="alertaEliminar(${z.id}, 'zonas')" title="Eliminar"><i data-lucide="trash-2" style="width:12px;height:12px;"></i></button>
                            </div>
                        </td>
                    </tr>`).join('');
                } else { tbodyZonas.innerHTML = '<tr><td colspan="5" class="text-center">Sin zonas</td></tr>'; }
            }

            renderMesas();

            const tbodyImpresoras = document.getElementById('tbodyImpresoras');
            if (tbodyImpresoras) {
                if (data.impresoras.length > 0) {
                    tbodyImpresoras.innerHTML = data.impresoras.map((imp, i) => {
                        return `<tr>
                            <td class="pl-4">${i + 1}</td>
                            <td>${imp.nombre}</td>
                            <td>${imp.ip || '-'}</td>
                            <td>${imp.puerto || '-'}</td>
                            <td>${imp.ancho_papel}mm</td>
                            <td><span class="badge bg-${imp.estado==1?'success':'secondary'} text-white">${imp.estado==1?'Activa':'Inactiva'}</span></td>
                            <td class="text-center">
                                <div class="d-flex justify-content-center" style="gap: 6px;">
                                    <button class="btn btn-sm p-1 d-flex align-items-center justify-content-center" style="border-radius:6px; color:#475569; background:#f8fafc; border:1px solid #e2e8f0; width:26px; height:26px;" onclick="alertaEditar(${imp.id}, 'impresoras')" title="Editar"><i data-lucide="pencil" style="width:12px;height:12px;"></i></button>
                                    <button class="btn btn-sm p-1 d-flex align-items-center justify-content-center" style="border-radius:6px; color:#ef4444; background:#fef2f2; border:1px solid #fecaca; width:26px; height:26px;" onclick="alertaEliminar(${imp.id}, 'impresoras')" title="Eliminar"><i data-lucide="trash-2" style="width:12px;height:12px;"></i></button>
                                </div>
                            </td>
                        </tr>`;
                    }).join('');
                } else { tbodyImpresoras.innerHTML = '<tr><td colspan="8" class="text-center">Sin impresoras registradas</td></tr>'; }
            }

            lucide.createIcons();
        }
    } catch (e) { console.error(e); }
}

window.filtroMesas = 'todos';

function filtrarMesas(id_zona) {
    window.filtroMesas = id_zona;
    renderMesas();
}

function renderMesas() {
    const containerFiltros = document.getElementById('filtrosMesas');
    if (containerFiltros) {
        let btnTodosClase = window.filtroMesas === 'todos' ? 'btn-primary shadow-sm fw-bold' : 'btn-outline-secondary';
        let filtrosHtml = `<button class="btn btn-sm ${btnTodosClase} px-3 rounded" onclick="filtrarMesas('todos')">Todos</button>`;
        
        window.datosApp.zonas.forEach(z => {
            let btnClase = window.filtroMesas == z.id ? 'btn-primary shadow-sm fw-bold' : 'btn-outline-secondary';
            filtrosHtml += `<button class="btn btn-sm ${btnClase} px-3 rounded ms-1" onclick="filtrarMesas(${z.id})">${z.nombre}</button>`;
        });
        containerFiltros.innerHTML = filtrosHtml;
    }

    let mesasRender = window.datosApp.mesas || [];
    if (window.filtroMesas !== 'todos') {
        mesasRender = mesasRender.filter(m => m.id_zona == window.filtroMesas);
    }

    const tbodyMesas = document.getElementById('tbodyMesas');
    if (tbodyMesas) {
        if (mesasRender.length > 0) {
            tbodyMesas.innerHTML = mesasRender.map((m, i) => {
                let estado = m.estado_mesa;
                let badge = estado=='libre'?'success':estado=='ocupada'?'danger':estado=='reservada'?'warning':'secondary';
                return `<tr>
                    <td class="pl-4">${i + 1}</td>
                    <td>${m.numero}</td>
                    <td><span class="badge" style="background:${m.zona_color};color:#fff;">${m.zona_nombre}</span></td>
                    <td>${m.capacidad}</td>
                    <td><span class="badge bg-${badge} ${badge==='warning'?'text-dark':'text-white'}">${estado.charAt(0).toUpperCase() + estado.slice(1)}</span></td>
                    <td class="text-center">
                        <div class="d-flex justify-content-center" style="gap: 6px;">
                            <button class="btn btn-sm p-1 d-flex align-items-center justify-content-center" style="border-radius:6px; color:#475569; background:#f8fafc; border:1px solid #e2e8f0; width:26px; height:26px;" onclick="alertaEditar(${m.id}, 'mesas')" title="Editar"><i data-lucide="pencil" style="width:12px;height:12px;"></i></button>
                            <button class="btn btn-sm p-1 d-flex align-items-center justify-content-center" style="border-radius:6px; color:#ef4444; background:#fef2f2; border:1px solid #fecaca; width:26px; height:26px;" onclick="alertaEliminar(${m.id}, 'mesas')" title="Eliminar"><i data-lucide="trash-2" style="width:12px;height:12px;"></i></button>
                        </div>
                    </td>
                </tr>`;
            }).join('');
        } else { tbodyMesas.innerHTML = '<tr><td colspan="6" class="text-center">No hay mesas en esta zona</td></tr>'; }
    }
    lucide.createIcons();
}

