<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title m-0">Gestión de Platillos</h3>
        <button class="btn btn-primary btn-sm ms-auto" id="btn-nuevo-platillo">
            <i class="bi bi-plus-circle"></i> Nuevo Platillo
        </button>
    </div>
    <div class="card-body">
        <table id="tabla-platillos" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Categoría</th>
                    <th>Precio</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Hamburguesa Clásica</td>
                    <td>Comida Rápida</td>
                    <td>$8.50</td>
                    <td>
                        <button class="btn btn-sm btn-warning"><i class="bi bi-pencil"></i></button>
                        <button class="btn btn-sm btn-danger btn-eliminar"><i class="bi bi-trash"></i></button>
                    </td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Pizza Margarita</td>
                    <td>Italiana</td>
                    <td>$12.00</td>
                    <td>
                        <button class="btn btn-sm btn-warning"><i class="bi bi-pencil"></i></button>
                        <button class="btn btn-sm btn-danger btn-eliminar"><i class="bi bi-trash"></i></button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<script>
    // Este script se ejecutará automáticamente gracias a jQuery.load() en nuestro SPA
    $(document).ready(function() {
        // Inicializar DataTables
        if (!$.fn.DataTable.isDataTable('#tabla-platillos')) {
            $('#tabla-platillos').DataTable({
                language: {
                    url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json' // Traducción al español
                }
            });
        }

        // Evento para el botón nuevo
        $('#btn-nuevo-platillo').on('click', function() {
            Swal.fire({
                title: 'Nuevo Platillo',
                text: 'Aquí abriríamos un modal o cargaríamos otro formulario.',
                icon: 'info'
            });
        });

        // Evento para eliminar
        $('.btn-eliminar').on('click', function() {
            Swal.fire({
                title: '¿Estás seguro?',
                text: "No podrás revertir esto",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sí, eliminar',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire('Eliminado!', 'El platillo ha sido eliminado.', 'success');
                }
            });
        });
    });
</script>
