<?php
require_once __DIR__ . '/../../config/database.php';
// DEBUG TEST
header('Content-Type: application/json');
$pdo = Database::getInstance()->getConnection();

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$tipo = $_GET['tipo'] ?? '';

try {
    // Crear tablas si no existen
    $pdo->exec("CREATE TABLE IF NOT EXISTS categorias (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(100) NOT NULL,
        id_impresora INT NULL,
        estado TINYINT DEFAULT 1
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS subcategorias (
        id INT AUTO_INCREMENT PRIMARY KEY,
        id_categoria INT NOT NULL,
        nombre VARCHAR(150) NOT NULL,
        descripcion TEXT,
        tiene_tamanos TINYINT DEFAULT 0,
        is_combo TINYINT DEFAULT 0,
        estado TINYINT DEFAULT 1
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS productos (
        id INT AUTO_INCREMENT PRIMARY KEY,
        id_subcategoria INT NOT NULL,
        nombre VARCHAR(100) NOT NULL,
        precio DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        estado TINYINT DEFAULT 1
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS modificadores (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(100) NOT NULL,
        precio_extra DECIMAL(10,2) DEFAULT 0.00,
        aplica_a VARCHAR(255),
        tipo ENUM('ingrediente', 'instruccion', 'especial') DEFAULT 'ingrediente',
        estado TINYINT DEFAULT 1
    )");

    // Asegurar columnas si las tablas ya existían de versiones previas
    try { $pdo->exec("ALTER TABLE categorias ADD COLUMN id_impresora INT NULL AFTER nombre"); } catch(PDOException $e) {}
    try { $pdo->exec("ALTER TABLE categorias ADD COLUMN imagen VARCHAR(255) NULL AFTER nombre"); } catch(PDOException $e) {}
    try { $pdo->exec("ALTER TABLE subcategorias ADD COLUMN id_areaproduccion INT NULL AFTER id_categoria"); } catch(PDOException $e) {}
    try { $pdo->exec("ALTER TABLE subcategorias ADD COLUMN tiene_tamanos TINYINT DEFAULT 0 AFTER descripcion"); } catch(PDOException $e) {}
    try { $pdo->exec("ALTER TABLE subcategorias ADD COLUMN is_combo TINYINT DEFAULT 0 AFTER tiene_tamanos"); } catch(PDOException $e) {}
    try { $pdo->exec("ALTER TABLE productos ADD COLUMN descripcion TEXT NULL AFTER nombre"); } catch(PDOException $e) {}
    try { $pdo->exec("ALTER TABLE productos ADD COLUMN nombre_t1 VARCHAR(50) NULL"); } catch(PDOException $e) {}
    try { $pdo->exec("ALTER TABLE productos ADD COLUMN precio_1 DECIMAL(10,2) NULL"); } catch(PDOException $e) {}
    try { $pdo->exec("ALTER TABLE productos ADD COLUMN nombre_t2 VARCHAR(50) NULL"); } catch(PDOException $e) {}
    try { $pdo->exec("ALTER TABLE productos ADD COLUMN precio_2 DECIMAL(10,2) NULL"); } catch(PDOException $e) {}
    try { $pdo->exec("ALTER TABLE productos ADD COLUMN nombre_t3 VARCHAR(50) NULL"); } catch(PDOException $e) {}
    try { $pdo->exec("ALTER TABLE productos ADD COLUMN precio_3 DECIMAL(10,2) NULL"); } catch(PDOException $e) {}
    try { $pdo->exec("ALTER TABLE productos ADD COLUMN nombre_t4 VARCHAR(50) NULL"); } catch(PDOException $e) {}
    try { $pdo->exec("ALTER TABLE productos ADD COLUMN precio_4 DECIMAL(10,2) NULL"); } catch(PDOException $e) {}
    try { $pdo->exec("ALTER TABLE productos ADD COLUMN codigo_sunat VARCHAR(50) NULL"); } catch(PDOException $e) {}
    try { $pdo->exec("ALTER TABLE productos ADD COLUMN codigo_interno VARCHAR(50) NULL"); } catch(PDOException $e) {}
    try { $pdo->exec("ALTER TABLE productos ADD COLUMN unidad_medida VARCHAR(20) DEFAULT 'NIU'"); } catch(PDOException $e) {}
    try { $pdo->exec("ALTER TABLE productos ADD COLUMN control_stock TINYINT(1) DEFAULT 0"); } catch(PDOException $e) {}
    try { $pdo->exec("ALTER TABLE modificadores ADD COLUMN requiere_texto TINYINT DEFAULT 0 AFTER tipo"); } catch(PDOException $e) {}

    if ($method === 'GET') {
        $stmtCat = $pdo->query("SELECT c.*, i.nombre as impresora_nombre FROM categorias c LEFT JOIN impresoras i ON c.id_impresora = i.id WHERE c.estado = 1 ORDER BY c.nombre");
        $categorias = $stmtCat->fetchAll(PDO::FETCH_ASSOC);

        $stmtProd = $pdo->query("SELECT p.*, c.nombre as categoria_nombre FROM subcategorias p LEFT JOIN categorias c ON p.id_categoria = c.id WHERE p.estado = 1 ORDER BY c.nombre, p.nombre");
        $subcategorias = $stmtProd->fetchAll(PDO::FETCH_ASSOC);

        $stmtPres = $pdo->query("SELECT pr.*, p.nombre as subcategoria_nombre FROM productos pr LEFT JOIN subcategorias p ON pr.id_subcategoria = p.id WHERE pr.estado = 1 ORDER BY pr.id_subcategoria, pr.precio");
        $productos = $stmtPres->fetchAll(PDO::FETCH_ASSOC);

        $stmtMod = $pdo->query("SELECT * FROM modificadores WHERE estado = 1");
        $modificadores = $stmtMod->fetchAll(PDO::FETCH_ASSOC);

        $stmtImp = $pdo->query("SELECT id, nombre FROM impresoras WHERE estado = 1");
        $impresoras = $stmtImp->fetchAll(PDO::FETCH_ASSOC);

        $stmtAreas = $pdo->query("SELECT id, nombre FROM areas_produccion WHERE estado = 1");
        $areas_produccion = $stmtAreas->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            "status" => "ok",
            "data" => [
                "categorias" => $categorias,
                "subcategorias" => $subcategorias,
                "productos" => $productos,
                "modificadores" => $modificadores,
                "impresoras" => $impresoras,
                "areas_produccion" => $areas_produccion
            ]
        ]);
        exit;
    }

    if ($method === 'POST') {
        $input = json_decode(file_get_contents("php://input"), true);
        if (empty($input) && !empty($_POST)) {
            $input = $_POST;
        }

        if ($tipo === 'categorias') {
            $imgPath = null;
            if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
                $uploadDir = __DIR__ . '/../../storage/categorias/';
                if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
                $ext = strtolower(pathinfo($_FILES['imagen']['name'], PATHINFO_EXTENSION));
                if(in_array($ext, ['jpg','jpeg','png','webp','gif'])) {
                    $filename = uniqid('cat_') . '.' . $ext;
                    if (move_uploaded_file($_FILES['imagen']['tmp_name'], $uploadDir . $filename)) {
                        $imgPath = 'storage/categorias/' . $filename;
                    }
                }
            }

            if ($action === 'crear') {
                $stmt = $pdo->prepare("INSERT INTO categorias (nombre, id_impresora, tiene_tamanos, imagen) VALUES (?, ?, ?, ?)");
                $stmt->execute([$input['nombre'], (empty($input['id_impresora']) || $input['id_impresora'] === 'null') ? null : (int)$input['id_impresora'], $input['tiene_tamanos'] ?? 0, $imgPath]);
                echo json_encode(["status" => "ok", "message" => "Categoría creada"]);
            } elseif ($action === 'editar') {
                if ($imgPath) {
                    $stmt = $pdo->prepare("UPDATE categorias SET nombre=?, id_impresora=?, tiene_tamanos=?, imagen=? WHERE id=?");
                    $stmt->execute([$input['nombre'], (empty($input['id_impresora']) || $input['id_impresora'] === 'null') ? null : (int)$input['id_impresora'], $input['tiene_tamanos'] ?? 0, $imgPath, $input['id']]);
                } else {
                    $stmt = $pdo->prepare("UPDATE categorias SET nombre=?, id_impresora=?, tiene_tamanos=? WHERE id=?");
                    $stmt->execute([$input['nombre'], (empty($input['id_impresora']) || $input['id_impresora'] === 'null') ? null : (int)$input['id_impresora'], $input['tiene_tamanos'] ?? 0, $input['id']]);
                }
                echo json_encode(["status" => "ok", "message" => "Categoría actualizada"]);
            } elseif ($action === 'eliminar') {
                $stmt = $pdo->prepare("UPDATE categorias SET estado=0 WHERE id=?");
                $stmt->execute([$input['id']]);
                echo json_encode(["status" => "ok", "message" => "Categoría eliminada"]);
            }
        } elseif ($tipo === 'subcategorias') {
            if ($action === 'crear') {
                $stmt = $pdo->prepare("INSERT INTO subcategorias (id_categoria, id_areaproduccion, nombre, descripcion, tiene_tamanos, is_combo) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$input['id_categoria'], $input['id_areaproduccion'] ?: null, $input['nombre'], $input['descripcion'] ?? '', $input['tiene_tamanos'] ?? 0, $input['is_combo'] ?? 0]);
                $idSubcategoria = $pdo->lastInsertId();

                // Crear productos si se enviaron
                if (!empty($input['productos']) && is_array($input['productos'])) {
                    $stmtP = $pdo->prepare("INSERT INTO productos (id_subcategoria, nombre, precio) VALUES (?, ?, ?)");
                    foreach ($input['productos'] as $pres) {
                        if (!empty($pres['nombre'])) {
                            $stmtP->execute([$idSubcategoria, $pres['nombre'], $pres['precio'] ?? 0]);
                        }
                    }
                }
                echo json_encode(["status" => "ok", "message" => "Subcategoria creado"]);
            } elseif ($action === 'editar') {
                $stmt = $pdo->prepare("UPDATE subcategorias SET id_categoria=?, id_areaproduccion=?, nombre=?, descripcion=?, tiene_tamanos=?, is_combo=? WHERE id=?");
                $stmt->execute([$input['id_categoria'], $input['id_areaproduccion'] ?: null, $input['nombre'], $input['descripcion'] ?? '', $input['tiene_tamanos'] ?? 0, $input['is_combo'] ?? 0, $input['id']]);
                echo json_encode(["status" => "ok", "message" => "Subcategoria actualizado"]);
            } elseif ($action === 'eliminar') {
                $stmt = $pdo->prepare("UPDATE subcategorias SET estado=0 WHERE id=?");
                $stmt->execute([$input['id']]);
                echo json_encode(["status" => "ok", "message" => "Subcategoria eliminado"]);
            }
        } elseif ($tipo === 'productos') {
            $imgPath = null;
            if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
                $uploadDir = __DIR__ . '/../../storage/productos/';
                if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
                $ext = strtolower(pathinfo($_FILES['imagen']['name'], PATHINFO_EXTENSION));
                if(in_array($ext, ['jpg','jpeg','png','webp','gif'])) {
                    $filename = uniqid('prod_') . '.' . $ext;
                    if (move_uploaded_file($_FILES['imagen']['tmp_name'], $uploadDir . $filename)) {
                        $imgPath = 'storage/productos/' . $filename;
                    }
                }
            }

            if ($action === 'crear') {
                $stmt = $pdo->prepare("INSERT INTO productos (id_subcategoria, nombre, descripcion, precio, imagen, nombre_t1, precio_1, nombre_t2, precio_2, nombre_t3, precio_3, nombre_t4, precio_4, codigo_sunat, codigo_interno, unidad_medida, control_stock) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                
                $precio = is_numeric($input['precio'] ?? 0) ? (float)($input['precio'] ?? 0) : 0;
                $stmt->execute([
                    $input['id_subcategoria'],
                    $input['nombre'] ?? 'Única',
                    $input['descripcion'] ?? '',
                    $precio,
                    $imgPath,
                    $input['nombre_t1'] ?? null,
                    is_numeric($input['precio_1'] ?? null) ? (float)$input['precio_1'] : null,
                    $input['nombre_t2'] ?? null,
                    is_numeric($input['precio_2'] ?? null) ? (float)$input['precio_2'] : null,
                    $input['nombre_t3'] ?? null,
                    is_numeric($input['precio_3'] ?? null) ? (float)$input['precio_3'] : null,
                    $input['nombre_t4'] ?? null,
                    is_numeric($input['precio_4'] ?? null) ? (float)$input['precio_4'] : null,
                    $input['codigo_sunat'] ?? null,
                    $input['codigo_interno'] ?? null,
                    $input['unidad_medida'] ?? 'NIU',
                    isset($input['control_stock']) ? (int)$input['control_stock'] : 0
                ]);
                
                echo json_encode(["status" => "ok", "message" => "Producto creada"]);
            } elseif ($action === 'editar') {
                $precio = is_numeric($input['precio'] ?? 0) ? (float)($input['precio'] ?? 0) : 0;
                if ($imgPath) {
                    $stmt = $pdo->prepare("UPDATE productos SET id_subcategoria=?, nombre=?, descripcion=?, precio=?, imagen=?, nombre_t1=?, precio_1=?, nombre_t2=?, precio_2=?, nombre_t3=?, precio_3=?, nombre_t4=?, precio_4=?, codigo_sunat=?, codigo_interno=?, unidad_medida=?, control_stock=? WHERE id=?");
                    $stmt->execute([
                        $input['id_subcategoria'],
                        $input['nombre'],
                        $input['descripcion'] ?? '',
                        $precio,
                        $imgPath,
                        $input['nombre_t1'] ?? null,
                        is_numeric($input['precio_1'] ?? null) ? (float)$input['precio_1'] : null,
                        $input['nombre_t2'] ?? null,
                        is_numeric($input['precio_2'] ?? null) ? (float)$input['precio_2'] : null,
                        $input['nombre_t3'] ?? null,
                        is_numeric($input['precio_3'] ?? null) ? (float)$input['precio_3'] : null,
                        $input['nombre_t4'] ?? null,
                        is_numeric($input['precio_4'] ?? null) ? (float)$input['precio_4'] : null,
                        $input['codigo_sunat'] ?? null,
                        $input['codigo_interno'] ?? null,
                        $input['unidad_medida'] ?? 'NIU',
                        isset($input['control_stock']) ? (int)$input['control_stock'] : 0,
                        $input['id']
                    ]);
                } else {
                    $stmt = $pdo->prepare("UPDATE productos SET id_subcategoria=?, nombre=?, descripcion=?, precio=?, nombre_t1=?, precio_1=?, nombre_t2=?, precio_2=?, nombre_t3=?, precio_3=?, nombre_t4=?, precio_4=?, codigo_sunat=?, codigo_interno=?, unidad_medida=?, control_stock=? WHERE id=?");
                    $stmt->execute([
                        $input['id_subcategoria'],
                        $input['nombre'],
                        $input['descripcion'] ?? '',
                        $precio,
                        $input['nombre_t1'] ?? null,
                        is_numeric($input['precio_1'] ?? null) ? (float)$input['precio_1'] : null,
                        $input['nombre_t2'] ?? null,
                        is_numeric($input['precio_2'] ?? null) ? (float)$input['precio_2'] : null,
                        $input['nombre_t3'] ?? null,
                        is_numeric($input['precio_3'] ?? null) ? (float)$input['precio_3'] : null,
                        $input['nombre_t4'] ?? null,
                        is_numeric($input['precio_4'] ?? null) ? (float)$input['precio_4'] : null,
                        $input['codigo_sunat'] ?? null,
                        $input['codigo_interno'] ?? null,
                        $input['unidad_medida'] ?? 'NIU',
                        isset($input['control_stock']) ? (int)$input['control_stock'] : 0,
                        $input['id']
                    ]);
                }
                echo json_encode(["status" => "ok", "message" => "Producto actualizada"]);
            } elseif ($action === 'eliminar') {
                $stmt = $pdo->prepare("UPDATE productos SET estado=0 WHERE id=?");
                $stmt->execute([$input['id']]);
                echo json_encode(["status" => "ok", "message" => "Producto eliminada"]);
            }
        } elseif ($tipo === 'modificadores') {
            if ($action === 'crear') {
                $stmt = $pdo->prepare("INSERT INTO modificadores (nombre, precio_extra, aplica_a, tipo, requiere_texto) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$input['nombre'], $input['precio_extra'], is_array($input['aplica_a'] ?? '') ? implode(',', $input['aplica_a']) : ($input['aplica_a'] ?? ''), $input['tipo'], $input['requiere_texto'] ?? 0]);
                echo json_encode(["status" => "ok", "message" => "Modificador creado"]);
            } elseif ($action === 'editar') {
                $stmt = $pdo->prepare("UPDATE modificadores SET nombre=?, precio_extra=?, aplica_a=?, tipo=?, requiere_texto=? WHERE id=?");
                $stmt->execute([$input['nombre'], $input['precio_extra'], is_array($input['aplica_a'] ?? '') ? implode(',', $input['aplica_a']) : ($input['aplica_a'] ?? ''), $input['tipo'], $input['requiere_texto'] ?? 0, $input['id']]);
                echo json_encode(["status" => "ok", "message" => "Modificador actualizado"]);
            } elseif ($action === 'eliminar') {
                $stmt = $pdo->prepare("UPDATE modificadores SET estado=0 WHERE id=?");
                $stmt->execute([$input['id']]);
                echo json_encode(["status" => "ok", "message" => "Modificador eliminado"]);
            }
        }
    }

} catch(PDOException $e) {
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}

