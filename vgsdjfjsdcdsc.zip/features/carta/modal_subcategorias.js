function modalNuevoGrupo(idCategoria, nombreCategoria) {
    let opcionesAreas = window.datosApp.areas_produccion ? '<option value="">-- Sin Área Específica --</option>' + window.datosApp.areas_produccion.map(a => `<option value="${a.id}">${a.nombre}</option>`).join('') : '<option value="">-- Sin Área Específica --</option>';
    
    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Nueva Subcategoría</h5><p style="margin: 0; font-size: 0.85rem; color: #6b7280; font-weight: normal;">Agrega una subcategoría al menú</p></div>',
        html: `
            <div style="text-align: left; font-family: 'Inter', sans-serif;" class="p-1 overflow-hidden">
                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Nombre <span class="text-danger">*</span></label>
                        <input id="swal-grupo-nombre" class="form-control form-control-sm border-secondary-subtle">
                    </div>
                    <div class="col-12">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Descripción</label>
                        <input id="swal-grupo-descripcion" class="form-control form-control-sm border-secondary-subtle">
                    </div>
                    <div class="col-12">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Área de Producción</label>
                        <select id="swal-grupo-area" class="form-select form-select-sm border-secondary-subtle">${opcionesAreas}</select>
                    </div>
                </div>
            </div>
        `,
        width: 550,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-secondary px-4',
            actions: 'w-100 justify-content-center mt-3 pt-3 border-top gap-3',
            popup: 'rounded-lg p-4',
            title: 'w-100 m-0'
        },
        didOpen: () => {
            if (typeof lucide !== 'undefined') lucide.createIcons();
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            confirmBtn.style.borderRadius = '8px';
            confirmBtn.style.fontWeight = '500';
            cancelBtn.style.borderRadius = '8px';
        },
        preConfirm: () => {
            const nombre = document.getElementById('swal-grupo-nombre').value.trim();
            if (!nombre) { Swal.showValidationMessage('Nombre obligatorio'); return false; }
            return {
                id_categoria: idCategoria,
                nombre: nombre,
                descripcion: document.getElementById('swal-grupo-descripcion').value.trim(),
                id_areaproduccion: document.getElementById('swal-grupo-area').value,
                tiene_tamanos: 0,
                is_combo: 0
            };
        }
    }).then(async (r) => {
        if (r.isConfirmed && r.value.nombre && r.value.nombre && r.value.nombre) {
            const res = await fetch('features/carta/controller_carta.php?tipo=subcategorias&action=crear', { method: 'POST', body: JSON.stringify(r.value) });
            if ((await res.json()).status === 'ok') { 
                mostrarAlerta('success', 'Subcategoría creada'); 
                cargarCarta(); 
            }
        }
    });
}

function alertaEditarGrupo(idGrupo) {
    let grupo = window.datosApp.subcategorias.find(g => g.id == idGrupo);
    if (!grupo) return;
    
    let opcionesAreas = window.datosApp.areas_produccion ? '<option value="">-- Sin Área Específica --</option>' + window.datosApp.areas_produccion.map(a => `<option value="${a.id}" ${a.id == grupo.id_areaproduccion ? 'selected' : ''}>${a.nombre}</option>`).join('') : '<option value="">-- Sin Área Específica --</option>';
    
    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Editar Subcategoría</h5><p style="margin: 0; font-size: 0.85rem; color: #6b7280; font-weight: normal;">Modifica los detalles de la subcategoría</p></div>',
        html: `
            <div style="text-align: left; font-family: 'Inter', sans-serif;" class="p-1 overflow-hidden">
                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Nombre de la subcategoría <span class="text-danger">*</span></label>
                        <input id="swal-prod-nombre" class="form-control form-control-sm border-secondary-subtle" placeholder="Ej: Pizzas Clásicas" value="${grupo.nombre}">
                    </div>
                    <div class="col-12">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Descripción (opcional)</label>
                        <input id="swal-prod-desc" class="form-control form-control-sm border-secondary-subtle" placeholder="Breve descripción de la subcategoría" value="${grupo.descripcion || ''}">
                    </div>
                    <div class="col-12">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Área de producción</label>
                        <select id="swal-prod-area" class="form-select form-select-sm border-secondary-subtle">
                            ${opcionesAreas}
                        </select>
                    </div>
                </div>
            </div>
        `,
        width: 550,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-secondary px-4',
            actions: 'w-100 justify-content-center mt-3 pt-3 border-top gap-3',
            popup: 'rounded-lg p-4',
            title: 'w-100 m-0'
        },
        
        
        didOpen: () => {
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            confirmBtn.style.borderRadius = '8px';
            confirmBtn.style.fontWeight = '500';
            cancelBtn.style.borderRadius = '8px';
        },
        preConfirm: () => ({
            id: grupo.id,
            nombre: document.getElementById('swal-prod-nombre').value,
            descripcion: document.getElementById('swal-prod-desc').value,
            id_areaproduccion: document.getElementById('swal-prod-area').value,
            id_categoria: grupo.id_categoria,
            tiene_tamanos: 0,
            is_combo: grupo.is_combo
        })
    }).then(async (r) => {
        if (r.isConfirmed && r.value.nombre) {
            const res = await fetch('features/carta/controller_carta.php?tipo=subcategorias&action=editar', { method: 'POST', body: JSON.stringify(r.value) });
            if ((await res.json()).status === 'ok') { 
                mostrarAlerta('success', 'Subcategoría actualizada'); 
                cargarCarta(); 
            }
        }
    });
}

function alertaEditarSubcategoria(id) {
    let item = window.datosApp.subcategorias.find(x => x.id == id);
    if (!item) return;
    let opcionesCat = window.datosApp.categorias.map(c => `<option value="${c.id}" ${c.id==item.id_categoria?'selected':''}>${c.nombre}</option>`).join('');
    let opcionesAreas = window.datosApp.areas_produccion ? '<option value="">-- Sin Área Específica --</option>' + window.datosApp.areas_produccion.map(a => `<option value="${a.id}" ${a.id==item.id_areaproduccion?'selected':''}>${a.nombre}</option>`).join('') : '<option value="">-- Sin Área Específica --</option>';
    Swal.fire({
        title: 'Editar Subcategoria',
        html: `
            <div style="text-align: left; font-family: 'Inter', sans-serif;" class="p-1 overflow-hidden">
                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Nombre del subcategoria <span class="text-danger">*</span></label>
                        <input id="swal-prod-nombre" class="form-control form-control-sm border-secondary-subtle" placeholder="Nombre" value="${item.nombre}">
                    </div>
                    <div class="col-12">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Descripción (opcional)</label>
                        <input id="swal-prod-desc" class="form-control form-control-sm border-secondary-subtle" placeholder="Descripción" value="${item.descripcion || ''}">
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Categoría</label>
                        <select id="swal-prod-cat" class="form-select form-select-sm border-secondary-subtle">${opcionesCat}</select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Área de Producción</label>
                        <select id="swal-prod-area" class="form-select form-select-sm border-secondary-subtle">${opcionesAreas}</select>
                    </div>
                    
                    
                    
                    <div class="col-12">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Tipo</label>
                        <select id="swal-prod-combo" class="form-select form-select-sm border-secondary-subtle">
                            <option value="0" ${item.is_combo==0?'selected':''}>Subcategoria normal</option>
                            <option value="1" ${item.is_combo==1?'selected':''}>Es un Combo</option>
                        </select>
                    </div>
                </div>
            </div>
        `,
        width: 500,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Guardar',
        cancelButtonText: 'Cancelar',
        
        
        didOpen: () => {
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            confirmBtn.style.borderRadius = '8px';
            confirmBtn.style.fontWeight = '500';
            cancelBtn.style.borderRadius = '8px';
        },
        preConfirm: () => ({
            id: id,
            nombre: document.getElementById('swal-prod-nombre').value,
            descripcion: document.getElementById('swal-prod-desc').value,
            id_categoria: document.getElementById('swal-prod-cat').value,
            id_areaproduccion: document.getElementById('swal-prod-area').value,
            is_combo: document.getElementById('swal-prod-combo').value,
            tiene_tamanos: item.tiene_tamanos
        })
    }).then(async (r) => {
        if (r.isConfirmed) {
            const res = await fetch('features/carta/controller_carta.php?tipo=subcategorias&action=editar', { method: 'POST', body: JSON.stringify(r.value) });
            if ((await res.json()).status === 'ok') { mostrarAlerta('success', 'Subcategoria actualizado'); cargarCarta(); }
        }
    });
}

function modalNuevoSubcategoriaContextual() {
    let cat = window.datosApp.categorias.find(c => c.id == window.filtroCarta);
    if(!cat) return mostrarAlerta('error', 'Selecciona una categoría primero');
    
    // Este botón ahora solo crea grupos
    modalNuevoGrupo(cat.id, cat.nombre);
}