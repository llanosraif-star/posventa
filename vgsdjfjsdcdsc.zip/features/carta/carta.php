<style>

    
    @media (min-width: 992px) {
        .carta-main-row {
            height: calc(100vh - 150px);
        }
        .carta-col {
            height: 100%;
        }
    }
    @media (max-width: 991px) {
        .carta-main-row {
            height: auto;
            min-height: 0 !important;
        }
        .carta-col {
            height: auto;
            min-height: 400px;
        }
    }
</style>
<!--begin::App Content Header-->
<div class="app-content-header">
    <!--begin::Container-->
    <div class="container-fluid">
        <!--begin::Row-->
        <div class="row align-items-center">
            <div class="col-sm-6">
                <h4 class="mb-0 d-flex align-items-center text-dark" style="font-weight: 600; font-size: 22px;">
                    <i data-lucide="book-open" style="width:22px;height:22px;margin-right:8px; color: #475569;"></i> Gestión de Carta
                </h4>
            </div>
        </div>
        <!--end::Row-->
    </div>
    <!--end::Container-->
</div>
<!--end::App Content Header-->
            
            <!-- Cards Principales: Categorías y Productos separadas -->
            <div class="row mb-4 carta-main-row" style="min-height: 500px; margin-left: -10px; margin-right: -10px;">
                <!-- Columna Izquierda: Barra de Categorías -->
                <div class="col-lg-4 mb-3 mb-lg-0 carta-col" style="padding-left: 10px; padding-right: 10px;">
                    <div class="card h-100" style="border-radius: 12px; overflow: hidden; border: 1px solid #a8b4c5; box-shadow: 0 8px 30px rgba(148, 163, 184, 0.5) !important; background-color: #f8fafc; display: flex; flex-direction: column;">
                        <div class="p-3 border-bottom" style="background: transparent; flex-shrink: 0;">
                            <h5 class="mb-1 font-weight-bold text-dark" style="font-size: 1.15rem;">Categorías</h5>
                            <p class="text-muted mb-0" style="font-size: 0.8rem;" id="carta-stats-categorias">Cargando...</p>
                        </div>
                        <div class="p-3" style="overflow-y: auto; flex-grow: 1;" id="filtrosCarta">
                            <div class="text-center w-100 py-2 text-muted">Cargando categorías...</div>
                        </div>
                        <div class="p-3 border-top" style="background: transparent; flex-shrink: 0;">
                            <button class="btn w-100 font-weight-bold shadow-sm d-flex justify-content-center align-items-center" onclick="modalNuevaCategoria()" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; color: #334155; font-size: 0.85rem; padding: 0.5rem;">
                                <i data-lucide="plus" style="width:16px;height:16px;margin-right:6px;"></i> Añadir categoría
                            </button>
                        </div>
                    </div>
                </div>
                
                <!-- Columna Derecha: Subcategorías y Productos -->
                <div class="col-lg-8 carta-col" style="padding-left: 10px; padding-right: 10px;">
                    <div class="card h-100" style="border-radius: 12px; overflow: hidden; border: 1px solid #a8b4c5; box-shadow: 0 8px 30px rgba(148, 163, 184, 0.5) !important; display: flex; flex-direction: column; background: #fff;">
                        <!-- Cabecera Derecha -->
                        <div class="px-4 pt-4 pb-2 bg-white" style="flex-shrink: 0; border-bottom: 2px solid #cbd5e1;">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <div>
                                    <h3 class="font-weight-bold text-dark mb-1" id="tituloTablaInteligente" style="font-size: 1.4rem;">Selecciona una categoría</h3>
                                    <p class="text-muted mb-0" id="carta-stats-subcategorias" style="font-size: 0.85rem;"></p>
                                </div>
                                <div class="d-flex" style="gap: 8px;">
                                    <button id="btnNuevoSubcategoriaContextual" class="btn btn-sm bg-white font-weight-bold d-none d-flex align-items-center shadow-sm" onclick="modalNuevoSubcategoriaContextual()" style="border: 1px solid #cbd5e1; border-radius: 20px; color: #475569; padding: 0.4rem 1rem;">
                                        <i data-lucide="plus" style="width:14px;height:14px;margin-right:4px;"></i> <span id="txtBtnContextual">Nueva subcategoría</span>
                                    </button>
                                    <button id="btnNuevaProductoContextual" class="btn btn-sm font-weight-bold d-none d-flex align-items-center shadow-sm" onclick="modalNuevaProductoGlobalContextual()" style="background: #e0f2fe; border: 1px solid #bae6fd; border-radius: 20px; color: #0369a1; padding: 0.4rem 1rem;">
                                        <i data-lucide="plus" style="width:14px;height:14px;margin-right:4px;"></i> <span id="txtBtnPresContextual">Nuevo producto</span>
                                    </button>
                                </div>
                            </div>
                            
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="d-flex flex-wrap" id="gruposBadges" style="gap: 8px;"></div>
                                <div class="position-relative d-none" id="buscadorCartaContenedor">
                                    <i data-lucide="search" class="position-absolute" style="left:12px; top:50%; transform:translateY(-50%); width:14px; height:14px; color:#94a3b8;"></i>
                                    <input type="text" class="form-control form-control-sm" id="buscadorCarta" placeholder="Buscar producto..." style="padding-left: 32px; border-radius: 20px; border: 1px solid #cbd5e1; width: 220px; box-shadow: none;" onkeyup="buscarItemCarta(this.value)">
                                </div>
                            </div>
                        </div>
                        
                        <!-- Lista de Subcategorias con Scroll -->
                        <div class="bg-white px-4 pt-0 pb-4" style="flex-grow: 1; overflow-y: auto; height: 0;" id="tbodyInteligente">
                            <div class="text-center py-5 text-muted mt-5">
                                <i data-lucide="mouse-pointer-click" style="width:48px;height:48px;color:#cbd5e1;display:block;margin:0 auto 15px;"></i>
                                <span style="font-size:1.1rem; font-weight:500;">Esperando selección...</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card Secundario: Modificadores (Ocupa la mitad) -->
            <div class="row">
                <div class="col-lg-6">
                    <div class="card mb-4" style="border-radius: 12px; overflow: hidden; border: 1px solid #a8b4c5; box-shadow: 0 8px 30px rgba(148, 163, 184, 0.5) !important; display: flex; flex-direction: column;">
                        <div class="p-3 border-bottom d-flex justify-content-between align-items-center" style="background: #f8fafc; flex-shrink: 0;">
                            <div class="d-flex align-items-center" style="gap: 8px;">
                                <i data-lucide="sliders" style="width:18px;height:18px;color:#64748b;"></i>
                                <h5 class="m-0 font-weight-bold text-dark" style="font-size:1.1rem;">Modificadores Globales</h5>
                            </div>
                            <button class="btn btn-sm shadow-sm d-flex align-items-center justify-content-center" onclick="modalNuevoModificador()" style="background: #ffffff; border: 1px solid #cbd5e1; border-radius: 6px; color: #334155; padding: 0.4rem 0.8rem;" title="Añadir modificador">
                                <i data-lucide="plus" style="width:14px;height:14px;margin-right:4px;"></i> Nuevo
                            </button>
                        </div>
                        <div class="p-3" style="background: #ffffff;">
                            <div class="list-group list-group-flush" id="listModificadores">
                                <div class="list-group-item text-center py-4 text-muted border-0">Cargando...</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div><script>if(typeof cargarCarta === 'function') cargarCarta();</script>
