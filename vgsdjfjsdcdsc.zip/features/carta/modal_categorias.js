function modalNuevaCategoria() {
    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Nueva Categoría</h5><p style="margin: 0; font-size: 0.85rem; color: #6b7280; font-weight: normal;">Agrega una nueva categoría al menú</p></div>',
        html: `
            <div style="text-align: left; font-family: 'Inter', sans-serif;" class="p-1 overflow-hidden">
                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Nombre de categoría <span class="text-danger">*</span></label>
                        <input id="swal-cat-nombre" class="form-control form-control-sm border-secondary-subtle" placeholder="Ej: Bebidas Frías">
                    </div>
                    <div class="col-12">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Imagen de la categoría</label>
                        <div class="d-flex align-items-center gap-3">
                            <div id="swal-cat-img-preview" style="width:56px;height:56px;border-radius:10px;background:#f1f5f9;border:2px dashed #cbd5e1;display:flex;align-items:center;justify-content:center;overflow:hidden;flex-shrink:0;">
                                <i data-lucide="image-plus" style="width:22px;height:22px;color:#94a3b8;"></i>
                            </div>
                            <input type="file" id="swal-cat-imagen" class="form-control form-control-sm border-secondary-subtle" accept="image/*" onchange="if(this.files[0]){let r=new FileReader();r.onload=e=>{document.getElementById('swal-cat-img-preview').innerHTML='<img src=\\''+e.target.result+'\\' style=\\'width:100%;height:100%;object-fit:cover;\\'>'};r.readAsDataURL(this.files[0])}">
                        </div>
                    </div>
                </div>
            </div>
        `,
        width: 550,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-secondary px-4',
            actions: 'w-100 justify-content-center mt-3 pt-3 border-top gap-3',
            popup: 'rounded-lg p-4',
            title: 'w-100 m-0'
        },
        didOpen: () => {
            if (typeof lucide !== 'undefined') lucide.createIcons();
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            if (confirmBtn) {
                confirmBtn.style.borderRadius = '8px';
                confirmBtn.style.fontWeight = '500';
            }
            if (cancelBtn) {
                cancelBtn.style.borderRadius = '8px';
            }
        },
        preConfirm: () => {
            const nombre = document.getElementById('swal-cat-nombre').value.trim();
            if (!nombre) {
                Swal.showValidationMessage('El nombre es obligatorio');
                return false;
            }
            return {
                nombre: nombre,
                imagen: document.getElementById('swal-cat-imagen').files[0]
            };
        }
    }).then(async (result) => {
        if (result.isConfirmed) {
            const formData = new FormData();
            formData.append('nombre', result.value.nombre);
            // Default values since they are no longer in UI
            formData.append('id_impresora', '');
            formData.append('tiene_tamanos', '0');
            if (result.value.imagen) formData.append('imagen', result.value.imagen);

            try {
                const res = await fetch('features/carta/controller_carta.php?tipo=categorias&action=crear', { method: 'POST', body: formData });
                if ((await res.json()).status === 'ok') { mostrarAlerta('success', 'Categoría creada'); cargarCarta(); }
            } catch(e) {
                mostrarAlerta('error', 'Error al crear la categoría');
            }
        }
    });
}

function alertaEditarCategoria(id) {
    let item = window.datosApp.categorias.find(x => x.id == id);
    if (!item) return;
    let opcionesImp = window.datosApp.impresoras.map(i => `<option value="${i.id}" ${i.id==item.id_impresora?'selected':''}>${i.nombre}</option>`).join('');
    let imgPreview = item.imagen 
        ? `<img src="${item.imagen}" style="width:100%;height:100%;object-fit:cover;">`
        : `<i data-lucide="image-plus" style="width:22px;height:22px;color:#94a3b8;"></i>`;
    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Editar Categoría</h5><p style="margin: 0; font-size: 0.85rem; color: #6b7280; font-weight: normal;">Modifica los detalles de la categoría</p></div>',
        html: `
            <div style="text-align: left; font-family: 'Inter', sans-serif;" class="p-1 overflow-hidden">
                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Nombre de la categoría <span class="text-danger">*</span></label>
                        <input id="swal-cat-nombre" class="form-control form-control-sm border-secondary-subtle" placeholder="Ej: Ensaladas" value="${item.nombre}">
                    </div>
                    
                    <div class="col-12">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Imagen de la categoría</label>
                        <div class="d-flex align-items-center gap-3">
                            <div id="swal-cat-img-preview" style="width:56px;height:56px;border-radius:10px;background:#f1f5f9;border:2px dashed #cbd5e1;display:flex;align-items:center;justify-content:center;overflow:hidden;flex-shrink:0;">
                                ${imgPreview}
                            </div>
                            <input type="file" id="swal-cat-imagen" class="form-control form-control-sm border-secondary-subtle" accept="image/*" onchange="if(this.files[0]){let r=new FileReader();r.onload=e=>{document.getElementById('swal-cat-img-preview').innerHTML='<img src=\\''+e.target.result+'\\' style=\\'width:100%;height:100%;object-fit:cover;\\'>'};r.readAsDataURL(this.files[0])}">
                        </div>
                    </div>
                    
                    </div>
                </div>
            </div>
        `,
        width: 550,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-secondary px-4',
            actions: 'w-100 justify-content-center mt-3 pt-3 border-top gap-3',
            popup: 'rounded-lg p-4',
            title: 'w-100 m-0'
        },
        
        
        didOpen: () => {
            if(typeof lucide !== 'undefined') lucide.createIcons();
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            confirmBtn.style.borderRadius = '8px';
            confirmBtn.style.fontWeight = '500';
            cancelBtn.style.borderRadius = '8px';
        },
        preConfirm: () => ({ 
            id: id, 
            nombre: document.getElementById('swal-cat-nombre').value, 
            id_impresora: item.id_impresora,
            tiene_tamanos: item.tiene_tamanos,
            imagen: document.getElementById('swal-cat-imagen').files[0] || null
        })
    }).then(async (r) => {
        if (r.isConfirmed) {
            let formData = new FormData();
            formData.append('id', r.value.id);
            formData.append('nombre', r.value.nombre);
            formData.append('id_impresora', r.value.id_impresora);
            formData.append('tiene_tamanos', r.value.tiene_tamanos);
            if (r.value.imagen) formData.append('imagen', r.value.imagen);
            const res = await fetch('features/carta/controller_carta.php?tipo=categorias&action=editar', { method: 'POST', body: formData });
            if ((await res.json()).status === 'ok') { mostrarAlerta('success', 'Categoría actualizada'); cargarCarta(); }
        }
    });
}