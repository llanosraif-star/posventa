function modalNuevoModificador() {
    Swal.fire({
        title: 'Nuevo Modificador',
        html: `
            <div style="text-align: left; font-family: 'Inter', sans-serif;" class="p-1 overflow-hidden">
                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Nombre del modificador <span class="text-danger">*</span></label>
                        <input id="swal-mod-nombre" class="form-control form-control-sm border-secondary-subtle" placeholder="Ej: Ingrediente Extra Familiar">
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Precio extra (S/)</label>
                        <input id="swal-mod-precio" type="number" step="0.01" class="form-control form-control-sm border-secondary-subtle" placeholder="0.00 (dejar vacío si gratis)">
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Tipo de modificador</label>
                        <select id="swal-mod-tipo" class="form-select form-select-sm border-secondary-subtle">
                            <option value="ingrediente">Ingrediente Extra</option>
                            <option value="instruccion">Instrucción (Ej. Bien cocida)</option>
                            <option value="especial">Especial (Ej. Mitad y Mitad)</option>
                        </select>
                    </div>
                    
                    <div class="col-12">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Aplica a categorías (opcional)</label>
                        <input id="swal-mod-aplica" class="form-control form-control-sm border-secondary-subtle" placeholder="IDs separados por coma, o vacío para todas">
                    </div>
                    
                    <div class="col-12 mt-4">
                        <h6 class="border-bottom pb-2 mb-3 fw-bold" style="font-size: 0.85rem; color: #475569;">OPCIONES AVANZADAS</h6>
                        <div class="form-check d-flex align-items-center gap-2 m-0 p-0 ps-1">
                            <input class="form-check-input m-0" type="checkbox" id="swal-mod-req-texto" style="width: 18px; height: 18px; cursor: pointer;">
                            <label class="form-check-label text-muted" for="swal-mod-req-texto" style="font-size: 0.85rem; cursor: pointer;">
                                El cajero debe ingresar el nombre manualmente (Texto Libre)
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        `,
        width: 500,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Guardar',
        cancelButtonText: 'Cancelar',
        
        
        didOpen: () => {
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            confirmBtn.style.borderRadius = '8px';
            confirmBtn.style.fontWeight = '500';
            cancelBtn.style.borderRadius = '8px';
            setTimeout(() => { document.getElementById('swal-mod-nombre')?.focus(); }, 100);
        },
        preConfirm: () => { 
            return { 
                nombre: document.getElementById('swal-mod-nombre').value, 
                precio_extra: document.getElementById('swal-mod-precio').value, 
                tipo: document.getElementById('swal-mod-tipo').value, 
                aplica_a: document.getElementById('swal-mod-aplica').value, 
                requiere_texto: document.getElementById('swal-mod-req-texto').checked ? 1 : 0 
            }; 
        }
    }).then(async (r) => {
        if (r.isConfirmed) {
            try {
                const res = await fetch('features/carta/controller_carta.php?tipo=modificadores&action=crear', { 
                    method: 'POST', 
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify(r.value) 
                });
                const data = await res.json();
                console.log('Respuesta crear modificador:', data);
                if (data.status === 'ok') { 
                    mostrarAlerta('success', 'Modificador creado'); 
                    cargarCarta(); 
                } else {
                    mostrarAlerta('error', data.message || 'Error al crear modificador');
                }
            } catch(err) {
                console.error('Error creando modificador:', err);
                mostrarAlerta('error', 'Error de conexión al crear modificador');
            }
        }
    });
}

function alertaEditarModificador(id) {
    let item = window.datosApp.modificadores.find(x => x.id == id);
    if (!item) return;
    Swal.fire({
        title: 'Editar Modificador',
        html: `
            <div style="text-align: left; font-family: 'Inter', sans-serif;" class="p-1 overflow-hidden">
                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Nombre del modificador <span class="text-danger">*</span></label>
                        <input id="swal-mod-nombre" class="form-control form-control-sm border-secondary-subtle" placeholder="Ej: Ingrediente Extra Familiar" value="${item.nombre}">
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Precio extra (S/)</label>
                        <input id="swal-mod-precio" type="number" step="0.01" class="form-control form-control-sm border-secondary-subtle" placeholder="0.00" value="${item.precio_extra}">
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Tipo de modificador</label>
                        <select id="swal-mod-tipo" class="form-select form-select-sm border-secondary-subtle">
                            <option value="ingrediente" ${item.tipo=='ingrediente'?'selected':''}>Ingrediente Extra</option>
                            <option value="instruccion" ${item.tipo=='instruccion'?'selected':''}>Instrucción</option>
                            <option value="especial" ${item.tipo=='especial'?'selected':''}>Especial</option>
                        </select>
                    </div>
                    
                    <div class="col-12">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Aplica a categorías (opcional)</label>
                        <input id="swal-mod-aplica" class="form-control form-control-sm border-secondary-subtle" placeholder="IDs separados por coma, o vacío para todas" value="${item.aplica_a || ''}">
                    </div>
                    
                    <div class="col-12 mt-4">
                        <h6 class="border-bottom pb-2 mb-3 fw-bold" style="font-size: 0.85rem; color: #475569;">OPCIONES AVANZADAS</h6>
                        <div class="form-check d-flex align-items-center gap-2 m-0 p-0 ps-1">
                            <input class="form-check-input m-0" type="checkbox" id="swal-mod-req-texto" style="width: 18px; height: 18px; cursor: pointer;" ${item.requiere_texto == 1 ? 'checked' : ''}>
                            <label class="form-check-label text-muted" for="swal-mod-req-texto" style="font-size: 0.85rem; cursor: pointer;">
                                El cajero debe ingresar el nombre manualmente (Texto Libre)
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        `,
        width: 500,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Guardar',
        cancelButtonText: 'Cancelar',
        
        
        didOpen: () => {
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            confirmBtn.style.borderRadius = '8px';
            confirmBtn.style.fontWeight = '500';
            cancelBtn.style.borderRadius = '8px';
        },
        preConfirm: () => { 
            return { 
                id: id, 
                nombre: document.getElementById('swal-mod-nombre').value, 
                precio_extra: document.getElementById('swal-mod-precio').value, 
                tipo: document.getElementById('swal-mod-tipo').value, 
                aplica_a: document.getElementById('swal-mod-aplica').value, 
                requiere_texto: document.getElementById('swal-mod-req-texto').checked ? 1 : 0 
            }; 
        }
    }).then(async (r) => {
        if (r.isConfirmed) {
            try {
                const res = await fetch('features/carta/controller_carta.php?tipo=modificadores&action=editar', { 
                    method: 'POST', 
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify(r.value) 
                });
                const data = await res.json();
                if (data.status === 'ok') { 
                    mostrarAlerta('success', 'Modificador actualizado'); 
                    cargarCarta(); 
                } else {
                    mostrarAlerta('error', data.message || 'Error al editar');
                }
            } catch(err) {
                console.error('Error editando modificador:', err);
                mostrarAlerta('error', 'Error de conexión');
            }
        }
    });
}