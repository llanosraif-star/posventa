function modalNuevoProducto(idSubcategoria = null, nombreSubcategoria = '') {
    let cat = window.datosApp.categorias.find(c => c.id == window.filtroCarta);
    let gruposDeCategoria = cat ? window.datosApp.subcategorias.filter(p => p.id_categoria == cat.id) : window.datosApp.subcategorias;
    let opcionesGrupo = gruposDeCategoria.map(g => `<option value="${g.id}" ${g.id == idSubcategoria ? 'selected' : ''}>${g.nombre}</option>`).join('');

    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Nuevo Producto</h5><p style="margin: 0; font-size: 0.85rem; color: #6b7280; font-weight: normal;">Agrega un nuevo producto al menú</p></div>',
        html: `
            <div style="text-align: left; font-family: 'Inter', sans-serif;" class="p-1 overflow-hidden">
                <div class="row g-2">
                    <!-- Columna Izquierda -->
                    <div class="col-md-8">
                        <div class="row g-2">
                            <div class="col-12">
                                <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Nombre del producto <span class="text-danger">*</span></label>
                                <input id="swal-pres-nombre" class="form-control form-control-sm border-secondary-subtle" placeholder="Ej: Jugo de fresa">
                            </div>
                            <div class="col-12">
                                <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Descripción</label>
                                <input id="swal-pres-desc" class="form-control form-control-sm border-secondary-subtle" placeholder="Breve descripción del producto">
                            </div>
                            <div class="col-12">
                                <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Subcategoría</label>
                                <select id="swal-pres-grupo" class="form-select form-select-sm border-secondary-subtle">
                                    ${opcionesGrupo}
                                </select>
                            </div>
                            
                            <div class="col-md-4">
                                <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Código interno</label>
                                <input id="swal-pres-codigo-interno" class="form-control form-control-sm border-secondary-subtle" placeholder="Ej: P001">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Código SUNAT</label>
                                <input id="swal-pres-codigo-sunat" class="form-control form-control-sm border-secondary-subtle" placeholder="Ej: 50202306">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Unidad de medida</label>
                                <select id="swal-pres-unidad" class="form-select form-select-sm border-secondary-subtle">
                                    <option value="NIU" selected>NIU</option>
                                    <option value="KGM">KGM</option>
                                    <option value="LTR">LTR</option>
                                    <option value="BX">BX (Caja)</option>
                                </select>
                            </div>

                            <div class="col-12 mt-2">
                                <div class="d-flex align-items-center gap-3">
                                    <label class="form-label mb-0 text-muted fw-bold" style="font-size: 0.88rem;">Presentación</label>
                                    <div class="form-check mb-0">
                                        <input class="form-check-input" type="radio" name="swal-tipo-pres" id="swal-tipo-unico" value="0" checked onchange="toggleTipoPres(this.value)">
                                        <label class="form-check-label" for="swal-tipo-unico" style="font-size: 0.88rem;">Único</label>
                                    </div>
                                    <div class="form-check mb-0">
                                        <input class="form-check-input" type="radio" name="swal-tipo-pres" id="swal-tipo-tamanos" value="1" onchange="toggleTipoPres(this.value)">
                                        <label class="form-check-label" for="swal-tipo-tamanos" style="font-size: 0.88rem;">Varias</label>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Sección Precio Único -->
                            <div class="col-12" id="sec-precio-unico">
                                <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Precio (S/)</label>
                                <input type="number" step="0.01" id="swal-pres-precio" class="form-control form-control-sm border-secondary-subtle" placeholder="0.00" style="max-width: 150px;">
                            </div>

                            <!-- Sección Múltiples Tamaños -->
                            <div class="col-12" id="sec-tamanos" style="display:none;">
                                <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Precios por presentación</label>
                                <div id="swal-tamanos-container">
                                    <div class='d-flex mb-2 align-items-center tam-row' style='gap:8px;'>
                                        <input class='form-control form-control-sm tam-nombre border-secondary-subtle' placeholder='Personal' style='flex:1;'>
                                        <input type='number' step='0.01' class='form-control form-control-sm tam-precio border-secondary-subtle' placeholder='15.00' style='width:90px;'>
                                        <button type='button' class='btn btn-sm btn-outline-secondary' style='width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:6px;' onclick='this.parentElement.remove()'>&times;</button>
                                    </div>
                                    <div class='d-flex mb-2 align-items-center tam-row' style='gap:8px;'>
                                        <input class='form-control form-control-sm tam-nombre border-secondary-subtle' placeholder='Mediana' style='flex:1;'>
                                        <input type='number' step='0.01' class='form-control form-control-sm tam-precio border-secondary-subtle' placeholder='25.00' style='width:90px;'>
                                        <button type='button' class='btn btn-sm btn-outline-secondary' style='width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:6px;' onclick='this.parentElement.remove()'>&times;</button>
                                    </div>
                                    <div class='d-flex mb-2 align-items-center tam-row' style='gap:8px;'>
                                        <input class='form-control form-control-sm tam-nombre border-secondary-subtle' placeholder='Familiar' style='flex:1;'>
                                        <input type='number' step='0.01' class='form-control form-control-sm tam-precio border-secondary-subtle' placeholder='38.00' style='width:90px;'>
                                        <button type='button' class='btn btn-sm btn-outline-secondary' style='width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:6px;' onclick='this.parentElement.remove()'>&times;</button>
                                    </div>
                                </div>
                                <button type="button" class="btn btn-sm mt-1 w-100 text-dark" style="border-radius:8px; display:flex; align-items:center; justify-content:center; gap:6px; border: 1px dashed #cbd5e1; background: #fff;" onclick="(function(){let c=document.getElementById('swal-tamanos-container'); let n=c.querySelectorAll('.tam-row').length; if(n<4){c.insertAdjacentHTML('beforeend', \`<div class='d-flex mb-2 align-items-center tam-row' style='gap:8px;'><input class='form-control form-control-sm tam-nombre border-secondary-subtle' placeholder='Nombre presentación' style='flex:1;'><input type='number' step='0.01' class='form-control form-control-sm tam-precio border-secondary-subtle' placeholder='0.00' style='width:90px;'><button type='button' class='btn btn-sm btn-outline-secondary' style='width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:6px;' onclick='this.parentElement.remove()'>&times;</button></div>\`)} else {Swal.showValidationMessage('Máximo 4 tamaños')}})()">
                                    + Agregar presentación
                                </button>
                            </div>
                            
                            <!-- Control de Stock -->
                            <div class="col-12 mt-2 p-2 rounded" style="background-color: #f8fafc; border: 1px dashed #cbd5e1;">
                                <div class="form-check form-switch mb-1">
                                    <input class="form-check-input" type="checkbox" id="swal-pres-control-stock">
                                    <label class="form-check-label fw-bold text-dark" for="swal-pres-control-stock" style="font-size: 0.88rem;">Controlar Stock</label>
                                </div>
                                <small class="text-muted d-block" style="font-size: 0.75rem; line-height: 1.2;"><i data-lucide="info" style="width: 12px; height: 12px; display: inline-block; margin-bottom: 2px; color: #3b82f6;"></i> El stock se descontará del Inventario usando el <strong>Código Interno</strong>.</small>
                            </div>

                        </div>
                    </div>
                    
                    <!-- Columna Derecha -->
                    <div class="col-md-4 text-center">
                        <label class="form-label mb-1 text-muted fw-bold d-block text-start" style="font-size: 0.88rem;">Imagen / foto</label>
                        <div id="swal-pres-img-preview" style="width:100%;height:130px;border-radius:10px;background:#f8fafc;border:2px dashed #cbd5e1;display:flex;align-items:center;justify-content:center;flex-direction:column;overflow:hidden;margin-bottom:10px;">
                            <i data-lucide="image-plus" style="width:36px;height:36px;color:#94a3b8;margin-bottom:8px;"></i>
                            <span style="font-size:0.8rem;color:#94a3b8;">Max 15MB</span>
                        </div>
                        <input type="file" id="swal-pres-foto" class="d-none" accept="image/*" onchange="if(this.files[0]){let r=new FileReader();r.onload=e=>{document.getElementById('swal-pres-img-preview').innerHTML='<img src=\\''+e.target.result+'\\' style=\\'width:100%;height:100%;object-fit:cover;\\'>'};r.readAsDataURL(this.files[0])}">
                        <button type="button" class="btn btn-sm btn-outline-secondary w-100" style="border-radius:8px;" onclick="document.getElementById('swal-pres-foto').click()">Seleccionar archivo</button>
                    </div>
                </div>
            </div>
        `,
        width: 700,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-secondary px-4',
            actions: 'w-100 justify-content-center mt-2 pt-2 border-top gap-3',
            popup: 'rounded-lg p-3',
            title: 'w-100 m-0'
        },
        
        
        didOpen: () => {
            if(typeof lucide !== 'undefined') lucide.createIcons();
            
            // Global toggle function for this modal
            window.toggleTipoPres = function(val) {
                if(val == '1') {
                    document.getElementById('sec-precio-unico').style.display = 'none';
                    document.getElementById('sec-tamanos').style.display = 'block';
                } else {
                    document.getElementById('sec-precio-unico').style.display = 'block';
                    document.getElementById('sec-tamanos').style.display = 'none';
                }
            };
            
            // Check if subcategoria is selected and has multiple sizes by default
            if(idSubcategoria) {
                let sub = window.datosApp.subcategorias.find(s => s.id == idSubcategoria);
                if(sub && sub.tiene_tamanos == 1) {
                    document.getElementById('swal-tipo-tamanos').checked = true;
                    window.toggleTipoPres('1');
                }
            }
            
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            confirmBtn.style.borderRadius = '8px';
            confirmBtn.style.fontWeight = '500';
            cancelBtn.style.borderRadius = '8px';
            setTimeout(() => { document.getElementById('swal-pres-nombre')?.focus(); }, 100);
        },
        preConfirm: () => {
            let tieneTamanos = document.querySelector('input[name="swal-tipo-pres"]:checked').value == '1';
            let result = {
                nombre: document.getElementById('swal-pres-nombre').value,
                descripcion: document.getElementById('swal-pres-desc').value,
                id_subcategoria: document.getElementById('swal-pres-grupo').value,
                codigo_interno: document.getElementById('swal-pres-codigo-interno').value,
                codigo_sunat: document.getElementById('swal-pres-codigo-sunat').value,
                unidad_medida: document.getElementById('swal-pres-unidad').value,
                precio: tieneTamanos ? 0 : (document.getElementById('swal-pres-precio').value || 0),
                tiene_tamanos: tieneTamanos ? 1 : 0,
                control_stock: document.getElementById('swal-pres-control-stock') ? (document.getElementById('swal-pres-control-stock').checked ? 1 : 0) : 0
            };
            if (tieneTamanos) {
                document.getElementById('swal-tamanos-container').querySelectorAll('.tam-nombre').forEach((n, i) => { 
                    result['nombre_t' + (i+1)] = n.value; 
                });
                document.getElementById('swal-tamanos-container').querySelectorAll('.tam-precio').forEach((p, i) => { 
                    result['precio_' + (i+1)] = p.value || 0; 
                });
            }
            return result;
        }
    }).then(async (r) => {
        if (r.isConfirmed && r.value.nombre) {
            let formData = new FormData();
            for (let key in r.value) {
                formData.append(key, r.value[key]);
            }
            let foto = document.getElementById('swal-pres-foto').files[0];
            if (foto) formData.append('imagen', foto);

            const res = await fetch('features/carta/controller_carta.php?tipo=productos&action=crear', { method: 'POST', body: formData });
            if ((await res.json()).status === 'ok') { 
                mostrarAlerta('success', 'Producto creado'); 
                cargarCarta(); 
            }
        }
    });
}

function alertaEditarProducto(idProducto) {
    let item = window.datosApp.productos.find(p => p.id == idProducto);
    if(!item) return;

    let subcat = window.datosApp.subcategorias.find(s => s.id == item.id_subcategoria);
    let cat = subcat ? window.datosApp.categorias.find(c => c.id == subcat.id_categoria) : null;
    let gruposDeCategoria = cat ? window.datosApp.subcategorias.filter(p => p.id_categoria == cat.id) : window.datosApp.subcategorias;
    let opcionesGrupo = gruposDeCategoria.map(g => `<option value="${g.id}" ${g.id == item.id_subcategoria ? 'selected' : ''}>${g.nombre}</option>`).join('');
    
    let tieneTamanos = item.nombre_t1 && item.nombre_t1.trim() !== '';

    let imgPreview = item.imagen ? `<img src="${item.imagen}" style="width:100%;height:100%;object-fit:cover;">` : `<i data-lucide="image-plus" style="width:36px;height:36px;color:#94a3b8;margin-bottom:8px;"></i><span style="font-size:0.8rem;color:#94a3b8;">Max 15MB</span>`;

    let tamsHtml = '';
    if(tieneTamanos) {
        for(let i=1; i<=4; i++) {
            if(item['nombre_t'+i]) {
                tamsHtml += `<div class='d-flex mb-2 align-items-center tam-row' style='gap:8px;'>
                    <input class='form-control form-control-sm tam-nombre border-secondary-subtle' placeholder='Nombre' style='flex:1;' value='${item['nombre_t'+i]}'>
                    <input type='number' step='0.01' class='form-control form-control-sm tam-precio border-secondary-subtle' placeholder='0.00' style='width:90px;' value='${item['precio_'+i]}'>
                    <button type='button' class='btn btn-sm btn-outline-secondary' style='width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:6px;' onclick='this.parentElement.remove()'>&times;</button>
                </div>`;
            }
        }
    } else {
        // Default rows if user switches to Con presentaciones
        tamsHtml = `<div class='d-flex mb-2 align-items-center tam-row' style='gap:8px;'>
            <input class='form-control form-control-sm tam-nombre border-secondary-subtle' placeholder='Personal' style='flex:1;'>
            <input type='number' step='0.01' class='form-control form-control-sm tam-precio border-secondary-subtle' placeholder='15.00' style='width:90px;'>
            <button type='button' class='btn btn-sm btn-outline-secondary' style='width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:6px;' onclick='this.parentElement.remove()'>&times;</button>
        </div>`;
    }

    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Editar Producto</h5><p style="margin: 0; font-size: 0.85rem; color: #6b7280; font-weight: normal;">Modifica los detalles del producto</p></div>',
        html: `
            <div style="text-align: left; font-family: 'Inter', sans-serif;" class="p-1 overflow-hidden">
                <div class="row g-2">
                    <!-- Columna Izquierda -->
                    <div class="col-md-8">
                        <div class="row g-2">
                            <div class="col-12">
                                <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Nombre del producto <span class="text-danger">*</span></label>
                                <input id="swal-pres-nombre" class="form-control form-control-sm border-secondary-subtle" placeholder="Ej: Jugo de fresa" value="${item.nombre}">
                            </div>
                            <div class="col-12">
                                <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Descripción</label>
                                <input id="swal-pres-desc" class="form-control form-control-sm border-secondary-subtle" placeholder="Breve descripción" value="${item.descripcion || ''}">
                            </div>
                            <div class="col-12">
                                <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Subcategoría</label>
                                <select id="swal-pres-grupo" class="form-select form-select-sm border-secondary-subtle">
                                    ${opcionesGrupo}
                                </select>
                            </div>
                            
                            <div class="col-md-4">
                                <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Código interno</label>
                                <input id="swal-pres-codigo-interno" class="form-control form-control-sm border-secondary-subtle" placeholder="Ej: P001" value="${item.codigo_interno || ''}">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Código SUNAT</label>
                                <input id="swal-pres-codigo-sunat" class="form-control form-control-sm border-secondary-subtle" placeholder="Ej: 50202306" value="${item.codigo_sunat || ''}">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Unidad de medida</label>
                                <select id="swal-pres-unidad" class="form-select form-select-sm border-secondary-subtle">
                                    <option value="NIU" ${item.unidad_medida == 'NIU' ? 'selected' : ''}>NIU</option>
                                    <option value="KGM" ${item.unidad_medida == 'KGM' ? 'selected' : ''}>KGM</option>
                                    <option value="LTR" ${item.unidad_medida == 'LTR' ? 'selected' : ''}>LTR</option>
                                    <option value="BX" ${item.unidad_medida == 'BX' ? 'selected' : ''}>BX (Caja)</option>
                                </select>
                            </div>

                            <div class="col-12 mt-2">
                                <div class="d-flex align-items-center gap-3">
                                    <label class="form-label mb-0 text-muted fw-bold" style="font-size: 0.88rem;">Presentación</label>
                                    <div class="form-check mb-0">
                                        <input class="form-check-input" type="radio" name="swal-tipo-pres" id="swal-tipo-unico" value="0" ${!tieneTamanos ? 'checked' : ''} onchange="toggleTipoPres(this.value)">
                                        <label class="form-check-label" for="swal-tipo-unico" style="font-size: 0.88rem;">Único</label>
                                    </div>
                                    <div class="form-check mb-0">
                                        <input class="form-check-input" type="radio" name="swal-tipo-pres" id="swal-tipo-tamanos" value="1" ${tieneTamanos ? 'checked' : ''} onchange="toggleTipoPres(this.value)">
                                        <label class="form-check-label" for="swal-tipo-tamanos" style="font-size: 0.88rem;">Varias</label>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Sección Precio Único -->
                            <div class="col-12" id="sec-precio-unico" style="display:${!tieneTamanos ? 'block' : 'none'};">
                                <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Precio (S/)</label>
                                <input type="number" step="0.01" id="swal-pres-precio" class="form-control form-control-sm border-secondary-subtle" placeholder="0.00" style="max-width: 150px;" value="${item.precio}">
                            </div>

                            <!-- Sección Múltiples Tamaños -->
                            <div class="col-12" id="sec-tamanos" style="display:${tieneTamanos ? 'block' : 'none'};">
                                <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Precios por presentación</label>
                                <div id="swal-tamanos-container">
                                    ${tamsHtml}
                                </div>
                                <button type="button" class="btn btn-sm mt-1 w-100 text-dark" style="border-radius:8px; display:flex; align-items:center; justify-content:center; gap:6px; border: 1px dashed #cbd5e1; background: #fff;" onclick="(function(){let c=document.getElementById('swal-tamanos-container'); let n=c.querySelectorAll('.tam-row').length; if(n<4){c.insertAdjacentHTML('beforeend', \`<div class='d-flex mb-2 align-items-center tam-row' style='gap:8px;'><input class='form-control form-control-sm tam-nombre border-secondary-subtle' placeholder='Nombre presentación' style='flex:1;'><input type='number' step='0.01' class='form-control form-control-sm tam-precio border-secondary-subtle' placeholder='0.00' style='width:90px;'><button type='button' class='btn btn-sm btn-outline-secondary' style='width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:6px;' onclick='this.parentElement.remove()'>&times;</button></div>\`)} else {Swal.showValidationMessage('Máximo 4 tamaños')}})()">
                                    + Agregar presentación
                                </button>
                            </div>
                            
                            <!-- Control de Stock -->
                            <div class="col-12 mt-2 p-2 rounded" style="background-color: #f8fafc; border: 1px dashed #cbd5e1;">
                                <div class="form-check form-switch mb-1">
                                    <input class="form-check-input" type="checkbox" id="swal-pres-control-stock" ${item.control_stock == 1 ? 'checked' : ''}>
                                    <label class="form-check-label fw-bold text-dark" for="swal-pres-control-stock" style="font-size: 0.88rem;">Controlar Stock</label>
                                </div>
                                <small class="text-muted d-block" style="font-size: 0.75rem; line-height: 1.2;"><i data-lucide="info" style="width: 12px; height: 12px; display: inline-block; margin-bottom: 2px; color: #3b82f6;"></i> El stock se descontará del Inventario usando el <strong>Código Interno</strong>.</small>
                            </div>

                        </div>
                    </div>
                    
                    <!-- Columna Derecha -->
                    <div class="col-md-4 text-center">
                        <label class="form-label mb-1 text-muted fw-bold d-block text-start" style="font-size: 0.88rem;">Imagen / foto</label>
                        <div id="swal-pres-img-preview" style="width:100%;height:130px;border-radius:10px;background:#f8fafc;border:2px dashed #cbd5e1;display:flex;align-items:center;justify-content:center;flex-direction:column;overflow:hidden;margin-bottom:10px;">
                            ${imgPreview}
                        </div>
                        <input type="file" id="swal-pres-foto" class="d-none" accept="image/*" onchange="if(this.files[0]){let r=new FileReader();r.onload=e=>{document.getElementById('swal-pres-img-preview').innerHTML='<img src=\\''+e.target.result+'\\' style=\\'width:100%;height:100%;object-fit:cover;\\'>'};r.readAsDataURL(this.files[0])}">
                        <button type="button" class="btn btn-sm btn-outline-secondary w-100" style="border-radius:8px;" onclick="document.getElementById('swal-pres-foto').click()">Seleccionar archivo</button>
                    </div>
                </div>
            </div>
        `,
        width: 700,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-secondary px-4',
            actions: 'w-100 justify-content-center mt-2 pt-2 border-top gap-3',
            popup: 'rounded-lg p-3',
            title: 'w-100 m-0'
        },
        
        
        didOpen: () => {
            if(typeof lucide !== 'undefined') lucide.createIcons();
            
            window.toggleTipoPres = function(val) {
                if(val == '1') {
                    document.getElementById('sec-precio-unico').style.display = 'none';
                    document.getElementById('sec-tamanos').style.display = 'block';
                } else {
                    document.getElementById('sec-precio-unico').style.display = 'block';
                    document.getElementById('sec-tamanos').style.display = 'none';
                }
            };
            
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            confirmBtn.style.borderRadius = '8px';
            confirmBtn.style.fontWeight = '500';
            cancelBtn.style.borderRadius = '8px';
            setTimeout(() => { document.getElementById('swal-pres-nombre')?.focus(); }, 100);
        },
        preConfirm: () => {
            let tieneTamanos = document.querySelector('input[name="swal-tipo-pres"]:checked').value == '1';
            let result = {
                id: item.id,
                nombre: document.getElementById('swal-pres-nombre').value,
                descripcion: document.getElementById('swal-pres-desc').value,
                id_subcategoria: document.getElementById('swal-pres-grupo').value,
                codigo_interno: document.getElementById('swal-pres-codigo-interno').value,
                codigo_sunat: document.getElementById('swal-pres-codigo-sunat').value,
                unidad_medida: document.getElementById('swal-pres-unidad').value,
                precio: tieneTamanos ? 0 : (document.getElementById('swal-pres-precio').value || 0),
                tiene_tamanos: tieneTamanos ? 1 : 0,
                control_stock: document.getElementById('swal-pres-control-stock') ? (document.getElementById('swal-pres-control-stock').checked ? 1 : 0) : 0
            };
            
            // Si es tamaño único, hay que limpiar los campos de tamaños en la BD para que no salgan fantasmas
            for(let i=1; i<=4; i++) {
                result['nombre_t'+i] = '';
                result['precio_'+i] = 0;
            }
            
            if (tieneTamanos) {
                document.getElementById('swal-tamanos-container').querySelectorAll('.tam-nombre').forEach((n, i) => { 
                    result['nombre_t' + (i+1)] = n.value; 
                });
                document.getElementById('swal-tamanos-container').querySelectorAll('.tam-precio').forEach((p, i) => { 
                    result['precio_' + (i+1)] = p.value || 0; 
                });
            }
            return result;
        }
    }).then(async (r) => {
        if (r.isConfirmed && r.value.nombre) {
            let formData = new FormData();
            for (let key in r.value) {
                formData.append(key, r.value[key]);
            }
            let foto = document.getElementById('swal-pres-foto').files[0];
            if (foto) formData.append('imagen', foto);

            const res = await fetch('features/carta/controller_carta.php?tipo=productos&action=editar', { method: 'POST', body: formData });
            if ((await res.json()).status === 'ok') { 
                mostrarAlerta('success', 'Producto guardado'); 
                cargarCarta(); 
            }
        }
    });
}

function modalNuevaProducto(idSubcategoria) {
    Swal.fire({
        title: '<div style="text-align: left;"><h5 style="margin: 0; font-weight: bold; color: #111827;">Nuevo Producto</h5><p style="margin: 0; font-size: 0.85rem; color: #6b7280; font-weight: normal;">Agrega un producto a la subcategoría</p></div>',
        html: `
            <div style="text-align: left; font-family: 'Inter', sans-serif;" class="p-1 overflow-hidden">
                <div class="row g-2">
                    <div class="col-md-6">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Nombre (Ej. Hawaiana) <span class="text-danger">*</span></label>
                        <input id="swal-pres-nombre" class="form-control form-control-sm border-secondary-subtle" placeholder="Nombre">
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Precio Base (S/)</label>
                        <input id="swal-pres-precio" type="number" step="0.01" class="form-control form-control-sm border-secondary-subtle" placeholder="0.00">
                    </div>
                    
                    <div class="col-12">
                        <label class="form-label mb-1 text-muted fw-bold" style="font-size: 0.88rem;">Imagen / Foto (Max 15MB)</label>
                        <div class="d-flex align-items-center gap-3">
                            <div id="swal-pres-img-preview" style="width:56px;height:56px;border-radius:10px;background:#f1f5f9;border:2px dashed #cbd5e1;display:flex;align-items:center;justify-content:center;overflow:hidden;flex-shrink:0;">
                                <i data-lucide="image-plus" style="width:22px;height:22px;color:#94a3b8;"></i>
                            </div>
                            <input type="file" id="swal-pres-foto" class="form-control form-control-sm border-secondary-subtle" accept="image/*" onchange="if(this.files[0]){let r=new FileReader();r.onload=e=>{document.getElementById('swal-pres-img-preview').innerHTML='<img src=\\''+e.target.result+'\\' style=\\'width:100%;height:100%;object-fit:cover;\\'>'};r.readAsDataURL(this.files[0])}">
                        </div>
                    </div>
                    
                    <div class="col-12 mt-2">
                        <h6 class="border-bottom pb-2 mb-3 fw-bold" style="font-size: 0.85rem; color: #475569;">TAMAÑOS (OPCIONAL)</h6>
                        <div id="swal-tamanos-container"></div>
                        <button type="button" class="btn btn-sm btn-outline-primary mt-1 w-100 fw-bold" style="border-radius:8px;" onclick="document.getElementById('swal-tamanos-container').insertAdjacentHTML('beforeend','<div class=\\'d-flex mb-2\\' style=\\'gap:6px;\\'><input class=\\'form-control form-control-sm tam-nombre border-secondary-subtle\\' placeholder=\\'Ej: Familiar, Mediana\\'><input type=\\'number\\' step=\\'0.01\\' class=\\'form-control form-control-sm tam-precio border-secondary-subtle\\' placeholder=\\'Precio\\' style=\\'max-width:100px;\\'></div>')">
                            <i data-lucide="plus" style="width:14px;height:14px;display:inline-block;vertical-align:middle;margin-right:4px;"></i> Agregar tamaño
                        </button>
                    </div>
                </div>
            </div>
        `,
        width: 500,
        showCloseButton: false,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary px-4',
            cancelButton: 'btn btn-secondary px-4',
            actions: 'w-100 justify-content-center mt-2 pt-2 border-top gap-3',
            popup: 'rounded-lg p-3',
            title: 'w-100 m-0'
        },
        
        
        didOpen: () => {
            if (typeof lucide !== 'undefined') lucide.createIcons();
            let confirmBtn = Swal.getConfirmButton();
            let cancelBtn = Swal.getCancelButton();
            confirmBtn.style.borderRadius = '8px';
            confirmBtn.style.fontWeight = '500';
            cancelBtn.style.borderRadius = '8px';
            setTimeout(() => { document.getElementById('swal-pres-nombre')?.focus(); }, 100);
        },
        preConfirm: () => {
            let foto = document.getElementById('swal-pres-foto').files[0];
            if (foto && foto.size > 15 * 1024 * 1024) {
                Swal.showValidationMessage('La foto excede los 15MB permitidos');
                return false;
            }
            
            let result = {
                id_subcategoria: idSubcategoria,
                nombre: document.getElementById('swal-pres-nombre').value,
                precio: document.getElementById('swal-pres-precio').value || 0,
                foto: foto
            };
            document.getElementById('swal-tamanos-container').querySelectorAll('.tam-nombre').forEach((n, i) => { 
                if (i < 4 && n.value.trim()) { 
                    result['nombre_t' + (i+1)] = n.value.trim(); 
                    result['precio_' + (i+1)] = document.getElementById('swal-tamanos-container').querySelectorAll('.tam-precio')[i].value || 0; 
                } 
            });
            return result;
        }
    }).then(async (r) => {
        if (r.isConfirmed) {
            let formData = new FormData();
            for (let key in r.value) {
                if (key === 'foto' && r.value.foto) formData.append('foto', r.value.foto);
                else formData.append(key, r.value[key]);
            }
            const res = await fetch('features/carta/controller_carta.php?tipo=productos&action=crear', { method: 'POST', body: formData });
            if ((await res.json()).status === 'ok') { mostrarAlerta('success', 'Producto creada'); cargarCarta(); }
        }
    });
}

function modalNuevaProductoGlobalContextual() {
    let cat = window.datosApp.categorias.find(c => c.id == window.filtroCarta);
    if(!cat) return mostrarAlerta('error', 'Selecciona una categoría primero');
    
    let grupos = window.datosApp.subcategorias.filter(p => p.id_categoria == cat.id);
    if(grupos.length === 0) return mostrarAlerta('error', 'Primero debes crear una subcategoría');

    // Determinar qué grupo preseleccionar en el select
    let idGrupoPreseleccionado = grupos[0].id;
    if (window.filtroGrupoCarta && window.filtroGrupoCarta !== 'todos') {
        let grupoSeleccionado = grupos.find(p => p.id == window.filtroGrupoCarta);
        if (grupoSeleccionado) {
            idGrupoPreseleccionado = grupoSeleccionado.id;
        }
    }
    
    let nombreGrupo = grupos.find(p => p.id == idGrupoPreseleccionado).nombre;
    modalNuevoProducto(idGrupoPreseleccionado, nombreGrupo);
}