

// --- Productos CRUD ---

async function cargarCarta() {
    try {
        const response = await fetch('features/carta/controller_carta.php?t=' + Date.now());
        const result = await response.json();
        if (result.status === 'ok') {
            const d = result.data;
            window.datosApp.categorias = d.categorias;
            window.datosApp.subcategorias = d.subcategorias;
            window.datosApp.productos = d.productos;
            window.datosApp.modificadores = d.modificadores;
            window.datosApp.impresoras = d.impresoras;

            renderCategorias();
            renderSubcategorias();
            lucide.createIcons();
        }
    } catch(e) { console.error(e); }
}


function renderCategorias() {
    // Chips de Categorías interactivos
    const filtrosCarta = document.getElementById('filtrosCarta');
    if (filtrosCarta) {
        let d = window.datosApp;
        let totalCategorias = d.categorias.length;
        let totalItems = d.productos.length;
        let statsCat = document.getElementById('carta-stats-categorias');
        if(statsCat) statsCat.innerText = `${totalCategorias} categorías · ${totalItems} productos`;

        let chipHtml = '';
        if (d.categorias.length > 0) {
            chipHtml += d.categorias.map((c, index) => {
                let isActive = window.filtroCarta == c.id;
                let nProds = d.subcategorias.filter(p => p.id_categoria == c.id).length;
                let itemsCat = d.productos.filter(pr => {
                    let prod = d.subcategorias.find(p => p.id == pr.id_subcategoria);
                    return prod && prod.id_categoria == c.id;
                }).length;

                let imgHtml = c.imagen 
                    ? `<img src="${c.imagen}" style="width:100%;height:100%;object-fit:cover;">`
                    : `<i data-lucide="utensils" style="width:16px;height:16px;color:#64748b;"></i>`;

                let activeStyles = isActive 
                    ? 'background: #ffffff; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border: 1px solid #cbd5e1; border-radius: 12px;' 
                    : 'background: transparent; border: 1px solid transparent; border-radius: 12px;';

                return `<div class="d-flex align-items-center justify-content-between p-2 mb-1" 
                    style="cursor:pointer; transition: all 0.2s; ${activeStyles}"
                    onclick="if(event.target.closest('.dropdown')) return; filtrarCarta(${c.id})">
                    <div class="d-flex align-items-center">
                        <div style="width:32px;height:32px;border-radius:8px;background:${c.imagen ? 'transparent' : '#f1f5f9'};display:flex;align-items:center;justify-content:center;overflow:hidden;flex-shrink:0;margin-right:10px;">
                            ${imgHtml}
                        </div>
                        <div>
                            <div class="mb-0" style="font-size: 0.95rem; font-weight: ${isActive ? '600' : '500'}; color: ${isActive ? '#1e293b' : '#475569'}; line-height:1.2;">${c.nombre}</div>
                            <div class="text-muted" style="font-size: 0.75rem;">${nProds} subcategorías · ${itemsCat} productos</div>
                        </div>
                    </div>
                    <div class="d-flex align-items-center" style="gap: 6px;">
                        <span class="badge" style="background: ${isActive ? '#e0f2fe' : '#f1f5f9'}; color: ${isActive ? '#0284c7' : '#94a3b8'}; border-radius: 12px; font-size: 0.75rem; padding: 0.3rem 0.5rem;">${itemsCat}</span>
                        <div class="dropdown">
                            <button class="btn btn-sm p-0 d-flex align-items-center justify-content-center" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="width:24px; height:24px; color: #94a3b8; outline: none; box-shadow: none; background: transparent; border: none;">
                                <i data-lucide="more-vertical" style="width: 14px; height: 14px;"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" style="min-width: 8rem; border-radius: 8px; border: 1px solid #e2e8f0; font-size: 0.85rem; padding: 0.5rem 0;">
                                <a class="dropdown-item d-flex align-items-center py-2 px-3" href="#" onclick="event.preventDefault(); alertaEditarCategoria(${c.id})" style="gap: 8px; color: #475569;">
                                    <i data-lucide="pencil" style="width: 14px; height: 14px; color: #64748b;"></i> Editar
                                </a>
                                <a class="dropdown-item d-flex align-items-center py-2 px-3" href="#" onclick="event.preventDefault(); alertaEliminar(${c.id}, 'categorias')" style="gap: 8px; color: #ef4444;">
                                    <i data-lucide="trash-2" style="width: 14px; height: 14px;"></i> Eliminar
                                </a>
                            </div>
                        </div>
                    </div>
                </div>`;
            }).join('');
        } else {
            chipHtml += '<div class="text-muted text-center w-100 py-3">No hay categorías. Crea una para empezar.</div>';
        }

        filtrosCarta.innerHTML = chipHtml;
    }

}

function filtrarCarta(catId) {
    window.filtroCarta = catId;
    window.filtroGrupoCarta = 'todos';
    renderCategorias();
    renderSubcategorias();
    lucide.createIcons();
}

function renderSubcategorias() {
    const colTabla = document.getElementById('colTablaInteligente');
    const cardMod = document.getElementById('cardModificadoresDin');
    const tbody = document.getElementById('tbodyInteligente');
    const btnAdd = document.getElementById('btnNuevoSubcategoriaContextual');
    const txtBtn = document.getElementById('txtBtnContextual');
    const btnAddPres = document.getElementById('btnNuevaProductoContextual');
    const txtBtnPres = document.getElementById('txtBtnPresContextual');
    const titulo = document.getElementById('tituloTablaInteligente');
    const statsCat = document.getElementById('carta-stats-subcategorias');
    const buscadorCont = document.getElementById('buscadorCartaContenedor');

    if (window.filtroCarta === 'todos' || window.filtroCarta == null) {
        if(colTabla) colTabla.className = 'col-lg-12 transition-all p-0 h-100 d-flex flex-column';
        if(cardMod) { cardMod.classList.add('d-none'); cardMod.classList.remove('d-flex'); }
        if(btnAdd) { btnAdd.classList.add('d-none'); btnAdd.classList.remove('d-flex'); }
        if (btnAddPres) { btnAddPres.classList.add('d-none'); btnAddPres.classList.remove('d-flex'); }
        if (buscadorCont) { buscadorCont.classList.add('d-none'); }

        if(titulo) titulo.innerText = 'Selecciona una categoría';
        if(statsCat) statsCat.innerText = 'Por favor selecciona una categoría del menú lateral.';

        if (document.getElementById('gruposBadges')) {
            document.getElementById('gruposBadges').innerHTML = '';
        }
        if(tbody) tbody.innerHTML = `<div class="text-center py-5 text-muted mt-5">
            <i data-lucide="mouse-pointer-click" style="width:48px;height:48px;color:#cbd5e1;display:block;margin:0 auto 15px;"></i>
            <span style="font-size:1.1rem; font-weight:500;">Esperando selección...</span>
        </div>`;
        return;
    }

    let catSeleccionada = window.datosApp.categorias.find(c => c.id == window.filtroCarta);
    if (!catSeleccionada) return;

    if(titulo) titulo.innerText = catSeleccionada.nombre;

    let tieneTamanos = catSeleccionada.tiene_tamanos == 1 || catSeleccionada.nombre.toLowerCase().includes('pizza');

    if(colTabla) colTabla.className = 'col-lg-12 transition-all p-0 h-100 d-flex flex-column';

    window.filtroGrupoCarta = window.filtroGrupoCarta || 'todos';

    let grupos = window.datosApp.subcategorias.filter(p => p.id_categoria == window.filtroCarta);

    let itemsTotales = window.datosApp.productos.filter(pr => {
        let prod = window.datosApp.subcategorias.find(p => p.id == pr.id_subcategoria);
        return prod && prod.id_categoria == window.filtroCarta;
    }).length;
    let itemsSinPrecio = window.datosApp.productos.filter(pr => {
        let prod = window.datosApp.subcategorias.find(p => p.id == pr.id_subcategoria);
        return prod && prod.id_categoria == window.filtroCarta && (!pr.precio || parseFloat(pr.precio) <= 0) && !pr.nombre_t1;
    }).length;

    let statsText = `${grupos.length} subcategorías · ${itemsTotales} productos`;
    if(itemsSinPrecio > 0) statsText += ` · <span class="text-danger font-weight-bold">${itemsSinPrecio} sin precio</span>`;
    if(statsCat) statsCat.innerHTML = statsText;

    if(btnAdd) { btnAdd.classList.remove('d-none'); btnAdd.classList.add('d-flex'); }
    if(txtBtn) txtBtn.innerText = 'Nueva subcategoría';

    if (btnAddPres) {
        if (grupos.length > 0) {
            btnAddPres.classList.remove('d-none');
            btnAddPres.classList.add('d-flex');
            if(txtBtnPres) txtBtnPres.innerText = tieneTamanos ? 'Nuevo sabor' : 'Nuevo producto';
            if (buscadorCont) buscadorCont.classList.remove('d-none');
        } else {
            btnAddPres.classList.add('d-none');
            btnAddPres.classList.remove('d-flex');
            if (buscadorCont) buscadorCont.classList.add('d-none');
        }
    }

    const gruposBadges = document.getElementById('gruposBadges');
    if (gruposBadges) {
        let badgesHtml = `<button class="btn btn-sm ${window.filtroGrupoCarta === 'todos' ? 'font-weight-bold shadow-sm' : ''}" 
            style="${window.filtroGrupoCarta === 'todos' ? 'background: #2563eb; border: 1px solid #2563eb; color: #ffffff;' : 'background: #ffffff; border: 1px solid #cbd5e1; color: #475569;'} border-radius: 20px; padding: 0.4rem 1rem;" 
            onclick="filtrarPorGrupo('todos')">Todos</button>`;

        grupos.forEach(g => {
            let isActive = window.filtroGrupoCarta == g.id;
            badgesHtml += `
            <button class="btn btn-sm ${isActive ? 'font-weight-bold shadow-sm' : ''}" 
                style="${isActive ? 'background: #2563eb; border: 1px solid #2563eb; color: #ffffff;' : 'background: #ffffff; border: 1px solid #cbd5e1; color: #475569;'} border-radius: 20px; padding: 0.4rem 1rem;" 
                onclick="filtrarPorGrupo(${g.id})">${g.nombre}</button>`;
        });
        gruposBadges.innerHTML = badgesHtml;
    }

    if (grupos.length === 0) {
        if(tbody) tbody.innerHTML = `<div class="text-center py-5 text-muted mt-5">Aún no hay grupos creados en esta categoría.</div>`;
        return;
    }

    let productosParaMostrar = [];
    if (window.filtroGrupoCarta === 'todos') {
        grupos.forEach(g => {
            let pres = window.datosApp.productos.filter(pr => pr.id_subcategoria == g.id);
            pres = pres.map(pr => ({...pr, grupoNombre: g.nombre, grupoId: g.id}));
            productosParaMostrar = productosParaMostrar.concat(pres);
        });
    } else {
        let g = grupos.find(gx => gx.id == window.filtroGrupoCarta);
        if(g) {
            let pres = window.datosApp.productos.filter(pr => pr.id_subcategoria == g.id);
            pres = pres.map(pr => ({...pr, grupoNombre: g.nombre, grupoId: g.id}));
            productosParaMostrar = productosParaMostrar.concat(pres);
        }
    }

    let terminoBusqueda = '';
    let gruposAMostrar = window.filtroGrupoCarta === 'todos' ? grupos : grupos.filter(g => g.id == window.filtroGrupoCarta);
    const inputBusqueda = document.getElementById('buscadorCarta');
    if (inputBusqueda && inputBusqueda.value.trim() !== '') {
        terminoBusqueda = inputBusqueda.value.trim().toLowerCase();
        gruposAMostrar = gruposAMostrar.filter(g => {
            const hasMatchingItems = productosParaMostrar.some(pr => pr.grupoId == g.id);
            const matchesName = g.nombre.toLowerCase().includes(terminoBusqueda);
            return hasMatchingItems || matchesName;
        });
    }

    if (gruposAMostrar.length === 0) {
        if(tbody) tbody.innerHTML = `<div class="text-center py-5 text-muted mt-5">Aún no hay productos (productos) en esta subcategoría o no hay resultados para la búsqueda.</div>`;
        return;
    }

    let isFirstGroup = true;
    let htmlList = '';
    for (const grupo of gruposAMostrar) {
        let gName = grupo.nombre;
        let groupId = grupo.id;
        let items = productosParaMostrar.filter(pr => pr.grupoId == groupId);

        htmlList += `
        <div class="d-flex justify-content-between align-items-center mb-1 ${isFirstGroup ? 'mt-2' : 'mt-4'}" style="border-bottom: 1px solid #f1f5f9; padding-bottom: 0.3rem;">
            <div class="d-flex align-items-center" style="gap: 6px;">
                <i data-lucide="box" style="width:13px;height:13px;color:#94a3b8;"></i>
                <span class="font-weight-bold text-dark text-uppercase" style="font-size: 0.95rem; letter-spacing: 0.5px;">${gName}</span>
                <div class="dropdown ml-2">
                    <button class="btn btn-sm p-0 d-flex align-items-center justify-content-center" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="width:24px; height:24px; color: #64748b; outline: none; box-shadow: none; background: transparent; border: none;">
                        <i data-lucide="more-vertical" style="width: 14px; height: 14px;"></i>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" style="min-width: 8rem; border-radius: 8px; border: 1px solid #e2e8f0; font-size: 0.85rem; padding: 0.5rem 0;">
                        <a class="dropdown-item d-flex align-items-center py-2 px-3" href="#" onclick="event.preventDefault(); alertaEditarGrupo(${groupId})" style="gap: 8px; color: #475569;">
                            <i data-lucide="pencil" style="width: 14px; height: 14px; color: #64748b;"></i> Editar
                        </a>
                        <a class="dropdown-item d-flex align-items-center py-2 px-3" href="#" onclick="event.preventDefault(); alertaEliminar(${groupId}, 'subcategorias')" style="gap: 8px; color: #ef4444;">
                            <i data-lucide="trash-2" style="width: 14px; height: 14px;"></i> Eliminar
                        </a>
                    </div>
                </div>
            </div>
            <span class="text-muted font-weight-bold" style="font-size: 0.7rem;">${items.length} PRODUCTOS</span>
        </div>
        <div class="list-group mb-2" style="border-radius: 10px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 1px 2px rgba(0,0,0,0.04);">
        `;

        if (items.length === 0) {
            htmlList += `
            <div class="text-center py-3 text-muted" style="font-size: 0.85rem; background: #f8fafc;">
                Aún no hay productos en esta subcategoría.
            </div>`;
        }

        isFirstGroup = false;

        items.forEach((pr, idx) => {
            let imgHtml = pr.imagen 
                ? `<img src="${pr.imagen}" style="width:100%;height:100%;object-fit:cover;">`
                : `<div style="width:100%;height:100%;background:#f8fafc;display:flex;align-items:center;justify-content:center;"><i data-lucide="image" style="width:16px;height:16px;color:#cbd5e1;"></i></div>`;

            let precioHtml = '';
            let hasSizes = pr.nombre_t1 && pr.nombre_t1.trim();
            if (tieneTamanos && hasSizes) {
                 let tamsHtml = [];
                 for (let i = 1; i <= 4; i++) {
                     if (pr['nombre_t' + i] && pr['nombre_t' + i].trim()) {
                         let tName = pr['nombre_t' + i];
                         let tPrice = parseFloat(pr['precio_' + i]) || 0;
                         tamsHtml.push(`<div class="text-center" style="min-width: 65px; margin-right: 8px;">
                             <div style="font-size: 0.75rem; color: #64748b; font-weight: 600; margin-bottom: 2px;">${tName}</div>
                             <div style="font-size: 0.95rem; color: #0f172a; font-weight: 600;">S/ ${tPrice.toFixed(2)}</div>
                         </div>`);
                     }
                 }
                 precioHtml = `<div class="d-flex align-items-center">${tamsHtml.join('')}</div>`;
            } else {
                let precioVal = pr.precio || 0;
                precioHtml = precioVal > 0 
                    ? `<span class="font-weight-bold" style="font-size: 0.95rem; color:#0f172a;">S/ ${parseFloat(precioVal).toFixed(2)}</span>` 
                    : `<span class="badge bg-danger text-white px-1 py-1" style="border-radius: 6px; font-weight: normal; font-size:0.7rem;"><i data-lucide="alert-circle" style="width:10px;height:10px;margin-right:2px;"></i>Sin precio</span>`;
            }

            let desc = pr.descripcion ? pr.descripcion : '';
            let isComboHtml = pr.es_combo == 1 ? `<span class="badge" style="background:#fefce8; color:#a16207; border:1px solid #fef08a; border-radius:10px; font-weight:normal; font-size:0.65rem; margin-left:4px; padding:1px 5px;">Combo</span>` : '';
            let badgeGrupo = `<span class="badge mt-1" style="background:#ffedd5; color:#c2410c; border-radius:12px; font-weight:500; font-size:0.7rem; padding:3px 8px; display:inline-block;">${gName}</span>`;

            htmlList += `
            <div class="list-group-item bg-white d-flex justify-content-between align-items-center" style="border:none; border-bottom:${idx < items.length-1 ? '1px solid #f1f5f9' : 'none'}; padding:0.6rem 0.8rem;">
                <div class="d-flex align-items-center" style="gap:10px; flex:1; min-width:0;">
                    <div style="width:40px;height:40px;border-radius:8px;overflow:hidden;flex-shrink:0;border:1px solid #e2e8f0;background:#f8fafc;display:flex;align-items:center;justify-content:center;">
                        ${imgHtml}
                    </div>
                    <div style="min-width:0; flex:1;">
                        <div class="d-flex align-items-center" style="gap:4px;">
                            <span class="text-dark" style="font-size:0.95rem; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${pr.nombre === 'Única' || pr.nombre === 'Masa Tradicional' ? pr.grupoNombre : pr.nombre}</span>${isComboHtml}
                        </div>
                        ${desc ? `<div class="text-muted" style="font-size:0.73rem; line-height:1.2; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${desc}</div>` : ''}
                        ${badgeGrupo}
                    </div>
                </div>
                <div class="d-flex align-items-center" style="gap:12px; flex-shrink:0;">
                    ${precioHtml}
                    <div class="d-flex" style="gap:4px; border-left:1px solid #e2e8f0; padding-left:8px;">
                        <button class="btn btn-sm p-1 d-flex align-items-center justify-content-center" style="border-radius:6px; color:#475569; background:#f8fafc; border:1px solid #e2e8f0; width:26px; height:26px;" onclick="alertaEditarProducto(${pr.id})" title="Editar"><i data-lucide="pencil" style="width:12px;height:12px;"></i></button>
                        <button class="btn btn-sm p-1 d-flex align-items-center justify-content-center" style="border-radius:6px; color:#ef4444; background:#fef2f2; border:1px solid #fecaca; width:26px; height:26px;" onclick="alertaEliminar(${pr.id}, 'productos')" title="Eliminar"><i data-lucide="trash-2" style="width:12px;height:12px;"></i></button>
                    </div>
                </div>
            </div>`;
        });
        htmlList += `</div>`;
    }
    if(tbody) tbody.innerHTML = htmlList;
}
function filtrarPorGrupo(grupoId) {
    window.filtroGrupoCarta = grupoId;
    renderSubcategorias();
    lucide.createIcons();
}
function buscarItemCarta(val) {
    renderSubcategorias();
    lucide.createIcons();
}

document.addEventListener('DOMContentLoaded', () => {
    cargarCarta();
});

document.addEventListener('DOMContentLoaded', () => {
    cargarCarta();
});

