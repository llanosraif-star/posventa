<!--begin::App Content Header-->
<div class="app-content-header">
    <!--begin::Container-->
    <div class="container-fluid">
        <!--begin::Row-->
        <div class="row align-items-center">
            <div class="col-sm-6">
                <h4 class="mb-0 d-flex align-items-center text-dark" style="font-weight: 600; font-size: 22px;">
                    <i data-lucide="history" style="width:22px;height:22px;margin-right:8px; color: inherit;"></i> Historial de Ventas
                </h4>
            </div>
        </div>
        <!--end::Row-->
    </div>
    <!--end::Container-->
</div>
<!--end::App Content Header-->

<style>
    /* Efecto hover más gris para la tabla */
    .table-hover tbody tr:hover {
        background-color: #e2e8f0 !important;
        transition: background-color 0.2s ease;
    }
</style>

<div class="card mb-4 mx-3" style="border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.03) !important;">
    <div class="card-header py-3 d-flex flex-wrap justify-content-between align-items-center" style="border-radius: 12px 12px 0 0; gap: 10px;">
        <div class="d-flex flex-column">
            <h6 class="m-0 font-weight-bold d-flex align-items-center"><i data-lucide="list" style="width:16px;height:16px;margin-right:6px;"></i>Lista de Ventas</h6>
        </div>
        <!-- Filtros integrados en el header de la card -->
        <div class="d-flex flex-wrap align-items-center ms-auto" style="gap: 10px;">
            <div class="d-flex align-items-center gap-2">
                <label class="form-label mb-0" style="font-size: 0.85rem; font-weight: 600; color: #475569; white-space: nowrap;">Desde:</label>
                <input type="date" id="filtro-fecha-desde" class="form-control form-control-sm border" style="border-radius: 6px; width: 140px;">
            </div>
            <div class="d-flex align-items-center gap-2">
                <label class="form-label mb-0" style="font-size: 0.85rem; font-weight: 600; color: #475569; white-space: nowrap;">Hasta:</label>
                <input type="date" id="filtro-fecha-hasta" class="form-control form-control-sm border" style="border-radius: 6px; width: 140px;">
            </div>
            <div class="d-flex align-items-center gap-2">
                <select id="filtro-estado" class="form-select form-select-sm border" style="border-radius: 6px; width: 140px;">
                    <option value="">Todos los Estados</option>
                    <option value="pagado">Pagado</option>
                    <option value="pendiente">Pendiente</option>
                    <option value="cancelado">Cancelado</option>
                    <option value="en_preparacion">En Preparación</option>
                    <option value="listo">Listo</option>
                    <option value="entregado">Entregado</option>
                </select>
            </div>
            <button id="btn-filtrar-ventas" class="btn btn-primary btn-sm d-flex align-items-center" style="font-weight: 500; border-radius: 8px; padding: 0.25rem 0.75rem;">
                <i data-lucide="search" style="width:16px; height:16px; margin-right:4px;"></i> Filtrar
            </button>
        </div>
    </div>
    
    <div class="card-body p-0">
        <div class="table-responsive">
            <table id="tabla-ventas" class="table table-hover mb-0" style="font-size:0.85rem;">
                <thead style="border-bottom: 1px solid var(--bs-border-color);">
                    <tr>
                        <th class="border-0 pl-4 bg-body-secondary">Fecha</th>
                        <th class="border-0 bg-body-secondary">N° Pedido</th>
                        <th class="border-0 bg-body-secondary">Tipo</th>
                        <th class="border-0 bg-body-secondary">Cliente</th>
                        <th class="border-0 bg-body-secondary text-end">Total</th>
                        <th class="border-0 bg-body-secondary">Estado</th>
                        <th class="border-0 bg-body-secondary">Cajero</th>
                        <th class="border-0 text-center bg-body-secondary" style="width: 100px;">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Datos cargados por DataTables -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Detalles de Pedido -->
<div class="modal fade" id="modalDetallesVenta" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content" style="border-radius: 12px; border: none; box-shadow: 0 10px 25px rgba(0,0,0,0.1);">
            <div class="modal-header" style="background-color: #f8fafc; border-bottom: 1px solid #e2e8f0; border-radius: 12px 12px 0 0;">
                <h5 class="modal-title" style="font-weight: 600; color: #1e293b; display: flex; align-items: center; gap: 8px;">
                    <i data-lucide="shopping-cart" style="width: 20px; height: 20px; color: #3b82f6;"></i>
                    Detalle del Pedido <span id="lbl-detalle-pedido" class="text-primary ms-2"></span>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4">
                <div class="table-responsive">
                    <table class="table table-bordered mb-0" style="font-size: 0.9rem;">
                        <thead style="background-color: #f1f5f9;">
                            <tr>
                                <th style="width: 10%;">Cant</th>
                                <th>Subcategoria</th>
                                <th style="width: 15%; text-align: right;">Precio Unit.</th>
                                <th style="width: 15%; text-align: right;">Total</th>
                            </tr>
                        </thead>
                        <tbody id="lista-detalles-venta">
                            <!-- Items cargados por JS -->
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="3" class="text-end" style="font-size: 1.1rem;">TOTAL:</th>
                                <th class="text-end text-primary" style="font-size: 1.1rem;" id="lbl-total-venta">S/ 0.00</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            <div class="modal-footer" style="background-color: #f8fafc; border-top: 1px solid #e2e8f0; border-radius: 0 0 12px 12px;">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" style="border-radius: 8px;">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<script src="features/ventas/ventas.js?v=<?php echo time(); ?>"></script>
