<?php
session_start();
require_once __DIR__ . '/../../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

$action = $_GET['action'] ?? 'listar';
$db = Database::getInstance()->getConnection();

if ($action === 'listar') {
    $draw = isset($_POST['draw']) ? intval($_POST['draw']) : 1;
    $start = isset($_POST['start']) ? intval($_POST['start']) : 0;
    $length = isset($_POST['length']) ? intval($_POST['length']) : 10;
    $search = isset($_POST['search']['value']) ? $_POST['search']['value'] : '';
    
    $fechaInicioRaw = isset($_POST['fecha_inicio']) ? trim($_POST['fecha_inicio']) : '';
    $fechaFinRaw = isset($_POST['fecha_fin']) ? trim($_POST['fecha_fin']) : '';
    
    // Función para estandarizar a YYYY-MM-DD
    function estandarizarFecha($fecha) {
        if (empty($fecha)) return '';
        // Si ya está en formato YYYY-MM-DD
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha)) return $fecha;
        // Si viene con slashes DD/MM/YYYY
        if (strpos($fecha, '/') !== false) {
            $partes = explode('/', $fecha);
            if (count($partes) == 3) return $partes[2] . '-' . $partes[1] . '-' . $partes[0];
        }
        return date('Y-m-d', strtotime($fecha));
    }

    $fechaInicio = estandarizarFecha($fechaInicioRaw);
    $fechaFin = estandarizarFecha($fechaFinRaw);
    $estado = isset($_POST['estado_pedido']) ? $_POST['estado_pedido'] : '';

    $whereClause = "1=1";
    $params = [];

    if (!empty($search)) {
        $whereClause .= " AND (numero_pedido LIKE :search OR cliente_nombre LIKE :search OR cajero_nombre LIKE :search)";
        $params[':search'] = "%$search%";
    }

    if (!empty($fechaInicio) && !empty($fechaFin)) {
        $whereClause .= " AND DATE(created_at) BETWEEN :fecha_inicio AND :fecha_fin";
        $params[':fecha_inicio'] = $fechaInicio;
        $params[':fecha_fin'] = $fechaFin;
    }

    if (!empty($estado)) {
        $whereClause .= " AND estado_pedido = :estado";
        $params[':estado'] = $estado;
    }

    // Total de registros (sin filtros)
    $stmtTotal = $db->query("SELECT COUNT(id) FROM vista_historial_ventas");
    $recordsTotal = $stmtTotal->fetchColumn();

    // Total de registros (con filtros)
    $sqlFiltered = "SELECT COUNT(id) FROM vista_historial_ventas WHERE $whereClause";
    $stmtFiltered = $db->prepare($sqlFiltered);
    foreach ($params as $key => $val) {
        $stmtFiltered->bindValue($key, $val);
    }
    $stmtFiltered->execute();
    $recordsFiltered = $stmtFiltered->fetchColumn();

    // Obtener datos
    $sqlData = "SELECT * FROM vista_historial_ventas WHERE $whereClause ORDER BY created_at DESC LIMIT :start, :length";
    $stmtData = $db->prepare($sqlData);
    foreach ($params as $key => $val) {
        $stmtData->bindValue($key, $val);
    }
    $stmtData->bindValue(':start', $start, PDO::PARAM_INT);
    $stmtData->bindValue(':length', $length, PDO::PARAM_INT);
    $stmtData->execute();
    
    $data = $stmtData->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        "draw" => $draw,
        "recordsTotal" => intval($recordsTotal),
        "recordsFiltered" => intval($recordsFiltered),
        "data" => $data
    ]);
} elseif ($action === 'detalles') {
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    
    $stmt = $db->prepare("SELECT * FROM order_details WHERE order_id = ?");
    $stmt->execute([$id]);
    $detalles = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(["success" => true, "data" => $detalles]);
}
