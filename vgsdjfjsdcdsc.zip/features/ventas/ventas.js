$(function() {
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }

    // Ya no seteamos fechas por defecto para que muestre TODAS las ventas históricas 
    // tal como solicitó el usuario ("el administrador debe ver toda las ventas").
    $('#filtro-fecha-desde').val('');
    $('#filtro-fecha-hasta').val('');

    if ($.fn.DataTable.isDataTable('#tabla-ventas')) {
        $('#tabla-ventas').DataTable().destroy();
        $('#tabla-ventas').empty(); // Clear old DOM just in case
    }

    let tablaVentas = $('#tabla-ventas').DataTable({
        serverSide: true,
        processing: true,
        ajax: {
            url: 'features/ventas/controller_ventas.php?action=listar',
            type: 'POST',
            data: function(d) {
                d.fecha_inicio = $('#filtro-fecha-desde').val();
                d.fecha_fin = $('#filtro-fecha-hasta').val();
                d.estado_pedido = $('#filtro-estado').val();
            }
        },
        columns: [
            { 
                data: 'created_at',
                defaultContent: '-',
                render: function(data, type, row) {
                    if(!data) return '-';
                    // Reemplazar espacio por T para parseo seguro en todos los navegadores
                    let d = new Date(data.replace(' ', 'T'));
                    if (isNaN(d.getTime())) return data; // Si falla, retorna el original
                    return d.toLocaleDateString('es-PE') + ' ' + d.toLocaleTimeString('es-PE', {hour: '2-digit', minute:'2-digit'});
                }
            },
            { data: 'numero_pedido', defaultContent: '-', className: 'fw-bold text-dark' },
            { 
                data: 'tipo_pedido',
                defaultContent: '-',
                render: function(data) {
                    let map = {
                        'mesa': '<span class="badge bg-primary">Mesa</span>',
                        'llevar': '<span class="badge bg-info text-dark">Para Llevar</span>',
                        'delivery': '<span class="badge bg-warning text-dark">Delivery</span>'
                    };
                    return map[data] || data;
                }
            },
            { data: 'cliente_nombre', defaultContent: '-', render: function(data) { return data || '-'; } },
            { 
                data: 'total', 
                defaultContent: '0.00',
                className: 'text-end fw-bold text-primary',
                render: function(data) { return 'S/ ' + (parseFloat(data) || 0).toFixed(2); }
            },
            { 
                data: 'estado_pedido',
                defaultContent: '-',
                render: function(data) {
                    let map = {
                        'pagado': '<span class="badge bg-success">Pagado</span>',
                        'pendiente': '<span class="badge bg-secondary">Pendiente</span>',
                        'cancelado': '<span class="badge bg-danger">Cancelado</span>',
                        'en_preparacion': '<span class="badge bg-info text-dark">Preparación</span>',
                        'listo': '<span class="badge bg-primary">Listo</span>',
                        'entregado': '<span class="badge bg-success">Entregado</span>'
                    };
                    return map[data] || data;
                }
            },
            { data: 'cajero_nombre', defaultContent: '-', render: function(data) { return data || '-'; } },
            { 
                data: 'id', 
                className: 'text-center',
                orderable: false,
                render: function(data, type, row) {
                    return `
                        <button class="btn btn-sm btn-light border btn-ver-detalle" data-id="${data}" data-numero="${row.numero_pedido}" data-total="${row.total}" style="border-radius: 6px;" title="Ver Detalle">
                            <i data-lucide="eye" style="width:16px;height:16px; color:#475569;"></i>
                        </button>
                    `;
                }
            }
        ],
        order: [[0, 'desc']],
        language: {
            url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'
        },
        drawCallback: function() {
            if (typeof lucide !== 'undefined') {
                lucide.createIcons();
            }
        }
    });

    // Filtros manuales
    $('#btn-filtrar-ventas').on('click', function() {
        tablaVentas.ajax.reload();
    });

    // Ver Detalles
    $('#tabla-ventas tbody').on('click', '.btn-ver-detalle', function() {
        let id = $(this).data('id');
        let numero = $(this).data('numero');
        let total = $(this).data('total');

        $('#lbl-detalle-pedido').text(numero);
        $('#lbl-total-venta').text('S/ ' + parseFloat(total).toFixed(2));
        $('#lista-detalles-venta').html('<tr><td colspan="4" class="text-center py-4"><i data-lucide="loader-2" class="icon-spin"></i> Cargando...</td></tr>');
        if (typeof lucide !== 'undefined') lucide.createIcons();

        let modal = new bootstrap.Modal(document.getElementById('modalDetallesVenta'));
        modal.show();

        fetch(`features/ventas/controller_ventas.php?action=detalles&id=${id}`)
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    let html = '';
                    data.data.forEach(item => {
                        let rowTotal = parseFloat(item.quantity) * parseFloat(item.price);
                        html += `
                            <tr>
                                <td class="text-center">${parseFloat(item.quantity)}</td>
                                <td>${item.nombre_item || '-'}</td>
                                <td class="text-end">S/ ${parseFloat(item.price).toFixed(2)}</td>
                                <td class="text-end fw-bold">S/ ${rowTotal.toFixed(2)}</td>
                            </tr>
                        `;
                    });
                    $('#lista-detalles-venta').html(html);
                } else {
                    $('#lista-detalles-venta').html('<tr><td colspan="4" class="text-center text-danger">Error cargando detalles</td></tr>');
                }
            })
            .catch(err => {
                console.error(err);
                $('#lista-detalles-venta').html('<tr><td colspan="4" class="text-center text-danger">Error de conexión</td></tr>');
            });
    });
});
