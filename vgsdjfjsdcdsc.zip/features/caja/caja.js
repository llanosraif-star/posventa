/**
 * caja.js - Módulo de Caja
 * Apertura, cierre, historial y gestión de caja registradora
 */

// ==========================================
// MÓDULO DE CAJA
// ==========================================
window.cajaActual = null;
let cajaPedidosPaginaActual = 1;
let cajaPedidosDatos = [];

async function cargarCaja() {
    try {
        const res = await fetch('features/caja/controller_caja.php?action=estado&t=' + Date.now());
        const data = await res.json();
        if (data.status === 'ok') {
            window.cajaActual = data.caja;
            renderCajaEstado();
        }
    } catch(e) { console.error('Error cargando caja:', e); }
    lucide.createIcons();
}

function renderCajaEstado() {
    const c = document.getElementById('caja-estado-container');
    const panel = document.getElementById('caja-panel-principal');
    if (!c) return;

    if (!window.cajaActual) {
        if (panel) panel.classList.add('d-none');
        c.innerHTML = `
            <div class="card shadow-sm mb-4" style="border-radius:14px; border: 1px solid #e2e8f0;">
                <div class="card-body p-5 text-center">
                    <div class="rounded-circle mx-auto d-flex align-items-center justify-content-center mb-4" style="width:80px;height:80px;background:linear-gradient(135deg,#f0f9ff,#dbeafe);">
                        <i data-lucide="lock" style="width:36px;height:36px;color:#3b82f6;"></i>
                    </div>
                    <h4 class="font-weight-bold text-gray-800 mb-2">Caja Cerrada</h4>
                    <p class="text-muted mb-4">Para comenzar a registrar ventas, debe abrir la caja con un monto inicial.</p>
                    <button class="btn btn-theme-primary text-white px-5 py-2 font-weight-bold shadow" style="border-radius:10px;font-size:1rem;" onclick="cajaAbrir()">
                        <i data-lucide="unlock" style="width:18px;height:18px;margin-right:6px;"></i> Abrir Caja
                    </button>
                </div>
            </div>`;
    } else {
        let fecha = new Date(window.cajaActual.fecha_apertura).toLocaleString('es-PE', { hour:'2-digit', minute:'2-digit', day:'2-digit', month:'short' });
        let cajero = (window.cajaActual.cajero_nombre || '') + ' ' + (window.cajaActual.cajero_apellido || '');
        c.innerHTML = `
            <div class="card shadow-sm mb-4" style="border-radius:14px; border: 1px solid #e2e8f0; border-left: 5px solid #22c55e !important;">
                <div class="card-body py-3 px-4 d-flex justify-content-between align-items-center flex-wrap" style="gap:12px;">
                    <div class="d-flex align-items-center" style="gap:14px;">
                        <div class="rounded-circle d-flex align-items-center justify-content-center" style="width:46px;height:46px;background:#dcfce7;flex-shrink:0;">
                            <i data-lucide="check-circle" style="width:22px;height:22px;color:#22c55e;"></i>
                        </div>
                        <div>
                            <div class="font-weight-bold text-dark" style="font-size:1.05rem;">Caja Abierta <span class="badge bg-success text-white ml-2" style="border-radius:6px;">Activa</span></div>
                            <div class="text-muted" style="font-size:0.8rem;">Cajero: <b>${cajero}</b> · Apertura: <b>${fecha}</b></div>
                        </div>
                    </div>
                    <button class="btn btn-outline-danger font-weight-bold px-4" style="border-radius:8px;" onclick="cajaCerrar()">
                        <i data-lucide="lock" style="width:16px;height:16px;margin-right:4px;"></i> Cerrar Caja
                    </button>
                </div>
            </div>`;
        if (panel) panel.classList.remove('d-none');
        cajaActualizarStats();
        cajaCargarPedidos();
    }
    lucide.createIcons();
}

function cajaActualizarStats() {
    if (!window.cajaActual || !window.cajaActual.stats) return;
    let s = window.cajaActual.stats;
    let mApertura = parseFloat(window.cajaActual.monto_apertura);
    let tEfectivo = parseFloat(s.total_efectivo || 0);
    document.getElementById('caja-stat-ventas').innerText = 'S/ ' + parseFloat(s.total_ventas || 0).toFixed(2);
    document.getElementById('caja-stat-pedidos').innerText = s.total_pedidos || 0;
    document.getElementById('caja-stat-efectivo').innerText = 'S/ ' + (mApertura + tEfectivo).toFixed(2);
    document.getElementById('caja-stat-apertura').innerText = 'S/ ' + mApertura.toFixed(2);
    document.getElementById('caja-desglose-efectivo').innerText = 'S/ ' + tEfectivo.toFixed(2);
    document.getElementById('caja-desglose-yape').innerText = 'S/ ' + parseFloat(s.total_yape || 0).toFixed(2);
    document.getElementById('caja-desglose-tarjeta').innerText = 'S/ ' + parseFloat(s.total_tarjeta || 0).toFixed(2);
}

async function cajaCargarPedidos() {
    if (!window.cajaActual) return;
    try {
        const res = await fetch('features/caja/controller_caja.php?action=pedidos&id_caja=' + window.cajaActual.id);
        const data = await res.json();
        let tbody = document.getElementById('caja-pedidos-tbody');
        if (!tbody) return;
        
        if (!data.data || data.data.length === 0) { 
            cajaPedidosDatos = [];
            renderCajaPedidosPaginados();
            return; 
        }
        
        cajaPedidosDatos = data.data;
        // Aseguramos que siempre esté ordenado por ID (o número de pedido) descendente
        cajaPedidosDatos.sort((a, b) => b.id - a.id);

        cajaPedidosPaginaActual = 1;
        renderCajaPedidosPaginados();
    } catch(e) { console.error(e); }
}

function cambiarPaginaCajaPedidos(accion) {
    let perPageSelect = document.getElementById('caja-pedidos-per-page');
    let perPage = perPageSelect ? parseInt(perPageSelect.value) : 5;
    let totalPaginas = Math.ceil(cajaPedidosDatos.length / perPage);
    
    if (accion === 'prev') {
        if (cajaPedidosPaginaActual > 1) cajaPedidosPaginaActual--;
    } else if (accion === 'next') {
        if (cajaPedidosPaginaActual < totalPaginas) cajaPedidosPaginaActual++;
    } else if (typeof accion === 'number') {
        cajaPedidosPaginaActual = accion;
    }
    renderCajaPedidosPaginados();
}

function renderCajaPedidosPaginados() {
    let tbody = document.getElementById('caja-pedidos-tbody');
    let info = document.getElementById('caja-pedidos-info-paginacion');
    let pagesContainer = document.getElementById('caja-pedidos-paginas-container');
    let perPageSelect = document.getElementById('caja-pedidos-per-page');
    let btnPrev = document.getElementById('btn-prev-caja-pedidos');
    let btnNext = document.getElementById('btn-next-caja-pedidos');
    
    if (!tbody) return;
    
    let html = '';
    let perPage = perPageSelect ? parseInt(perPageSelect.value) : 5;
    
    let total = cajaPedidosDatos.length;
    let totalPaginas = Math.ceil(total / perPage);
    if (totalPaginas === 0) totalPaginas = 1;
    
    if (cajaPedidosPaginaActual > totalPaginas) cajaPedidosPaginaActual = totalPaginas;
    
    let inicio = (cajaPedidosPaginaActual - 1) * perPage;
    let fin = Math.min(inicio + perPage, total);
    
    if (total === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted py-4">Sin pedidos registrados en este turno</td></tr>';
        if (info) info.innerText = 'Mostrando 0 a 0 de 0 entradas';
    } else {
        let mostrar = cajaPedidosDatos.slice(inicio, fin);
        tbody.innerHTML = mostrar.map((p, index) => {
            let metBadge = p.metodo_pago === 'efectivo' ? 'bg-success' : p.metodo_pago === 'transferencia' ? 'bg-purple' : 'bg-primary';
            let metLbl = p.metodo_pago === 'efectivo' ? 'Efectivo' : p.metodo_pago === 'transferencia' ? 'Yape' : 'Tarjeta';
            // Colores del badge vienen directamente de la tabla tipo_orden en la BD
            let tipoBg     = p.badge_bg     || '#f3f4f6';
            let tipoColor  = p.badge_color  || '#4b5563';
            let tipoBorder = p.badge_border || '#d1d5db';
            let tipoLabel  = p.tipo_pedido  || '-';
            let tipoBadgeHtml = `<span class="badge px-2 py-1 font-weight-bold" style="border-radius:20px; font-size:0.75rem; background-color:${tipoBg}; color:${tipoColor}; border:1px solid ${tipoBorder};">${tipoLabel}</span>`;
            
            let hora = new Date(p.created_at).toLocaleTimeString('es-PE', { hour:'2-digit', minute:'2-digit' });

            let estadoBadge = '';
            // Badge de estado de pago
            let pagoBadge = '';
            if (p.estado_pago === 'pagado') pagoBadge = '<span class="badge bg-success text-white px-2 py-1" style="border-radius:6px;">Pagado</span>';
            else pagoBadge = '<span class="badge bg-secondary text-white px-2 py-1" style="border-radius:6px;">Pendiente</span>';
            
            // Badge de estado de pedido
            if (p.estado_pedido === 'completado') estadoBadge = '<span class="badge bg-success text-white px-2 py-1" style="border-radius:6px;">Completado</span>';
            else if (p.estado_pedido === 'listo') estadoBadge = '<span class="badge bg-info text-white px-2 py-1" style="border-radius:6px;">Listo</span>';
            else if (p.estado_pedido === 'en_camino') estadoBadge = '<span class="badge bg-primary text-white px-2 py-1" style="border-radius:6px;">En camino</span>';
            else if (p.estado_pedido === 'pendiente') estadoBadge = '<span class="badge bg-warning text-dark px-2 py-1" style="border-radius:6px;">Pendiente</span>';
            else if (p.estado_pedido === 'anulado') estadoBadge = '<span class="badge bg-danger text-white px-2 py-1" style="border-radius:6px;">Anulado</span>';
            else estadoBadge = `<span class="badge bg-light text-dark px-2 py-1" style="border-radius:6px;">${p.estado_pedido}</span>`;

            let cajeroStr = '-';
            if (p.cajero_nombre) cajeroStr = p.cajero_nombre + (p.cajero_apellido ? ' ' + p.cajero_apellido : '');

            return `<tr>
                <td class="pl-4 font-weight-bold">${p.numero_pedido}</td>
                <td>${tipoBadgeHtml}</td>
                <td>${p.cliente_nombre || '-'}</td>
                <td><span class="badge ${metBadge} text-white px-2 py-1" style="border-radius:6px;">${metLbl}</span></td>
                <td>${estadoBadge}</td>
                <td class="font-weight-bold">S/ ${parseFloat(p.total).toFixed(2)}</td>
                <td class="text-muted text-capitalize">${cajeroStr}</td>
                <td class="text-muted">${hora}</td>
                <td class="text-center">
                    <div class="d-flex justify-content-center align-items-center" style="gap: 4px;">
                        <button class="btn btn-sm btn-outline-danger px-2 py-1 fw-bold" onclick="cajaVerTicket(${p.id})" style="font-size: 0.75rem; border-radius: 4px;" title="Ver Ticket Interno">
                            <i data-lucide="file-text" style="width:12px;height:12px;margin-right:3px;margin-bottom:1px;"></i>TICKET
                        </button>
                        <div class="dropdown">
                            <button class="btn btn-sm btn-light border" type="button" data-bs-toggle="dropdown" aria-expanded="false" style="padding: 0.15rem 0.35rem; background: #f8fafc; border-color: #cbd5e1 !important; border-radius: 4px;">
                                <i data-lucide="more-vertical" style="width:14px;height:14px;color:#64748b;display:block;"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end shadow-sm" style="border-radius: 8px; font-size: 0.85rem; border-color: #e2e8f0;">
                                <li><a class="dropdown-item d-flex align-items-center py-2" href="#" onclick="event.preventDefault(); cajaEmitirBoleta(${p.id})"><i data-lucide="receipt" style="width:14px;height:14px;margin-right:8px;color:#3b82f6;"></i> Emitir Boleta</a></li>
                                <li><a class="dropdown-item d-flex align-items-center py-2" href="#" onclick="event.preventDefault(); cajaEmitirFactura(${p.id})"><i data-lucide="file-check-2" style="width:14px;height:14px;margin-right:8px;color:#8b5cf6;"></i> Emitir Factura</a></li>
                                <li><hr class="dropdown-divider my-1"></li>
                                <li><a class="dropdown-item d-flex align-items-center py-2 text-dark" href="#" onclick="event.preventDefault(); cajaVerDetallePedido(${p.id})"><i data-lucide="history" style="width:14px;height:14px;margin-right:8px;color:#475569;"></i> Historial de Pedido</a></li>
                            </ul>
                        </div>
                    </div>
                </td>
            </tr>`;
        }).join('');
        if (info) info.innerText = `Mostrando ${inicio + 1} a ${fin} de ${total} entradas`;
    }
    
    if (pagesContainer) {
        let btns = '';
        
        let addPageBtn = (page) => {
            let active = (page === cajaPedidosPaginaActual) ? 'btn-primary text-white border-primary' : 'btn-light border bg-white text-dark';
            btns += `<button class="btn btn-sm ${active}" style="border-radius:6px; min-width:32px; font-weight:500;" onclick="cambiarPaginaCajaPedidos(${page})">${page}</button>`;
        };

        let addEllipsis = () => {
            btns += `<span class="px-1 py-1 text-muted" style="align-self: flex-end;">...</span>`;
        };

        if (totalPaginas <= 7) {
            for (let i = 1; i <= totalPaginas; i++) {
                addPageBtn(i);
            }
        } else {
            if (cajaPedidosPaginaActual <= 4) {
                for (let i = 1; i <= 5; i++) addPageBtn(i);
                addEllipsis();
                addPageBtn(totalPaginas);
            } else if (cajaPedidosPaginaActual >= totalPaginas - 3) {
                addPageBtn(1);
                addEllipsis();
                for (let i = totalPaginas - 4; i <= totalPaginas; i++) addPageBtn(i);
            } else {
                addPageBtn(1);
                addEllipsis();
                addPageBtn(cajaPedidosPaginaActual - 1);
                addPageBtn(cajaPedidosPaginaActual);
                addPageBtn(cajaPedidosPaginaActual + 1);
                addEllipsis();
                addPageBtn(totalPaginas);
            }
        }
        
        pagesContainer.innerHTML = btns;
    }
    
    if (btnPrev) {
        btnPrev.disabled = (cajaPedidosPaginaActual === 1);
        btnPrev.style.borderRadius = '6px';
        btnPrev.style.fontWeight = '500';
    }
    if (btnNext) {
        btnNext.disabled = (cajaPedidosPaginaActual === totalPaginas);
        btnNext.style.borderRadius = '6px';
        btnNext.style.fontWeight = '500';
    }
    if (typeof lucide !== 'undefined') lucide.createIcons();
}

function cajaAbrir() {
    Swal.fire({
        title: 'Abrir Caja',
        html: `
            <div class="text-left mt-2">
                <label class="font-weight-bold text-muted" style="font-size:0.85rem;">Monto Inicial (S/)</label>
                <input id="swal-caja-monto" type="number" class="form-control mb-3" placeholder="0.00" min="0" step="0.01" value="100.00" style="border-radius:8px;font-size:1.1rem;font-weight:bold;">
                <label class="font-weight-bold text-muted" style="font-size:0.85rem;">Observaciones (opcional)</label>
                <textarea id="swal-caja-obs" class="form-control" rows="2" placeholder="Notas..." style="border-radius:8px;"></textarea>
            </div>`,
        confirmButtonText: 'Aceptar',
        showCancelButton: true, cancelButtonText: 'Cancelar',
        confirmButtonColor: '#22c55e',
        preConfirm: () => {
            let m = parseFloat(document.getElementById('swal-caja-monto').value);
            if (isNaN(m) || m < 0) { Swal.showValidationMessage('Monto inválido'); return false; }
            return { monto: m };
        }
    }).then(async (r) => {
        if (!r.isConfirmed) return;
        try {
            const res = await fetch('features/caja/controller_caja.php?action=abrir', {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ monto_apertura: r.value.monto, id_usuario: 1 })
            });
            const data = await res.json();
            if (data.status === 'ok') { mostrarAlerta('success', 'Caja abierta'); cargarCaja(); }
            else mostrarAlerta('error', data.message);
        } catch(e) { mostrarAlerta('error', 'Error de conexión'); }
    });
}

function cajaCerrar() {
    if (!window.cajaActual) return;
    let mApertura = parseFloat(window.cajaActual.monto_apertura);
    let tEfectivo = parseFloat(window.cajaActual.stats?.total_efectivo || 0);
    let esperado = mApertura + tEfectivo;

    Swal.fire({
        title: 'Cerrar Caja',
        html: `
            <div class="text-left mt-2" style="font-size:0.9rem;">
                <div class="p-3 rounded mb-3" style="background:#f8fafc;">
                    <div class="d-flex justify-content-between mb-1"><span class="text-muted">Apertura:</span><b>S/ ${mApertura.toFixed(2)}</b></div>
                    <div class="d-flex justify-content-between mb-1"><span class="text-muted">Efectivo ventas:</span><b>S/ ${tEfectivo.toFixed(2)}</b></div>
                    <hr class="my-2"><div class="d-flex justify-content-between"><span class="font-weight-bold">Esperado en caja:</span><b class="text-theme-primary" style="font-size:1.1rem;">S/ ${esperado.toFixed(2)}</b></div>
                </div>
                <label class="font-weight-bold text-muted" style="font-size:0.85rem;">Monto Físico Contado (S/)</label>
                <input id="swal-cierre-monto" type="number" class="form-control mb-2" placeholder="0.00" min="0" step="0.01" value="${esperado.toFixed(2)}" style="border-radius:8px;font-size:1.1rem;font-weight:bold;" oninput="cajaCierreDiff(${esperado})">
                <div class="d-flex justify-content-between p-2 rounded" style="background:#fff7ed;">
                    <span class="font-weight-bold text-muted">Diferencia:</span>
                    <span class="font-weight-bold" id="swal-cierre-diff" style="font-size:1rem;">S/ 0.00</span>
                </div>
            </div>`,
        confirmButtonText: 'Aceptar', showCancelButton: true, cancelButtonText: 'Cancelar',
        confirmButtonColor: '#e11d48',
        preConfirm: () => {
            let m = parseFloat(document.getElementById('swal-cierre-monto').value);
            if (isNaN(m) || m < 0) { Swal.showValidationMessage('Monto inválido'); return false; }
            return { monto_cierre: m };
        }
    }).then(async (r) => {
        if (!r.isConfirmed) return;
        try {
            const res = await fetch('features/caja/controller_caja.php?action=cerrar', {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ monto_cierre: r.value.monto_cierre })
            });
            const data = await res.json();
            if (data.status === 'ok') {
                let rs = data.resumen;
                let diffColor = rs.diferencia >= 0 ? '#22c55e' : '#e11d48';
                Swal.fire({
                    title: 'Caja Cerrada',
                    html: `<div class="text-left" style="font-size:0.9rem;">
                        <div class="d-flex justify-content-between mb-1"><span>Pedidos:</span><b>${rs.total_pedidos}</b></div>
                        <div class="d-flex justify-content-between mb-1"><span>Total Ventas:</span><b>S/ ${parseFloat(rs.total_ventas).toFixed(2)}</b></div>
                        <hr class="my-2">
                        <div class="d-flex justify-content-between mb-1"><span>Efectivo:</span><b>S/ ${parseFloat(rs.total_efectivo).toFixed(2)}</b></div>
                        <div class="d-flex justify-content-between mb-1"><span>Yape:</span><b>S/ ${parseFloat(rs.total_yape).toFixed(2)}</b></div>
                        <div class="d-flex justify-content-between mb-1"><span>Tarjeta:</span><b>S/ ${parseFloat(rs.total_tarjeta).toFixed(2)}</b></div>
                        <hr class="my-2">
                        <div class="d-flex justify-content-between"><span class="font-weight-bold">Diferencia:</span><b style="color:${diffColor};font-size:1.1rem;">S/ ${parseFloat(rs.diferencia).toFixed(2)}</b></div>
                    </div>`, icon: 'info', confirmButtonColor: '#188df1'
                });
                cargarCaja();
            } else mostrarAlerta('error', data.message);
        } catch(e) { mostrarAlerta('error', 'Error de conexión'); }
    });
}

function cajaCierreDiff(esperado) {
    let m = parseFloat(document.getElementById('swal-cierre-monto')?.value || 0);
    let d = document.getElementById('swal-cierre-diff');
    let diff = m - esperado;
    if (d) { d.innerText = 'S/ ' + diff.toFixed(2); d.style.color = diff >= 0 ? '#22c55e' : '#e11d48'; }
}

async function cajaRefrescar() { await cargarCaja(); mostrarAlerta('success', 'Datos actualizados'); }

async function cajaVerHistorial() {
    try {
        const res = await fetch('features/caja/controller_caja.php?action=historial');
        const data = await res.json();
        if (!data.data || data.data.length === 0) { mostrarAlerta('info', 'No hay registros de caja'); return; }
        let rows = data.data.map(c => {
            let estado = c.estado_caja === 'abierta' ? '<span class="badge bg-success text-white">Abierta</span>' : '<span class="badge bg-secondary text-white">Cerrada</span>';
            let f = new Date(c.fecha_apertura).toLocaleDateString('es-PE', { day:'2-digit', month:'short', year:'numeric' });
            return `<tr><td>${f}</td><td>S/ ${parseFloat(c.monto_apertura).toFixed(2)}</td><td>S/ ${parseFloat(c.total_ventas||0).toFixed(2)}</td><td>S/ ${parseFloat(c.diferencia||0).toFixed(2)}</td><td>${estado}</td></tr>`;
        }).join('');
        Swal.fire({
            title: 'Historial de Cajas', width: 650,
            html: `<div class="table-responsive"><table class="table table-sm text-left" style="font-size:0.85rem;"><thead class="bg-light"><tr><th>Fecha</th><th>Apertura</th><th>Ventas</th><th>Diferencia</th><th>Estado</th></tr></thead><tbody>${rows}</tbody></table></div>`,
            confirmButtonColor: '#188df1'
        });
    } catch(e) { mostrarAlerta('error', 'Error cargando historial'); }
}

async function cajaVerTicket(id_orden) {
    try {
        Swal.fire({title: 'Generando ticket...', allowOutsideClick: false, didOpen: () => { Swal.showLoading(); }});
        const res = await fetch('features/caja/controller_caja.php?action=detalle_orden&id=' + id_orden);
        const data = await res.json();
        Swal.close();
        if (data.status === 'ok') {
            let p = data.pedido;
            let items = data.items;
            
            let titulo = p.estado_pago === 'pagado' ? 'NOTA DE VENTA' : 'COMANDA / PRECUENTA';
            let extra = p.estado_pago === 'pagado' ? '*** GRACIAS POR SU COMPRA ***' : '*** NO ES COMPROBANTE DE PAGO ***';
            
            cajaImprimirTicketModal(titulo, p.numero_pedido, p.cliente_nombre || '-', items, parseFloat(p.total), p.tipo_pedido, extra, p.cajero_nombre);
        } else {
            mostrarAlerta('error', data.message || 'Error cargando detalle');
        }
    } catch(e) {
        console.error("Error en cajaVerTicket:", e);
        Swal.close();
        mostrarAlerta('error', 'Error: ' + (e.message || e));
    }
}

function numeroALetrasCaja(num) {
    const unidades = ['','UNO','DOS','TRES','CUATRO','CINCO','SEIS','SIETE','OCHO','NUEVE'];
    const decenas = ['','DIEZ','VEINTE','TREINTA','CUARENTA','CINCUENTA','SESENTA','SETENTA','OCHENTA','NOVENTA'];
    const especiales = {11:'ONCE',12:'DOCE',13:'TRECE',14:'CATORCE',15:'QUINCE',16:'DIECISEIS',17:'DIECISIETE',18:'DIECIOCHO',19:'DIECINUEVE'};
    const centenas = ['','CIENTO','DOSCIENTOS','TRESCIENTOS','CUATROCIENTOS','QUINIENTOS','SEISCIENTOS','SETECIENTOS','OCHOCIENTOS','NOVECIENTOS'];
    
    let entero = Math.floor(num);
    let decimales = Math.round((num - entero) * 100);
    
    function convertir(n) {
        if (n === 0) return 'CERO';
        if (n === 100) return 'CIEN';
        let str = '';
        if (n >= 100) { str += centenas[Math.floor(n/100)] + ' '; n %= 100; }
        if (n >= 11 && n <= 19) { str += especiales[n]; return str; }
        if (n >= 10) { 
            let d = Math.floor(n/10); 
            let u = n % 10;
            if (d === 2 && u > 0) { str += 'VEINTI' + unidades[u]; return str; }
            str += decenas[d]; 
            if (u > 0) str += ' Y ' + unidades[u];
            return str;
        }
        if (n > 0) { str += unidades[n]; }
        return str.trim();
    }
    
    let strEntero = '';
    if (entero >= 1000) {
        let miles = Math.floor(entero/1000);
        if (miles === 1) strEntero += 'MIL ';
        else strEntero += convertir(miles) + ' MIL ';
        entero %= 1000;
    }
    if (entero > 0 || strEntero === '') {
        strEntero += convertir(entero);
    }
    
    let strDec = decimales.toString().padStart(2, '0') + '/100 SOLES';
    return `SON: ${strEntero.trim()} CON ${strDec}`;
}

function padRCaja(str, len) { return (str.toString() || '').substring(0, len).padEnd(len, ' '); }
function padLCaja(str, len) { return (str.toString() || '').substring(0, len).padStart(len, ' '); }

function cajaImprimirTicketModal(titulo, numero, cliente, items, total, tipo, extra, cajero_nombre = null) {
    let dateStr = new Date().toLocaleString('es-PE', {day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit', hour12:true});
    let cajero = cajero_nombre || (typeof cajaCajeroActual !== 'undefined' ? cajaCajeroActual : '--');

    let itemsHtml = items.map(i => `
        <tr>
            <td style="text-align: left; vertical-align: top; padding: 2px 0;">${i.cantidad}</td>
            <td style="text-align: left; vertical-align: top; padding: 2px 4px;">${i.subcategoria_nombre || i.nombre || ''}</td>
            <td style="text-align: right; vertical-align: top; padding: 2px 0;">${parseFloat(i.precio).toFixed(2)}</td>
            <td style="text-align: right; vertical-align: top; padding: 2px 0;">${(i.cantidad * parseFloat(i.precio)).toFixed(2)}</td>
        </tr>
    `).join('');

    let htmlContent = `
        <div style="width: 100%; padding: 4mm; font-family: 'Courier New', Courier, monospace; font-size: 12px; color: #000; box-sizing: border-box; background: #fff; margin: 0 auto; line-height: 1.2;">
            <div style="text-align: center; margin-bottom: 5px;">
                Pizeria sac.<br>
                JR. JUAN VALER SANDOVAL Nº 682<br>
                RUC:20615656888
            </div>
            
            <div style="border-bottom: 1px dashed #000; margin-bottom: 2px;"></div>
            <div style="border-bottom: 3px double #000; margin-bottom: 5px;"></div>
            
            <div style="text-align: center; font-weight: bold; margin-bottom: 5px; font-size: 14px;">
                NOTA DE VENTA<br>
                Nº ${numero}
            </div>
            
            <div style="border-bottom: 3px double #000; margin-bottom: 5px;"></div>
            
            <table style="width: 100%; font-size: 12px; font-family: 'Courier New', Courier, monospace; margin-bottom: 5px; border-collapse: collapse;">
                <tr><td style="width: 75px; vertical-align: top;">FECHA</td><td style="vertical-align: top;">: ${dateStr}</td></tr>
                <tr><td style="vertical-align: top;">SEÑOR(ES)</td><td style="vertical-align: top;">: ${cliente || '--'}</td></tr>
                <tr><td style="vertical-align: top;">TIPO</td><td style="vertical-align: top;">: ${tipo || 'MESA'}</td></tr>
                <tr><td style="vertical-align: top;">CAJERO</td><td style="vertical-align: top;">: ${cajero || '--'}</td></tr>
            </table>
            
            <div style="border-bottom: 1px dashed #000; margin-bottom: 5px;"></div>
            
            <table style="width: 100%; font-size: 12px; font-family: 'Courier New', Courier, monospace; border-collapse: collapse;">
                <tr>
                    <th style="text-align: left; width: 15%; padding-bottom: 3px;">CANT</th>
                    <th style="text-align: left; width: 45%; padding-bottom: 3px;">DESCRIPCIÓN</th>
                    <th style="text-align: right; width: 20%; padding-bottom: 3px;">PU</th>
                    <th style="text-align: right; width: 20%; padding-bottom: 3px;">TOTAL</th>
                </tr>
                <tr><td colspan="4"><div style="border-bottom: 1px dashed #000; margin-bottom: 3px;"></div></td></tr>
                ${itemsHtml}
                <tr><td colspan="4"><div style="border-bottom: 1px dashed #000; margin-top: 3px; margin-bottom: 3px;"></div></td></tr>
            </table>
            
            <table style="width: 100%; font-size: 12px; font-family: 'Courier New', Courier, monospace; margin-bottom: 5px; border-collapse: collapse;">
                <tr>
                    <td style="text-align: right;">DESCUENTO</td>
                    <td style="text-align: right; width: 30%;">0.00</td>
                </tr>
                <tr><td colspan="2"><div style="border-bottom: 3px double #000; margin: 3px 0;"></div></td></tr>
                <tr>
                    <td style="text-align: left; font-size: 13px;"><strong>IMPORTE TOTAL</strong></td>
                    <td style="text-align: right; font-size: 13px;"><strong>S/. ${parseFloat(total).toFixed(2)}</strong></td>
                </tr>
                <tr><td colspan="2"><div style="border-bottom: 3px double #000; margin: 3px 0;"></div></td></tr>
            </table>
            
            <div style="margin-bottom: 5px;">
                SON: ${numeroALetrasCaja(total)}
            </div>
            
            <div style="border-bottom: 1px dashed #000; margin-bottom: 5px;"></div>
            
            <div style="text-align: center; margin-top: 5px; font-weight: bold;">
                *** GRACIAS POR SU COMPRA ***<br>
                ${extra ? extra : ''}
            </div>
        </div>
    `;

    Swal.fire({title: 'Generando PDF...', allowOutsideClick: false, didOpen: () => { Swal.showLoading(); }});

    if (typeof html2pdf === 'undefined') {
        Swal.close();
        mostrarAlerta('error', 'La librería PDF no se cargó. Recarga la página.');
        return;
    }

    let tempElement = document.createElement('div');
    tempElement.innerHTML = htmlContent;

    let opt = {
        margin: 0,
        filename: numero + '.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'mm', format: [80, 250], orientation: 'portrait' }
    };

    html2pdf().set(opt).from(tempElement).output('blob').then(function(pdfBlob) {
        let pdfUrl = URL.createObjectURL(pdfBlob);
        Swal.fire({
            title: `<div style="font-size: 1.15rem; color: #1f2937; margin-bottom: -10px;">${titulo} - ${numero}</div>`,
            html: `
                <div style="height: 50vh; background: #525659; border-radius: 6px; padding: 4px; box-sizing: border-box; margin-bottom: 15px; margin-top: 15px;">
                     <iframe id="ticket-pdf-iframe" src="${pdfUrl}" style="width: 100%; height: 100%; border: none; border-radius: 4px; background: white;"></iframe>
                </div>
                <div style="display: flex; gap: 8px; justify-content: flex-start; align-items: center; border-top: 1px solid #e5e7eb; padding-top: 15px;">
                    <button id="btn-print-pdf" class="btn text-white" style="background-color: #f97316; border-color: #f97316; padding: 6px 14px; font-weight: 500; border-radius: 6px; font-size: 14px; display: flex; align-items: center; gap: 5px;">
                        <i data-lucide="printer" style="width:16px;height:16px;"></i> Imprimir
                    </button>
                    <button id="btn-download-pdf" class="btn btn-light border" style="padding: 6px 14px; font-weight: 500; border-radius: 6px; font-size: 14px; color: #4b5563; display: flex; align-items: center; gap: 5px;">
                        <i data-lucide="download" style="width:16px;height:16px;"></i> Descargar
                    </button>
                    <button id="btn-close-pdf" class="btn btn-light border" style="padding: 6px 14px; font-weight: 500; border-radius: 6px; font-size: 14px; color: #4b5563; margin-left: auto;">
                        Cerrar
                    </button>
                </div>
            `,
            width: 480,
            showConfirmButton: false,
            showCloseButton: false,
            padding: '1.25em',
            didOpen: () => { 
                if (typeof lucide !== 'undefined') lucide.createIcons(); 
                document.getElementById('btn-print-pdf').addEventListener('click', () => {
                    let iframe = document.getElementById('ticket-pdf-iframe');
                    if (iframe) { iframe.contentWindow.print(); }
                });
                document.getElementById('btn-download-pdf').addEventListener('click', () => {
                    let a = document.createElement('a');
                    a.href = pdfUrl;
                    a.download = numero + '.pdf';
                    a.click();
                });
                document.getElementById('btn-close-pdf').addEventListener('click', () => {
                    Swal.close();
                });
            }
        });
    });
}

// ==========================================
// FUNCIONES DEL MENÚ DE HISTORIAL (3 PUNTOS)
// ==========================================
window.cajaEmitirBoleta = function(id_orden) {
    cajaEmitirComprobanteManual(id_orden, 'boleta');
};

window.cajaEmitirFactura = function(id_orden) {
    cajaEmitirComprobanteManual(id_orden, 'factura');
};

window.cajaVerDetallePedido = function(id_orden) {
    // Para el detalle, reutilizamos la generación del ticket interno por ahora
    cajaVerTicket(id_orden);
};

async function cajaEmitirComprobanteManual(id_orden, tipo_comprobante) {
    if(typeof window.posAbrirModalCobro !== 'function') {
        return mostrarAlerta('error', 'Módulo de POS no disponible');
    }

    try {
        Swal.fire({title: 'Cargando orden...', allowOutsideClick: false, didOpen: () => { Swal.showLoading(); }});
        
        // Obtener detalles del pedido desde la BD local
        const resPed = await fetch('features/caja/controller_caja.php?action=detalle_orden&id=' + id_orden);
        const dataPed = await resPed.json();
        
        Swal.close();
        
        if (dataPed.status !== 'ok') {
            return mostrarAlerta('error', 'Error al cargar pedido para emitir comprobante');
        }
        
        let p = dataPed.pedido;
        let items = dataPed.items;
        let finalTotal = parseFloat(p.total);

        // Preparamos config para el modal de cobro (existente)
        let config = {
            items: items.map(x => ({ 
                id: x.id_subcategoria || x.product_id, 
                nombre: x.nombre_item || x.subcategoria_nombre || 'Subcategoria', 
                cantidad: parseFloat(x.cantidad), 
                precio: parseFloat(x.precio), 
                subtotal: parseFloat(x.subtotal) 
            })),
            tipoPedidoDB: p.tipo_pedido || 'salon',
            cliente: p.cliente_nombre || '',
            idMesa: p.table_id || null,
            orderId: id_orden,
            isExistente: true,
            completarAuto: false,
            total: finalTotal,
            lbl: 'Orden ' + p.numero_pedido
        };
        
        posAbrirModalCobro(config);
        
        // Pre-seleccionar el tipo de comprobante en el modal de cobro (esperar a que el modal renderice)
        setTimeout(() => {
            if (typeof posModalCobroSeleccionarComprobante === 'function') {
                posModalCobroSeleccionarComprobante(tipo_comprobante);
            }
        }, 150);

    } catch(e) {
        Swal.close();
        mostrarAlerta('error', 'Error conectando con la orden');
    }
}

