<?php
require_once __DIR__ . '/../../config/database.php';

class ModelCaja {
    public static function getDB() {
        return Database::getInstance()->getConnection();
    }

    public static function getCajaAbierta() {
        $db = self::getDB();
        $stmt = $db->query("SELECT c.*, u.nombre as cajero_nombre, u.apellido as cajero_apellido 
                            FROM caja c 
                            LEFT JOIN usuarios u ON c.id_usuario = u.id 
                            WHERE c.estado_caja = 'abierta' 
                            ORDER BY c.id DESC LIMIT 1");
        return $stmt->fetch();
    }

    public static function getStatsCaja($id_caja) {
        $db = self::getDB();
        $stmtP = $db->prepare("SELECT COUNT(*) as total_pedidos, 
                                COALESCE(SUM(total_amount), 0) as total_ventas,
                                COALESCE(SUM(CASE WHEN payment_method = 'efectivo' THEN total_amount ELSE 0 END), 0) as total_efectivo,
                                COALESCE(SUM(CASE WHEN payment_method = 'transferencia' THEN total_amount ELSE 0 END), 0) as total_yape,
                                COALESCE(SUM(CASE WHEN payment_method = 'tarjeta' THEN total_amount ELSE 0 END), 0) as total_tarjeta
                                FROM orders WHERE id_caja = ? AND estado_pedido != 'anulado'");
        $stmtP->execute([$id_caja]);
        return $stmtP->fetch();
    }

    public static function abrirCaja($id_usuario, $monto) {
        $db = self::getDB();
        $stmt = $db->prepare("INSERT INTO caja (id_usuario, monto_apertura, estado_caja, fecha_apertura) VALUES (?, ?, 'abierta', NOW())");
        $stmt->execute([$id_usuario, $monto]);
        return $db->lastInsertId();
    }

    public static function cerrarCaja($id_caja, $monto_cierre, $total_ventas, $total_efectivo, $total_tarjeta, $total_yape, $diferencia, $observaciones) {
        $db = self::getDB();
        $stmtC = $db->prepare("UPDATE caja SET 
            monto_cierre = ?, total_ventas = ?, total_efectivo = ?, total_tarjeta = ?, total_transferencia = ?,
            diferencia = ?, observaciones = ?, estado_caja = 'cerrada', fecha_cierre = NOW() WHERE id = ?");
        return $stmtC->execute([$monto_cierre, $total_ventas, $total_efectivo, $total_tarjeta, $total_yape, $diferencia, $observaciones, $id_caja]);
    }
    
    public static function getHistorialCaja() {
        $db = self::getDB();
        $stmt = $db->query("SELECT c.*, u.nombre as cajero_nombre, u.apellido as cajero_apellido 
                            FROM caja c 
                            LEFT JOIN usuarios u ON c.id_usuario = u.id 
                            ORDER BY c.id DESC LIMIT 20");
        return $stmt->fetchAll();
    }

    public static function getPedidosCaja($id_caja) {
        $db = self::getDB();
        $stmt = $db->prepare("SELECT o.id, o.numero_pedido, o.estado_pedido, o.estado_pago, o.total_amount as total, o.payment_method as metodo_pago,
                              o.created_at, o.updated_at,
                              t.nombre as tipo_pedido, t.codigo as tipo_codigo,
                              t.badge_bg, t.badge_color, t.badge_border,
                              COALESCE(od.customer_name, op.customer_name) as cliente_nombre,
                              u.nombre as cajero_nombre, u.apellido as cajero_apellido
                              FROM orders o 
                              LEFT JOIN tipo_orden t ON o.tipo_orden_id = t.id
                              LEFT JOIN order_delivery od ON o.id = od.order_id
                              LEFT JOIN order_pickup op ON o.id = op.order_id
                              LEFT JOIN usuarios u ON o.user_id = u.id
                              WHERE o.id_caja = ? ORDER BY o.id DESC");
        $stmt->execute([$id_caja]);
        return $stmt->fetchAll();
    }
}
