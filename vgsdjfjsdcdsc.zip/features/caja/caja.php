<!--begin::App Content Header-->
<div class="app-content-header">
    <!--begin::Container-->
    <div class="container-fluid">
        <!--begin::Row-->
        <div class="row align-items-center">
            <div class="col-sm-6">
                <h3 class="mb-0 d-flex align-items-center">
                    <i data-lucide="landmark" style="width:24px;height:24px;margin-right:8px;"></i> Caja
                </h3>
            </div>
            <div class="col-sm-6">
                <div class="float-sm-end d-flex align-items-center gap-3">
                    <button class="btn btn-sm btn-outline-secondary shadow-sm" style="border-radius:8px;" onclick="cajaVerHistorial()">
                        <i data-lucide="history" class="lucide-btn"></i> Historial
                    </button>
                </div>
            </div>
        </div>
        <!--end::Row-->
    </div>
    <!--end::Container-->
</div>
<!--end::App Content Header-->

            <!-- Estado de Caja -->
            <div id="caja-estado-container">
                <!-- Se renderiza dinámicamente -->
            </div>

            <!-- Panel Principal (visible solo si caja abierta) -->
            <div id="caja-panel-principal" class="d-none">
                <!-- Stats Cards -->
                <div class="row g-3 mb-4" id="caja-stats-row">
                    <div class="col-xl-3 col-md-6">
                        <div class="card shadow-sm h-100" style="border-radius:12px; border: 1px solid #e2e8f0; border-left: 5px solid #22c55e !important;">
                            <div class="card-body py-3">
                                <div class="fw-bold text-uppercase mb-1" style="font-size: 0.9rem; color:#22c55e;">Ventas del Turno</div>
                                <div class="mb-0 fw-bold text-gray-800" style="font-size: 1.1rem;" id="caja-stat-ventas">S/ 0.00</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6">
                        <div class="card shadow-sm h-100" style="border-radius:12px; border: 1px solid #e2e8f0; border-left: 5px solid #3b82f6 !important;">
                            <div class="card-body py-3">
                                <div class="fw-bold text-uppercase mb-1" style="font-size: 0.9rem; color:#3b82f6;">Pedidos</div>
                                <div class="mb-0 fw-bold text-gray-800" style="font-size: 1.1rem;" id="caja-stat-pedidos">0</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6">
                        <div class="card shadow-sm h-100" style="border-radius:12px; border: 1px solid #e2e8f0; border-left: 5px solid #8b5cf6 !important;">
                            <div class="card-body py-3">
                                <div class="fw-bold text-uppercase mb-1" style="font-size: 0.9rem; color:#8b5cf6;">Efectivo en Caja</div>
                                <div class="mb-0 fw-bold text-gray-800" style="font-size: 1.1rem;" id="caja-stat-efectivo">S/ 0.00</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6">
                        <div class="card shadow-sm h-100" style="border-radius:12px; border: 1px solid #e2e8f0; border-left: 5px solid #f59e0b !important;">
                            <div class="card-body py-3">
                                <div class="fw-bold text-uppercase mb-1" style="font-size: 0.9rem; color:#f59e0b;">Monto Apertura</div>
                                <div class="mb-0 fw-bold text-gray-800" style="font-size: 1.1rem;" id="caja-stat-apertura">S/ 0.00</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Desglose por tipo de pago -->
                <div class="row g-3 mb-4">
                    <div class="col-lg-4">
                        <div class="card shadow-sm" style="border-radius:12px; border: 1px solid #e2e8f0;">
                            <div class="card-body p-3 d-flex align-items-center" style="gap: 15px;">
                                <div class="rounded-circle d-flex align-items-center justify-content-center" style="width:42px;height:42px;background:#dcfce7;flex-shrink:0;">
                                    <i data-lucide="banknote" style="width:20px;height:20px;color:#22c55e;"></i>
                                </div>
                                <div>
                                    <div class="text-muted fw-bold text-uppercase" style="font-size: 0.9rem;">Efectivo</div>
                                    <div class="mb-0 fw-bold text-dark" style="font-size: 1.1rem;" id="caja-desglose-efectivo">S/ 0.00</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card shadow-sm" style="border-radius:12px; border: 1px solid #e2e8f0;">
                            <div class="card-body p-3 d-flex align-items-center" style="gap: 15px;">
                                <div class="rounded-circle d-flex align-items-center justify-content-center" style="width:42px;height:42px;background:#ede9fe;flex-shrink:0;">
                                    <i data-lucide="smartphone" style="width:20px;height:20px;color:#8b5cf6;"></i>
                                </div>
                                <div>
                                    <div class="text-muted fw-bold text-uppercase" style="font-size: 0.9rem;">Yape / Transferencia</div>
                                    <div class="mb-0 fw-bold text-dark" style="font-size: 1.1rem;" id="caja-desglose-yape">S/ 0.00</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card shadow-sm" style="border-radius:12px; border: 1px solid #e2e8f0;">
                            <div class="card-body p-3 d-flex align-items-center" style="gap: 15px;">
                                <div class="rounded-circle d-flex align-items-center justify-content-center" style="width:42px;height:42px;background:#dbeafe;flex-shrink:0;">
                                    <i data-lucide="credit-card" style="width:20px;height:20px;color:#3b82f6;"></i>
                                </div>
                                <div>
                                    <div class="text-muted fw-bold text-uppercase" style="font-size: 0.9rem;">Tarjeta</div>
                                    <div class="mb-0 fw-bold text-dark" style="font-size: 1.1rem;" id="caja-desglose-tarjeta">S/ 0.00</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <style>
                    /* Efecto hover más gris para la tabla */
                    .table-hover tbody tr:hover {
                        background-color: #e2e8f0 !important;
                        transition: background-color 0.2s ease;
                    }
                </style>
                <!-- Tabla de últimos pedidos -->
                <div class="card mb-4" style="border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.03) !important;">
                    <div class="card-header py-3 d-flex justify-content-between align-items-center" style="border-radius: 12px 12px 0 0;">
                        <div class="d-flex flex-column">
                            <h6 class="m-0 font-weight-bold d-flex align-items-center"><i data-lucide="receipt" style="width:16px;height:16px;margin-right:6px;"></i>Últimos Pedidos del Turno</h6>
                        </div>
                        <div class="d-flex align-items-center ms-auto" style="gap: 10px;">
                            <select id="caja-pedidos-per-page" class="form-select form-select-sm border" style="border-radius:6px; width: 120px;" onchange="cambiarPaginaCajaPedidos(1)">
                                <option value="5">5 entradas</option>
                                <option value="10">10 entradas</option>
                                <option value="20">20 entradas</option>
                                <option value="50">50 entradas</option>
                            </select>
                            <button class="btn btn-sm btn-outline-primary" onclick="cajaRefrescar()" style="border-radius:6px;">
                                <i data-lucide="refresh-cw" style="width:14px;height:14px;"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0" style="font-size:0.85rem;">
                                <thead style="border-bottom: 1px solid var(--bs-border-color);">
                                    <tr>
                                        <th class="border-0 pl-4 bg-body-secondary">N° Pedido</th>
                                        <th class="border-0 bg-body-secondary">Tipo</th>
                                        <th class="border-0 bg-body-secondary">Cliente</th>
                                        <th class="border-0 bg-body-secondary">Método</th>
                                        <th class="border-0 bg-body-secondary">Estado</th>
                                        <th class="border-0 bg-body-secondary">Total</th>
                                        <th class="border-0 bg-body-secondary">Cajero</th>
                                        <th class="border-0 bg-body-secondary">Hora</th>
                                        <th class="border-0 text-center pr-4 bg-body-secondary">Ticket</th>
                                    </tr>
                                </thead>
                                <tbody id="caja-pedidos-tbody">
                                    <tr><td colspan="9" class="text-center text-muted py-4">Sin pedidos registrados en este turno</td></tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="card-footer clearfix border-top">
                            <div class="float-start text-muted small mt-1" id="caja-pedidos-info-paginacion">Mostrando 0 a 0 de 0 entradas</div>
                            <div class="d-flex float-end" style="gap: 5px;">
                                <button class="btn btn-sm btn-light border" id="btn-prev-caja-pedidos" onclick="cambiarPaginaCajaPedidos('prev')">Anterior</button>
                                <span id="caja-pedidos-paginas-container" class="d-flex" style="gap: 5px;"></span>
                                <button class="btn btn-sm btn-light border" id="btn-next-caja-pedidos" onclick="cambiarPaginaCajaPedidos('next')">Siguiente</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<script>
// Auto-inicializar cuando el SPA inyecte el HTML
if (typeof cargarCaja === 'function') {
    cargarCaja();
}
</script>
