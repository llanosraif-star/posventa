<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/model_caja.php';

$db = Database::getInstance()->getConnection();
$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        // ============================================
        case 'estado':
            $stmt = $db->query("SELECT c.*, u.nombre as cajero_nombre, u.apellido as cajero_apellido 
                                FROM caja c 
                                LEFT JOIN usuarios u ON c.id_usuario = u.id 
                                WHERE c.estado_caja = 'abierta' 
                                ORDER BY c.id DESC LIMIT 1");
            $caja = $stmt->fetch();
            
            if ($caja) {
                $stmtP = $db->prepare("SELECT COUNT(*) as total_pedidos, 
                                        COALESCE(SUM(total_amount), 0) as total_ventas,
                                        COALESCE(SUM(CASE WHEN payment_method = 'efectivo' THEN total_amount ELSE 0 END), 0) as total_efectivo,
                                        COALESCE(SUM(CASE WHEN payment_method = 'transferencia' THEN total_amount ELSE 0 END), 0) as total_yape,
                                        COALESCE(SUM(CASE WHEN payment_method = 'tarjeta' THEN total_amount ELSE 0 END), 0) as total_tarjeta
                                        FROM orders WHERE id_caja = ? AND estado_pedido != 'anulado'");
                $stmtP->execute([$caja['id']]);
                $caja['stats'] = $stmtP->fetch();
            }
            
            echo json_encode(['status' => 'ok', 'caja' => $caja ?: null]);
            break;

        // ============================================
        case 'abrir':
            $data = json_decode(file_get_contents('php://input'), true);
            $monto = floatval($data['monto_apertura'] ?? 0);
            $id_usuario = intval($data['id_usuario'] ?? 1);

            $check = $db->query("SELECT id FROM caja WHERE estado_caja = 'abierta' LIMIT 1")->fetch();
            if ($check) {
                echo json_encode(['status' => 'error', 'message' => 'Ya existe una caja abierta. Ciérrala primero.']);
                break;
            }

            $stmt = $db->prepare("INSERT INTO caja (id_usuario, monto_apertura, estado_caja, fecha_apertura) VALUES (?, ?, 'abierta', NOW())");
            $stmt->execute([$id_usuario, $monto]);
            echo json_encode(['status' => 'ok', 'message' => 'Caja abierta correctamente', 'id' => $db->lastInsertId()]);
            break;

        // ============================================
        case 'cerrar':
            $data = json_decode(file_get_contents('php://input'), true);
            $monto_cierre = floatval($data['monto_cierre'] ?? 0);
            $observaciones = $data['observaciones'] ?? '';

            $caja = $db->query("SELECT * FROM caja WHERE estado_caja = 'abierta' ORDER BY id DESC LIMIT 1")->fetch();
            if (!$caja) {
                echo json_encode(['status' => 'error', 'message' => 'No hay caja abierta']);
                break;
            }

            $stmtP = $db->prepare("SELECT COUNT(*) as total_pedidos,
                COALESCE(SUM(total_amount), 0) as total_ventas,
                COALESCE(SUM(CASE WHEN payment_method = 'efectivo' THEN total_amount ELSE 0 END), 0) as total_efectivo,
                COALESCE(SUM(CASE WHEN payment_method = 'transferencia' THEN total_amount ELSE 0 END), 0) as total_yape,
                COALESCE(SUM(CASE WHEN payment_method = 'tarjeta' THEN total_amount ELSE 0 END), 0) as total_tarjeta
                FROM orders WHERE id_caja = ? AND estado_pedido != 'anulado'");
            $stmtP->execute([$caja['id']]);
            $stats = $stmtP->fetch();

            $total_ventas = floatval($stats['total_ventas']);
            $total_efectivo = floatval($stats['total_efectivo']);
            $total_tarjeta = floatval($stats['total_tarjeta']);
            $total_yape = floatval($stats['total_yape']);
            $esperado = floatval($caja['monto_apertura']) + $total_efectivo;
            $diferencia = $monto_cierre - $esperado;

            $stmtC = $db->prepare("UPDATE caja SET 
                monto_cierre = ?, total_ventas = ?, total_efectivo = ?, total_tarjeta = ?, total_transferencia = ?,
                diferencia = ?, observaciones = ?, estado_caja = 'cerrada', fecha_cierre = NOW() WHERE id = ?");
            $stmtC->execute([$monto_cierre, $total_ventas, $total_efectivo, $total_tarjeta, $total_yape, $diferencia, $observaciones, $caja['id']]);

            echo json_encode(['status' => 'ok', 'message' => 'Caja cerrada']);
            break;

        // ============================================
        case 'guardar_orden':
            $data = json_decode(file_get_contents('php://input'), true);

            // [VALIDACION] Verificar caja abierta
            $checkCaja = $db->query("SELECT id FROM caja WHERE estado_caja = 'abierta' LIMIT 1")->fetch();
            if (!$checkCaja) {
                echo json_encode(['status' => 'error', 'message' => 'No puede ingresar pedidos porque la caja no está aperturada.']);
                break;
            }

            $tipo_pedido = $data['tipo_pedido'] ?? 'delivery';
            $id_mesa = !empty($data['id_mesa']) ? intval($data['id_mesa']) : null;
            $cliente_nombre = $data['cliente_nombre'] ?? 'Cliente';
            $cliente_telefono = $data['cliente_telefono'] ?? null;
            $cliente_direccion = $data['cliente_direccion'] ?? null;
            $pickup_time_raw = $data['pickup_time'] ?? null;
            $pickup_datetime = null;
            if ($pickup_time_raw) {
                $pickup_datetime = date('Y-m-d') . ' ' . $pickup_time_raw . ':00';
            }
            $items = $data['items'] ?? [];
            $user_id = $_SESSION['user_id'] ?? 1;

            // Resolver tipo_orden desde la tabla tipo_orden por codigo
            $stmtTipo = $db->prepare("SELECT id, codigo, tabla_detalle FROM tipo_orden WHERE codigo = ? AND activo = 1 LIMIT 1");
            $stmtTipo->execute([$tipo_pedido]);
            $tipoOrden = $stmtTipo->fetch();
            if (!$tipoOrden) {
                echo json_encode(['status' => 'error', 'message' => 'Tipo de pedido no válido: ' . $tipo_pedido]);
                break;
            }
            $tipo_orden_id = $tipoOrden['id'];
            $tipo_tabla   = $tipoOrden['tabla_detalle'];

            // --- Validaciones de integridad por tipo ---
            if ($tipo_pedido === 'salon' && !$id_mesa) {
                echo json_encode(['status' => 'error', 'message' => 'Debe seleccionar una mesa para órdenes de salón.']);
                break;
            }
            if ($tipo_pedido === 'delivery') {
                if (empty($cliente_nombre) || $cliente_nombre === 'Cliente') {
                    echo json_encode(['status' => 'error', 'message' => 'El nombre del cliente es obligatorio para delivery.']);
                    break;
                }
                if (empty($cliente_direccion)) {
                    echo json_encode(['status' => 'error', 'message' => 'La dirección es obligatoria para delivery.']);
                    break;
                }
                if (empty($cliente_telefono)) {
                    echo json_encode(['status' => 'error', 'message' => 'El teléfono es obligatorio para delivery.']);
                    break;
                }
            }
            if (in_array($tipo_pedido, ['recoger', 'recojo']) && (empty($cliente_nombre) || $cliente_nombre === 'Cliente')) {
                echo json_encode(['status' => 'error', 'message' => 'El nombre del cliente es obligatorio para recojo.']);
                break;
            }

            $db->beginTransaction();

            $order_id_request = intval($data['order_id'] ?? 0);

            // --- Pedidos incrementales: si es mesa ocupada, agregar a orden activa ---
            $pedidoId = null;
            $numero_pedido = '';
            $esIncremental = false;

            if ($order_id_request > 0) {
                $stmtExist = $db->prepare("SELECT id, numero_pedido FROM orders WHERE id = ? AND estado_pago = 'pendiente' AND estado_pedido IN ('pendiente','listo')");
                $stmtExist->execute([$order_id_request]);
                $ordenActiva = $stmtExist->fetch();
                if ($ordenActiva) {
                    $pedidoId = $ordenActiva['id'];
                    $numero_pedido = $ordenActiva['numero_pedido'];
                    $esIncremental = true;
                    
                    // Actualizar datos del cliente si vinieron en el request (opcional)
                    if ($tipo_tabla === 'order_delivery') {
                        $db->prepare("UPDATE order_delivery SET customer_name=?, phone=?, address=? WHERE order_id=?")->execute([$cliente_nombre, $cliente_telefono, $cliente_direccion, $pedidoId]);
                    } elseif ($tipo_tabla === 'order_pickup') {
                        $db->prepare("UPDATE order_pickup SET customer_name=?, phone=?, pickup_time=? WHERE order_id=?")->execute([$cliente_nombre, $cliente_telefono, $pickup_datetime, $pedidoId]);
                    }
                }
            } elseif ($tipo_pedido === 'salon' && $id_mesa) {
                // Buscar orden activa de la mesa: pendiente o precuenta (mesa ocupada → pedido incremental)
                $stmtExist = $db->prepare("SELECT o.id, o.numero_pedido, o.total_amount FROM orders o JOIN order_salon os ON o.id = os.order_id WHERE os.table_id = ? AND o.estado_pago = 'pendiente' AND o.estado_pedido IN ('pendiente','listo') ORDER BY o.id DESC LIMIT 1");
                $stmtExist->execute([$id_mesa]);
                $ordenActiva = $stmtExist->fetch();

                if ($ordenActiva) {
                    $pedidoId = $ordenActiva['id'];
                    $numero_pedido = $ordenActiva['numero_pedido'];
                    $esIncremental = true;
                }
            }

            if (!$pedidoId) {
                // Generar numero_pedido unificado N-000000
                $stmtNum = $db->query("SELECT COALESCE(MAX(CAST(SUBSTRING(numero_pedido, 3) AS UNSIGNED)), 0) + 1 as next_num FROM orders WHERE numero_pedido LIKE 'N-%'");
                $nextNum = $stmtNum->fetch()['next_num'];
                $numero_pedido = 'N-' . str_pad($nextNum, 6, '0', STR_PAD_LEFT);

                $stmtPed = $db->prepare("INSERT INTO orders (user_id, numero_pedido, total_amount, discount, estado_pedido, estado_pago, tipo_orden_id) VALUES (?, ?, 0, 0, 'pendiente', 'pendiente', ?)");
                $stmtPed->execute([$user_id, $numero_pedido, $tipo_orden_id]);
                $pedidoId = $db->lastInsertId();

                if ($tipo_tabla === 'order_salon' && $id_mesa) {
                    $db->prepare("INSERT INTO order_salon (order_id, table_id) VALUES (?, ?)")->execute([$pedidoId, $id_mesa]);
                    $db->prepare("UPDATE mesas SET estado_mesa = 'ocupada' WHERE id = ?")->execute([$id_mesa]);
                } elseif ($tipo_tabla === 'order_delivery') {
                    $db->prepare("INSERT INTO order_delivery (order_id, customer_name, address, phone) VALUES (?, ?, ?, ?)")->execute([$pedidoId, $cliente_nombre, $cliente_direccion, $cliente_telefono]);
                } elseif ($tipo_tabla === 'order_pickup') {
                    $db->prepare("INSERT INTO order_pickup (order_id, customer_name, phone, pickup_time) VALUES (?, ?, ?, ?)")->execute([$pedidoId, $cliente_nombre, $cliente_telefono, $pickup_datetime]);
                }
            }

            // Insertar nuevos items con print_status = 0 (pendientes de envío a cocina)
            $totalNuevos = 0;
            $newItemIds = [];
            if (!empty($items)) {
                $stmtDet = $db->prepare("INSERT INTO order_details (order_id, product_id, nombre_item, quantity, price, subtotal, print_status, notas) VALUES (?, ?, ?, ?, ?, ?, 0, ?)");
                $stmtProd = $db->prepare("SELECT p.id_areaproduccion FROM subcategorias p INNER JOIN areas_produccion a ON p.id_areaproduccion = a.id WHERE p.id = ?");
                $stmtKds = $db->prepare("INSERT INTO kds_pedidos (id_order, id_order_detail, id_areaproduccion, estado_kds) VALUES (?, ?, ?, 'pendiente')");

                // --- Inventario ---
                $stmtCheckInv = $db->prepare("SELECT control_stock, codigo_interno FROM productos WHERE id = ?");
                $stmtDeductInv = $db->prepare("UPDATE inventario_pos SET stock_actual = stock_actual - ? WHERE codigo_interno = ? AND codigo_interno != ''");
                $stmtMovInv = $db->prepare("INSERT INTO inventario_pos_movimientos (id_articulo, tipo_movimiento, cantidad, motivo, usuario_id) SELECT id, 'salida', ?, 'Venta POS - Pedido', ? FROM inventario_pos WHERE codigo_interno = ? AND codigo_interno != ''");

                foreach ($items as $item) {
                    $sub = floatval($item['cantidad']) * floatval($item['precio']);
                    $prod_id = intval($item['id_subcategoria'] ?? 1);
                    $stmtDet->execute([
                        $pedidoId,
                        $prod_id,
                        $item['nombre'] ?? null,
                        intval($item['cantidad']),
                        floatval($item['precio']),
                        $sub,
                        $item['notas'] ?? null
                    ]);
                    $detail_id = $db->lastInsertId();
                    $newItemIds[] = $detail_id;
                    $totalNuevos += $sub;

                    // Insertar en kds_pedidos
                    $stmtProd->execute([$prod_id]);
                    $prod_data = $stmtProd->fetch();
                    if ($prod_data && !empty($prod_data['id_areaproduccion'])) {
                        $stmtKds->execute([$pedidoId, $detail_id, $prod_data['id_areaproduccion']]);
                    }

                    // --- Descontar stock ---
                    $inv_prod_id = intval($item['producto_id'] ?? $prod_id);
                    $stmtCheckInv->execute([$inv_prod_id]);
                    $prodInv = $stmtCheckInv->fetch(PDO::FETCH_ASSOC);
                    if ($prodInv && $prodInv['control_stock'] == 1 && !empty($prodInv['codigo_interno'])) {
                        $cant = floatval($item['cantidad']);
                        $stmtDeductInv->execute([$cant, $prodInv['codigo_interno']]);
                        $stmtMovInv->execute([$cant, $user_id, $prodInv['codigo_interno']]);
                    }
                }
            }

            // Recalcular total de la orden sumando TODOS los items
            $stmtTotal = $db->prepare("SELECT COALESCE(SUM(subtotal), 0) as total FROM order_details WHERE order_id = ?");
            $stmtTotal->execute([$pedidoId]);
            $nuevoTotal = floatval($stmtTotal->fetch()['total']);
            $db->prepare("UPDATE orders SET total_amount = ?, updated_at = NOW() WHERE id = ?")->execute([$nuevoTotal, $pedidoId]);

            // Control de impresión: marcar los items recién insertados como enviados a cocina (print_status = 1)
            if (!empty($newItemIds)) {
                $placeholders = implode(',', array_fill(0, count($newItemIds), '?'));
                $db->prepare("UPDATE order_details SET print_status = 1 WHERE id IN ($placeholders)")->execute($newItemIds);
            }

            $db->commit();
            echo json_encode([
                'status' => 'ok',
                'message' => $esIncremental ? 'Items agregados a la orden activa y enviados a cocina' : 'Orden guardada y enviada a cocina',
                'numero_pedido' => $numero_pedido,
                'order_id' => $pedidoId,
                'es_incremental' => $esIncremental,
                'total' => $nuevoTotal,
                'items_enviados' => count($newItemIds)
            ]);
            break;

        // ============================================
        case 'cambiar_mesa':
            $data = json_decode(file_get_contents('php://input'), true);
            $id_mesa_origen = intval($data['id_mesa_origen'] ?? 0);
            $id_mesa_destino = intval($data['id_mesa_destino'] ?? 0);

            if (!$id_mesa_origen || !$id_mesa_destino) {
                echo json_encode(['status' => 'error', 'message' => 'Mesa origen y destino son requeridas']);
                break;
            }

            $db->beginTransaction();

            try {
                // Verificar mesa destino libre
                $stmtDestino = $db->prepare("SELECT estado_mesa FROM mesas WHERE id = ? FOR UPDATE");
                $stmtDestino->execute([$id_mesa_destino]);
                $mesaDestino = $stmtDestino->fetch();
                if (!$mesaDestino || $mesaDestino['estado_mesa'] !== 'libre') {
                    throw new Exception('La mesa destino no está libre.');
                }

                // Buscar orden activa en la mesa de origen
                $stmtExist = $db->prepare("SELECT o.id FROM orders o JOIN order_salon os ON o.id = os.order_id WHERE os.table_id = ? AND o.estado_pago = 'pendiente' AND o.estado_pedido NOT IN ('completado','anulado') ORDER BY o.id DESC LIMIT 1");
                $stmtExist->execute([$id_mesa_origen]);
                $ordenActiva = $stmtExist->fetch();

                if (!$ordenActiva) {
                    throw new Exception('No hay orden activa en la mesa de origen.');
                }

                // Actualizar mesa en order_salon
                $db->prepare("UPDATE order_salon SET table_id = ? WHERE order_id = ?")->execute([$id_mesa_destino, $ordenActiva['id']]);

                // Actualizar estados de mesas
                $db->prepare("UPDATE mesas SET estado_mesa = 'libre' WHERE id = ?")->execute([$id_mesa_origen]);
                $db->prepare("UPDATE mesas SET estado_mesa = 'ocupada' WHERE id = ?")->execute([$id_mesa_destino]);

                $db->commit();
                echo json_encode(['status' => 'ok', 'message' => 'Mesa cambiada exitosamente']);
            } catch (Exception $e) {
                $db->rollBack();
                echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
            }
            break;

        // ============================================
        case 'cobrar':
            $data = json_decode(file_get_contents('php://input'), true);

            $rol = $_SESSION['user_rol'] ?? 'mesero';
            if ($rol !== 'cajero' && $rol !== 'admin') {
                echo json_encode(['status' => 'error', 'message' => 'Acceso denegado. Solo un Cajero o Admin puede procesar pagos.']);
                break;
            }
            
            $caja = $db->query("SELECT id FROM caja WHERE estado_caja = 'abierta' ORDER BY id DESC LIMIT 1")->fetch();
            if (!$caja) {
                echo json_encode(['status' => 'error', 'message' => 'No hay caja abierta. Abra la caja primero.']);
                break;
            }

            $tipo_pedido = $data['tipo_pedido'] ?? 'salon';
            $id_mesa = !empty($data['id_mesa']) ? intval($data['id_mesa']) : null;
            $metodo_pago = $data['metodo_pago'] ?? 'efectivo';
            $cliente_nombre = $data['cliente_nombre'] ?? 'Cliente';
            $cliente_telefono = $data['cliente_telefono'] ?? null;
            $cliente_direccion = $data['cliente_direccion'] ?? null;
            $pickup_time_raw = $data['pickup_time'] ?? null;
            $pickup_datetime = null;
            if ($pickup_time_raw) {
                $pickup_datetime = date('Y-m-d') . ' ' . $pickup_time_raw . ':00';
            }
            $total = floatval($data['total'] ?? 0);
            $items = $data['items'] ?? [];
            $user_id = $_SESSION['user_id'] ?? 1;

            // Resolver tipo_orden
            $stmtTipo = $db->prepare("SELECT id, codigo, tabla_detalle FROM tipo_orden WHERE codigo = ? AND activo = 1 LIMIT 1");
            $stmtTipo->execute([$tipo_pedido]);
            $tipoOrden = $stmtTipo->fetch();
            $tipo_orden_id = $tipoOrden ? $tipoOrden['id'] : 1;
            $tipo_tabla   = $tipoOrden ? $tipoOrden['tabla_detalle'] : 'order_salon';

            $db->beginTransaction();

            // Para salón: cobrar la orden pendiente existente de la mesa
            if ($tipo_pedido === 'salon' && $id_mesa) {
                // Buscar orden activa: puede estar en 'pendiente' o 'precuenta'
                $stmtExist = $db->prepare("SELECT o.id, o.numero_pedido FROM orders o JOIN order_salon os ON o.id = os.order_id WHERE os.table_id = ? AND o.estado_pago = 'pendiente' AND o.estado_pedido IN ('pendiente','listo') ORDER BY o.id DESC LIMIT 1");
                $stmtExist->execute([$id_mesa]);
                $ordenActiva = $stmtExist->fetch();

                if ($ordenActiva) {
                    // Recalcular total desde order_details
                    $stmtTotal = $db->prepare("SELECT COALESCE(SUM(subtotal), 0) as total FROM order_details WHERE order_id = ?");
                    $stmtTotal->execute([$ordenActiva['id']]);
                    $totalReal = floatval($stmtTotal->fetch()['total']);

                    // Cobro: actualizar status, payment_method, id_caja y updated_at
                    $db->prepare("UPDATE orders SET estado_pago = 'pagado', estado_pedido = 'completado', payment_method = ?, id_caja = ?, total_amount = ?, updated_at = NOW() WHERE id = ?")
                       ->execute([$metodo_pago, $caja['id'], $totalReal, $ordenActiva['id']]);
                    // Solo tras el cobro exitoso, la mesa vuelve a status libre
                    $db->prepare("UPDATE mesas SET estado_mesa = 'libre' WHERE id = ?")->execute([$id_mesa]);

                    $db->commit();
                    echo json_encode(['status' => 'ok', 'message' => 'Cobro registrado correctamente', 'numero_pedido' => $ordenActiva['numero_pedido']]);
                    break;
                }
            }

            // Para delivery/pickup o mesa sin orden previa: crear nueva orden pagada
            $stmtNum = $db->query("SELECT COALESCE(MAX(CAST(SUBSTRING(numero_pedido, 3) AS UNSIGNED)), 0) + 1 as next_num FROM orders WHERE numero_pedido LIKE 'N-%'");
            $nextNum = $stmtNum->fetch()['next_num'];
            $numero_pedido = 'N-' . str_pad($nextNum, 6, '0', STR_PAD_LEFT);

            $stmtPed = $db->prepare("INSERT INTO orders (user_id, id_caja, numero_pedido, total_amount, estado_pedido, estado_pago, tipo_orden_id, payment_method) VALUES (?, ?, ?, ?, 'completado', 'pagado', ?, ?)");
            $stmtPed->execute([$user_id, $caja['id'], $numero_pedido, $total, $tipo_orden_id, $metodo_pago]);
            $pedidoId = $db->lastInsertId();

            if ($tipo_tabla === 'order_salon' && $id_mesa) {
                $db->prepare("INSERT INTO order_salon (order_id, table_id) VALUES (?, ?)")->execute([$pedidoId, $id_mesa]);
                $db->prepare("UPDATE mesas SET estado_mesa = 'libre' WHERE id = ?")->execute([$id_mesa]);
            } elseif ($tipo_tabla === 'order_delivery') {
                $db->prepare("INSERT INTO order_delivery (order_id, customer_name, address, phone) VALUES (?, ?, ?, ?)")->execute([$pedidoId, $cliente_nombre, $cliente_direccion, $cliente_telefono]);
            } elseif ($tipo_tabla === 'order_pickup') {
                $db->prepare("INSERT INTO order_pickup (order_id, customer_name, phone, pickup_time) VALUES (?, ?, ?, ?)")->execute([$pedidoId, $cliente_nombre, $cliente_telefono, $pickup_datetime]);
            }

            if (!empty($items)) {
                $stmtDet = $db->prepare("INSERT INTO order_details (order_id, product_id, nombre_item, quantity, price, subtotal, print_status, notas) VALUES (?, ?, ?, ?, ?, ?, 1, ?)");
                $stmtProd = $db->prepare("SELECT p.id_areaproduccion FROM subcategorias p INNER JOIN areas_produccion a ON p.id_areaproduccion = a.id WHERE p.id = ?");
                $stmtKds = $db->prepare("INSERT INTO kds_pedidos (id_order, id_order_detail, id_areaproduccion, estado_kds) VALUES (?, ?, ?, 'pendiente')");

                // --- Inventario ---
                $stmtCheckInv = $db->prepare("SELECT control_stock, codigo_interno FROM productos WHERE id = ?");
                $stmtDeductInv = $db->prepare("UPDATE inventario_pos SET stock_actual = stock_actual - ? WHERE codigo_interno = ? AND codigo_interno != ''");
                $stmtMovInv = $db->prepare("INSERT INTO inventario_pos_movimientos (id_articulo, tipo_movimiento, cantidad, motivo, usuario_id) SELECT id, 'salida', ?, 'Venta POS - Directa', ? FROM inventario_pos WHERE codigo_interno = ? AND codigo_interno != ''");

                foreach ($items as $item) {
                    $prod_id = intval($item['id_subcategoria'] ?? 1);
                    $stmtDet->execute([
                        $pedidoId,
                        $prod_id,
                        $item['nombre'] ?? null,
                        intval($item['cantidad']),
                        floatval($item['precio']),
                        floatval($item['cantidad']) * floatval($item['precio']),
                        $item['notas'] ?? null
                    ]);
                    $detail_id = $db->lastInsertId();

                    // Insertar en kds_pedidos
                    $stmtProd->execute([$prod_id]);
                    $prod_data = $stmtProd->fetch();
                    if ($prod_data && !empty($prod_data['id_areaproduccion'])) {
                        $stmtKds->execute([$pedidoId, $detail_id, $prod_data['id_areaproduccion']]);
                    }

                    // --- Descontar stock ---
                    $inv_prod_id = intval($item['producto_id'] ?? $prod_id);
                    $stmtCheckInv->execute([$inv_prod_id]);
                    $prodInv = $stmtCheckInv->fetch(PDO::FETCH_ASSOC);
                    if ($prodInv && $prodInv['control_stock'] == 1 && !empty($prodInv['codigo_interno'])) {
                        $cant = floatval($item['cantidad']);
                        $stmtDeductInv->execute([$cant, $prodInv['codigo_interno']]);
                        $stmtMovInv->execute([$cant, $user_id, $prodInv['codigo_interno']]);
                    }
                }
            }

            $db->commit();
            echo json_encode(['status' => 'ok', 'message' => 'Cobro registrado correctamente', 'numero_pedido' => $numero_pedido]);
            break;

        // ============================================
        case 'historial':
            $stmt = $db->query("SELECT c.*, u.nombre as cajero_nombre, u.apellido as cajero_apellido 
                                FROM caja c 
                                LEFT JOIN usuarios u ON c.id_usuario = u.id 
                                ORDER BY c.id DESC LIMIT 20");
            echo json_encode(['status' => 'ok', 'data' => $stmt->fetchAll()]);
            break;

        // ============================================
        case 'pedidos':
            $id_caja = intval($_GET['id_caja'] ?? 0);
            $stmt = $db->prepare("SELECT o.id, o.numero_pedido, o.estado_pedido, o.estado_pago, o.total_amount as total, o.payment_method as metodo_pago,
                                  o.created_at, o.updated_at,
                                  t.nombre as tipo_pedido, t.codigo as tipo_codigo,
                                  t.badge_bg, t.badge_color, t.badge_border,
                                  COALESCE(od.customer_name, op.customer_name) as cliente_nombre,
                                  u.nombre as cajero_nombre, u.apellido as cajero_apellido
                                  FROM orders o 
                                  LEFT JOIN tipo_orden t ON o.tipo_orden_id = t.id
                                  LEFT JOIN order_delivery od ON o.id = od.order_id
                                  LEFT JOIN order_pickup op ON o.id = op.order_id
                                  LEFT JOIN usuarios u ON o.user_id = u.id
                                  WHERE o.id_caja = ? ORDER BY o.id DESC");
            $stmt->execute([$id_caja]);
            echo json_encode(['status' => 'ok', 'data' => $stmt->fetchAll()]);
            break;

        // ============================================
        case 'ordenes_activas':
            $filtro = $_GET['filtro'] ?? 'todos';
            $where = "WHERE o.estado_pedido NOT IN ('completado', 'anulado')";
            
            if ($filtro === 'delivery') {
                $where .= " AND t.codigo = 'delivery'";
            } elseif ($filtro === 'llevar') {
                $where .= " AND t.codigo = 'llevar'";
            } elseif ($filtro === 'recoger' || $filtro === 'recojo') {
                $where .= " AND t.codigo = 'recoger'";
            } elseif ($filtro === 'mesa') {
                $where .= " AND t.codigo = 'salon'";
            }

            $stmt = $db->query("SELECT o.id, o.numero_pedido, o.total_amount as total, o.estado_pedido, o.estado_pago,
                t.nombre as tipo_pedido, t.codigo as tipo_codigo,
                t.badge_bg, t.badge_color, t.badge_border,
                COALESCE(od.customer_name, op.customer_name) as cliente_nombre,
                od.address as cliente_direccion,
                COALESCE(od.phone, op.phone) as cliente_telefono,
                od.delivery_boy_id,
                (SELECT COUNT(*) FROM order_details WHERE order_id = o.id) as total_items,
                DATE_FORMAT(o.created_at, '%H:%i') as hora,
                os.table_id, m.numero as nombre_mesa
                FROM orders o 
                LEFT JOIN tipo_orden t ON o.tipo_orden_id = t.id
                LEFT JOIN order_delivery od ON o.id = od.order_id
                LEFT JOIN order_pickup op ON o.id = op.order_id
                LEFT JOIN order_salon os ON o.id = os.order_id
                LEFT JOIN mesas m ON os.table_id = m.id
                $where ORDER BY o.id DESC");
            echo json_encode(['status' => 'ok', 'data' => $stmt->fetchAll()]);
            break;

        // ============================================
        case 'detalle_orden':
            $id = intval($_GET['id'] ?? 0);
            $stmt = $db->prepare("SELECT o.*, o.numero_pedido, o.total_amount as total, o.estado_pedido, o.estado_pago,
                t.nombre as tipo_pedido, t.codigo as tipo_codigo,
                t.badge_bg, t.badge_color, t.badge_border,
                COALESCE(od.customer_name, op.customer_name) as cliente_nombre,
                od.address as cliente_direccion, COALESCE(od.phone, op.phone) as cliente_telefono,
                od.delivery_boy_id, od.shipping_cost,
                os.table_id, u.nombre as cajero_nombre
                FROM orders o 
                LEFT JOIN tipo_orden t ON o.tipo_orden_id = t.id
                LEFT JOIN order_delivery od ON o.id = od.order_id
                LEFT JOIN order_pickup op ON o.id = op.order_id
                LEFT JOIN order_salon os ON o.id = os.order_id
                LEFT JOIN usuarios u ON o.user_id = u.id
                WHERE o.id = ?");
            $stmt->execute([$id]);
            $pedido = $stmt->fetch();
            if (!$pedido) { echo json_encode(['status' => 'error', 'message' => 'Pedido no encontrado']); break; }

            $stmtD = $db->prepare("SELECT dp.product_id as id_subcategoria, COALESCE(dp.nombre_item, p.nombre) as subcategoria_nombre, dp.quantity as cantidad, dp.price as precio, dp.subtotal
                FROM order_details dp LEFT JOIN subcategorias p ON dp.product_id = p.id WHERE dp.order_id = ?");
            $stmtD->execute([$id]);
            $items = $stmtD->fetchAll();

            echo json_encode(['status' => 'ok', 'pedido' => $pedido, 'items' => $items]);
            break;

        // ============================================
        // ACTUALIZAR ESTADO DELIVERY
        // ============================================
        case 'actualizar_estado':
            $data = json_decode(file_get_contents('php://input'), true);
            $id = intval($data['id'] ?? 0);
            $estado = $data['estado'] ?? '';
            
            // Validar que el estado sea uno de los permitidos
            $estadosValidos = ['pendiente', 'listo', 'en_camino', 'completado', 'anulado'];
            if (!in_array($estado, $estadosValidos)) {
                echo json_encode(['status' => 'error', 'message' => 'Estado no válido: ' . $estado]);
                break;
            }
            
            if ($estado === 'completado') {
                $stmtCheck = $db->prepare("SELECT estado_pago FROM orders WHERE id = ?");
                $stmtCheck->execute([$id]);
                $ordenCheck = $stmtCheck->fetch();
                if ($ordenCheck && $ordenCheck['estado_pago'] !== 'pagado') {
                    echo json_encode(['status' => 'error', 'message' => 'No se puede completar el pedido sin haber sido pagado']);
                    break;
                }
            }
            
            if (in_array($estado, ['listo', 'en_camino', 'completado'])) {
                $stmtKds = $db->prepare("SELECT COUNT(*) FROM kds_pedidos WHERE id_order = ? AND estado_kds != 'listo'");
                $stmtKds->execute([$id]);
                if ($stmtKds->fetchColumn() > 0) {
                    echo json_encode(['status' => 'error', 'message' => 'No se puede cambiar el estado. El pedido aún está siendo preparado en cocina.']);
                    break;
                }
            }
            
            // Actualizar estado_pedido directamente en orders
            $db->prepare("UPDATE orders SET estado_pedido = ?, updated_at = NOW() WHERE id = ?")->execute([$estado, $id]);
            
            echo json_encode(['status' => 'ok', 'message' => 'Estado actualizado']);
            break;

        // ============================================
        // ASIGNAR REPARTIDOR
        // ============================================
        case 'asignar_repartidor':
            $data = json_decode(file_get_contents('php://input'), true);
            $order_id = intval($data['order_id'] ?? 0);
            $delivery_boy_id = intval($data['delivery_boy_id'] ?? 0);
            $shipping_cost = floatval($data['shipping_cost'] ?? 0);
            
            $db->prepare("UPDATE order_delivery SET delivery_boy_id = ?, shipping_cost = ? WHERE order_id = ?")
               ->execute([$delivery_boy_id, $shipping_cost, $order_id]);
            // Actualizar estado_pedido a en_camino en la tabla principal
            $db->prepare("UPDATE orders SET estado_pedido = 'en_camino', updated_at = NOW() WHERE id = ?")->execute([$order_id]);
            
            echo json_encode(['status' => 'ok', 'message' => 'Repartidor asignado, orden en camino']);
            break;

        // ============================================
        // COBRAR ORDEN EXISTENTE (Delivery/Pickup que ya fue creada)
        // ============================================
        case 'cobrar_orden_existente':
            $data = json_decode(file_get_contents('php://input'), true);
            
            $rol = $_SESSION['user_rol'] ?? 'mesero';
            if ($rol !== 'cajero' && $rol !== 'admin') {
                echo json_encode(['status' => 'error', 'message' => 'Acceso denegado. Solo Cajero o Admin.']);
                break;
            }
            
            $caja = $db->query("SELECT id FROM caja WHERE estado_caja = 'abierta' ORDER BY id DESC LIMIT 1")->fetch();
            if (!$caja) {
                echo json_encode(['status' => 'error', 'message' => 'No hay caja abierta.']);
                break;
            }
            
            $order_id = intval($data['order_id'] ?? 0);
            $metodo_pago = $data['metodo_pago'] ?? 'efectivo';
            
            // Check if already paid
            $ordenCheck = $db->prepare("SELECT estado_pago FROM orders WHERE id = ?");
            $ordenCheck->execute([$order_id]);
            $estadoCheck = $ordenCheck->fetchColumn();
            
            if ($estadoCheck === 'pagado') {
                echo json_encode(['status' => 'error', 'message' => 'Esta orden ya ha sido pagada.']);
                break;
            }
            
            $completar = !empty($data['completar_pedido']);
            
            if ($completar) {
                $stmtKds = $db->prepare("SELECT COUNT(*) FROM kds_pedidos WHERE id_order = ? AND estado_kds != 'listo'");
                $stmtKds->execute([$order_id]);
                if ($stmtKds->fetchColumn() > 0) {
                    echo json_encode(['status' => 'error', 'message' => 'No se puede completar la orden. Aún hay platos siendo preparados en cocina.']);
                    break;
                }
            }
            
            if ($completar) {
                // Cobro: actualizar estado_pago y completar estado_pedido
                $db->prepare("UPDATE orders SET estado_pago = 'pagado', estado_pedido = 'completado', payment_method = ?, id_caja = ?, updated_at = NOW() WHERE id = ?")
                   ->execute([$metodo_pago, $caja['id'], $order_id]);
                // Si es mesa, liberar
                $db->prepare("UPDATE mesas m JOIN order_salon os ON m.id = os.table_id SET m.estado_mesa = 'libre' WHERE os.order_id = ?")->execute([$order_id]);
            } else {
                // Cobro: actualizar SOLO estado_pago (se mantiene pendiente/listo/en_camino logísticamente)
                $db->prepare("UPDATE orders SET estado_pago = 'pagado', payment_method = ?, id_caja = ?, updated_at = NOW() WHERE id = ?")
                   ->execute([$metodo_pago, $caja['id'], $order_id]);
            }
            
            echo json_encode(['status' => 'ok', 'message' => 'Orden cobrada correctamente']);
            break;

        // ============================================
        case 'cancelar_orden':
            $data = json_decode(file_get_contents('php://input'), true);
            $id = intval($data['id'] ?? 0);
            $stmt = $db->prepare("UPDATE orders SET estado_pedido = 'anulado', updated_at = NOW() WHERE id = ?");
            $stmt->execute([$id]);
            echo json_encode(['status' => 'ok', 'message' => 'Orden cancelada']);
            break;

        // ============================================
        case 'pedidos_mesa':
            $id_mesa = intval($_GET['id_mesa'] ?? 0);
            
            $stmt = $db->prepare("SELECT o.id, o.numero_pedido, o.total_amount as total, o.estado_pedido, o.estado_pago,
                DATE_FORMAT(o.created_at, '%H:%i') as hora
                FROM orders o 
                JOIN order_salon os ON o.id = os.order_id
                WHERE os.table_id = ? AND o.estado_pago = 'pendiente' AND o.estado_pedido NOT IN ('completado','anulado') 
                ORDER BY o.id ASC");
            $stmt->execute([$id_mesa]);
            $pedidos = $stmt->fetchAll();

            $stmtItems = $db->prepare("SELECT dp.product_id as id_subcategoria, COALESCE(dp.nombre_item, p.nombre) as subcategoria_nombre, dp.quantity as cantidad, dp.price as precio_unitario, dp.subtotal, dp.print_status 
                FROM order_details dp 
                LEFT JOIN subcategorias p ON dp.product_id = p.id 
                WHERE dp.order_id = ?");
            
            foreach ($pedidos as &$ped) {
                $stmtItems->execute([$ped['id']]);
                $ped['items'] = $stmtItems->fetchAll();
            }

            echo json_encode(['status' => 'ok', 'data' => $pedidos]);
            break;

        // ============================================
        case 'cambiar_estado_mesa':
            $data = json_decode(file_get_contents('php://input'), true);
            $id_mesa = intval($data['id_mesa'] ?? 0);
            $estado = $data['estado'] ?? 'libre';
            if ($id_mesa > 0) {
                $db->prepare("UPDATE mesas SET estado_mesa = ? WHERE id = ?")->execute([$estado, $id_mesa]);
                echo json_encode(['status' => 'ok', 'message' => 'Estado actualizado']);
            } else { echo json_encode(['status' => 'error', 'message' => 'Mesa no válida']); }
            break;

        // ============================================
        // MARCAR ITEMS COMO IMPRESOS (tras enviar a cocina)
        // ============================================
        case 'marcar_impreso':
            $data = json_decode(file_get_contents('php://input'), true);
            $order_id = intval($data['order_id'] ?? 0);
            if ($order_id > 0) {
                $db->prepare("UPDATE order_details SET print_status = 1 WHERE order_id = ? AND print_status = 0")->execute([$order_id]);
                echo json_encode(['status' => 'ok', 'message' => 'Items marcados como impresos']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'ID de orden no válido']);
            }
            break;

        // ============================================
        // ITEMS PENDIENTES DE IMPRESIÓN (para enviar a cocina)
        // ============================================
        case 'items_por_imprimir':
            $order_id = intval($_GET['order_id'] ?? 0);
            $stmt = $db->prepare("SELECT od.id, od.nombre_item, od.quantity, od.price, od.subtotal FROM order_details od WHERE od.order_id = ? AND od.print_status = 0");
            $stmt->execute([$order_id]);
            echo json_encode(['status' => 'ok', 'data' => $stmt->fetchAll()]);
            break;

        // ============================================
        // PRECUENTA: Cambiar mesa a "cuenta" (mozo solicita al cajero)
        // ============================================
        case 'precuenta':
            $data = json_decode(file_get_contents('php://input'), true);
            $id_mesa = intval($data['id_mesa'] ?? 0);
            if ($id_mesa > 0) {
                // Cambiar estado de mesa a 'cuenta' (status = 2 visual)
                $db->prepare("UPDATE mesas SET estado_mesa = 'cuenta' WHERE id = ?")->execute([$id_mesa]);
                // Cambiar estado_pedido de la orden activa para indicar que la mesa pide la cuenta
                // (estado_pedido sigue 'pendiente' porque aún no se ha entregado/completado, pero la mesa cambia a 'cuenta')
                // No se cambia estado_pedido aquí, solo el estado visual de la mesa
                // La orden se mantiene pendiente hasta que el cajero la cobre
                echo json_encode(['status' => 'ok', 'message' => 'Pre-cuenta solicitada. El cajero puede proceder al cobro.']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Mesa no válida']);
            }
            break;

        // ============================================
        // GET ROL: Devolver rol del usuario en sesión (para RBAC frontend)
        // ============================================
        case 'get_rol':
            echo json_encode([
                'status' => 'ok',
                'rol' => $_SESSION['user_rol'] ?? 'mesero',
                'user_id' => $_SESSION['user_id'] ?? null,
                'user_nombre' => $_SESSION['user_nombre'] ?? 'Usuario'
            ]);
            break;

        default:
            echo json_encode(['status' => 'error', 'message' => 'Acción no válida']);
    }

} catch (Exception $e) {
    if ($db->inTransaction()) $db->rollBack();
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}


