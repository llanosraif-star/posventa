<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../vendor/autoload.php';

use Mike42\Escpos\Printer;
use Mike42\Escpos\PrintConnectors\NetworkPrintConnector;

$db = Database::getInstance()->getConnection();
$method = $_SERVER['REQUEST_METHOD'];

if ($method !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Método no permitido']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';

// Función auxiliar para texto alineado a la derecha
function textRightAligned($printer, $label, $value, $width = 42) {
    // Si la impresora soporta 48 caracteres, ajusta el 42 a 48, pero 42 es seguro para la mayoría.
    $len = strlen($label) + strlen($value);
    $spaces = $width - $len;
    if ($spaces < 1) $spaces = 1;
    $printer->text($label . str_repeat(' ', $spaces) . $value . "\n");
}

try {
    // Asegurar tabla de secuencias
    $db->exec("CREATE TABLE IF NOT EXISTS secuencia_comandas (
        fecha DATE PRIMARY KEY,
        ultimo_numero INT DEFAULT 0
    )");

    if ($action === 'comanda') {
        $numero_pedido = $input['numero_pedido'] ?? '----';
        $cliente = $input['cliente_nombre'] ?? 'Cliente';
        $tipo_pedido = $input['tipo_pedido'] ?? 'MESA';
        $mozo = $input['mozo'] ?? 'No especificado';
        $items = $input['items'] ?? [];
        
        // 1. Generar Número de Comanda
        $hoy = date('Y-m-d');
        $db->exec("INSERT IGNORE INTO secuencia_comandas (fecha, ultimo_numero) VALUES ('$hoy', 0)");
        $db->exec("UPDATE secuencia_comandas SET ultimo_numero = ultimo_numero + 1 WHERE fecha = '$hoy'");
        $stmtSec = $db->query("SELECT ultimo_numero FROM secuencia_comandas WHERE fecha = '$hoy'");
        $num_comanda = str_pad($stmtSec->fetchColumn(), 4, '0', STR_PAD_LEFT);
        
        // 2. Agrupar items por impresora IP y luego por Categoría
        $impresorasJobs = [];
        
        foreach ($items as $item) {
            $stmt = $db->prepare("
                SELECT i.ip, i.puerto, i.nombre as impresora_nombre, c.nombre as categoria_nombre 
                FROM subcategorias p 
                JOIN categorias c ON p.id_categoria = c.id 
                JOIN impresoras i ON c.id_impresora = i.id 
                WHERE p.id = ? AND i.ip IS NOT NULL AND i.ip != ''
            ");
            $stmt->execute([$item['id_subcategoria']]);
            $impresora = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($impresora) {
                $key = $impresora['ip'] . ':' . ($impresora['puerto'] ?: '9100');
                if (!isset($impresorasJobs[$key])) {
                    $impresorasJobs[$key] = [
                        'ip' => $impresora['ip'],
                        'puerto' => $impresora['puerto'] ?: 9100,
                        'nombre_impresora' => $impresora['impresora_nombre'],
                        'categorias' => []
                    ];
                }
                
                $catNombre = mb_strtoupper($impresora['categoria_nombre'], 'UTF-8');
                if (!isset($impresorasJobs[$key]['categorias'][$catNombre])) {
                    $impresorasJobs[$key]['categorias'][$catNombre] = [];
                }
                
                $impresorasJobs[$key]['categorias'][$catNombre][] = $item;
            }
        }
        
        $errores = [];
        
        // 3. Imprimir en cada IP que tenga items asignados
        foreach ($impresorasJobs as $job) {
            try {
                $connector = new NetworkPrintConnector($job['ip'], $job['puerto']);
                $printer = new Printer($connector);
                
                // Cabecera Centrada
                $printer->setJustification(Printer::JUSTIFY_CENTER);
                $printer->setTextSize(2, 2);
                $printer->text("COMANDA DE COCINA\n");
                $printer->setTextSize(1, 1);
                $printer->text("------------------------------------------\n");
                
                // Datos Alineados a la derecha
                $printer->setJustification(Printer::JUSTIFY_LEFT);
                
                // Si es delivery/llevar/recoger, mostrar el tipo de pedido en grande
                if (strtoupper($tipo_pedido) !== 'MESA') {
                    $printer->setJustification(Printer::JUSTIFY_CENTER);
                    $printer->setEmphasis(true);
                    $printer->text("=== " . strtoupper($tipo_pedido) . " ===\n");
                    $printer->setEmphasis(false);
                    $printer->setJustification(Printer::JUSTIFY_LEFT);
                }

                textRightAligned($printer, "Cliente/Mesa:", $cliente);
                textRightAligned($printer, "Mozo:", $mozo);
                textRightAligned($printer, "Pedido Gral:", $numero_pedido);
                textRightAligned($printer, "Comanda Nro:", $num_comanda);
                textRightAligned($printer, "Hora:", date("h:i a"));
                
                $printer->text("------------------------------------------\n\n");
                
                // Bloques por Categoría
                foreach ($job['categorias'] as $catNombre => $catItems) {
                    $printer->setJustification(Printer::JUSTIFY_CENTER);
                    $printer->setReverseColors(true);
                    // Añadimos espacios alrededor para hacer el bloque negro más vistoso
                    $printer->text("  [ " . $catNombre . " ]  \n");
                    $printer->setReverseColors(false);
                    $printer->setJustification(Printer::JUSTIFY_LEFT);
                    $printer->text("\n");
                    
                    foreach ($catItems as $item) {
                        $printer->setEmphasis(true);
                        $printer->text($item['cantidad'] . "x " . mb_strtoupper($item['nombre'], 'UTF-8') . "\n");
                        $printer->setEmphasis(false);
                        if (!empty($item['notas'])) {
                            $printer->text("  » " . $item['notas'] . "\n");
                        }
                    }
                    $printer->text("\n"); // Espacio antes de la siguiente categoría
                }
                
                $printer->feed(3);
                $printer->cut();
                $printer->close();
            } catch (Exception $e) {
                $errores[] = "Error en impresora {$job['ip']}: " . $e->getMessage();
            }
        }
        
        if (count($errores) > 0) {
            echo json_encode(['status' => 'error', 'message' => 'Falló alguna impresora', 'errores' => $errores]);
        } else {
            echo json_encode(['status' => 'ok', 'message' => 'Comandas enviadas correctamente', 'comanda' => $num_comanda]);
        }
        exit;
    }

    echo json_encode(['status' => 'error', 'message' => 'Acción no válida']);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Excepción: ' . $e->getMessage()]);
}

