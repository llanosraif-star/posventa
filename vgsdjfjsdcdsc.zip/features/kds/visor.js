let visorKdsRefreshTimer = null;
let visorHtmlCache = '';

// Función que se llamará al cargar la vista
function initVisorKds() {
    visorCargarAreas();
    
    // Limpiar timer anterior si existe
    if (visorKdsRefreshTimer) {
        clearInterval(visorKdsRefreshTimer);
    }
    
    // Iniciar auto refresco
    visorKdsRefreshTimer = setInterval(visorCargarPedidos, 5000);
}

// Al salir del módulo, detener el timer
$(window).on('hashchange', function() {
    if (window.location.hash !== '#kds/visor' && visorKdsRefreshTimer) {
        clearInterval(visorKdsRefreshTimer);
        visorKdsRefreshTimer = null;
    }
});

// Llamada inicial manual (se invoca aquí porque app.js carga el script primero, 
// o bien se puede llamar directamente al final de visor.php)
setTimeout(initVisorKds, 300);

async function visorCargarAreas() {
    try {
        let res = await fetch('features/mesas/controller_areas.php?action=list');
        let data = await res.json();
        
        let select = document.getElementById('visorKdsAreaSelect');
        if (!select) return; // Puede que ya no estemos en la vista
        
        select.innerHTML = '<option value="">-- Todas las Áreas --</option>';
        if (data.status === 'ok') {
            data.data.forEach(area => {
                select.innerHTML += `<option value="${area.id}">${area.nombre}</option>`;
            });
        }
        
        // Cargar pedidos inmediatamente después
        visorCargarPedidos();
    } catch(e) {
        console.error("Error cargando áreas KDS", e);
    }
}

function visorCambiarArea() {
    visorHtmlCache = ''; // Resetear cache para forzar render
    visorCargarPedidos();
}

async function visorCargarPedidos() {
    let select = document.getElementById('visorKdsAreaSelect');
    if (!select) return; // Si salimos de la vista

    let id_area = select.value;
    // Si no hay id_area (Todas las áreas), mandamos 0 o vacío (el backend asume "todos" si no está presente o es vacío)
    let url = 'features/kds/controller_kds.php?action=pedidos';
    if (id_area) {
        url += '&id_areaproduccion=' + id_area;
    }

    try {
        let res = await fetch(url);
        let data = await res.json();
        
        if (data.status === 'ok') {
            visorRenderizarPedidos(data.data);
        }
    } catch(e) {
        console.error("Error al refrescar Visor KDS", e);
    }
}

function visorRenderizarPedidos(pedidos) {
    const container = document.getElementById('visorKdsContainer');
    if (!container) return;

    if (pedidos.length === 0) {
        let emptyHtml = `
        <div class="visor-empty-state">
            <i data-lucide="check-circle" style="width: 64px; height: 64px; color: #10b981;"></i>
            <h3 class="mt-3 text-dark">¡Todo al día!</h3>
            <p>No hay pedidos pendientes en esta estación.</p>
        </div>`;
        if (visorHtmlCache !== emptyHtml) {
            container.innerHTML = emptyHtml;
            visorHtmlCache = emptyHtml;
            if (typeof lucide !== 'undefined') lucide.createIcons();
        }
        return;
    }

    let html = '';
    pedidos.forEach(p => {
        let esUrgente = p.minutos_transcurridos >= 15; // 15 minutos en rojo
        let urgentClass = esUrgente ? 'urgent' : '';
        let timerDisplay = p.minutos_transcurridos + ' min';
        
        let tipoLabel = p.tipo_codigo === 'salon' ? 'Mesa ' + (p.nombre_mesa||'') : (p.tipo_pedido||'Delivery');
        let clienteLabel = p.cliente_nombre ? ' - ' + p.cliente_nombre : '';

        html += `
        <div class="visor-card">
            <div class="visor-card-header ${urgentClass}">
                <div>
                    <div class="visor-order-number">${p.numero_pedido}</div>
                    <div class="visor-order-meta">${tipoLabel}${clienteLabel}</div>
                </div>
                <div class="visor-order-timer ${urgentClass}">
                    <i data-lucide="clock" style="width:14px;height:14px;"></i> ${timerDisplay}
                </div>
            </div>
            <div class="visor-card-body">
        `;
        
        p.items.forEach(item => {
            let btnClass = item.estado_kds === 'listo' ? 'listo' : '';
            let notasHtml = item.notas ? `<div class="visor-item-notes"><i data-lucide="alert-circle" style="width:12px;height:12px;"></i> ${item.notas}</div>` : '';
            
            html += `
                <div class="visor-item ${btnClass}" onclick="visorMarcarItem(${item.kds_id}, '${item.estado_kds}')" style="cursor: pointer;">
                    <div class="w-100">
                        <div class="d-flex align-items-center">
                            <span class="visor-item-qty">${item.quantity}x</span>
                            <span class="visor-item-name">${item.nombre_item}</span>
                        </div>
                        ${notasHtml}
                    </div>
                </div>
            `;
        });
        
        html += `
            </div>
        </div>`;
    });
    
    if(visorHtmlCache !== html) {
        container.innerHTML = html;
        visorHtmlCache = html;
        if (typeof lucide !== 'undefined') lucide.createIcons();
    }
}

async function visorMarcarItem(kds_id, currentStatus) {
    if (currentStatus === 'listo') return; // Ya está tachado
    
    // Preguntar confirmación antes de tachar (es el administrador)
    let conf = await Swal.fire({
        title: '¿Marcar como Listo?',
        text: 'Esto avisará a caja/mozos que el plato está preparado.',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Sí, listo',
        cancelButtonText: 'Cancelar'
    });
    
    if (!conf.isConfirmed) return;

    try {
        let res = await fetch('features/kds/controller_kds.php?action=actualizar_estado', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                id_kds_pedido: kds_id,
                estado: 'listo'
            })
        });
        
        let data = await res.json();
        if (data.status === 'ok') {
            visorHtmlCache = ''; // forzar redibujado
            visorCargarPedidos();
        } else {
            Swal.fire('Error', data.message || 'No se pudo actualizar', 'error');
        }
    } catch(e) {
        Swal.fire('Error', 'Error de red', 'error');
    }
}
