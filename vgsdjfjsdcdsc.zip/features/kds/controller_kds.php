<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../config/database.php';

// Check if user is logged in (Role 'cocina' or 'admin' or 'cajero')
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'No autorizado']);
    exit;
}

$db = Database::getInstance()->getConnection();
$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'pantallas_activas':
            $stmt = $db->query("SELECT id, nombre, id_areaproduccion FROM kds_pantallas WHERE estado = 1");
            echo json_encode(['status' => 'ok', 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
            break;

        case 'pedidos':
            $id_areaproduccion = intval($_GET['id_areaproduccion'] ?? 0);
            if (!$id_areaproduccion) {
                echo json_encode(['status' => 'error', 'message' => 'Área de producción requerida']);
                break;
            }

            // Seleccionar todos los items pendientes o en preparación para esta área
            // Se agruparán en el frontend por order_id
            $sql = "SELECT k.id as kds_id, k.estado_kds, k.id_order, o.numero_pedido, o.created_at, 
                           t.nombre as tipo_pedido, t.codigo as tipo_codigo, 
                           t.badge_bg, t.badge_color, t.badge_border,
                           d.nombre_item, d.quantity, d.notas,
                           COALESCE(od.customer_name, op.customer_name) as cliente_nombre,
                           m.numero as nombre_mesa
                    FROM kds_pedidos k 
                    JOIN orders o ON k.id_order = o.id
                    JOIN order_details d ON k.id_order_detail = d.id
                    LEFT JOIN tipo_orden t ON o.tipo_orden_id = t.id
                    LEFT JOIN order_delivery od ON o.id = od.order_id
                    LEFT JOIN order_pickup op ON o.id = op.order_id
                    LEFT JOIN order_salon os ON o.id = os.order_id
                    LEFT JOIN mesas m ON os.table_id = m.id
                    WHERE k.id_areaproduccion = ? AND k.estado_kds != 'listo'
                    ORDER BY o.created_at ASC";
            
            $stmt = $db->prepare($sql);
            $stmt->execute([$id_areaproduccion]);
            $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Agrupar por order_id
            $pedidos = [];
            foreach ($items as $item) {
                $oid = $item['id_order'];
                if (!isset($pedidos[$oid])) {
                    // Calcular tiempo transcurrido
                    $datetime1 = new DateTime($item['created_at']);
                    $datetime2 = new DateTime();
                    $interval = $datetime1->diff($datetime2);
                    $minutos_transcurridos = ($interval->days * 24 * 60) + ($interval->h * 60) + $interval->i;

                    $pedidos[$oid] = [
                        'order_id' => $oid,
                        'numero_pedido' => $item['numero_pedido'],
                        'tipo_pedido' => $item['tipo_pedido'],
                        'tipo_codigo' => $item['tipo_codigo'],
                        'badge_bg' => $item['badge_bg'],
                        'badge_color' => $item['badge_color'],
                        'badge_border' => $item['badge_border'],
                        'cliente_nombre' => $item['cliente_nombre'],
                        'nombre_mesa' => $item['nombre_mesa'],
                        'minutos_transcurridos' => $minutos_transcurridos,
                        'items' => []
                    ];
                }
                $pedidos[$oid]['items'][] = [
                    'kds_id' => $item['kds_id'],
                    'nombre_item' => $item['nombre_item'],
                    'quantity' => $item['quantity'],
                    'notas' => $item['notas'],
                    'estado_kds' => $item['estado_kds']
                ];
            }

            echo json_encode(['status' => 'ok', 'data' => array_values($pedidos)]);
            break;

        case 'actualizar_estado':
            $data = json_decode(file_get_contents('php://input'), true);
            $kds_id = intval($data['kds_id'] ?? 0);
            $nuevo_estado = $data['estado'] ?? 'listo'; // 'pendiente', 'en_preparacion', 'listo'
            
            if ($kds_id > 0) {
                $stmt = $db->prepare("UPDATE kds_pedidos SET estado_kds = ? WHERE id = ?");
                $stmt->execute([$nuevo_estado, $kds_id]);
                echo json_encode(['status' => 'ok', 'message' => 'Estado actualizado']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'ID inválido']);
            }
            break;

        default:
            echo json_encode(['status' => 'error', 'message' => 'Acción no válida']);
            break;
    }
} catch (Exception $e) {
    error_log("Error en controller_kds: " . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => 'Error interno del servidor']);
}
