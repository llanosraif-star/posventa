<style>
    /* Estilos adaptados del KDS original para el visor interno */
    #visorKdsContainer * {
        box-sizing: border-box;
    }
    
    .visor-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 20px;
        align-items: flex-start;
        padding-top: 10px;
    }

    .visor-card {
        background-color: #1e293b;
        border-radius: 12px;
        border: 1px solid #334155;
        box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1);
        overflow: hidden;
        animation: fadeIn 0.3s ease-in-out;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .visor-card-header {
        padding: 12px 15px;
        border-bottom: 1px solid #334155;
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
    }
    
    .visor-card-header.urgent {
        background-color: #7f1d1d; /* Rojo para urgencias */
        border-bottom-color: #991b1b;
    }

    .visor-order-number {
        font-size: 1.25rem;
        font-weight: 700;
        color: #f8fafc;
        margin-bottom: 2px;
    }
    
    .visor-order-meta {
        font-size: 0.8rem;
        color: #94a3b8;
    }

    .visor-order-timer {
        font-size: 1.1rem;
        font-weight: 600;
        background: #0f172a;
        padding: 4px 10px;
        border-radius: 6px;
        color: #22d3ee;
    }
    
    .visor-order-timer.urgent { color: #fca5a5; background: rgba(0,0,0,0.2); }

    /* Items */
    .visor-item {
        padding: 12px 15px;
        border-bottom: 1px solid #334155;
        display: flex;
        justify-content: space-between;
        align-items: center;
        transition: background-color 0.2s;
    }

    .visor-item:last-child { border-bottom: none; }
    
    .visor-item:hover { background-color: #334155; }
    
    .visor-item.listo {
        opacity: 0.5;
        text-decoration: line-through;
        background-color: #064e3b; /* Verde oscuro */
    }
    
    .visor-item-qty {
        font-weight: 700;
        color: #38bdf8;
        background: rgba(56, 189, 248, 0.1);
        padding: 2px 8px;
        border-radius: 4px;
        margin-right: 10px;
    }

    .visor-item-name {
        font-size: 1.1rem;
        font-weight: 500;
        color: #e2e8f0;
    }
    
    .visor-item-notes {
        font-size: 0.85rem;
        color: #fca5a5;
        margin-top: 4px;
        font-style: italic;
    }
    
    .visor-empty-state {
        text-align: center;
        padding: 80px 20px;
        color: #64748b;
        grid-column: 1 / -1;
    }
</style>

<div class="container-fluid py-4" style="background-color: #f8fafc; min-height: 85vh;">
    <!-- Encabezado del visor -->
    <div class="d-flex justify-content-between align-items-center mb-4 p-3 bg-white rounded shadow-sm border border-light">
        <h3 class="fw-bold mb-0 text-dark d-flex align-items-center">
            <i data-lucide="monitor" class="me-3" style="color: #f472b6;"></i> 
            Visor de Comandas (KDS)
        </h3>
        
        <div class="d-flex gap-3 align-items-center">
            <span class="text-muted fw-bold small">Ver Área:</span>
            <select id="visorKdsAreaSelect" class="form-select border-secondary-subtle fw-bold" style="width: 250px; background-color: #f1f5f9;" onchange="visorCambiarArea()">
                <option value="">Cargando áreas...</option>
            </select>
            
            <button class="btn btn-outline-secondary d-flex align-items-center justify-content-center" style="width: 38px; height: 38px; padding: 0;" onclick="visorCargarPedidos()" title="Refrescar">
                <i data-lucide="refresh-cw" style="width: 16px;"></i>
            </button>
        </div>
    </div>
    
    <!-- Contenedor Grid KDS -->
    <div id="visorKdsContainer" class="visor-grid">
        <div class="visor-empty-state">
            <i data-lucide="loader" class="fa-spin mb-3" style="width: 40px; height: 40px;"></i>
            <h5>Sincronizando con el servidor...</h5>
        </div>
    </div>
</div>
