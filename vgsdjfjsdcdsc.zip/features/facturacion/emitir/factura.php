<!--begin::App Content Header-->
<div class="app-content-header">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-sm-6">
                <h4 class="mb-0 d-flex align-items-center text-dark" style="font-weight: 600; font-size: 22px;">
                    <i data-lucide="file-text" style="width:22px;height:22px;margin-right:8px;"></i> Emitir Factura
                </h4>
            </div>
        </div>
    </div>
</div>
<!--end::App Content Header-->

<!--begin::App Content-->
<div class="app-content">
    <div class="container-fluid">
        <form id="form-emitir-factura">
            <!-- Datos del documento -->
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-white border-bottom-0 pt-4 pb-0">
                    <h5 class="card-title fw-bold" style="font-size: 1.1rem;">Datos del documento</h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label fw-semibold">Serie</label>
                            <input type="text" id="f-serie" class="form-control font-monospace text-uppercase" value="F001" maxlength="4" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold">Fecha emisión</label>
                            <input type="date" id="f-fecha" class="form-control" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold">Moneda</label>
                            <select id="f-moneda" class="form-select">
                                <option value="PEN" selected>PEN (Soles)</option>
                                <option value="USD">USD (Dólares)</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold">Forma de pago</label>
                            <select id="f-pago" class="form-select">
                                <option value="Contado" selected>Contado</option>
                                <option value="Credito">Crédito</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Cliente -->
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-white border-bottom-0 pt-4 pb-0 d-flex justify-content-between align-items-center">
                    <h5 class="card-title fw-bold mb-0" style="font-size: 1.1rem;">Cliente</h5>
                    <button type="button" class="btn btn-sm btn-outline-primary" onclick="facBuscarCliente()">
                        <i data-lucide="search" style="width:16px;height:16px;"></i> Buscar Cliente
                    </button>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label fw-semibold">RUC</label>
                            <input type="text" id="c-num-doc" class="form-control" placeholder="RUC" required readonly>
                            <input type="hidden" id="c-tipo-doc" value="6">
                        </div>
                        <div class="col-md-9">
                            <label class="form-label fw-semibold">Razón Social</label>
                            <input type="text" id="c-razon-social" class="form-control" placeholder="Razón Social" required readonly>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label fw-semibold">Dirección</label>
                            <input type="text" id="c-direccion" class="form-control" placeholder="Dirección Fiscal (opcional)" readonly>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Subcategorias -->
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-white border-bottom-0 pt-4 pb-2 d-flex justify-content-between align-items-center">
                    <h5 class="card-title fw-bold mb-0" style="font-size: 1.1rem;">Subcategorias / Servicios</h5>
                    <button type="button" class="btn btn-sm btn-primary" onclick="facAgregarSubcategoria()">
                        <i data-lucide="plus" style="width:16px;height:16px;"></i> Agregar Subcategoria
                    </button>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0" id="tabla-items-factura">
                            <thead class="table-light">
                                <tr>
                                    <th width="10%">Cant.</th>
                                    <th width="10%">Unidad</th>
                                    <th width="40%">Descripción</th>
                                    <th width="15%">V. Unit.</th>
                                    <th width="15%">Total</th>
                                    <th width="10%" class="text-center">Quitar</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Los items se insertarán aquí dinámicamente -->
                                <tr id="row-empty">
                                    <td colspan="6" class="text-center text-muted py-4">No hay subcategorias agregados.</td>
                                </tr>
                            </tbody>
                            <tfoot class="table-light d-none" id="tfoot-totales">
                                <tr>
                                    <td colspan="4" class="text-end fw-bold">OP. GRAVADA</td>
                                    <td class="text-end fw-bold" id="tot-gravada">0.00</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td colspan="4" class="text-end fw-bold">IGV (18%)</td>
                                    <td class="text-end fw-bold" id="tot-igv">0.00</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td colspan="4" class="text-end fw-bold text-primary fs-5">TOTAL A PAGAR</td>
                                    <td class="text-end fw-bold text-primary fs-5" id="tot-total">0.00</td>
                                    <td></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Botón Guardar -->
            <div class="d-flex justify-content-end mb-4">
                <button type="submit" id="btn-emitir-factura" class="btn btn-primary btn-lg shadow-sm px-5 fw-bold">
                    <i data-lucide="check-circle" style="width:20px;height:20px;margin-right:8px;"></i> Emitir Factura
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Buscar Cliente -->
<div class="modal fade" id="modalBuscarCliente" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold">Buscar Cliente</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" id="input-search-cliente" placeholder="Buscar por RUC o Razón Social...">
                    <button class="btn btn-primary" type="button" onclick="buscarClienteVista()"><i data-lucide="search"></i> Buscar</button>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>RUC/DNI</th>
                                <th>Razón Social</th>
                                <th>Acción</th>
                            </tr>
                        </thead>
                        <tbody id="tbody-clientes-search">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Agregar Subcategoria -->
<div class="modal fade" id="modalAgregarSubcategoria" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold">Agregar Subcategoria</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="form-item-temp">
                    <div class="row g-3">
                        <div class="col-md-8">
                            <label class="form-label fw-semibold">Descripción</label>
                            <input type="text" class="form-control" id="item-desc" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Código (opcional)</label>
                            <input type="text" class="form-control" id="item-codigo">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Cantidad</label>
                            <input type="number" class="form-control" id="item-cant" value="1" min="0.01" step="0.01" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Valor Unitario (Sin IGV)</label>
                            <input type="number" class="form-control" id="item-vu" min="0" step="0.01" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Unidad Medida</label>
                            <select class="form-select" id="item-unidad">
                                <option value="NIU">NIU (Unidades)</option>
                                <option value="ZZ">ZZ (Servicios)</option>
                                <option value="KGM">KGM (Kilogramos)</option>
                            </select>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end mt-4">
                        <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Añadir a Factura</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="features/facturacion/emitir/factura.js?v=<?= time() ?>"></script>
