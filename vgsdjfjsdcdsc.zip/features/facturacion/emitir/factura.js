let facturaItems = [];
let modalBuscarClienteInstance = null;
let modalAgregarSubcategoriaInstance = null;

$(document).ready(function() {
    // Inicializar Fechas
    const hoy = new Date().toISOString().split('T')[0];
    $('#f-fecha').val(hoy);
    
    // Inicializar Modales
    if (document.getElementById('modalBuscarCliente')) {
        modalBuscarClienteInstance = new bootstrap.Modal(document.getElementById('modalBuscarCliente'));
    }
    if (document.getElementById('modalAgregarSubcategoria')) {
        modalAgregarSubcategoriaInstance = new bootstrap.Modal(document.getElementById('modalAgregarSubcategoria'));
    }

    // Bind form item temp
    $('#form-item-temp').on('submit', function(e) {
        e.preventDefault();
        
        const cant = parseFloat($('#item-cant').val());
        const vu = parseFloat($('#item-vu').val()); // Valor unitario (sin IGV)
        const desc = $('#item-desc').val();
        
        const item = {
            codigo: $('#item-codigo').val() || '001',
            descripcion: desc,
            unidad: $('#item-unidad').val(),
            cantidad: cant,
            precio_unitario: (vu * 1.18).toFixed(2), // La API Sunat/Factus espera precio con IGV o nosotros mandamos precio_unitario (incluye IGV en el template Tailwind). Wait, tip_afe_igv = 10 implica q el precio_unitario incluye igv en ese demo.
            valor_unitario: vu, // Lo guardamos para mostrar
            tip_afe_igv: "10" 
        };
        
        // En App.api de Facturacion (Factus/Greenter) se envía precio_unitario CON IGV si es gravado.
        // Vamos a mandar precio unitario = VU * 1.18.
        
        facturaItems.push(item);
        renderTablaItems();
        
        this.reset();
        $('#item-cant').val('1');
        modalAgregarSubcategoriaInstance.hide();
    });

    // Submit Venta
    $('#form-emitir-factura').on('submit', async function(e) {
        e.preventDefault();
        
        if (!App || !App.api) {
            Swal.fire('Error', 'API de facturación no inicializada.', 'error');
            return;
        }
        
        if (!$('#c-num-doc').val()) {
            Swal.fire('Atención', 'Debe seleccionar un cliente (RUC).', 'warning');
            return;
        }
        
        if (facturaItems.length === 0) {
            Swal.fire('Atención', 'Debe agregar al menos un subcategoria o servicio.', 'warning');
            return;
        }

        const payload = {
            serie: $('#f-serie').val().toUpperCase(),
            fecha_emision: $('#f-fecha').val(),
            tipo_moneda: $('#f-moneda').val(),
            forma_pago: $('#f-pago').val(),
            cliente: {
                tipo_doc: $('#c-tipo-doc').val(), // 6 para RUC
                num_doc: $('#c-num-doc').val(),
                razon_social: $('#c-razon-social').val(),
                direccion: $('#c-direccion').val()
            },
            items: facturaItems.map(it => ({
                codigo: it.codigo,
                descripcion: it.descripcion,
                unidad: it.unidad,
                cantidad: parseFloat(it.cantidad),
                precio_unitario: parseFloat(it.precio_unitario),
                tip_afe_igv: it.tip_afe_igv
            }))
        };

        const btn = document.getElementById('btn-emitir-factura');
        const oldHtml = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span> Emitiendo...';

        try {
            const res = await App.api.crearFactura(payload);
            // Mostrar modal de respuesta heredado
            if (typeof App.ResponseModal !== 'undefined') {
                new App.ResponseModal({ response: res, tipo: 'facturas', pdfFormat: 'ticket-80' }).render(document.body);
            } else {
                Swal.fire('Éxito', 'Factura generada correctamente', 'success');
            }
            // Reset
            facturaItems = [];
            renderTablaItems();
            $('#c-num-doc, #c-razon-social, #c-direccion').val('');
        } catch(error) {
            Swal.fire('Error al emitir', error.message || 'Ocurrió un error', 'error');
        } finally {
            btn.disabled = false;
            btn.innerHTML = oldHtml;
        }
    });
});

function facBuscarCliente() {
    if (modalBuscarClienteInstance) {
        $('#tbody-clientes-search').html('<tr><td colspan="3" class="text-center text-muted">Escriba el RUC o Nombre para buscar en la BD local</td></tr>');
        $('#input-search-cliente').val('');
        modalBuscarClienteInstance.show();
    }
}

async function buscarClienteVista() {
    const q = $('#input-search-cliente').val().trim();
    if (q.length < 2) return;
    
    $('#tbody-clientes-search').html('<tr><td colspan="3" class="text-center"><div class="spinner-border text-primary"></div></td></tr>');
    
    try {
        const res = await fetch('features/clientes/controller_clientes.php?action=list');
        const json = await res.json();
        if (json.status === 'ok') {
            const list = json.data.filter(c => c.ruc.includes(q) || c.nombre_empresa.toLowerCase().includes(q.toLowerCase()));
            let html = '';
            list.forEach(c => {
                // Solo clientes con RUC para facturas
                if (c.ruc && c.ruc.length === 11) {
                    html += `<tr>
                        <td>${c.ruc}</td>
                        <td>${c.nombre_empresa}</td>
                        <td>
                            <button class="btn btn-sm btn-outline-success" onclick="facSeleccionarCliente('${c.ruc}', '${c.nombre_empresa}', '${c.direccion || ''}')">Seleccionar</button>
                        </td>
                    </tr>`;
                }
            });
            if (html === '') {
                html = '<tr><td colspan="3" class="text-center">No se encontraron clientes con RUC válido (11 dígitos).</td></tr>';
            }
            $('#tbody-clientes-search').html(html);
        }
    } catch(e) {
        $('#tbody-clientes-search').html('<tr><td colspan="3" class="text-center text-danger">Error al buscar clientes</td></tr>');
    }
}

function facSeleccionarCliente(ruc, razon, dir) {
    $('#c-num-doc').val(ruc);
    $('#c-razon-social').val(razon);
    $('#c-direccion').val(dir);
    $('#c-tipo-doc').val('6');
    if (modalBuscarClienteInstance) modalBuscarClienteInstance.hide();
}

function facAgregarSubcategoria() {
    if (modalAgregarSubcategoriaInstance) {
        modalAgregarSubcategoriaInstance.show();
    }
}

function facRemoverItem(index) {
    facturaItems.splice(index, 1);
    renderTablaItems();
}

function renderTablaItems() {
    const tbody = $('#tabla-items-factura tbody');
    const tfoot = $('#tfoot-totales');
    
    tbody.empty();
    
    if (facturaItems.length === 0) {
        tbody.append('<tr id="row-empty"><td colspan="6" class="text-center text-muted py-4">No hay subcategorias agregados.</td></tr>');
        tfoot.addClass('d-none');
        return;
    }
    
    tfoot.removeClass('d-none');
    let subtotalGravado = 0;
    
    facturaItems.forEach((it, i) => {
        // La API asume precio_unitario CON IGV si tip_afe_igv = 10
        // Monto = cant * valor_unitario
        const valorUnitario = parseFloat(it.valor_unitario);
        const cant = parseFloat(it.cantidad);
        const st = valorUnitario * cant;
        subtotalGravado += st;
        
        tbody.append(`
            <tr>
                <td>${cant}</td>
                <td><span class="badge bg-secondary">${it.unidad}</span></td>
                <td><strong>${it.descripcion}</strong><br><small class="text-muted">Cod: ${it.codigo}</small></td>
                <td>${valorUnitario.toFixed(2)}</td>
                <td>${st.toFixed(2)}</td>
                <td class="text-center">
                    <button type="button" class="btn btn-sm btn-outline-danger" onclick="facRemoverItem(${i})"><i data-lucide="trash-2" style="width:16px;height:16px;"></i></button>
                </td>
            </tr>
        `);
    });
    
    const igv = subtotalGravado * 0.18;
    const total = subtotalGravado + igv;
    
    $('#tot-gravada').text(subtotalGravado.toFixed(2));
    $('#tot-igv').text(igv.toFixed(2));
    $('#tot-total').text(total.toFixed(2));
    
    if (typeof lucide !== 'undefined') lucide.createIcons();
}
