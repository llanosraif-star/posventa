<!--begin::App Content Header-->
<div class="app-content-header">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-sm-6">
                <h4 class="mb-0 d-flex align-items-center text-dark" style="font-weight: 600; font-size: 22px;">
                    <i data-lucide="receipt" style="width:22px;height:22px;margin-right:8px;"></i> Emitir Boleta
                </h4>
            </div>
        </div>
    </div>
</div>
<!--end::App Content Header-->

<!--begin::App Content-->
<div class="app-content">
    <div class="container-fluid">
        <form id="form-emitir-boleta">
            <!-- Datos del documento -->
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-white border-bottom-0 pt-4 pb-0">
                    <h5 class="card-title fw-bold" style="font-size: 1.1rem;">Datos del documento</h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label fw-semibold">Serie</label>
                            <input type="text" id="b-serie" class="form-control font-monospace text-uppercase" value="B001" maxlength="4" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold">Fecha emisión</label>
                            <input type="date" id="b-fecha" class="form-control" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold">Moneda</label>
                            <select id="b-moneda" class="form-select">
                                <option value="PEN" selected>PEN (Soles)</option>
                                <option value="USD">USD (Dólares)</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold">Forma de pago</label>
                            <select id="b-pago" class="form-select">
                                <option value="Contado" selected>Contado</option>
                                <option value="Credito">Crédito</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Cliente -->
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-white border-bottom-0 pt-4 pb-0 d-flex justify-content-between align-items-center">
                    <h5 class="card-title fw-bold mb-0" style="font-size: 1.1rem;">Cliente (Opcional si es menor a S/ 700)</h5>
                    <button type="button" class="btn btn-sm btn-outline-primary" onclick="bolBuscarCliente()">
                        <i data-lucide="search" style="width:16px;height:16px;"></i> Buscar Cliente
                    </button>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label fw-semibold">Tipo Doc.</label>
                            <select id="bc-tipo-doc" class="form-select">
                                <option value="1">1 - DNI</option>
                                <option value="6">6 - RUC</option>
                                <option value="4">4 - CARNET EXTR.</option>
                                <option value="-">Sin Documento</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold">Número</label>
                            <input type="text" id="bc-num-doc" class="form-control" placeholder="Número Doc." required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Nombres / Razón Social</label>
                            <input type="text" id="bc-razon-social" class="form-control" placeholder="Nombre completo o Razón Social" required>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label fw-semibold">Dirección</label>
                            <input type="text" id="bc-direccion" class="form-control" placeholder="Dirección (opcional)">
                        </div>
                    </div>
                </div>
            </div>

            <!-- Subcategorias -->
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-white border-bottom-0 pt-4 pb-2 d-flex justify-content-between align-items-center">
                    <h5 class="card-title fw-bold mb-0" style="font-size: 1.1rem;">Subcategorias / Servicios</h5>
                    <button type="button" class="btn btn-sm btn-primary" onclick="bolAgregarSubcategoria()">
                        <i data-lucide="plus" style="width:16px;height:16px;"></i> Agregar Subcategoria
                    </button>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0" id="tabla-items-boleta">
                            <thead class="table-light">
                                <tr>
                                    <th width="10%">Cant.</th>
                                    <th width="10%">Unidad</th>
                                    <th width="40%">Descripción</th>
                                    <th width="15%">V. Unit.</th>
                                    <th width="15%">Total</th>
                                    <th width="10%" class="text-center">Quitar</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Los items se insertarán aquí dinámicamente -->
                                <tr id="row-empty-bol">
                                    <td colspan="6" class="text-center text-muted py-4">No hay subcategorias agregados.</td>
                                </tr>
                            </tbody>
                            <tfoot class="table-light d-none" id="tfoot-totales-bol">
                                <tr>
                                    <td colspan="4" class="text-end fw-bold">OP. GRAVADA</td>
                                    <td class="text-end fw-bold" id="tot-gravada-bol">0.00</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td colspan="4" class="text-end fw-bold">IGV (18%)</td>
                                    <td class="text-end fw-bold" id="tot-igv-bol">0.00</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td colspan="4" class="text-end fw-bold text-primary fs-5">TOTAL A PAGAR</td>
                                    <td class="text-end fw-bold text-primary fs-5" id="tot-total-bol">0.00</td>
                                    <td></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Botón Guardar -->
            <div class="d-flex justify-content-end mb-4">
                <button type="submit" id="btn-emitir-boleta" class="btn btn-primary btn-lg shadow-sm px-5 fw-bold">
                    <i data-lucide="check-circle" style="width:20px;height:20px;margin-right:8px;"></i> Emitir Boleta
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Buscar Cliente -->
<div class="modal fade" id="modalBuscarClienteBol" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold">Buscar Cliente</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" id="input-search-cliente-bol" placeholder="Buscar por DNI, RUC o Nombre...">
                    <button class="btn btn-primary" type="button" onclick="buscarClienteVistaBol()"><i data-lucide="search"></i> Buscar</button>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Doc.</th>
                                <th>Nombre / Razón Social</th>
                                <th>Acción</th>
                            </tr>
                        </thead>
                        <tbody id="tbody-clientes-search-bol">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Agregar Subcategoria -->
<div class="modal fade" id="modalAgregarSubcategoriaBol" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold">Agregar Subcategoria</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="form-item-temp-bol">
                    <div class="row g-3">
                        <div class="col-md-8">
                            <label class="form-label fw-semibold">Descripción</label>
                            <input type="text" class="form-control" id="item-desc-bol" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Código (opcional)</label>
                            <input type="text" class="form-control" id="item-codigo-bol">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Cantidad</label>
                            <input type="number" class="form-control" id="item-cant-bol" value="1" min="0.01" step="0.01" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Valor Unitario (Sin IGV)</label>
                            <input type="number" class="form-control" id="item-vu-bol" min="0" step="0.01" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Unidad Medida</label>
                            <select class="form-select" id="item-unidad-bol">
                                <option value="NIU">NIU (Unidades)</option>
                                <option value="ZZ">ZZ (Servicios)</option>
                                <option value="KGM">KGM (Kilogramos)</option>
                            </select>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end mt-4">
                        <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Añadir a Boleta</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="features/facturacion/emitir/boleta.js?v=<?= time() ?>"></script>
