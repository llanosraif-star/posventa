let boletaItems = [];
let modalBuscarClienteBolInstance = null;
let modalAgregarSubcategoriaBolInstance = null;

$(document).ready(function() {
    // Inicializar Fechas
    const hoy = new Date().toISOString().split('T')[0];
    $('#b-fecha').val(hoy);
    
    // Inicializar Modales
    if (document.getElementById('modalBuscarClienteBol')) {
        modalBuscarClienteBolInstance = new bootstrap.Modal(document.getElementById('modalBuscarClienteBol'));
    }
    if (document.getElementById('modalAgregarSubcategoriaBol')) {
        modalAgregarSubcategoriaBolInstance = new bootstrap.Modal(document.getElementById('modalAgregarSubcategoriaBol'));
    }

    // Si el tipo de doc es "Sin Documento", deshabilitar el input
    $('#bc-tipo-doc').on('change', function() {
        if ($(this).val() === '-') {
            $('#bc-num-doc').val('-').prop('readonly', true);
            $('#bc-razon-social').val('Clientes Varios');
        } else {
            $('#bc-num-doc').val('').prop('readonly', false);
            $('#bc-razon-social').val('');
        }
    });

    // Bind form item temp
    $('#form-item-temp-bol').on('submit', function(e) {
        e.preventDefault();
        
        const cant = parseFloat($('#item-cant-bol').val());
        const vu = parseFloat($('#item-vu-bol').val()); // Valor unitario (sin IGV)
        const desc = $('#item-desc-bol').val();
        
        const item = {
            codigo: $('#item-codigo-bol').val() || '001',
            descripcion: desc,
            unidad: $('#item-unidad-bol').val(),
            cantidad: cant,
            precio_unitario: (vu * 1.18).toFixed(2), 
            valor_unitario: vu, 
            tip_afe_igv: "10" 
        };
        
        boletaItems.push(item);
        renderTablaItemsBol();
        
        this.reset();
        $('#item-cant-bol').val('1');
        modalAgregarSubcategoriaBolInstance.hide();
    });

    // Submit Venta
    $('#form-emitir-boleta').on('submit', async function(e) {
        e.preventDefault();
        
        if (!App || !App.api) {
            Swal.fire('Error', 'API de facturación no inicializada.', 'error');
            return;
        }
        
        if (boletaItems.length === 0) {
            Swal.fire('Atención', 'Debe agregar al menos un subcategoria o servicio.', 'warning');
            return;
        }
        
        let subtotalGravado = boletaItems.reduce((acc, it) => acc + (parseFloat(it.valor_unitario) * parseFloat(it.cantidad)), 0);
        let total = subtotalGravado * 1.18;
        
        if (total >= 700) {
            if ($('#bc-tipo-doc').val() === '-' || !$('#bc-num-doc').val() || $('#bc-num-doc').val() === '-') {
                Swal.fire('Atención', 'Para boletas mayores a S/ 700 es OBLIGATORIO ingresar el DNI o documento del cliente.', 'warning');
                return;
            }
        }

        const payload = {
            serie: $('#b-serie').val().toUpperCase(),
            fecha_emision: $('#b-fecha').val(),
            tipo_moneda: $('#b-moneda').val(),
            forma_pago: $('#b-pago').val(),
            cliente: {
                tipo_doc: $('#bc-tipo-doc').val(), 
                num_doc: $('#bc-num-doc').val(),
                razon_social: $('#bc-razon-social').val(),
                direccion: $('#bc-direccion').val()
            },
            items: boletaItems.map(it => ({
                codigo: it.codigo,
                descripcion: it.descripcion,
                unidad: it.unidad,
                cantidad: parseFloat(it.cantidad),
                precio_unitario: parseFloat(it.precio_unitario),
                tip_afe_igv: it.tip_afe_igv
            }))
        };

        const btn = document.getElementById('btn-emitir-boleta');
        const oldHtml = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span> Emitiendo...';

        try {
            const res = await App.api.crearBoleta(payload);
            if (typeof App.ResponseModal !== 'undefined') {
                new App.ResponseModal({ response: res, tipo: 'boletas', pdfFormat: 'ticket-80' }).render(document.body);
            } else {
                Swal.fire('Éxito', 'Boleta generada correctamente', 'success');
            }
            // Reset
            boletaItems = [];
            renderTablaItemsBol();
            $('#bc-num-doc, #bc-razon-social, #bc-direccion').val('');
            $('#bc-tipo-doc').val('1').trigger('change');
        } catch(error) {
            Swal.fire('Error al emitir', error.message || 'Ocurrió un error', 'error');
        } finally {
            btn.disabled = false;
            btn.innerHTML = oldHtml;
        }
    });
});

function bolBuscarCliente() {
    if (modalBuscarClienteBolInstance) {
        $('#tbody-clientes-search-bol').html('<tr><td colspan="3" class="text-center text-muted">Escriba el DNI, RUC o Nombre para buscar</td></tr>');
        $('#input-search-cliente-bol').val('');
        modalBuscarClienteBolInstance.show();
    }
}

async function buscarClienteVistaBol() {
    const q = $('#input-search-cliente-bol').val().trim();
    if (q.length < 2) return;
    
    $('#tbody-clientes-search-bol').html('<tr><td colspan="3" class="text-center"><div class="spinner-border text-primary"></div></td></tr>');
    
    try {
        const res = await fetch('features/clientes/controller_clientes.php?action=list');
        const json = await res.json();
        if (json.status === 'ok') {
            const list = json.data.filter(c => (c.dni && c.dni.includes(q)) || (c.ruc && c.ruc.includes(q)) || c.nombre_empresa.toLowerCase().includes(q.toLowerCase()));
            let html = '';
            list.forEach(c => {
                let doc = c.dni || c.ruc || '-';
                let tipo = c.dni ? '1' : (c.ruc ? '6' : '-');
                html += `<tr>
                    <td>${doc}</td>
                    <td>${c.nombre_empresa}</td>
                    <td>
                        <button class="btn btn-sm btn-outline-success" onclick="bolSeleccionarCliente('${tipo}', '${doc}', '${c.nombre_empresa}', '${c.direccion || ''}')">Seleccionar</button>
                    </td>
                </tr>`;
            });
            if (html === '') html = '<tr><td colspan="3" class="text-center">No se encontraron clientes.</td></tr>';
            $('#tbody-clientes-search-bol').html(html);
        }
    } catch(e) {
        $('#tbody-clientes-search-bol').html('<tr><td colspan="3" class="text-center text-danger">Error al buscar clientes</td></tr>');
    }
}

function bolSeleccionarCliente(tipo, doc, razon, dir) {
    $('#bc-tipo-doc').val(tipo);
    $('#bc-num-doc').val(doc).prop('readonly', false);
    $('#bc-razon-social').val(razon);
    $('#bc-direccion').val(dir);
    if (modalBuscarClienteBolInstance) modalBuscarClienteBolInstance.hide();
}

function bolAgregarSubcategoria() {
    if (modalAgregarSubcategoriaBolInstance) modalAgregarSubcategoriaBolInstance.show();
}

function bolRemoverItem(index) {
    boletaItems.splice(index, 1);
    renderTablaItemsBol();
}

function renderTablaItemsBol() {
    const tbody = $('#tabla-items-boleta tbody');
    const tfoot = $('#tfoot-totales-bol');
    
    tbody.empty();
    
    if (boletaItems.length === 0) {
        tbody.append('<tr id="row-empty-bol"><td colspan="6" class="text-center text-muted py-4">No hay subcategorias agregados.</td></tr>');
        tfoot.addClass('d-none');
        return;
    }
    
    tfoot.removeClass('d-none');
    let subtotalGravado = 0;
    
    boletaItems.forEach((it, i) => {
        const valorUnitario = parseFloat(it.valor_unitario);
        const cant = parseFloat(it.cantidad);
        const st = valorUnitario * cant;
        subtotalGravado += st;
        
        tbody.append(`
            <tr>
                <td>${cant}</td>
                <td><span class="badge bg-secondary">${it.unidad}</span></td>
                <td><strong>${it.descripcion}</strong><br><small class="text-muted">Cod: ${it.codigo}</small></td>
                <td>${valorUnitario.toFixed(2)}</td>
                <td>${st.toFixed(2)}</td>
                <td class="text-center">
                    <button type="button" class="btn btn-sm btn-outline-danger" onclick="bolRemoverItem(${i})"><i data-lucide="trash-2" style="width:16px;height:16px;"></i></button>
                </td>
            </tr>
        `);
    });
    
    const igv = subtotalGravado * 0.18;
    const total = subtotalGravado + igv;
    
    $('#tot-gravada-bol').text(subtotalGravado.toFixed(2));
    $('#tot-igv-bol').text(igv.toFixed(2));
    $('#tot-total-bol').text(total.toFixed(2));
    
    if (typeof lucide !== 'undefined') lucide.createIcons();
}
