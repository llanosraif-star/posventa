var App = window.App || (window.App = {});

(function () {
  App.ResponseModal = class ResponseModal {
    constructor(opts) {
      this.response = opts.response;
      this.error = opts.error;
      this.tipo = opts.tipo;
      this.onClose = opts.onClose;

      this.success = !this.error && this.response && this.response.success;
      this.data = this.response && this.response.data;
      this.docId = this.data && this.data.id;
      this.numero = (this.data && this.data.numero_completo) || 'S/N';

      this.canShowPdf = this.success && this.docId && this.tipo;
      this.pdfFormat = opts.pdfFormat || 'ticket-80';
      this.pdfBlobUrl = null;
    }

    async render(container) {
      if (!this.canShowPdf) {
        var msg = (this.error && this.error.message) || 'Error desconocido';
        var errorsBlock = (this.error && this.error.errors)
          ? '<pre style="font-size: 0.75rem; color: rgb(185 28 28); background: rgb(254 242 242); border-radius: 0.5rem; padding: 0.75rem; text-align: left; max-height: 15rem; overflow: auto; width: 100%; font-family: monospace; white-space: pre-wrap;">'
              + App.escapeHtml(JSON.stringify(this.error.errors, null, 2)) + '</pre>'
          : '';
          
        Swal.fire({
            title: 'Error de Facturación',
            html: msg + '<br><br>' + errorsBlock,
            icon: 'error'
        }).then(() => {
            if (this.onClose) this.onClose();
        });
        return;
      }

      Swal.fire({title: 'Descargando PDF de SUNAT...', allowOutsideClick: false, didOpen: () => { Swal.showLoading(); }});

      try {
        var blob = await App.api.descargarPdf(this.tipo, this.docId, this.pdfFormat);
        this.pdfBlobUrl = URL.createObjectURL(blob);
        
        var titulo = this.tipo === 'facturas' ? 'FACTURA ELECTRÓNICA' : 'BOLETA ELECTRÓNICA';
        
        Swal.fire({
            title: `<div style="font-size: 1.15rem; color: #1f2937; margin-bottom: -10px; font-weight: bold;">${titulo}<br>${this.numero}</div>`,
            html: `
                <div style="height: 50vh; background: #525659; border-radius: 6px; padding: 4px; box-sizing: border-box; margin-bottom: 15px; margin-top: 15px;">
                     <iframe id="ticket-pdf-iframe" src="${this.pdfBlobUrl}" style="width: 100%; height: 100%; border: none; border-radius: 4px; background: white;"></iframe>
                </div>
                <div style="display: flex; gap: 8px; justify-content: flex-start; align-items: center; border-top: 1px solid #e5e7eb; padding-top: 15px;">
                    <button id="btn-print-pdf" class="btn text-white" style="background-color: #f97316; border-color: #f97316; padding: 6px 14px; font-weight: 500; border-radius: 6px; font-size: 14px; display: flex; align-items: center; gap: 5px;">
                        <i data-lucide="printer" style="width:16px;height:16px;"></i> Imprimir
                    </button>
                    <button id="btn-download-pdf" class="btn btn-light border" style="padding: 6px 14px; font-weight: 500; border-radius: 6px; font-size: 14px; color: #4b5563; display: flex; align-items: center; gap: 5px;">
                        <i data-lucide="download" style="width:16px;height:16px;"></i> Descargar
                    </button>
                    <button id="btn-close-pdf" class="btn btn-light border" style="padding: 6px 14px; font-weight: 500; border-radius: 6px; font-size: 14px; color: #4b5563; margin-left: auto;">
                        Cerrar
                    </button>
                </div>
            `,
            width: 480,
            showConfirmButton: false,
            showCloseButton: false,
            padding: '1.25em',
            didOpen: () => { 
                if (typeof lucide !== 'undefined') lucide.createIcons(); 
                document.getElementById('btn-print-pdf').addEventListener('click', () => {
                    let iframe = document.getElementById('ticket-pdf-iframe');
                    if (iframe) { iframe.contentWindow.print(); }
                });
                document.getElementById('btn-download-pdf').addEventListener('click', () => {
                    let a = document.createElement('a');
                    a.href = this.pdfBlobUrl;
                    a.download = this.numero + '.pdf';
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                });
                document.getElementById('btn-close-pdf').addEventListener('click', () => {
                    Swal.close();
                });
            }
        }).then(() => {
            if (this.pdfBlobUrl) URL.revokeObjectURL(this.pdfBlobUrl);
            if (this.onClose) this.onClose();
        });

      } catch (e) {
        console.error('Error cargando PDF:', e);
        Swal.fire('Error', 'No se pudo cargar el PDF de SUNAT', 'error').then(() => {
            if (this.onClose) this.onClose();
        });
      }
    }
  };
})();

