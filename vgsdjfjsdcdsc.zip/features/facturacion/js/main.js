// ================================================
// Facturación — Controlador Principal
// ================================================

// Cargar configuración de la BD de inmediato al cargar el script
App.loadConfig().then(function () {
    console.log('[Facturación] Config cargada:', App.isConfigured() ? 'API configurada ✓' : 'API NO configurada ✗');
}).catch(function (e) {
    console.error('[Facturación] Error cargando config:', e);
});

// Registrar MutationObserver para inicializar las pantallas cuando el SPA inyecte el HTML
document.addEventListener('DOMContentLoaded', function () {
    var contenido = document.getElementById('main-content');
    if (!contenido) return;

    var observer = new MutationObserver(function () {
        facInitConfigScreen();
        facInitDashboard();
        facInitLista();
    });

    observer.observe(contenido, { childList: true });
});

// ================================================
// PANTALLA: Configuración de API
// ================================================
function facInitConfigScreen() {
    var formConfig = document.getElementById('form-facturacion-config');
    if (!formConfig || formConfig.dataset.initialized) return;
    formConfig.dataset.initialized = 'true';

    // Esperar a que la config esté cargada desde BD antes de rellenar campos
    App.waitForConfig().then(function (cfg) {
        cfg = cfg || {};
        var elUrl    = document.getElementById('fc-base-url');
        var elKey    = document.getElementById('fc-api-key');
        var elSecret = document.getElementById('fc-api-secret');
        var elToken  = document.getElementById('fc-jsonpe-token');

        if (elUrl)    elUrl.value    = cfg.base_url     || '';
        if (elKey)    elKey.value    = cfg.api_key      || '';
        if (elSecret) elSecret.value = cfg.api_secret   || '';
        if (elToken)  elToken.value  = cfg.jsonpe_token || '';

        // Auto-cargar datos de empresa si ya hay credenciales
        if (cfg.api_key && cfg.api_secret) {
            facCargarEmpresaInfo();
        }
    }).catch(function (e) {
        console.error('[Facturación] Error al cargar config en pantalla:', e);
    });

    // Guardar configuración al enviar el formulario
    formConfig.addEventListener('submit', async function (e) {
        e.preventDefault();
        var btn = formConfig.querySelector('button[type="submit"]');
        var originalHtml = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Guardando...';

        try {
            await App.saveConfig({
                base_url:     document.getElementById('fc-base-url').value.trim(),
                api_key:      document.getElementById('fc-api-key').value.trim(),
                api_secret:   document.getElementById('fc-api-secret').value.trim(),
                jsonpe_token: document.getElementById('fc-jsonpe-token').value.trim()
            });
            Swal.fire({ icon: 'success', title: 'Guardado', text: 'Configuración guardada correctamente.', confirmButtonColor: '#0ea5e9' });
        } catch (err) {
            Swal.fire({ icon: 'error', title: 'Error al guardar', text: err.message });
        } finally {
            btn.disabled = false;
            btn.innerHTML = originalHtml;
            if (typeof lucide !== 'undefined') lucide.createIcons();
        }
    });
}

// ================================================
// Probar Conexión
// ================================================
window.facProbarConexion = async function () {
    var testKey    = document.getElementById('fc-api-key').value.trim();
    var testSecret = document.getElementById('fc-api-secret').value.trim();
    var testUrl    = document.getElementById('fc-base-url').value.trim();
    var testToken  = document.getElementById('fc-jsonpe-token').value.trim();

    if (!testKey || !testSecret) {
        return Swal.fire('Atención', 'Ingresa primero el API Key y API Secret', 'warning');
    }

    Swal.fire({
        title: 'Probando Conexión...',
        text: 'Conectando con la API de SUNAT...',
        allowOutsideClick: false,
        didOpen: function () { Swal.showLoading(); }
    });

    try {
        // Guardar en memoria y BD para que api.js use estas credenciales
        await App.saveConfig({
            base_url:     testUrl,
            api_key:      testKey,
            api_secret:   testSecret,
            jsonpe_token: testToken
        });

        // Llamar al endpoint de empresa
        var res = await App.api.getEmpresa();

        if (res.success || res.data) {
            window.facDatosEmpresa = res.data;
            facRenderEmpresaInfo();

            Swal.fire({
                icon: 'success',
                title: '¡Conexión Exitosa!',
                html: '<strong>' + (res.data.razon_social || 'Empresa') + '</strong><br>RUC: ' + (res.data.ruc || '-') + '<br>Entorno: ' + (res.data.entorno || 'beta'),
                confirmButtonColor: '#22c55e'
            });
        } else {
            Swal.fire('Atención', 'La API respondió pero con un formato inesperado.', 'warning');
        }
    } catch (e) {
        console.error('Error prueba conexión:', e);
        Swal.fire({
            icon: 'error',
            title: 'Error de Conexión',
            html: '<strong>' + (e.message || 'Error desconocido') + '</strong><br><small class="text-muted">Verifica que las credenciales sean correctas y que tengas conexión a internet.</small>'
        });
    }
};

// ================================================
// Cargar y Mostrar Info de Empresa
// ================================================
async function facCargarEmpresaInfo() {
    var container = document.getElementById('fc-empresa-info');
    if (!container) return;

    container.innerHTML = '<div class="text-center py-3"><div class="spinner-border spinner-border-sm text-primary"></div><p class="mt-2 small text-muted">Conectando con SUNAT...</p></div>';

    try {
        var res = await App.api.getEmpresa();
        if (res.success || res.data) {
            window.facDatosEmpresa = res.data;
            facRenderEmpresaInfo();
        } else {
            container.innerHTML = '<p class="text-warning small">No se pudo obtener los datos de la empresa.</p>';
        }
    } catch (e) {
        container.innerHTML = '<p class="text-danger small">' + e.message + '</p>';
    }
}

function facRenderEmpresaInfo() {
    var container = document.getElementById('fc-empresa-info');
    if (!container || !window.facDatosEmpresa) return;

    var e = window.facDatosEmpresa;
    var direccion = e.direccion || e.domicilio_fiscal || 'Dirección no registrada';
    var entorno = (e.entorno || 'beta').toLowerCase();
    var entornoBadge = entorno === 'produccion' ? 'bg-success' : 'bg-warning text-dark';

    container.innerHTML = ''
        + '<div class="mb-2"><strong>Razón Social:</strong><br><span class="text-dark">' + (e.razon_social || e.nombre || '-') + '</span></div>'
        + '<div class="mb-2"><strong>RUC:</strong> <span class="text-dark">' + (e.ruc || e.numero_documento || '-') + '</span></div>'
        + '<div class="mb-2"><strong>Dirección:</strong> <span class="text-dark small">' + direccion + '</span></div>'
        + '<div class="mb-2"><strong>Entorno:</strong> <span class="badge ' + entornoBadge + '">' + entorno.toUpperCase() + '</span></div>'
        + '<div class="mb-2"><strong>Plan:</strong> <span class="text-dark">' + (e.plan || '-') + '</span></div>'
        + '<hr>'
        + '<div class="small text-success d-flex align-items-center gap-1"><i data-lucide="check-circle-2" style="width:16px;height:16px;"></i> Conectado y listo para facturar.</div>';

    if (typeof lucide !== 'undefined') lucide.createIcons();
}
window.facRenderEmpresaInfo = facRenderEmpresaInfo;

// ================================================
// PANTALLA: Dashboard de Facturación
// ================================================
function facInitDashboard() {
    var stats = document.getElementById('fac-dash-stats');
    if (!stats || stats.dataset.loaded) return;
    stats.dataset.loaded = 'true';
    window.facDashLoad();
}

window.facDashLoad = async function () {
    var container = document.getElementById('fac-dash-stats');
    if (!container) return;
    container.innerHTML = '<div class="col-12 text-center py-5"><div class="spinner-border text-primary"></div></div>';

    try {
        var res = await App.api.panelIndicadores();
        var d = res.data || {};
        var boletas = d.boletas || {};
        var facturas = d.facturas || {};

        container.innerHTML = ''
            + '<div class="col-xl-3 col-md-6 mb-4"><div class="card border-left-success shadow h-100 py-2"><div class="card-body"><div class="row no-gutters align-items-center"><div class="col mr-2"><div class="text-xs font-weight-bold text-success text-uppercase mb-1">Boletas Emitidas</div><div class="h5 mb-0 font-weight-bold text-gray-800">' + (boletas.cantidad || 0) + '</div></div><div class="col-auto"><i data-lucide="file-text" class="text-gray-300" style="width:2rem;height:2rem;"></i></div></div></div></div></div>'
            + '<div class="col-xl-3 col-md-6 mb-4"><div class="card border-left-primary shadow h-100 py-2"><div class="card-body"><div class="row no-gutters align-items-center"><div class="col mr-2"><div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Facturas Emitidas</div><div class="h5 mb-0 font-weight-bold text-gray-800">' + (facturas.cantidad || 0) + '</div></div><div class="col-auto"><i data-lucide="briefcase" class="text-gray-300" style="width:2rem;height:2rem;"></i></div></div></div></div></div>'
            + '<div class="col-xl-3 col-md-6 mb-4"><div class="card border-left-info shadow h-100 py-2"><div class="card-body"><div class="row no-gutters align-items-center"><div class="col mr-2"><div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Boletas</div><div class="h5 mb-0 font-weight-bold text-gray-800">S/ ' + ((boletas.total || 0)).toFixed(2) + '</div></div><div class="col-auto"><i data-lucide="wallet" class="text-gray-300" style="width:2rem;height:2rem;"></i></div></div></div></div></div>'
            + '<div class="col-xl-3 col-md-6 mb-4"><div class="card border-left-warning shadow h-100 py-2"><div class="card-body"><div class="row no-gutters align-items-center"><div class="col mr-2"><div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Total Facturas</div><div class="h5 mb-0 font-weight-bold text-gray-800">S/ ' + ((facturas.total || 0)).toFixed(2) + '</div></div><div class="col-auto"><i data-lucide="trending-up" class="text-gray-300" style="width:2rem;height:2rem;"></i></div></div></div></div></div>';

        if (typeof lucide !== 'undefined') lucide.createIcons();
    } catch (e) {
        container.innerHTML = '<div class="col-12"><div class="alert alert-danger">Error al cargar indicadores: ' + e.message + '</div></div>';
    }
};

// ================================================
// PANTALLA: Lista de Documentos
// ================================================
function facInitLista() {
    var tbody = document.getElementById('fac-lista-tbody');
    if (!tbody || tbody.dataset.loaded) return;
    tbody.dataset.loaded = 'true';
    window.facCurrentPage = 1;
    window.facItemsPerPage = 10;
    window.facAllDocs = [];
    window.facFilteredDocs = [];
    window.facListLoad();
}

window.facListLoad = async function () {
    var tbody = document.getElementById('fac-lista-tbody');
    if (!tbody) return;

    tbody.innerHTML = '<tr><td colspan="12" class="text-center py-5"><div class="spinner-border text-primary"></div></td></tr>';

    try {
        var [resFac, resBol] = await Promise.all([
            App.api.listarFacturas(),
            App.api.listarBoletas()
        ]);
        
        var facturas = Array.isArray(resFac.data) ? resFac.data : ((resFac.data && resFac.data.datos) || resFac.data || []);
        var boletas = Array.isArray(resBol.data) ? resBol.data : ((resBol.data && resBol.data.datos) || resBol.data || []);
        
        if (!Array.isArray(facturas)) facturas = [];
        if (!Array.isArray(boletas)) boletas = [];
        
        facturas.forEach(f => f._tipo_doc = 'facturas');
        boletas.forEach(b => b._tipo_doc = 'boletas');
        
        window.facAllDocs = [...facturas, ...boletas];
        
        // Ordenar por fecha descendente
        window.facAllDocs.sort(function(a, b) {
            var dateA = new Date(a.fecha_emision || 0);
            var dateB = new Date(b.fecha_emision || 0);
            return dateB - dateA;
        });

        window.facFiltrarLista();
    } catch (e) {
        tbody.innerHTML = '<tr><td colspan="12" class="text-danger py-3 text-center">Error: ' + e.message + '</td></tr>';
    }
};

window.facFiltrarLista = function() {
    var estadoFilter = document.getElementById('fac-filtro-estado') ? document.getElementById('fac-filtro-estado').value.toLowerCase() : '';
    var textoFilter = document.getElementById('fac-filtro-texto') ? document.getElementById('fac-filtro-texto').value.toLowerCase() : '';
    var desdeFilter = document.getElementById('fac-filtro-desde') ? document.getElementById('fac-filtro-desde').value : '';
    var hastaFilter = document.getElementById('fac-filtro-hasta') ? document.getElementById('fac-filtro-hasta').value : '';

    window.facFilteredDocs = window.facAllDocs.filter(function(d) {
        var estado = ((d.sunat && d.sunat.estado) || d.sunat_status || d.estado_sunat || d.estado || 'pendiente').toLowerCase();
        if (estadoFilter && !estado.includes(estadoFilter)) return false;
        
        if (desdeFilter && d.fecha_emision) {
            if (d.fecha_emision.slice(0, 10) < desdeFilter) return false;
        }
        if (hastaFilter && d.fecha_emision) {
            if (d.fecha_emision.slice(0, 10) > hastaFilter) return false;
        }
        
        if (textoFilter) {
            var cliente = ((d.cliente && d.cliente.razon_social) || d.client_razon_social || (d.destinatario && d.destinatario.razon_social) || (d.cliente && d.cliente.rznSocial) || '').toLowerCase();
            var numero = (d.numero_completo || (d.serie + '-' + d.correlativo)).toLowerCase();
            if (!cliente.includes(textoFilter) && !numero.includes(textoFilter)) return false;
        }
        
        return true;
    });

    window.facCurrentPage = 1;
    window.facRenderTabla();
};

window.facChangeLimite = function() {
    var limite = document.getElementById('fac-filtro-limite');
    if (limite) {
        window.facItemsPerPage = parseInt(limite.value) || 10;
        window.facCurrentPage = 1;
        window.facRenderTabla();
    }
};

window.facPagPrev = function() {
    if (window.facCurrentPage > 1) {
        window.facCurrentPage--;
        window.facRenderTabla();
    }
};

window.facPagNext = function() {
    var totalPages = Math.ceil(window.facFilteredDocs.length / window.facItemsPerPage);
    if (window.facCurrentPage < totalPages) {
        window.facCurrentPage++;
        window.facRenderTabla();
    }
};

window.facRenderTabla = function() {
    var tbody = document.getElementById('fac-lista-tbody');
    var pagInfo = document.getElementById('fac-pag-info');
    var pagText = document.getElementById('fac-pag-text');
    if (!tbody) return;

    if (window.facFilteredDocs.length === 0) {
        tbody.innerHTML = '<tr><td colspan="12" class="text-center text-muted py-4">No se encontraron comprobantes</td></tr>';
        if (pagInfo) pagInfo.innerHTML = 'Mostrando 0-0 de 0 comprobantes';
        if (pagText) pagText.innerHTML = 'Página 1 de 1';
        return;
    }

    var totalItems = window.facFilteredDocs.length;
    var totalPages = Math.ceil(totalItems / window.facItemsPerPage);
    if (window.facCurrentPage > totalPages) window.facCurrentPage = totalPages;

    var startIdx = (window.facCurrentPage - 1) * window.facItemsPerPage;
    var endIdx = Math.min(startIdx + window.facItemsPerPage, totalItems);
    
    var docsToRender = window.facFilteredDocs.slice(startIdx, endIdx);

    tbody.innerHTML = docsToRender.map(function (d) {
        var fecha = (d.fecha_emision || '').slice(0, 10).split('-').reverse().join('/') || '-';
        var cliente = (d.cliente && d.cliente.razon_social) || d.client_razon_social || (d.destinatario && d.destinatario.razon_social) || (d.cliente && d.cliente.rznSocial) || 'Sin Cliente';
        var totalVal = (d.totales && d.totales.total != null) ? d.totales.total : (d.mto_imp_venta != null ? d.mto_imp_venta : (d.monto_total != null ? d.monto_total : d.total || 0));
        var total = parseFloat(totalVal).toFixed(2);
        var estado = (d.sunat && d.sunat.estado) || d.sunat_status || d.estado_sunat || d.estado || 'pendiente';
        
        var tipoLabel = d._tipo_doc === 'facturas' ? 'FACTURA' : 'BOLETA';
        var numero = d.numero_completo || (d.serie + '-' + d.correlativo);
        
        // Condicion de pago, estado de pago, saldo pendiente defaults
        var condPago = d.condicion_pago || 'Contado';
        var estadoPago = d.estado_pago || 'Pagado';
        var saldoPend = d.saldo_pendiente != null ? parseFloat(d.saldo_pendiente).toFixed(2) : '0.00';
        
        var condHtml = condPago.toLowerCase() === 'contado' 
            ? '<span class="badge-estado bg-success bg-opacity-10 text-success border border-success-subtle"><span class="badge-estado-punto bg-success"></span>' + condPago + '</span>'
            : '<span class="badge-estado bg-warning bg-opacity-10 text-warning border border-warning-subtle"><span class="badge-estado-punto bg-warning"></span>' + condPago + '</span>';
            
        var estPagoHtml = estadoPago.toLowerCase() === 'pagado'
            ? '<span class="badge-estado bg-success bg-opacity-10 text-success border border-success-subtle">' + estadoPago + '</span>'
            : '<span class="badge-estado bg-warning bg-opacity-10 text-warning border border-warning-subtle">' + estadoPago + '</span>';
            
        var badgeSunatClass = estado.toLowerCase() === 'aceptado' ? 'bg-success bg-opacity-10 text-success border border-success-subtle' : (estado.toLowerCase() === 'rechazado' ? 'bg-danger bg-opacity-10 text-danger border border-danger-subtle' : 'bg-warning bg-opacity-10 text-warning border border-warning-subtle');
        var badgeSunat = '<span class="badge-estado ' + badgeSunatClass + '">' + (estado.charAt(0).toUpperCase() + estado.slice(1).toLowerCase()) + '</span>';

        return '<tr>'
            + '<td class="text-muted" style="padding-left: 20px;">' + fecha + '</td>'
            + '<td><div class="text-muted" style="font-size: 0.7rem; font-weight: 600; letter-spacing: 0.5px;">' + tipoLabel + '</div><div class="fw-bold text-dark" style="font-size: 0.85rem;">' + numero + '</div></td>'
            + '<td class="text-muted" style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + cliente + '</td>'
            + '<td class="fw-bold text-dark">S/ ' + total + '</td>'
            + '<td class="text-center">' + condHtml + '</td>'
            + '<td class="text-center">' + badgeSunat + '</td>'
            + '<td class="text-center"><button class="btn btn-sm p-0" onclick="window.facViewDoc(\'' + d._tipo_doc + '\',' + d.id + ',\'' + numero + '\')" style="color: #ef4444; border: 1px solid #fca5a5; background: #fef2f2; border-radius: 6px; display: flex; align-items: center; justify-content: center; width: 24px; height: 24px; margin: 0 auto;" title="PDF"><i data-lucide="file-text" style="width:12px;height:12px;"></i></button></td>'
            + '<td class="text-center"><button class="btn btn-sm p-0" onclick="window.facViewXml(\'' + d._tipo_doc + '\',' + d.id + ',\'' + numero + '\')" style="color: #f97316; border: 1px solid #fdba74; background: #fff7ed; border-radius: 6px; display: flex; align-items: center; justify-content: center; width: 24px; height: 24px; margin: 0 auto;" title="XML"><i data-lucide="file-code" style="width:12px;height:12px;"></i></button></td>'
            + '<td class="text-center"><button class="btn btn-sm p-0" onclick="window.facViewCdr(\'' + d._tipo_doc + '\',' + d.id + ',\'' + numero + '\')" style="color: #475569; border: 1px solid #cbd5e1; background: #f8fafc; border-radius: 6px; display: flex; align-items: center; justify-content: center; width: 24px; height: 24px; margin: 0 auto;" title="CDR"><i data-lucide="file-check" style="width:12px;height:12px;"></i></button></td>'
            + '<td class="text-center">'
            + '  <div class="d-flex justify-content-center align-items-center" style="gap: 6px;">'
            + '    <button class="btn btn-sm p-0" style="color: #10b981; border: 1px solid #6ee7b7; background: #ecfdf5; border-radius: 6px; display:flex; align-items:center; justify-content: center; height: 24px; padding: 0 5px !important;" title="WhatsApp"><i data-lucide="message-circle" style="width:12px;height:12px;"></i><i data-lucide="chevron-down" style="width:10px;height:10px;margin-left:2px;"></i></button>'
            + '    <div class="dropdown">'
            + '      <button class="btn btn-sm btn-light p-0" type="button" data-bs-toggle="dropdown" aria-expanded="false" style="background: #f8fafc; border: 1px solid #cbd5e1 !important; border-radius: 6px; display: flex; align-items: center; justify-content: center; width: 24px; height: 24px;">'
            + '        <i data-lucide="more-vertical" style="width:12px;height:12px;color:#64748b;display:block;"></i>'
            + '      </button>'
            + '      <ul class="dropdown-menu dropdown-menu-end shadow-sm" style="border-radius: 8px; font-size: 0.85rem; border-color: #e2e8f0;">'
            + '        <li><a class="dropdown-item d-flex align-items-center py-2 text-danger fw-bold" href="#" onclick="event.preventDefault(); window.facAnularDoc(\'' + d._tipo_doc + '\',' + d.id + ')"><i data-lucide="ban" style="width:14px;height:14px;margin-right:8px;"></i> Anular Documento</a></li>'
            + '      </ul>'
            + '    </div>'
            + '  </div>'
            + '</td>'
            + '</tr>';
    }).join('');

    if (pagInfo) pagInfo.innerHTML = 'Mostrando ' + (startIdx + 1) + '-' + endIdx + ' de ' + totalItems + ' comprobantes';
    if (pagText) pagText.innerHTML = 'Página ' + window.facCurrentPage + ' de ' + totalPages;

    if (typeof lucide !== 'undefined') lucide.createIcons();
};

window.facViewDoc = async function (tipo, id, numero) {
    let titulo = tipo === 'facturas' ? 'FACTURA' : 'BOLETA';
    numero = numero || 'DOCUMENTO';

    Swal.fire({title: 'Cargando PDF...', allowOutsideClick: false, didOpen: () => { Swal.showLoading(); }});

    try {
        var blob = await App.api.descargarPdf(tipo, id, 'ticket-80');
        var pdfUrl = URL.createObjectURL(blob);
        
        Swal.fire({
            title: `<div style="font-size: 1.15rem; color: #1f2937; margin-bottom: -10px;">${titulo} - ${numero}</div>`,
            html: `
                <div style="height: 50vh; background: #525659; border-radius: 6px; padding: 4px; box-sizing: border-box; margin-bottom: 15px; margin-top: 15px;">
                     <iframe id="ticket-pdf-iframe" src="${pdfUrl}" style="width: 100%; height: 100%; border: none; border-radius: 4px; background: white;"></iframe>
                </div>
                <div style="display: flex; gap: 8px; justify-content: flex-start; align-items: center; border-top: 1px solid #e5e7eb; padding-top: 15px;">
                    <button id="btn-print-pdf" class="btn text-white" style="background-color: #f97316; border-color: #f97316; padding: 6px 14px; font-weight: 500; border-radius: 6px; font-size: 14px; display: flex; align-items: center; gap: 5px;">
                        <i data-lucide="printer" style="width:16px;height:16px;"></i> Imprimir
                    </button>
                    <button id="btn-download-pdf" class="btn btn-light border" style="padding: 6px 14px; font-weight: 500; border-radius: 6px; font-size: 14px; color: #4b5563; display: flex; align-items: center; gap: 5px;">
                        <i data-lucide="download" style="width:16px;height:16px;"></i> Descargar
                    </button>
                    <button id="btn-close-pdf" class="btn btn-light border" style="padding: 6px 14px; font-weight: 500; border-radius: 6px; font-size: 14px; color: #4b5563; margin-left: auto;">
                        Cerrar
                    </button>
                </div>
            `,
            width: 480,
            showConfirmButton: false,
            showCloseButton: false,
            padding: '1.25em',
            didOpen: () => { 
                if (typeof lucide !== 'undefined') lucide.createIcons(); 
                document.getElementById('btn-print-pdf').addEventListener('click', () => {
                    let iframe = document.getElementById('ticket-pdf-iframe');
                    if (iframe) { iframe.contentWindow.print(); }
                });
                document.getElementById('btn-download-pdf').addEventListener('click', () => {
                    let a = document.createElement('a');
                    a.href = pdfUrl;
                    a.download = numero + '.pdf';
                    a.click();
                });
                document.getElementById('btn-close-pdf').addEventListener('click', () => {
                    Swal.close();
                });
            }
        });
    } catch (e) {
        Swal.fire('Error', e.message, 'error');
    }
};

// ================================================
// INTEGRACIÓN CON CAJA / POS
// ================================================
window.facCurrentCustomer = null;

window.facBuscarCliente = async function (tipo_doc, numero) {
    if (!numero || numero.length < 8) return null;
    try {
        var res = await App.api.buscarDocumento(tipo_doc, numero);
        if (res && res.data) {
            window.facCurrentCustomer = res.data;
            return res.data;
        }
    } catch (e) {
        console.error('Error buscando cliente:', e);
        return null;
    }
    return null;
};

// Se llama después de que caja.php registra el pago exitosamente
window.facEmitirComprobante = async function (orden_id, items, tipo_comprobante, monto_total, clienteDoc, clienteNombre, clienteDireccion) {
    if (!App.isConfigured()) {
        console.warn('[Facturación] API no configurada, omitiendo emisión SUNAT.');
        await Swal.fire({
            title: 'API SUNAT no configurada',
            html: 'El cobro se registró <b>localmente</b> pero <b>NO se emitió comprobante electrónico</b>.<br>Configura tu API Key y API Secret en:<br><b>Facturación → Configuración API</b>',
            icon: 'warning',
            confirmButtonColor: '#f59e0b'
        });
        return false;
    }

    if (tipo_comprobante === 'ticket' || tipo_comprobante === 'nota_venta' || !tipo_comprobante) return false;

    var cDoc = clienteDoc || '';
    var cNom = clienteNombre || 'CLIENTES VARIOS';
    var cDir = clienteDireccion || '';
    
    // Determinar tipo_doc según reglas SUNAT (Catálogo 06)
    var tipoDocSunat = '0'; // Por defecto: "Sin documento"
    if (tipo_comprobante === 'factura') {
        tipoDocSunat = '6'; // RUC obligatorio
    } else {
        if (cDoc.length === 8) tipoDocSunat = '1'; // DNI
        else if (cDoc.length > 8 && cDoc.length !== 11) tipoDocSunat = '4'; // Carnet Extranjería
    }

    var cliente = {
        tipo_doc: tipoDocSunat,
        num_doc: cDoc || '00000000',
        razon_social: cNom,
        direccion: cDir
    };

    var payload = {
        serie: tipo_comprobante === 'factura' ? 'F001' : 'B001',
        fecha_emision: new Date().toISOString().slice(0, 10),
        forma_pago: 'Contado',
        tipo_moneda: 'PEN',
        cliente: cliente,
        items: items.map(function (item) {
            var precioUnit = parseFloat(item.precio) || 0;
            var cant = parseFloat(item.cantidad) || 1;
            return {
                codigo: String(item.id_subcategoria || item.id || '001'),
                unidad: 'NIU',
                descripcion: item.subcategoria_nombre || item.nombre || item.descripcion || 'Subcategoria',
                cantidad: cant,
                precio_unitario: precioUnit,
                tip_afe_igv: '10'
            };
        })
    };

    console.log('[Facturación] Enviando a SUNAT → tipo:', tipo_comprobante, '| items:', payload.items.length, '| total:', monto_total);

    try {
        Swal.fire({ title: 'Emitiendo a SUNAT...', html: 'Enviando ' + (tipo_comprobante === 'factura' ? 'Factura' : 'Boleta') + ' electrónica...', didOpen: function () { Swal.showLoading(); }, allowOutsideClick: false });

        var res;
        var tipo = 'boletas';
        var tipoCod = '03';
        if (tipo_comprobante === 'factura') {
            res = await App.api.crearFactura(payload);
            tipo = 'facturas';
            tipoCod = '01';
        } else {
            res = await App.api.crearBoleta(payload);
        }

        Swal.close();

        if (res.success && res.data) {
            try {
                await fetch('features/facturacion/controller_guardar_comprobante.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        order_id: orden_id,
                        tipo_comprobante: tipoCod,
                        serie: res.data.serie || payload.serie,
                        correlativo: res.data.correlativo || 0,
                        total: monto_total,
                        estado_sunat: res.data.estado_sunat || 'Registrado',
                        enlace_pdf: (res.data.links && res.data.links.pdf) || '',
                        enlace_xml: (res.data.links && res.data.links.xml) || ''
                    })
                });
            } catch (dbErr) {
                console.error('Error guardando comprobante en BD local:', dbErr);
            }

            var modalContainer = document.getElementById('fac-modal-container');
            if (!modalContainer) {
                modalContainer = document.createElement('div');
                modalContainer.id = 'fac-modal-container';
                document.body.appendChild(modalContainer);
            }
            var modal = new App.ResponseModal({ response: res, tipo: tipo, pdfFormat: 'ticket-80' });
            modal.render(modalContainer);
            return true;
        }
    } catch (e) {
        console.error('[Facturación] Error SUNAT:', e);
        var errorDetails = e.message || 'Sin conexión con el servidor de facturación';
        if (e.errors) {
            errorDetails += '<br><br><div style="text-align:left; font-size:11px; background:#fee2e2; padding:10px; border-radius:5px; color:#991b1b; white-space:pre-wrap;">' + JSON.stringify(e.errors, null, 2) + '</div>';
        }
        await Swal.fire({
            title: 'Error al emitir a SUNAT',
            html: '<b>El cobro SÍ se registró localmente</b>, pero la API rechazó la emisión.<br><br>' + errorDetails,
            icon: 'error',
            confirmButtonColor: '#ef4444'
        });
        return false;
    }
    return false;
};

window.facViewXml = async function (tipo, id, numero) {
    numero = numero || 'XML';
    Swal.fire({ title: 'Cargando XML...', didOpen: function () { Swal.showLoading(); } });
    try {
        var blob = await App.api.descargarXml(tipo, id);
        Swal.close();
        if (blob) {
            let url = window.URL.createObjectURL(blob);
            let a = document.createElement('a');
            a.href = url;
            a.download = numero + '.xml';
            document.body.appendChild(a);
            a.click();
            a.remove();
            setTimeout(() => window.URL.revokeObjectURL(url), 1000);
            Swal.fire('Éxito', 'El XML se ha descargado correctamente.', 'success');
        }
    } catch (e) {
        Swal.fire('Error', e.message || 'No se pudo obtener el XML', 'error');
    }
};

window.facViewCdr = async function (tipo, id, numero) {
    numero = numero || 'CDR';
    Swal.fire({ title: 'Cargando CDR...', didOpen: function () { Swal.showLoading(); } });
    try {
        var blob = await App.api.descargarCdr(tipo, id);
        Swal.close();
        if (blob) {
            let url = window.URL.createObjectURL(blob);
            let a = document.createElement('a');
            a.href = url;
            a.download = 'R-' + numero + '.zip';
            document.body.appendChild(a);
            a.click();
            a.remove();
            setTimeout(() => window.URL.revokeObjectURL(url), 1000);
            Swal.fire('Éxito', 'El CDR se ha descargado correctamente.', 'success');
        }
    } catch (e) {
        Swal.fire('Error', e.message || 'No se pudo obtener el CDR', 'error');
    }
};

window.facAnularDoc = async function (tipo, id) {
    const { value: motivo } = await Swal.fire({
        title: '¿Anular documento?',
        text: 'Esta acción comunicará la baja a SUNAT. Ingresa el motivo:',
        input: 'text',
        inputPlaceholder: 'Error en los datos del documento',
        showCancelButton: true,
        confirmButtonText: 'Sí, anular',
        cancelButtonText: 'Cancelar',
        inputValidator: (value) => {
            if (!value) return 'Debes ingresar un motivo';
        }
    });

    if (motivo) {
        Swal.fire({ title: 'Procesando anulación...', didOpen: function () { Swal.showLoading(); } });
        try {
            var hoy = new Date().toISOString().split('T')[0];
            
            if (tipo === 'boletas') {
                await App.api.crearResumen({
                    fecha_resumen: hoy,
                    anular: [{ id: id, motivo: motivo }]
                });
            } else {
                // Obtener datos de la factura primero para serie y correlativo
                var resFac = await App.api.verFactura(id);
                var doc = resFac.data || resFac;
                
                await App.api.crearAnulacion({
                    fecha_generacion: hoy,
                    fecha_comunicacion: hoy,
                    detalles: [{
                        tipo_documento: doc.tipo_documento || '01',
                        serie: doc.serie,
                        correlativo: doc.correlativo,
                        motivo: motivo
                    }]
                });
            }

            Swal.fire('¡Anulado!', 'El documento ha sido anulado correctamente en SUNAT.', 'success').then(() => {
                if (window.facListLoad) window.facListLoad();
            });
        } catch (e) {
            Swal.fire('Error', e.message || 'Error al anular el documento', 'error');
        }
    }
};

