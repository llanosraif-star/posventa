var App = window.App || (window.App = {});

(function () {
  // Configuración — se carga desde BD y se mantiene en memoria
  var currentConfig = null;
  var configLoaded = false;

  var DEFAULT_CONFIG = {
    base_url: 'https://apisunatv2.kodevo.es/api/v1',
    api_key: '',
    api_secret: '',
    jsonpe_token: '',
  };

  // Carga síncrona-first: intenta leer del sessionStorage como caché rápida
  try {
    var cached = sessionStorage.getItem('fac_config_cache');
    if (cached) currentConfig = JSON.parse(cached);
  } catch(e) {}

  // Carga asíncrona desde el servidor (BD)
  App.loadConfig = async function () {
    try {
      var res = await fetch('features/facturacion/controller_config.php');
      var data = await res.json();
      if (data.status === 'ok' && data.config) {
        currentConfig = data.config;
        // Cachear en sessionStorage para que getConfig() funcione inmediatamente en recargas
        try { sessionStorage.setItem('fac_config_cache', JSON.stringify(currentConfig)); } catch(e){}
      } else {
        currentConfig = Object.assign({}, DEFAULT_CONFIG);
      }
    } catch (e) {
      console.error('Error cargando config de facturación', e);
      if (!currentConfig) currentConfig = Object.assign({}, DEFAULT_CONFIG);
    }
    configLoaded = true;
    return currentConfig;
  };

  // Retorna la config actual (síncrono) — siempre tiene algo gracias al caché
  App.getConfig = function () {
    return currentConfig || Object.assign({}, DEFAULT_CONFIG);
  };

  // Actualiza la config en memoria inmediatamente Y la guarda en BD
  App.saveConfig = async function (config) {
    // Actualizar en memoria INMEDIATAMENTE (antes del fetch)
    currentConfig = Object.assign({}, config);
    try { sessionStorage.setItem('fac_config_cache', JSON.stringify(currentConfig)); } catch(e){}

    try {
      var res = await fetch('features/facturacion/controller_config.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config)
      });
      var data = await res.json();
      if (data.status !== 'ok') {
        throw new Error(data.message || 'Error al guardar');
      }
      return true;
    } catch (e) {
      console.error('Error guardando config de facturación', e);
      throw e;
    }
  };

  App.isConfigured = function () {
    var c = App.getConfig();
    return Boolean(c.api_key && c.api_secret);
  };

  // Esperar a que la config esté cargada desde BD (siempre hace fetch si aún no cargó)
  App.waitForConfig = function () {
    if (configLoaded) return Promise.resolve(currentConfig);
    return App.loadConfig();
  };
})();

