<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No autenticado']);
    exit;
}

$db = Database::getInstance()->getConnection();
$stmt = $db->query("SELECT api_key, api_secret, sunat_base_url FROM empresa LIMIT 1");
$config = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$config || empty($config['api_key'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'API no configurada en la BD local']);
    exit;
}

$endpoint = $_GET['path'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];

$url = rtrim($config['sunat_base_url'], '/') . '/' . ltrim($endpoint, '/');

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);

$headers = [
    'Accept: application/json',
    'X-Api-Key: ' . trim($config['api_key']),
    'X-Api-Secret: ' . trim($config['api_secret'])
];

if ($method === 'POST' || $method === 'PUT' || $method === 'PATCH') {
    $body = file_get_contents('php://input');
    curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    $headers[] = 'Content-Type: application/json';
}

curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

// Desactivar validación estricta SSL para entornos de desarrollo locales
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

$response = curl_exec($ch);
$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$content_type = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
$error = curl_error($ch);
curl_close($ch);

http_response_code($httpcode);

if ($error) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => false, 'message' => 'Error CURL proxy: ' . $error]);
} else {
    // Retornar exactamente el Content-Type que respondió la API original (ej: application/pdf)
    if ($content_type) {
        header('Content-Type: ' . $content_type);
    }
    echo $response;
}
