<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../config/database.php';

// Verificación de autenticación
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'No autenticado']);
    exit;
}

$db = Database::getInstance()->getConnection();
$method = $_SERVER['REQUEST_METHOD'];

try {
    if ($method === 'POST') {
        $data = json_decode(file_get_contents('php://input'), true);
        
        $order_id = intval($data['order_id'] ?? 0);
        $tipo_comprobante = $data['tipo_comprobante'] ?? ''; // '01' o '03'
        $serie = $data['serie'] ?? '';
        $correlativo = intval($data['correlativo'] ?? 0);
        $total = floatval($data['total'] ?? 0);
        $estado_sunat = $data['estado_sunat'] ?? 'Registrado';
        $enlace_pdf = $data['enlace_pdf'] ?? '';
        $enlace_xml = $data['enlace_xml'] ?? '';

        if ($order_id === 0 || empty($tipo_comprobante) || empty($serie)) {
            echo json_encode(['status' => 'error', 'message' => 'Datos insuficientes']);
            exit;
        }

        $stmt = $db->prepare("INSERT INTO comprobantes (order_id, tipo_comprobante, serie, correlativo, total, estado_sunat, enlace_pdf, enlace_xml) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$order_id, $tipo_comprobante, $serie, $correlativo, $total, $estado_sunat, $enlace_pdf, $enlace_xml]);

        echo json_encode(['status' => 'ok', 'message' => 'Comprobante guardado en la base de datos', 'id' => $db->lastInsertId()]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Método no soportado']);
    }
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}

