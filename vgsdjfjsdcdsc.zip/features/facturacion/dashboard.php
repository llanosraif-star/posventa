<div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="mb-0 text-gray-800" style="font-size: 24px; font-weight: 600;"><i data-lucide="bar-chart-2" style="width:24px;height:24px;margin-right:8px;color:inherit;stroke-width:2.7;"></i>Dashboard Facturación</h1>
                <button class="btn btn-sm btn-primary" onclick="window.facDashLoad()"><i data-lucide="refresh-cw" class="lucide-btn"></i> Actualizar</button>
            </div>
            <div class="row" id="fac-dash-stats">
                <div class="col-12 text-center py-5"><div class="spinner-border text-primary" role="status"></div></div>
            </div>
<script>
if (typeof facInitDashboard === 'function') {
    facInitDashboard();
}
</script>