<!--begin::App Content Header-->
<div class="app-content-header py-3">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-sm-6">
                <h4 class="mb-1 text-dark" style="font-weight: 700; font-size: 1.25rem; font-family: 'Inter', sans-serif;">
                    Comprobantes electrónicos
                </h4>
                <p class="text-muted mb-0" style="font-size: 0.85rem;">Facturas y boletas de venta.</p>
            </div>
            <div class="col-sm-6 d-flex justify-content-end" style="gap: 8px;">
                <button class="btn btn-sm shadow-sm px-3 fw-bold" style="background: #334155; color: white; border-radius: 8px; font-size: 0.8rem;">
                    Facturas y boletas
                </button>
                <button class="btn btn-sm bg-white border shadow-sm px-3 fw-bold text-muted" style="border-radius: 8px; font-size: 0.8rem;">
                    <i data-lucide="file-edit" style="width:14px;height:14px;margin-right:4px;"></i> Notas de crédito
                </button>
                <button class="btn btn-sm bg-white border shadow-sm px-3 fw-bold text-muted" style="border-radius: 8px; font-size: 0.8rem;">
                    <i data-lucide="file-minus" style="width:14px;height:14px;margin-right:4px;"></i> Resúmenes y bajas
                </button>
                <button class="btn btn-sm bg-white border shadow-sm px-3 fw-bold text-muted" onclick="window.facListLoad()" style="border-radius: 8px; font-size: 0.8rem;">
                    <i data-lucide="refresh-cw" style="width:14px;height:14px;margin-right:4px;"></i> Actualizar
                </button>
            </div>
        </div>
    </div>
</div>
<!--end::App Content Header-->

<style>
    .table-fac th {
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: #64748b;
        font-weight: 700;
        border-bottom: none;
        background-color: #f1f5f9;
        padding-top: 12px;
        padding-bottom: 12px;
    }
    .table-fac td {
        vertical-align: middle;
        font-size: 0.85rem;
        border-bottom: 1px solid #f1f5f9;
        padding-top: 14px;
        padding-bottom: 14px;
    }
    .table-fac tr:hover {
        background-color: #f8fafc;
    }
    .badge-estado {
        border-radius: 20px;
        padding: 4px 10px;
        font-weight: 600;
        font-size: 0.72rem;
        display: inline-flex;
        align-items: center;
        gap: 4px;
    }
    .badge-estado-punto {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        display: inline-block;
    }
</style>

<div class="container-fluid mb-4">
    <!-- Contenedor Principal (Blanco, bordes sutiles) -->
    <div class="bg-white" style="border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.02);">
        
        <!-- Barra de Filtros -->
        <div class="p-3 d-flex flex-wrap align-items-center justify-content-between" style="border-bottom: 1px solid #e2e8f0; gap: 15px;">
            <div class="d-flex flex-wrap align-items-center" style="gap: 10px; flex: 1;">
                <select id="fac-filtro-estado" class="form-select form-select-sm border-secondary-subtle" style="width: 150px; border-radius: 8px; font-size: 0.85rem; color: #475569; height: 34px;" onchange="window.facFiltrarLista()">
                    <option value="">Todos los estados</option>
                    <option value="Aceptado">Aceptado</option>
                    <option value="Pendiente">Pendiente</option>
                    <option value="Rechazado">Rechazado</option>
                </select>
                
                <div class="position-relative" style="flex: 1; min-width: 250px; max-width: 400px;">
                    <i data-lucide="search" class="position-absolute" style="left:10px; top:50%; transform:translateY(-50%); width:14px; height:14px; color:#94a3b8;"></i>
                    <input type="text" id="fac-filtro-texto" class="form-control form-control-sm border-secondary-subtle" placeholder="Buscar por cliente, serie o número..." style="padding-left: 30px; border-radius: 8px; font-size: 0.85rem; height: 34px;" onkeyup="window.facFiltrarLista()">
                </div>
            </div>
            
            <div class="d-flex flex-wrap align-items-center" style="gap: 10px;">
                <input type="date" id="fac-filtro-desde" class="form-control form-control-sm border-secondary-subtle" style="width: 130px; border-radius: 8px; font-size: 0.85rem; color: #475569; height: 34px;" onchange="window.facFiltrarLista()">
                <input type="date" id="fac-filtro-hasta" class="form-control form-control-sm border-secondary-subtle" style="width: 130px; border-radius: 8px; font-size: 0.85rem; color: #475569; height: 34px;" onchange="window.facFiltrarLista()">
                
                <div class="d-flex align-items-center" style="font-size: 0.85rem; color: #64748b; gap: 6px;">
                    Mostrar
                    <select id="fac-filtro-limite" class="form-select form-select-sm border-secondary-subtle" style="width: 70px; border-radius: 8px; font-size: 0.85rem; padding-right: 20px; height: 34px;" onchange="window.facChangeLimite()">
                        <option value="10">10</option>
                        <option value="25">25</option>
                        <option value="50">50</option>
                    </select>
                    por página
                </div>
            </div>
        </div>
        
        <!-- Tabla -->
        <div class="table-responsive">
            <table class="table table-fac mb-0">
                <thead>
                    <tr>
                        <th class="fw-bold text-dark" style="padding-left: 20px; font-weight: 800 !important; color: #0f172a !important;">FECHA</th>
                        <th class="fw-bold text-dark" style="font-weight: 800 !important; color: #0f172a !important;">COMPROBANTE</th>
                        <th class="fw-bold text-dark" style="font-weight: 800 !important; color: #0f172a !important;">CLIENTE</th>
                        <th class="fw-bold text-dark" style="font-weight: 800 !important; color: #0f172a !important;">TOTAL</th>
                        <th class="text-center fw-bold text-dark" style="font-weight: 800 !important; color: #0f172a !important;">CONDICIÓN DE PAGO</th>
                        <th class="text-center fw-bold text-dark" style="font-weight: 800 !important; color: #0f172a !important;">ESTADO SUNAT</th>
                        <th class="text-center fw-bold text-dark" style="font-weight: 800 !important; color: #0f172a !important;">PDF</th>
                        <th class="text-center fw-bold text-dark" style="font-weight: 800 !important; color: #0f172a !important;">XML</th>
                        <th class="text-center fw-bold text-dark" style="font-weight: 800 !important; color: #0f172a !important;">CDR</th>
                        <th class="text-center fw-bold text-dark" style="font-weight: 800 !important; color: #0f172a !important;">ACCIONES</th>
                    </tr>
                </thead>
                <tbody id="fac-lista-tbody">
                    <tr><td colspan="10" class="text-center py-5 text-muted"><div class="spinner-border text-primary spinner-border-sm me-2"></div> Cargando...</td></tr>
                </tbody>
            </table>
        </div>
        
        <!-- Paginación Footer -->
        <div class="p-3 d-flex justify-content-between align-items-center" style="border-top: 1px solid #e2e8f0;">
            <div id="fac-pag-info" class="text-muted" style="font-size: 0.85rem;">
                Mostrando 0-0 de 0 comprobantes
            </div>
            <div class="d-flex" style="gap: 4px;">
                <button class="btn btn-sm bg-white border text-muted" onclick="window.facPagPrev()" style="border-radius: 8px; font-size: 0.8rem; padding: 4px 12px;">Anterior</button>
                <div id="fac-pag-text" class="btn btn-sm bg-white border text-dark fw-bold" style="border-radius: 8px; font-size: 0.8rem; padding: 4px 12px; pointer-events: none;">Página 1 de 1</div>
                <button class="btn btn-sm bg-white border text-muted" onclick="window.facPagNext()" style="border-radius: 8px; font-size: 0.8rem; padding: 4px 12px;">Siguiente</button>
            </div>
        </div>
        
    </div>
</div>

<div id="fac-modal-container"></div>
<script>
if (typeof facInitLista === 'function') {
    facInitLista();
}
</script>
