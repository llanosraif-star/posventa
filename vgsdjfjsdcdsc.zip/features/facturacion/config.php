<!--begin::App Content Header-->
<div class="app-content-header">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-sm-8">
                <h4 class="mb-0 d-flex align-items-center text-dark" style="font-weight: 600; font-size: 22px;">
                    <i data-lucide="settings" style="width:22px;height:22px;margin-right:8px; color: #475569;"></i> Configuración Facturación (API)
                </h4>
                <p class="text-muted mb-0 d-none d-sm-block mt-1" style="font-size: 0.85rem; margin-left: 30px;">Administra tus credenciales y accesos al sistema de facturación electrónica.</p>
            </div>
        </div>
    </div>
</div>
<!--end::App Content Header-->
            
            <div class="row">
                <!-- Columna Izquierda: Formulario API -->
                <div class="col-lg-8">
                    <div class="card mb-4" style="border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.03) !important; border: 1px solid #e2e8f0;">
                        <div class="card-header py-3 d-flex flex-column" style="border-radius: 12px 12px 0 0; background-color: #fff; border-bottom: 1px solid #f1f5f9;">
                            <h6 class="m-0 font-weight-bold d-flex align-items-center text-dark" style="font-size: 1rem;"><i data-lucide="key" style="width:18px;height:18px;margin-right:8px;color:#0ea5e9;"></i>Credenciales de API</h6>
                            <span style="font-size: 0.75rem; color: #64748b; margin-top: 2px;">Ingresa las claves de tu proveedor o SUNAT</span>
                        </div>
                        <div class="card-body" style="padding: 1.25rem;">
                            <form id="form-facturacion-config">
                                <div class="p-3 bg-light mb-3" style="border-radius: 12px; border: 1px solid #e2e8f0;">
                                    <h6 class="fw-bold text-dark mb-3 d-flex align-items-center" style="font-size: 0.95rem;">
                                        <i data-lucide="server" class="me-2" style="width:16px;height:16px;color:#64748b;"></i>Entorno de Facturación
                                    </h6>
                                    <div class="mb-3">
                                        <label class="small fw-bold text-secondary mb-1">URL Base de la API SUNAT</label>
                                        <div class="input-group input-group-sm">
                                            <span class="input-group-text bg-white" style="border-radius: 8px 0 0 8px; border-color: #cbd5e1;"><i data-lucide="link" style="width:14px;height:14px;color:#94a3b8;"></i></span>
                                            <input type="url" class="form-control" id="fc-base-url" placeholder="https://api.ejemplo.com/v1" required style="border-radius: 0 8px 8px 0; border-color: #cbd5e1; box-shadow: none;">
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3 mb-md-0">
                                                <label class="small fw-bold text-secondary mb-1">X-API-Key</label>
                                                <input type="text" class="form-control form-control-sm" id="fc-api-key" placeholder="Ingresa tu API Key" required style="border-radius: 8px; border-color: #cbd5e1; padding: 10px 15px;">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-0">
                                                <label class="small fw-bold text-secondary mb-1">X-API-Secret</label>
                                                <div class="input-group input-group-sm">
                                                    <input type="password" class="form-control" id="fc-api-secret" placeholder="••••••••••••" required style="border-radius: 8px 0 0 8px; border-color: #cbd5e1; padding: 10px 15px;">
                                                    <button class="btn btn-outline-secondary bg-white" type="button" style="border-radius: 0 8px 8px 0; border-color: #cbd5e1; padding-left: 10px; padding-right: 10px;" onclick="var inp=document.getElementById('fc-api-secret');if(inp.type==='password'){inp.type='text';this.innerHTML='<i data-lucide=&quot;eye-off&quot; style=&quot;width:14px;height:14px;color:#94a3b8;&quot;></i>';} else {inp.type='password';this.innerHTML='<i data-lucide=&quot;eye&quot; style=&quot;width:14px;height:14px;color:#94a3b8;&quot;></i>';}lucide.createIcons();">
                                                        <i data-lucide="eye" style="width:14px;height:14px;color:#94a3b8;"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <hr class="my-3" style="border-color: #f1f5f9;">
                                
                                <div class="mb-0">
                                    <label class="small fw-bold text-secondary d-flex align-items-center mb-1">
                                        Token de API api.json.pe (Consulta DNI/RUC)
                                        <span class="badge bg-success ms-2 px-2 py-1" style="border-radius: 6px; font-weight: 600; font-size: 0.65rem;">Opcional</span>
                                    </label>
                                    <div class="input-group input-group-sm">
                                        <span class="input-group-text bg-white" style="border-radius: 8px 0 0 8px; border-color: #cbd5e1;"><i data-lucide="search" style="width:14px;height:14px;color:#94a3b8;"></i></span>
                                        <input type="password" class="form-control" id="fc-jsonpe-token" placeholder="Token para consultas externas" style="border-radius: 0 8px 8px 0; border-color: #cbd5e1; box-shadow: none;">
                                    </div>
                                    <small class="form-text text-muted mt-1 d-flex align-items-center" style="font-size: 0.75rem;"><i data-lucide="info" style="width:12px;height:12px;margin-right:4px;color:#3b82f6;"></i>Útil para autocompletar clientes desde su DNI/RUC.</small>
                                </div>
                                
                                <div class="d-flex justify-content-center mt-4 pt-3 border-top gap-3">
                                    <button type="button" class="btn btn-sm btn-light border fw-bold px-4 py-2 shadow-sm" onclick="window.facProbarConexion()" style="border-radius: 8px; color: #475569; background-color: #f8fafc;">
                                        <i data-lucide="wifi" style="width:16px;height:16px;color:#0ea5e9;margin-right:6px;"></i> Probar Conexión
                                    </button>
                                    <button type="submit" class="btn btn-sm btn-primary fw-bold px-4 py-2 shadow" style="border-radius: 8px; background: linear-gradient(135deg, #0ea5e9, #0284c7); border: none;">
                                        <i data-lucide="save" style="width:16px;height:16px;margin-right:6px;"></i> Guardar Configuración
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <!-- Columna Derecha: Información de Empresa -->
                <div class="col-lg-4">
                    <div class="card mb-4" style="border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.03) !important; border: 1px solid #e2e8f0;">
                        <div class="card-header py-3 d-flex flex-column" style="border-radius: 12px 12px 0 0; background-color: #fff; border-bottom: 1px solid #f1f5f9;">
                            <h6 class="m-0 font-weight-bold d-flex align-items-center text-dark" style="font-size: 1rem;"><i data-lucide="building-2" style="width:18px;height:18px;margin-right:8px;color:#16a34a;"></i>Empresa Activa</h6>
                            <span style="font-size: 0.75rem; color: #64748b; margin-top: 2px;">Datos vinculados a tu API</span>
                        </div>
                        <div class="card-body d-flex flex-column" style="padding: 1.25rem;" id="fc-empresa-info">
                            <!-- Estado Vacío por Defecto -->
                            <div class="text-center p-3 my-auto bg-white rounded shadow-sm border" style="border-color: #e2e8f0 !important; border-radius: 12px !important;">
                                <div class="mb-2 d-inline-flex align-items-center justify-content-center" style="width: 54px; height: 54px; border-radius: 50%; background-color: #f1f5f9;">
                                    <i data-lucide="shield-alert" style="width:28px;height:28px;color:#94a3b8;"></i>
                                </div>
                                <h6 class="font-weight-bold text-gray-700" style="font-size: 0.95rem;">No hay datos verificados</h6>
                                <p class="text-muted small mb-3" style="line-height: 1.4; font-size: 0.8rem;">Presiona "Probar Conexión" para sincronizar y cargar los datos de la empresa configurada.</p>
                                <button class="btn btn-sm btn-outline-primary" onclick="window.facProbarConexion()" style="border-radius: 20px; font-weight: 600; padding: 4px 16px; border-width: 1.5px; font-size: 0.8rem;">
                                    Verificar ahora
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Tarjeta Adicional de Estado de Certificado -->
                    <div class="card mb-4" style="border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.03) !important; border: 1px solid #e2e8f0; background-color: #fff;">
                        <div class="card-body d-flex align-items-center p-3">
                            <div class="mr-3 p-2 rounded-circle" style="background-color: #fef9c3; display: flex; align-items: center; justify-content: center; width: 40px; height: 40px;">
                                <i data-lucide="file-check-2" style="width:20px;height:20px;color:#ca8a04;"></i>
                            </div>
                            <div class="flex-grow-1">
                                <h6 class="mb-0 font-weight-bold text-dark" style="font-size: 0.95rem;">Certificado Digital</h6>
                                <small class="text-muted" style="font-size: 0.8rem;">Gestionado por el proveedor</small>
                            </div>
                            <div>
                                <span class="badge px-2 py-1" style="background-color: #fef08a; color: #854d0e; border-radius: 6px; font-weight: 600;">Automático</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<script>
if (typeof facInitConfigScreen === 'function') {
    facInitConfigScreen();
}
</script>