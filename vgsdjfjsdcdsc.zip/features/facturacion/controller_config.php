<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../config/database.php';

// Verificación de autenticación — si no hay sesión, devolver config vacía (no bloquear)
$authenticated = isset($_SESSION['user_id']);

$db = Database::getInstance()->getConnection();
$method = $_SERVER['REQUEST_METHOD'];

try {
    if ($method === 'GET') {
        $stmt = $db->query("SELECT api_key, api_secret, sunat_base_url as base_url, jsonpe_token FROM empresa LIMIT 1");
        $config = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$config) {
            $config = [
                'api_key' => '',
                'api_secret' => '',
                'base_url' => 'https://apisunatv2.kodevo.es/api/v1',
                'jsonpe_token' => ''
            ];
        }
        // Asegurar que base_url nunca esté vacío
        if (empty($config['base_url'])) {
            $config['base_url'] = 'https://apisunatv2.kodevo.es/api/v1';
        }
        echo json_encode(['status' => 'ok', 'config' => $config]);
    } 
    elseif ($method === 'POST') {
        if (!$authenticated) {
            echo json_encode(['status' => 'error', 'message' => 'No autenticado']);
            exit;
        }

        // Solo admins pueden guardar configuración
        $rol = $_SESSION['user_rol'] ?? 'mesero';
        if ($rol !== 'admin') {
            echo json_encode(['status' => 'error', 'message' => 'Permiso denegado. Solo administradores pueden guardar configuración.']);
            exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        
        $apiKey = trim($data['api_key'] ?? '');
        $apiSecret = trim($data['api_secret'] ?? '');
        $baseUrl = trim($data['base_url'] ?? 'https://apisunatv2.kodevo.es/api/v1');
        $jsonpeToken = trim($data['jsonpe_token'] ?? '');

        // Verificar que la tabla empresa tenga las columnas necesarias
        try {
            $stmt = $db->prepare("UPDATE empresa SET api_key = ?, api_secret = ?, sunat_base_url = ?, jsonpe_token = ?");
            $stmt->execute([$apiKey, $apiSecret, $baseUrl, $jsonpeToken]);
        } catch (PDOException $e) {
            // Si la columna no existe, intentar agregarla
            if (strpos($e->getMessage(), 'Unknown column') !== false) {
                $columns = [
                    'api_key' => 'VARCHAR(255) DEFAULT NULL',
                    'api_secret' => 'VARCHAR(255) DEFAULT NULL',
                    'sunat_base_url' => "VARCHAR(255) DEFAULT 'https://apisunatv2.kodevo.es/api/v1'",
                    'jsonpe_token' => 'VARCHAR(255) DEFAULT NULL'
                ];
                foreach ($columns as $col => $type) {
                    try { $db->exec("ALTER TABLE empresa ADD COLUMN $col $type"); } catch (Exception $ex) {}
                }
                // Reintentar
                $stmt = $db->prepare("UPDATE empresa SET api_key = ?, api_secret = ?, sunat_base_url = ?, jsonpe_token = ?");
                $stmt->execute([$apiKey, $apiSecret, $baseUrl, $jsonpeToken]);
            } else {
                throw $e;
            }
        }

        echo json_encode(['status' => 'ok', 'message' => 'Configuración guardada correctamente']);
    }
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}

