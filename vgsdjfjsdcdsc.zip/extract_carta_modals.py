import os
import re

def extract_functions(file_path, function_names):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    extracted = []
    
    for func_name in function_names:
        # Regex to find `function Name(` or `async function Name(`
        # We need a robust brace matcher to get the entire function body.
        pattern = r"(?:async\s+)?function\s+" + func_name + r"\s*\("
        match = re.search(pattern, content)
        if match:
            start_idx = match.start()
            # Find the opening brace
            brace_idx = content.find('{', start_idx)
            if brace_idx != -1:
                open_braces = 1
                curr_idx = brace_idx + 1
                while open_braces > 0 and curr_idx < len(content):
                    if content[curr_idx] == '{':
                        open_braces += 1
                    elif content[curr_idx] == '}':
                        open_braces -= 1
                    curr_idx += 1
                
                func_content = content[start_idx:curr_idx]
                extracted.append(func_content)
                
                # Replace with empty string (or spaces to preserve lines, but here we can just replace with empty string and we will write the rest)
                content = content[:start_idx] + content[curr_idx:]
    
    return "\n\n".join(extracted), content

def main():
    carta_path = r'd:\GOODY\laragon\www\Puntodeventa\features\carta\carta.js'
    
    # 1. Productos
    prod_funcs = [
        'modalNuevoProducto', 'alertaEditarProducto', 
        'modalNuevaProducto', 'modalNuevaProductoGlobalContextual'
    ]
    prod_content, carta_content = extract_functions(carta_path, prod_funcs)
    
    # 2. Categorias
    cat_funcs = [
        'modalNuevaCategoria', 'alertaEditarCategoria'
    ]
    cat_content, carta_content = extract_functions(carta_path, cat_funcs)
    
    # 3. Subcategorias
    subcat_funcs = [
        'modalNuevoGrupo', 'alertaEditarGrupo', 'alertaEditarSubcategoria', 'modalNuevoSubcategoriaContextual'
    ]
    subcat_content, carta_content = extract_functions(carta_path, subcat_funcs)
    
    # 4. Modificadores
    mod_funcs = [
        'modalNuevoModificador', 'alertaEditarModificador'
    ]
    mod_content, carta_content = extract_functions(carta_path, mod_funcs)
    
    # Write files
    base_dir = r'd:\GOODY\laragon\www\Puntodeventa\features\carta'
    
    if prod_content.strip():
        with open(os.path.join(base_dir, 'modal_productos.js'), 'w', encoding='utf-8') as f:
            f.write(prod_content)
            
    if cat_content.strip():
        with open(os.path.join(base_dir, 'modal_categorias.js'), 'w', encoding='utf-8') as f:
            f.write(cat_content)
            
    if subcat_content.strip():
        with open(os.path.join(base_dir, 'modal_subcategorias.js'), 'w', encoding='utf-8') as f:
            f.write(subcat_content)
            
    if mod_content.strip():
        with open(os.path.join(base_dir, 'modal_modificadores.js'), 'w', encoding='utf-8') as f:
            f.write(mod_content)
            
    # Clean up multiple empty lines in carta.js
    carta_content = re.sub(r'\n\s*\n', '\n\n', carta_content)
            
    with open(carta_path, 'w', encoding='utf-8') as f:
        f.write(carta_content)

if __name__ == '__main__':
    main()
