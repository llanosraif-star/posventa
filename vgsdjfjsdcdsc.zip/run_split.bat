@echo off
C:\laragon\bin\php\php-8.1.10\php.exe extract_carta.php
if %errorlevel% neq 0 (
    php extract_carta.php
)
echo Proceso finalizado.
pause
