const CACHE_NAME = 'mirestaurante-v2';
const urlsToCache = [
  './manifest.json',
  './css/adminlte.css',
  './assets/vendor/css/dm-sans.css',
  './assets/vendor/css/bootstrap.min.css',
  './assets/vendor/css/bootstrap-icons.min.css',
  './assets/vendor/js/bootstrap.min.js',
  './assets/vendor/js/jquery-3.7.1.min.js'
];

// Install Event
self.addEventListener('install', event => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Cache opened');
        return cache.addAll(urlsToCache);
      })
  );
});

// Fetch Event
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Cache hit - return response
        if (response) {
          return response;
        }
        return fetch(event.request);
      })
  );
});

// Activate Event (Cleanup old caches)
self.addEventListener('activate', event => {
  self.clients.claim();
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});
