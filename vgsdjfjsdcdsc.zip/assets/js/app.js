$(document).ready(function() {
    const $mainContent = $('#main-content');

    // Escuchar cambios en el Hash (cuando el usuario navega, usa Atrás/Adelante, o refresca la página)
    $(window).on('hashchange', function() {
        // Extraer el hash limpiando el '#'
        let hash = window.location.hash.replace('#', '');
        
        // Si no hay hash (ej: localhost/Puntodeventa/), ir al dashboard por defecto
        if (!hash) {
            hash = 'dashboard';
            window.location.hash = hash;
            return; // Esperar al siguiente evento hashchange
        }

        // Determinar la ruta física del archivo según el hash
        let path = '';
        if (hash.includes('/')) {
            // Ejemplo: facturacion/lista -> features/facturacion/lista.php
            path = 'features/' + hash + '.php';
        } else {
            // Ejemplo: clientes -> features/clientes/clientes.php
            path = 'features/' + hash + '/' + hash + '.php';
        }

        cargarModulo(path);
        actualizarMenuActivo(hash);
    });

    function cargarModulo(url) {
        // Mostrar estado de carga visual
        $mainContent.html('<div class="text-center mt-5"><div class="spinner-border text-primary" role="status"></div><p class="mt-2">Cargando módulo...</p></div>');

        // Cargar el HTML asíncronamente
        $mainContent.load(url, function(response, status, xhr) {
            if (status == "error") {
                const msg = "Error HTTP " + xhr.status + ": " + xhr.statusText;
                $mainContent.html(`<div class="alert alert-danger">
                    <h4><i class="bi bi-exclamation-triangle"></i> Error al cargar módulo</h4>
                    <p>No se encontró la ruta: <strong>${url}</strong></p>
                    <hr>
                    <p class="mb-0 text-muted">${msg}</p>
                </div>`);
                
                if (typeof Swal !== 'undefined') {
                    Swal.fire('Error', 'No se pudo cargar el módulo. Verifica la consola.', 'error');
                }
            }
        });
    }

    function actualizarMenuActivo(hash) {
        $('.ajax-link').removeClass('active');
        $(`.ajax-link[href="#${hash}"]`).addClass('active');
    }

    // Inicializar SPA al cargar la página (lanza un hashchange artificial)
    $(window).trigger('hashchange');
});

// Función global en caso de que algún botón viejo use onclick="navegarA('clientes')"
window.navegarA = function(modulo) {
    if (!modulo) return;
    window.location.hash = modulo;
};
