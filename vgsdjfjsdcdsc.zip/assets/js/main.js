/**
 * main.js - Configuraciones globales e inicialización
 * Estado global de la aplicación, enrutador de datos y funciones CRUD compartidas
 */

window.datosApp = {
    usuarios: [],
    zonas: [],
    mesas: [],
    impresoras: [],
    areas_produccion: []
};

// Estado del usuario en sesión (RBAC)
window.userRol = 'mesero';
window.userId = null;
window.userNombre = 'Usuario';

// Cargar rol del usuario desde la sesión del backend
async function cargarRolUsuario() {
    try {
        let res = await fetch('api/caja.php?action=get_rol');
        let data = await res.json();
        if (data.status === 'ok') {
            window.userRol = data.rol || 'mesero';
            window.userId = data.user_id;
            window.userNombre = data.user_nombre || 'Usuario';
        }
    } catch(e) { console.warn('No se pudo cargar rol de usuario'); }
}

function cargarDatos(pagina) {
    if (pagina === 'empresa') {
        cargarEmpresa();
    } else if (pagina === 'usuarios') {
        cargarUsuarios();
    } else if (pagina === 'mesas' || pagina === 'impresoras') {
        cargarMesasImpresoras();
    } else if (pagina === 'areas_produccion') {
        cargarAreasProduccion();
    } else if (pagina === 'carta') {
        cargarCarta();
    } else if (pagina === 'pos') {
        cargarPOS();
    } else if (pagina === 'caja') {
        cargarCaja();
    } else if (pagina === 'clientes') {
        cargarClientes();
    } else if (pagina === 'facturacion_config') {
        if (typeof facInitConfigScreen === 'function') facInitConfigScreen();
    } else if (pagina === 'facturacion_dashboard') {
        if (typeof facInitDashboard === 'function') facInitDashboard();
    } else if (pagina === 'facturacion_lista') {
        if (typeof facInitLista === 'function') facInitLista();
    }
}

// ==========================================
// MOSTRAR ALERTA GLOBAL (Toast)
// ==========================================
window.mostrarAlerta = function(icon, title) {
    Swal.fire({
        toast: true,
        position: 'top-end',
        icon: icon,
        title: title,
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true
    });
};

// ==========================================
// FUNCIONES GLOBALES CRUD (Eliminar)
// ==========================================
function alertaEliminar(id, tipo) {
    Swal.fire({
        title: '\u00bfEliminar registro #' + id + '?',
        text: 'Esta acci\u00f3n no se puede revertir',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#e74a3b',
        cancelButtonColor: '#858796',
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar'
    }).then(async (r) => {
        if (r.isConfirmed) {
            let url = '';
            if (tipo === 'usuarios') url = 'features/configuracion/controller_usuarios.php?action=eliminar';
            else if (['categorias', 'productos', 'modificadores', 'presentaciones'].includes(tipo)) url = 'features/carta/controller_carta.php?tipo=' + tipo + '&action=eliminar';
            else if (tipo === 'areas_produccion') url = 'features/mesas/controller_areas_produccion.php?action=eliminar';
            else url = 'features/mesas/controller_mesas.php?tipo=' + tipo + '&action=eliminar';

            try {
                const res = await fetch(url, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: id })
                });
                const result = await res.json();
                if (result.status === 'ok') {
                    mostrarAlerta('success', 'Registro eliminado');
                    if (tipo === 'usuarios') cargarUsuarios();
                    else if (['categorias', 'productos', 'modificadores', 'presentaciones'].includes(tipo)) cargarCarta();
                    else if (tipo === 'areas_produccion') cargarAreasProduccion();
                    else cargarMesasImpresoras();
                } else {
                    mostrarAlerta('error', result.message || 'Error al eliminar');
                }
            } catch(e) {
                mostrarAlerta('error', 'Error de conexi\u00f3n');
            }
        }
    });
}

// ==========================================
// FUNCION GLOBAL EDITAR (Dispatcher)
// ==========================================
function alertaEditar(id, tipo) {
    let item = window.datosApp[tipo].find(x => x.id == id);
    if (!item) return mostrarAlerta('error', 'No se encontr\u00f3 el registro');

    if (tipo === 'usuarios') {
        editarUsuario(id, item);
    } else if (tipo === 'areas_produccion') {
        editarAreaProduccion(id, item);
    } else if (tipo === 'zonas') {
        editarZona(id, item);
    } else if (tipo === 'mesas') {
        editarMesa(id, item);
    } else if (tipo === 'impresoras') {
        editarImpresora(id, item);
    }
}
