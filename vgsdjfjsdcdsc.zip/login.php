<?php
session_start();
// Si ya hay sesión, redirigir según el rol
if (isset($_SESSION['user_id'])) {
    if (isset($_SESSION['user_rol']) && strtolower($_SESSION['user_rol']) === 'cocinero') {
        header("Location: kds.php");
    } else {
        header("Location: index.php");
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#1a2538">
    <title>Inicia Sesión | Mi Restaurante</title>
    
    <!-- PWA Tags -->
    <link rel="manifest" href="./manifest.json" />
    <meta name="theme-color" content="#22c55e" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    <link rel="apple-touch-icon" href="./assets/img/AdminLTELogo.png" />

    <!-- Fonts -->
    <link href="./assets/vendor/css/dm-sans.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="./assets/vendor/css/bootstrap-icons.min.css">
    <!-- SweetAlert2 -->
    <link rel="stylesheet" href="./assets/vendor/css/sweetalert2.min.css" />

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        }

        body {
            display: flex;
            min-height: 100vh;
            background-color: #f9fafb; /* Fondo muy claro para el panel derecho si es necesario */
        }

        /* --- Left Panel --- */
        .left-panel {
            width: 50%;
            background-color: #1a2538; /* Navy dark background */
            color: #ffffff;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding: 40px 60px;
            position: relative;
        }

        .left-content-wrapper {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        /* Logo Area */
        .brand-header {
            margin-bottom: auto;
        }

        .brand-logo-container {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 4px;
        }

        .brand-icon-box {
            background-color: #22c55e; /* Green brand color */
            border-radius: 8px;
            width: 38px;
            height: 38px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ffffff;
            font-size: 18px;
        }
        
        .brand-text-main {
            font-size: 22px;
            font-weight: 700;
            letter-spacing: -0.5px;
            color: #ffffff;
        }

        .brand-subtitle {
            font-size: 9px;
            letter-spacing: 1px;
            color: rgba(255, 255, 255, 0.5);
            text-transform: uppercase;
            margin-left: 50px; /* Alineado al texto principal */
            margin-top: -6px;
        }

        /* Hero Text */
        .hero-title {
            font-size: 40px;
            font-weight: 700;
            line-height: 1.15;
            margin-bottom: 20px;
            max-width: 90%;
            letter-spacing: -1px;
        }

        .hero-subtitle {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.7);
            max-width: 420px;
            line-height: 1.5;
            margin-bottom: 60px;
        }

        /* Cards */
        .feature-cards-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 16px;
        }

        .feature-card {
            background: #233045; /* Slightly lighter navy for cards */
            border-radius: 12px;
            padding: 16px;
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }

        .feature-card-icon {
            width: 28px;
            height: 28px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 12px;
            font-size: 14px;
        }

        /* Colores de íconos en tarjetas */
        .icon-green { background: rgba(34, 197, 94, 0.15); color: #22c55e; }
        .icon-blue { background: rgba(59, 130, 246, 0.15); color: #3b82f6; }
        .icon-orange { background: rgba(245, 158, 11, 0.15); color: #f59e0b; }

        .feature-card h3 {
            font-size: 12px;
            font-weight: 700;
            margin-bottom: 4px;
            color: #ffffff;
        }

        .feature-card p {
            font-size: 10px;
            color: rgba(255, 255, 255, 0.5);
            line-height: 1.4;
        }

        .left-footer {
            font-size: 11px;
            color: rgba(255, 255, 255, 0.4);
            margin-top: auto;
        }

        /* --- Right Panel --- */
        .right-panel {
            width: 50%;
            background-color: #ffffff;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px;
            background: radial-gradient(circle at center, #ffffff 0%, #f4f6fa 100%);
        }

        .login-wrapper {
            width: 100%;
            max-width: 400px;
        }

        .login-title {
            font-size: 28px;
            font-weight: 700;
            color: #111827;
            margin-bottom: 8px;
            letter-spacing: -0.5px;
        }

        .login-subtitle {
            font-size: 13px;
            color: #6B7280;
            margin-bottom: 32px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            font-size: 11px;
            font-weight: 500;
            color: #6B7280;
            margin-bottom: 8px;
        }

        .input-container {
            position: relative;
            display: flex;
            align-items: center;
        }

        .input-icon-left {
            position: absolute;
            left: 14px;
            color: #9CA3AF;
            font-size: 16px;
        }

        .input-icon-right {
            position: absolute;
            right: 14px;
            color: #9CA3AF;
            font-size: 16px;
            cursor: pointer;
            background: none;
            border: none;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .form-input {
            width: 100%;
            padding: 12px 14px 12px 40px;
            font-size: 14px;
            border-radius: 8px;
            border: 1px solid #E5E7EB;
            outline: none;
            transition: all 0.2s;
            color: #111827;
            background-color: #ffffff;
        }

        .form-input[type="password"], .form-input.pwd-text {
            padding-right: 40px;
        }

        /* Focus state similar to image (green border) */
        .form-input:focus {
            border-color: #22c55e;
            box-shadow: 0 0 0 3px rgba(34, 197, 94, 0.1);
        }

        /* Checkbox and Link row */
        .form-options {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 16px;
            margin-bottom: 24px;
        }

        .checkbox-container {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            color: #6B7280;
            cursor: pointer;
        }
        
        .checkbox-container input {
            accent-color: #22c55e;
            width: 14px;
            height: 14px;
            cursor: pointer;
        }

        .forgot-link {
            font-size: 12px;
            color: #22c55e;
            text-decoration: none;
            font-weight: 500;
        }

        .forgot-link:hover {
            text-decoration: underline;
        }

        .btn-submit {
            width: 100%;
            padding: 14px;
            background-color: #1a2538;
            color: #ffffff;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: background-color 0.2s;
        }

        .btn-submit:hover {
            background-color: #111827;
        }

        .btn-submit:disabled {
            background-color: #9CA3AF;
            cursor: not-allowed;
        }

        .right-footer {
            text-align: center;
            font-size: 11px;
            color: #9CA3AF;
            margin-top: 40px;
        }

        /* Responsive */
        @media (max-width: 991px) {
            .left-panel {
                display: none;
            }
            .right-panel {
                width: 100%;
            }
        }
    </style>
</head>
<body>

    <!-- Left Panel -->
    <div class="left-panel">
        <div class="brand-header">
            <div class="brand-logo-container">
                <div class="brand-icon-box">
                    <i class="bi bi-shop"></i> <!-- Using shop icon as alternative to fork/knife for restaurant -->
                </div>
                <div class="brand-text-main">Mi Restaurante</div>
            </div>
            <div class="brand-subtitle">PANEL DE GESTIÓN</div>
        </div>

        <div class="left-content-wrapper">
            <h1 class="hero-title">
                Gestiona tu restaurante de forma más eficiente
            </h1>
            <p class="hero-subtitle">
                Ingresa al panel de tu restaurante para gestionar mesas, comandas, inventario y boletas electrónicas desde un solo lugar.
            </p>

            <!-- Cards -->
            <div class="feature-cards-container">
                <div class="feature-card">
                    <div class="feature-card-icon icon-green">
                        <i class="bi bi-grid"></i>
                    </div>
                    <h3>Mesas y comandas</h3>
                    <p>Toma pedidos y envíalos a cocina al instante</p>
                </div>
                <div class="feature-card">
                    <div class="feature-card-icon icon-blue">
                        <i class="bi bi-box-seam"></i>
                    </div>
                    <h3>Caja e inventario</h3>
                    <p>Stock, insumos y ventas en un solo kardex</p>
                </div>
                <div class="feature-card">
                    <div class="feature-card-icon icon-orange">
                        <i class="bi bi-receipt"></i>
                    </div>
                    <h3>Boletas SUNAT</h3>
                    <p>Emisión electrónica sin salir del panel</p>
                </div>
            </div>
        </div>

        <div class="left-footer">
            Mi Restaurante — Gestión y facturación electrónica
        </div>
    </div>

    <!-- Right Panel -->
    <div class="right-panel">
        <div class="login-wrapper">
            <h2 class="login-title">Bienvenido 👋</h2>
            <p class="login-subtitle">Ingresa tus credenciales para acceder al sistema</p>

            <form id="loginForm" method="POST" action="" novalidate>
                <div class="form-group">
                    <label class="form-label" for="email">Correo electrónico</label>
                    <div class="input-container">
                        <i class="bi bi-envelope input-icon-left"></i>
                        <input type="email" id="email" name="email" class="form-input" placeholder="demo@gmail.com" autocomplete="username" required autofocus>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="password">Contraseña</label>
                    <div class="input-container">
                        <i class="bi bi-lock input-icon-left"></i>
                        <input type="password" id="password" name="password" class="form-input" placeholder="••••••••" autocomplete="current-password" required>
                        <button type="button" class="input-icon-right" id="togglePassword" tabindex="-1">
                            <i class="bi bi-eye"></i>
                        </button>
                    </div>
                </div>

                <div class="form-options">
                    <label class="checkbox-container">
                        <input type="checkbox" id="rememberMe">
                        Recordarme
                    </label>
                    <a href="#" class="forgot-link">¿Olvidaste tu contraseña?</a>
                </div>

                <button type="submit" class="btn-submit" id="btnSubmit">
                    Entrar al panel <i class="bi bi-arrow-right"></i>
                </button>
            </form>

            <div class="right-footer">
                &copy; <?= date('Y') ?> Mi Restaurante — Todos los derechos reservados
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="./assets/vendor/js/sweetalert2.all.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Toggle Password
            const toggleBtn = document.getElementById('togglePassword');
            const passwordInput = document.getElementById('password');
            
            toggleBtn.addEventListener('click', () => {
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                
                if(type === 'text') {
                    passwordInput.classList.add('pwd-text');
                } else {
                    passwordInput.classList.remove('pwd-text');
                }

                const icon = toggleBtn.querySelector('i');
                icon.className = type === 'password' ? 'bi bi-eye' : 'bi bi-eye-slash';
            });

            // Handle Login Form
            const loginForm = document.getElementById('loginForm');
            const btnSubmit = document.getElementById('btnSubmit');

            loginForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const email = document.getElementById('email').value.trim();
                const pass = document.getElementById('password').value;

                if (!email || !pass) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Campos incompletos',
                        text: 'Por favor, ingrese correo y contraseña.',
                        confirmButtonColor: '#1a2538'
                    });
                    return;
                }

                const originalText = btnSubmit.innerHTML;
                btnSubmit.disabled = true;
                btnSubmit.innerHTML = 'Verificando...';

                try {
                    const response = await fetch('features/auth/controller_auth.php?action=login', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ email: email, password: pass })
                    });
                    
                    const data = await response.json();

                    if (data.status === 'ok') {
                        let timerInterval;
                        Swal.fire({
                            title: "¡Iniciando sesión!",
                            html: "Preparando tu panel en <b></b> milisegundos...",
                            timer: 1500,
                            timerProgressBar: true,
                            allowOutsideClick: false,
                            didOpen: () => {
                                Swal.showLoading();
                                const timer = Swal.getPopup().querySelector("b");
                                timerInterval = setInterval(() => {
                                    timer.textContent = `${Swal.getTimerLeft()}`;
                                }, 100);
                            },
                            willClose: () => {
                                clearInterval(timerInterval);
                            }
                        }).then(() => {
                            // Enviar el formulario de forma nativa para forzar al navegador a preguntar si desea guardar la contraseña
                            HTMLFormElement.prototype.submit.call(loginForm);
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error de autenticación',
                            text: data.message || 'Credenciales incorrectas.',
                            confirmButtonColor: '#1a2538'
                        });
                        btnSubmit.disabled = false;
                        btnSubmit.innerHTML = originalText;
                    }
                } catch (error) {
                    console.error('Error:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error de conexión',
                        text: 'No se pudo comunicar con el servidor.',
                        confirmButtonColor: '#1a2538'
                    });
                    btnSubmit.disabled = false;
                    btnSubmit.innerHTML = originalText;
                }
            });
        });

        // PWA Service Worker Registration
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('./sw.js')
                    .then(registration => console.log('ServiceWorker registrado con éxito'))
                    .catch(err => console.log('Error al registrar ServiceWorker: ', err));
            });
        }
    </script>
</body>
</html>
