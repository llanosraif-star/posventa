<?php
class Conexion {
    public static function conectar() {
        // Credenciales por defecto para entornos locales como Laragon
        $host = "localhost";
        $dbname = "bd_mirestaurante";
        $user = "root"; 
        $password = ""; 

        try {
            // Usamos PDO por su seguridad y soporte para consultas preparadas
            $link = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password);
            
            // Configurar PDO para que reporte todos los errores
            $link->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // Configurar para que devuelva arreglos asociativos por defecto
            $link->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

            return $link;
            
        } catch (PDOException $e) {
            // Si falla, detenemos la ejecución y mostramos el error
            die(json_encode([
                "status" => "error",
                "message" => "Error de conexión a la Base de Datos: " . $e->getMessage()
            ]));
        }
    }
}
?>
