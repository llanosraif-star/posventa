<?php
class Database {
    private static $instance = null;
    private $connection;

    private $host = "localhost";
    private $dbname = "bd_mirestaurante";
    private $user = "root";
    private $password = "";

    // Constructor privado para el patrón Singleton
    private function __construct() {
        try {
            $this->connection = new PDO(
                "mysql:host={$this->host};dbname={$this->dbname};charset=utf8", 
                $this->user, 
                $this->password,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            );
        } catch(PDOException $e) {
            die(json_encode([
                "status" => "error",
                "message" => "Error de conexión a la Base de Datos bd_mirestaurante: " . $e->getMessage()
            ]));
        }
    }

    // Prevenir la clonación del objeto
    private function __clone() {}

    // Prevenir la deserialización
    public function __wakeup() {}

    // Método principal del Singleton
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    // Método para obtener la conexión PDO real
    public function getConnection() {
        return $this->connection;
    }
}
?>
