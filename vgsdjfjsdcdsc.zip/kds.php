<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#0f172a">
    <title>KDS - Kitchen Display System</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="./css/adminlte.css" />
    <link href="./assets/vendor/css/dm-sans.css" rel="stylesheet">
    <link rel="stylesheet" href="./assets/vendor/css/sweetalert2.min.css" />
    <link rel="manifest" href="./manifest_kds.json?v=2" />
    
    <style>
        body {
            font-family: 'DM Sans', sans-serif !important;
            background-color: #0f172a; /* Dark theme for kitchen */
            color: #f8fafc;
            overflow-x: hidden;
        }
        
        /* Header */
        .kds-header {
            background-color: #1e293b;
            border-bottom: 1px solid #334155;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
        }

        .kds-title {
            font-size: 1.5rem;
            font-weight: 700;
            margin: 0;
            color: #38bdf8;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .station-name {
            background-color: #334155;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9rem;
            color: #cbd5e1;
            font-weight: 500;
        }

        /* Grid */
        .kds-grid {
            padding: 20px;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            align-items: flex-start;
        }

        /* Order Card */
        .kds-card {
            background-color: #1e293b;
            border-radius: 12px;
            border: 1px solid #334155;
            box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1);
            overflow: hidden;
            animation: fadeIn 0.3s ease-in-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .kds-card-header {
            padding: 12px 15px;
            border-bottom: 1px solid #334155;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }
        
        .kds-card-header.urgent {
            background-color: #7f1d1d; /* Reddish for urgent */
            border-bottom-color: #991b1b;
        }

        .order-number {
            font-size: 1.25rem;
            font-weight: 700;
            color: #f8fafc;
            margin-bottom: 2px;
        }
        
        .order-meta {
            font-size: 0.8rem;
            color: #94a3b8;
        }

        .order-timer {
            font-size: 1.1rem;
            font-weight: 600;
            background: #0f172a;
            padding: 4px 10px;
            border-radius: 6px;
            color: #22d3ee;
        }
        
        .order-timer.urgent { color: #fca5a5; background: rgba(0,0,0,0.2); }

        /* Items */
        .kds-item {
            padding: 12px 15px;
            border-bottom: 1px solid #334155;
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        .kds-item:last-child { border-bottom: none; }
        
        .kds-item:hover { background-color: #334155; }
        
        .kds-item.listo {
            opacity: 0.5;
            text-decoration: line-through;
            background-color: #064e3b; /* Greenish */
        }
        
        .item-qty {
            font-weight: 700;
            color: #38bdf8;
            background: rgba(56, 189, 248, 0.1);
            padding: 2px 8px;
            border-radius: 4px;
            margin-right: 10px;
        }

        .item-name {
            font-size: 1.1rem;
            font-weight: 500;
            color: #e2e8f0;
        }
        
        .item-notes {
            font-size: 0.85rem;
            color: #fca5a5;
            margin-top: 4px;
            font-style: italic;
        }
        
        .empty-state {
            text-align: center;
            padding: 100px 20px;
            color: #475569;
        }
    </style>
</head>
<body>

    <div class="kds-header">
        <h1 class="kds-title">
            <i data-lucide="chef-hat"></i> KDS 
            <span class="station-name" id="displayStationName">Cargando estación...</span>
        </h1>
        <div class="d-flex gap-3 align-items-center">
            <button class="btn btn-outline-light btn-sm" onclick="cambiarEstacion()"><i data-lucide="settings" style="width:16px;"></i> Cambiar Estación</button>
            <a href="index.php" class="btn btn-outline-danger btn-sm"><i data-lucide="log-out" style="width:16px;"></i> Salir</a>
        </div>
    </div>

    <div class="kds-grid" id="kds-container">
        <div class="empty-state w-100" style="grid-column: 1 / -1;">
            <i data-lucide="loader" class="fa-spin" style="width: 48px; height: 48px; color: #475569;"></i>
            <h4 class="mt-3">Sincronizando con el servidor...</h4>
        </div>
    </div>

    <!-- Scripts -->
    <script src="./assets/vendor/js/jquery-3.7.1.min.js"></script>
    <script src="./assets/vendor/js/sweetalert2.all.min.js"></script>
    <script src="./assets/vendor/js/lucide.min.js"></script>
    
    <script>
        lucide.createIcons();
        
        // Verificar si se pasa por URL (Lanzamiento directo desde admin)
        let urlParams = new URLSearchParams(window.location.search);
        if (urlParams.has('area') && urlParams.has('name')) {
            localStorage.setItem('kds_area_id', urlParams.get('area'));
            localStorage.setItem('kds_area_name', urlParams.get('name'));
            // Limpiar URL
            window.history.replaceState({}, document.title, window.location.pathname);
        }

        let kdsAreaId = localStorage.getItem('kds_area_id');
        let kdsAreaName = localStorage.getItem('kds_area_name');
        let autoRefresh;

        $(document).ready(function() {
            if (!kdsAreaId) {
                pedirEstacion();
            } else {
                iniciarKDS();
            }
        });

        async function pedirEstacion() {
            try {
                let res = await fetch('features/kds/controller_kds.php?action=pantallas_activas');
                let data = await res.json();
                
                if (data.status === 'ok' && data.data.length > 0) {
                    let options = {};
                    data.data.forEach(p => {
                        options[p.id_areaproduccion] = p.nombre;
                    });
                    
                    Swal.fire({
                        title: 'Configurar Tablet KDS',
                        text: 'Selecciona la estación de producción para esta pantalla',
                        input: 'select',
                        inputOptions: options,
                        inputPlaceholder: 'Seleccione un área',
                        showCancelButton: false,
                        allowOutsideClick: false,
                        confirmButtonText: 'Iniciar Estación'
                    }).then((result) => {
                        if (result.value) {
                            kdsAreaId = result.value;
                            kdsAreaName = options[result.value];
                            localStorage.setItem('kds_area_id', kdsAreaId);
                            localStorage.setItem('kds_area_name', kdsAreaName);
                            iniciarKDS();
                        }
                    });
                } else {
                    Swal.fire('Error', 'No hay pantallas KDS configuradas en el sistema. Contacte al administrador.', 'error');
                }
            } catch (e) {
                Swal.fire('Error', 'Error de conexión con el servidor', 'error');
            }
        }

        function cambiarEstacion() {
            localStorage.removeItem('kds_area_id');
            localStorage.removeItem('kds_area_name');
            clearInterval(autoRefresh);
            pedirEstacion();
        }

        function iniciarKDS() {
            document.getElementById('displayStationName').innerText = kdsAreaName;
            cargarPedidos();
            // Refresco cada 5 segundos
            autoRefresh = setInterval(cargarPedidos, 5000);
        }

        async function cargarPedidos() {
            try {
                let res = await fetch('features/kds/controller_kds.php?action=pedidos&id_areaproduccion=' + kdsAreaId);
                let data = await res.json();
                
                if (data.status === 'ok') {
                    renderizarPedidos(data.data);
                }
            } catch(e) {
                console.error("Error al refrescar KDS", e);
            }
        }

        function renderizarPedidos(pedidos) {
            const container = document.getElementById('kds-container');
            if (pedidos.length === 0) {
                container.innerHTML = `
                <div class="empty-state w-100" style="grid-column: 1 / -1;">
                    <i data-lucide="check-circle" style="width: 64px; height: 64px; color: #10b981;"></i>
                    <h3 class="mt-3 text-light">¡Buen trabajo!</h3>
                    <p>No hay pedidos pendientes en esta estación.</p>
                </div>`;
                lucide.createIcons();
                return;
            }

            let html = '';
            pedidos.forEach(p => {
                let esUrgente = p.minutos_transcurridos >= 15; // 15 minutos en rojo
                let urgentClass = esUrgente ? 'urgent' : '';
                let timerDisplay = p.minutos_transcurridos + ' min';
                
                let tipoLabel = p.tipo_codigo === 'salon' ? 'Mesa ' + (p.nombre_mesa||'') : (p.tipo_pedido||'Delivery');
                let clienteLabel = p.cliente_nombre ? ' - ' + p.cliente_nombre : '';

                html += `
                <div class="kds-card">
                    <div class="kds-card-header ${urgentClass}">
                        <div>
                            <div class="order-number">${p.numero_pedido}</div>
                            <div class="order-meta">${tipoLabel}${clienteLabel}</div>
                        </div>
                        <div class="order-timer ${urgentClass}">
                            <i data-lucide="clock" style="width:14px;height:14px;"></i> ${timerDisplay}
                        </div>
                    </div>
                    <div class="kds-card-body">
                `;
                
                p.items.forEach(item => {
                    let btnClass = item.estado_kds === 'listo' ? 'listo' : '';
                    let notasHtml = item.notas ? `<div class="item-notes"><i data-lucide="alert-circle" style="width:12px;height:12px;"></i> ${item.notas}</div>` : '';
                    
                    html += `
                        <div class="kds-item ${btnClass}" onclick="marcarItem(${item.kds_id}, '${item.estado_kds}')">
                            <div class="w-100">
                                <div class="d-flex align-items-center">
                                    <span class="item-qty">${item.quantity}x</span>
                                    <span class="item-name">${item.nombre_item}</span>
                                </div>
                                ${notasHtml}
                            </div>
                        </div>
                    `;
                });
                
                html += `
                    </div>
                </div>`;
            });
            
            // Only update DOM if HTML changed to avoid flicker
            if(container.innerHTML !== html) {
                container.innerHTML = html;
                lucide.createIcons();
            }
        }

        async function marcarItem(kds_id, currentStatus) {
            if (currentStatus === 'listo') return; // Ya está tachado
            
            try {
                let res = await fetch('features/kds/controller_kds.php?action=actualizar_estado', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ kds_id: kds_id, estado: 'listo' })
                });
                let data = await res.json();
                if (data.status === 'ok') {
                    // Refrescar inmediatamente para quitarlo de pantalla si era el último
                    cargarPedidos();
                }
            } catch(e) {
                console.error("Error al actualizar item", e);
            }
        }
    </script>
</body>
</html>
